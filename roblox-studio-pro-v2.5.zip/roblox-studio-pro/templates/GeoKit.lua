--!nonstrict
-- GeoKit — sinh hình học bằng code: lathe / loft / sweep / ellipsoid-surface / Fibonacci.
-- Phần "dữ liệu" (Data) là toán thuần: chạy và test được bằng luau CLI ngoài Studio.
-- Phần "dựng" (Build) cần Roblox: Tube (Part, chạy mọi nơi) và ToEditableMesh (Edit mode / Command Bar).

local GeoKit = {}

-- ===== Đường cong =====
function GeoKit.Bezier3(p0, p1, p2, p3, t)
	local u = 1 - t
	return p0 * (u * u * u) + p1 * (3 * u * u * t) + p2 * (3 * u * t * t) + p3 * (t * t * t)
end

-- Catmull-Rom qua các điểm (đi QUA điểm điều khiển — tiện cho thân/đuôi/cành).
function GeoKit.CatmullRom(pts, samplesPerSeg)
	local out = {}
	local n = #pts
	local sps = samplesPerSeg or 8
	for i = 1, n - 1 do
		local p0 = pts[math.max(i - 1, 1)]
		local p1, p2 = pts[i], pts[i + 1]
		local p3 = pts[math.min(i + 2, n)]
		for s = 0, sps - (i == n - 1 and 0 or 1) do
			local t = s / sps
			local t2, t3 = t * t, t * t * t
			out[#out + 1] = 0.5 * ((2 * p1) + (p2 - p0) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 + (3 * p1 - p0 - 3 * p2 + p3) * t3)
		end
	end
	return out
end

-- Fibonacci sphere: i = 0..count-1 → hướng đơn vị phân bố đều.
function GeoKit.Fibonacci(count)
	local golden = math.pi * (3 - math.sqrt(5))
	local dirs = {}
	for i = 0, count - 1 do
		local y = 1 - 2 * (i + 0.5) / count
		local r = math.sqrt(math.max(0, 1 - y * y))
		local th = golden * i
		dirs[#dirs + 1] = Vector3.new(math.cos(th) * r, y, math.sin(th) * r)
	end
	return dirs
end

-- Điểm + pháp tuyến trên ellipsoid bán trục a,b,c theo hướng d (từ tâm). Dùng đặt mắt/gai/vảy.
function GeoKit.EllipsoidSurface(a, b, c, d)
	d = d.Unit
	local k = math.sqrt((d.X / a) ^ 2 + (d.Y / b) ^ 2 + (d.Z / c) ^ 2)
	local P = d / k
	local n = Vector3.new(P.X / (a * a), P.Y / (b * b), P.Z / (c * c)).Unit
	return P, n
end

-- Sai số bề mặt: |(x/a)²+(y/b)²+(z/c)² − 1|; > 0.05 stud là sai (xem assets.md).
function GeoKit.EllipsoidError(a, b, c, p)
	return math.abs((p.X / a) ^ 2 + (p.Y / b) ^ 2 + (p.Z / c) ^ 2 - 1)
end

-- ===== Dữ liệu mesh (toán thuần) =====
-- Data = { verts = {Vector3}, tris = {{i,j,k}}, normals = {Vector3} }

-- Lathe: quay profile (list {r, y}) quanh trục Y, `sides` cạnh. Cho bình, cột, chai, thân tên lửa, mũ.
function GeoKit.Lathe(profile, sides)
	sides = math.max(3, sides or 16)
	local verts, tris = {}, {}
	for pi, pt in ipairs(profile) do
		for s = 0, sides - 1 do
			local th = (s / sides) * 2 * math.pi
			verts[#verts + 1] = Vector3.new(math.cos(th) * pt[1], pt[2], math.sin(th) * pt[1])
		end
	end
	for pi = 1, #profile - 1 do
		for s = 0, sides - 1 do
			local a = (pi - 1) * sides + s + 1
			local b = (pi - 1) * sides + (s + 1) % sides + 1
			local c = pi * sides + s + 1
			local d = pi * sides + (s + 1) % sides + 1
			tris[#tris + 1] = { a, c, b }
			tris[#tris + 1] = { b, c, d }
		end
	end
	return GeoKit._finish(verts, tris)
end

-- Loft: danh sách mặt cắt (mỗi mặt cắt = list Vector3 cùng số điểm, đóng vòng) nối thành bề mặt.
-- Cho thân tàu, cánh, thân thú: mỗi "rib" là một elip có kích thước khác nhau dọc thân.
function GeoKit.Loft(sections)
	local m = #sections[1]
	local verts, tris = {}, {}
	for _, sec in ipairs(sections) do
		assert(#sec == m, "[GeoKit.Loft] mọi mặt cắt phải cùng số điểm")
		for _, v in ipairs(sec) do verts[#verts + 1] = v end
	end
	for si = 1, #sections - 1 do
		for k = 0, m - 1 do
			local a = (si - 1) * m + k + 1
			local b = (si - 1) * m + (k + 1) % m + 1
			local c = si * m + k + 1
			local d = si * m + (k + 1) % m + 1
			tris[#tris + 1] = { a, c, b }
			tris[#tris + 1] = { b, c, d }
		end
	end
	return GeoKit._finish(verts, tris)
end

-- Mặt cắt elip tại tâm `center`, bán trục rx (X), ry (Y), `n` điểm; dùng cho Loft.
function GeoKit.EllipseSection(center, rx, ry, n)
	local pts = {}
	for i = 0, n - 1 do
		local th = i / n * 2 * math.pi
		pts[#pts + 1] = center + Vector3.new(math.cos(th) * rx, math.sin(th) * ry, 0)
	end
	return pts
end

-- Sweep: ống bán kính đổi dọc đường `path` (list Vector3) với `radii` (list số) — cành, đuôi, xúc tu.
function GeoKit.Sweep(path, radii, sides)
	sides = sides or 8
	local sections = {}
	local up = Vector3.yAxis
	for i, p in ipairs(path) do
		local nxt = path[math.min(i + 1, #path)]
		local prv = path[math.max(i - 1, 1)]
		local fwd = (nxt - prv)
		fwd = fwd.Magnitude > 1e-6 and fwd.Unit or Vector3.zAxis
		if math.abs(fwd:Dot(up)) > 0.98 then up = Vector3.xAxis end
		local right = fwd:Cross(up).Unit
		local u2 = right:Cross(fwd).Unit
		up = u2
		local r = radii[math.min(i, #radii)]
		local sec = {}
		for s = 0, sides - 1 do
			local th = s / sides * 2 * math.pi
			sec[#sec + 1] = p + right * (math.cos(th) * r) + u2 * (math.sin(th) * r)
		end
		sections[#sections + 1] = sec
	end
	return GeoKit.Loft(sections)
end

function GeoKit._finish(verts, tris)
	local normals = {}
	for i = 1, #verts do normals[i] = Vector3.zero end
	for _, t in ipairs(tris) do
		local a, b, c = verts[t[1]], verts[t[2]], verts[t[3]]
		local n = (b - a):Cross(c - a)
		for k = 1, 3 do normals[t[k]] = normals[t[k]] + n end
	end
	for i = 1, #normals do
		normals[i] = normals[i].Magnitude > 1e-9 and normals[i].Unit or Vector3.yAxis
	end
	return { verts = verts, tris = tris, normals = normals }
end

-- Thống kê để chấm ngân sách (tam giác, bbox).
function GeoKit.Stats(data)
	local mn, mx = data.verts[1], data.verts[1]
	for _, v in ipairs(data.verts) do
		mn = Vector3.new(math.min(mn.X, v.X), math.min(mn.Y, v.Y), math.min(mn.Z, v.Z))
		mx = Vector3.new(math.max(mx.X, v.X), math.max(mx.Y, v.Y), math.max(mx.Z, v.Z))
	end
	return { triangles = #data.tris, vertices = #data.verts, size = mx - mn }
end

-- ===== Dựng trong Roblox =====
-- Tube bằng Part: xi-lanh nối tiếp + bi ở khớp. Chạy ở mọi nơi (không cần EditableMesh).
function GeoKit.Tube(parent, path, radii, color, material)
	local model = Instance.new("Model")
	model.Name = "Tube"
	local prev
	for i = 1, #path - 1 do
		local a, b = path[i], path[i + 1]
		local len = (b - a).Magnitude
		local r = radii[math.min(i, #radii)]
		local seg = Instance.new("Part")
		seg.Shape = Enum.PartType.Cylinder
		seg.Size = Vector3.new(len, r * 2, r * 2) -- trục tròn của Cylinder là X
		seg.CFrame = CFrame.lookAt((a + b) / 2, b) * CFrame.Angles(0, math.pi / 2, 0)
		seg.Color, seg.Material = color or Color3.fromRGB(120, 100, 80), material or Enum.Material.SmoothPlastic
		seg.Anchored, seg.CanCollide, seg.CanQuery = true, false, false
		seg.Parent = model
		if i == 1 then model.PrimaryPart = seg end
		local joint = Instance.new("Part")
		joint.Shape = Enum.PartType.Ball
		joint.Size = Vector3.one * (r * 2)
		joint.Position = b
		joint.Color, joint.Material = seg.Color, seg.Material
		joint.Anchored, joint.CanCollide, joint.CanQuery = true, false, false
		joint.Parent = model
		prev = seg
	end
	model.Parent = parent
	return model
end

-- Chuyển Data → MeshPart qua EditableMesh. CHỈ khi API khả dụng (Edit mode / Studio có quyền);
-- trả nil + lý do nếu không, để caller rơi về Tube/primitive. KHÔNG destroy EditableMesh khi MeshPart còn dùng.
function GeoKit.ToMeshPart(data, parent)
	local AssetService = game:GetService("AssetService")
	local okC, em = pcall(function() return AssetService:CreateEditableMesh() end)
	if not okC or not em then return nil, "CreateEditableMesh không khả dụng: " .. tostring(em) end
	local ids = {}
	for i, v in ipairs(data.verts) do ids[i] = em:AddVertex(v) end
	for _, t in ipairs(data.tris) do em:AddTriangle(ids[t[1]], ids[t[2]], ids[t[3]]) end
	local okM, mp = pcall(function() return AssetService:CreateMeshPartAsync(Content.fromObject(em)) end)
	if not okM or not mp then return nil, "CreateMeshPartAsync lỗi: " .. tostring(mp) end
	mp.Anchored = true
	mp.Parent = parent
	return mp
end


-- ===== GeoKit.Raw: lưới thuần số (mảng {x,y,z}), KHÔNG cần Roblox — test và render được ngoài Studio =====
-- mesh = { verts = { {x,y,z}, ... }, tris = { {i,j,k}, ... } } với mặt trước = ngược chiều kim đồng hồ nhìn từ ngoài (pháp tuyến hướng ra).
local Raw = {}
GeoKit.Raw = Raw

local function v3add(a, b) return { a[1] + b[1], a[2] + b[2], a[3] + b[3] } end
local function v3sub(a, b) return { a[1] - b[1], a[2] - b[2], a[3] - b[3] } end
local function v3mul(a, s) return { a[1] * s, a[2] * s, a[3] * s } end
local function v3dot(a, b) return a[1] * b[1] + a[2] * b[2] + a[3] * b[3] end
local function v3cross(a, b) return { a[2] * b[3] - a[3] * b[2], a[3] * b[1] - a[1] * b[3], a[1] * b[2] - a[2] * b[1] } end
local function v3len(a) return math.sqrt(v3dot(a, a)) end
local function v3unit(a) local m = v3len(a); if m < 1e-12 then return { 0, 0, 0 } end return { a[1] / m, a[2] / m, a[3] / m } end
Raw.add, Raw.sub, Raw.mul, Raw.dot, Raw.cross, Raw.len, Raw.unit = v3add, v3sub, v3mul, v3dot, v3cross, v3len, v3unit

-- Thể tích có dấu (> 0 nếu pháp tuyến hướng ra ngoài) — công thức tứ diện tại gốc.
function Raw.Volume(mesh)
	local vol = 0
	for _, t in ipairs(mesh.tris) do
		local a, b, c = mesh.verts[t[1]], mesh.verts[t[2]], mesh.verts[t[3]]
		vol += v3dot(a, v3cross(b, c)) / 6
	end
	return vol
end

function Raw.Area(mesh)
	local ar = 0
	for _, t in ipairs(mesh.tris) do
		local a, b, c = mesh.verts[t[1]], mesh.verts[t[2]], mesh.verts[t[3]]
		ar += v3len(v3cross(v3sub(b, a), v3sub(c, a))) / 2
	end
	return ar
end

-- Gộp đỉnh trùng (khoảng cách < eps), bỏ tam giác suy biến (diện tích ~ 0 hoặc trùng đỉnh).
function Raw.Weld(mesh, eps)
	eps = eps or 1e-6
	local inv = 1 / eps
	local grid, map, verts = {}, {}, {}
	for i, v in ipairs(mesh.verts) do
		local kx, ky, kz = math.floor(v[1] * inv + 0.5), math.floor(v[2] * inv + 0.5), math.floor(v[3] * inv + 0.5)
		local key = kx .. "," .. ky .. "," .. kz
		local id = grid[key]
		if not id then verts[#verts + 1] = v; id = #verts; grid[key] = id end
		map[i] = id
	end
	local tris = {}
	for _, t in ipairs(mesh.tris) do
		local a, b, c = map[t[1]], map[t[2]], map[t[3]]
		if a ~= b and b ~= c and a ~= c then
			local ar = v3len(v3cross(v3sub(verts[b], verts[a]), v3sub(verts[c], verts[a]))) / 2
			if ar > eps * eps then tris[#tris + 1] = { a, b, c } end
		end
	end
	return { verts = verts, tris = tris }
end

-- Lật chiều toàn bộ tam giác nếu thể tích âm (đảm bảo pháp tuyến hướng ra).
function Raw.Orient(mesh)
	if Raw.Volume(mesh) < 0 then
		for _, t in ipairs(mesh.tris) do t[2], t[3] = t[3], t[2] end
	end
	return mesh
end

-- Kiểm lưới kín & nhất quán: mỗi cạnh có hướng xuất hiện đúng 1 lần theo mỗi hướng (2-manifold, định hướng).
-- Trả { closed, manifold, volume, area, degenerate, boundaryEdges, nonManifoldEdges, flippedEdges }.
function Raw.Validate(mesh)
	local dir = {}
	local degenerate = 0
	for _, t in ipairs(mesh.tris) do
		local a, b, c = mesh.verts[t[1]], mesh.verts[t[2]], mesh.verts[t[3]]
		if v3len(v3cross(v3sub(b, a), v3sub(c, a))) < 1e-12 then degenerate += 1 end
		for k = 1, 3 do
			local i, j = t[k], t[k % 3 + 1]
			local key = i .. ">" .. j
			dir[key] = (dir[key] or 0) + 1
		end
	end
	local boundary, nonman, flipped = 0, 0, 0
	for key, cnt in pairs(dir) do
		local i, j = key:match("^(%d+)>(%d+)$")
		local rev = dir[j .. ">" .. i] or 0
		if cnt > 1 then nonman += 1 end
		if rev == 0 then boundary += 1 end
	end
	-- cạnh cùng hướng ở hai mặt (cnt>1) = chiều không nhất quán
	for _, cnt in pairs(dir) do if cnt > 1 then flipped += 1 end end
	return { closed = boundary == 0, manifold = nonman == 0, volume = Raw.Volume(mesh), area = Raw.Area(mesh), degenerate = degenerate,
		boundaryEdges = boundary, nonManifoldEdges = nonman, flippedEdges = flipped, verts = #mesh.verts, tris = #mesh.tris }
end

-- Dải đùn (lưỡi dao, cánh, vây): hai đường dẫn A_i (sống) và B_i (lưỡi) trên mặt phẳng giữa, đùn theo `nrm` với nửa dày ha[i] (ở A) và hb[i] (ở B).
-- A_i == B_i ở mũi → tam giác. Mặt trên/dưới nối A→B nên độ dày đổi tuyến tính từ sống sang lưỡi (mài phẳng "flat grind").
function Raw.ExtrudeStrip(A, B, nrm, ha, hb)
	local n = #A
	assert(#B == n and #ha == n and #hb == n, "[GeoKit.Raw.ExtrudeStrip] độ dài mảng không khớp")
	local nr = v3unit(nrm)
	-- Mũi nhọn: nếu A_n trùng B_n thì hai nửa dày phải bằng nhau, nếu không các đỉnh cùng toạ độ-YZ nhưng khác X
	-- tạo nắp mũi suy biến (diện tích 0) bị Weld loại → lưới hở. Ép bằng nhau để Weld gộp sạch thành một điểm.
	if v3len(v3sub(A[n], B[n])) < 1e-9 then
		local h = math.min(ha[n], hb[n])
		ha, hb = table.clone(ha), table.clone(hb)
		ha[n], hb[n] = h, h
	end
	local verts, ap, am, bp, bm = {}, {}, {}, {}, {}
	local function push(p) verts[#verts + 1] = p; return #verts end
	for i = 1, n do
		ap[i] = push(v3add(A[i], v3mul(nr, ha[i])))
		am[i] = push(v3sub(A[i], v3mul(nr, ha[i])))
		bp[i] = push(v3add(B[i], v3mul(nr, hb[i])))
		bm[i] = push(v3sub(B[i], v3mul(nr, hb[i])))
	end
	local tris = {}
	local function quad(a, b, c, d) tris[#tris + 1] = { a, b, c }; tris[#tris + 1] = { a, c, d } end
	for i = 1, n - 1 do
		quad(ap[i], bp[i], bp[i + 1], ap[i + 1])      -- mặt +nrm
		quad(am[i], am[i + 1], bm[i + 1], bm[i])      -- mặt −nrm
		quad(ap[i], ap[i + 1], am[i + 1], am[i])      -- thành sống
		quad(bp[i], bm[i], bm[i + 1], bp[i + 1])      -- thành lưỡi
	end
	quad(ap[1], am[1], bm[1], bp[1])                  -- nắp gốc
	quad(ap[n], bp[n], bm[n], am[n])                  -- nắp mũi (suy biến nếu A_n==B_n → bị Weld loại)
	return Raw.Orient(Raw.Weld({ verts = verts, tris = tris }, 1e-7))
end

-- Vòng xuyến (nhẫn ngón tay, vòng đệm). Mặt phẳng vòng do u,v (đơn vị, trực giao); pháp tuyến n = u×v.
-- R: bán kính chính; rr: nửa bề rộng hướng kính của tiết diện; rn: nửa dày theo n (tiết diện elip). M: số đoạn quanh vòng; m: số đoạn tiết diện.
function Raw.Torus(center, u, v, R, rr, rn, M, m)
	M, m = math.max(8, M or 24), math.max(6, m or 8)
	local n = v3unit(v3cross(u, v))
	local verts, tris = {}, {}
	for i = 0, M - 1 do
		local th = i / M * 2 * math.pi
		local radial = v3add(v3mul(u, math.cos(th)), v3mul(v, math.sin(th)))
		for j = 0, m - 1 do
			local ph = j / m * 2 * math.pi
			verts[#verts + 1] = v3add(v3add(center, v3mul(radial, R + rr * math.cos(ph))), v3mul(n, rn * math.sin(ph)))
		end
	end
	for i = 0, M - 1 do
		for j = 0, m - 1 do
			local a = i * m + j + 1
			local b = i * m + (j + 1) % m + 1
			local c = ((i + 1) % M) * m + j + 1
			local d = ((i + 1) % M) * m + (j + 1) % m + 1
			tris[#tris + 1] = { a, c, b }; tris[#tris + 1] = { b, c, d }
		end
	end
	return Raw.Orient({ verts = verts, tris = tris })
end

-- Ống elip đổi cỡ dọc đường `path` (list {x,y,z}); rx[i] (theo trục "phải" của khung), ry[i] (theo trục "lên"); bít hai đầu bằng nắp phẳng.
-- up0: vector tham chiếu để dựng khung ban đầu (mặc định trục Y; nếu song song thì dùng X). Khung được vận chuyển song song → không xoắn.
function Raw.SweepEllipse(path, rx, ry, sides, up0)
	sides = math.max(6, sides or 12)
	local n = #path
	local verts, tris = {}, {}
	local fwdPrev
	local up = up0 or { 0, 1, 0 }
	local rows = {}
	for i = 1, n do
		local f = v3unit(v3sub(path[math.min(i + 1, n)], path[math.max(i - 1, 1)]))
		if v3len(f) < 1e-9 then f = { 0, 0, 1 } end
		if math.abs(v3dot(f, up)) > 0.98 then up = (math.abs(f[1]) < 0.9) and { 1, 0, 0 } or { 0, 0, 1 } end
		local right = v3unit(v3cross(f, up))
		local u2 = v3unit(v3cross(right, f))
		up = u2
		local row = {}
		for s = 0, sides - 1 do
			local th = s / sides * 2 * math.pi
			verts[#verts + 1] = v3add(v3add(path[i], v3mul(right, math.cos(th) * rx[math.min(i, #rx)])), v3mul(u2, math.sin(th) * ry[math.min(i, #ry)]))
			row[s + 1] = #verts
		end
		rows[i] = row
		fwdPrev = f
	end
	for i = 1, n - 1 do
		for s = 1, sides do
			local a, b = rows[i][s], rows[i][s % sides + 1]
			local c, d = rows[i + 1][s], rows[i + 1][s % sides + 1]
			tris[#tris + 1] = { a, c, b }; tris[#tris + 1] = { b, c, d }
		end
	end
	local c1 = #verts + 1; verts[c1] = path[1]
	local c2 = #verts + 1; verts[c2] = path[n]
	for s = 1, sides do
		tris[#tris + 1] = { c1, rows[1][s], rows[1][s % sides + 1] }
		tris[#tris + 1] = { c2, rows[n][s % sides + 1], rows[n][s] }
	end
	return Raw.Orient({ verts = verts, tris = tris })
end

-- Gộp nhiều lưới thành một (không hàn) — để xuất một MeshPart/một ảnh.
function Raw.Merge(list)
	local verts, tris = {}, {}
	for _, m in ipairs(list) do
		local off = #verts
		for _, v in ipairs(m.verts) do verts[#verts + 1] = v end
		for _, t in ipairs(m.tris) do tris[#tris + 1] = { t[1] + off, t[2] + off, t[3] + off } end
	end
	return { verts = verts, tris = tris }
end

-- Lưới thuần → Data dạng Vector3 để ToMeshPart dùng.
function Raw.ToData(mesh)
	local verts = {}
	for i, v in ipairs(mesh.verts) do verts[i] = Vector3.new(v[1], v[2], v[3]) end
	return { verts = verts, tris = mesh.tris }
end

return GeoKit
