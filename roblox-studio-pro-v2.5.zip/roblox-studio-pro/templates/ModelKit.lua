--!nonstrict
-- ModelKit — lắp ráp và kiểm tra model dựng bằng code (ModuleScript; dùng trong Edit mode/Command Bar hoặc runtime).
-- Quy tắc: dựng part ở origin với size cuối → đặt vị trí → weld chuỗi → PivotTo. Không scale cụm đã đặt.

local ModelKit = {}

-- Thông số tỉ lệ: 1 m = 3 studs (người 1.7 m ≈ 5 studs).
ModelKit.STUDS_PER_METRE = 3
function ModelKit.M(metres) return metres * ModelKit.STUDS_PER_METRE end

-- Tạo part chuẩn: không va chạm/query (trang trí) trừ khi opts.Solid.
function ModelKit.Part(parent, name, shape, size, cf, color, material, opts)
	local p = Instance.new("Part")
	p.Name, p.Shape, p.Size, p.CFrame = name, shape or Enum.PartType.Block, size, cf
	p.Color, p.Material = color, material or Enum.Material.SmoothPlastic
	p.Anchored = true
	local solid = opts and opts.Solid
	p.CanCollide, p.CanQuery, p.CanTouch = solid or false, solid or false, solid or false
	p.TopSurface, p.BottomSurface = Enum.SurfaceType.Smooth, Enum.SurfaceType.Smooth
	p.Parent = parent -- Parent cuối
	return p
end

-- Wedge cho mép/vát; flip = lật 180° quanh Y.
function ModelKit.Wedge(parent, name, size, cf, color, material, flip)
	local w = Instance.new("WedgePart")
	w.Name, w.Size, w.Color, w.Material = name, size, color, material or Enum.Material.SmoothPlastic
	w.CFrame = flip and cf * CFrame.Angles(0, math.pi, 0) or cf
	w.Anchored, w.CanCollide, w.CanQuery, w.CanTouch = true, false, false, false
	w.Parent = parent
	return w
end

-- Soi gương qua mặt phẳng YZ (X → -X): dùng để tạo nửa đối xứng. Trả list part mới.
function ModelKit.MirrorX(model, filter)
	local out = {}
	for _, d in ipairs(model:GetChildren()) do
		if d:IsA("BasePart") and (not filter or filter(d)) then
			local c = d:Clone()
			local cf = d.CFrame
			local rel = model:GetPivot():ToObjectSpace(cf)
			local px, py, pz, r00, r01, r02, r10, r11, r12, r20, r21, r22 = rel:GetComponents()
			local mirrored = CFrame.new(-px, py, pz, r00, -r01, -r02, -r10, r11, r12, -r20, r21, r22)
			c.CFrame = model:GetPivot():ToWorldSpace(mirrored)
			c.Name = d.Name .. "_R"
			c.Parent = model
			out[#out + 1] = c
		end
	end
	return out
end

-- Weld chuỗi mọi part vào PrimaryPart rồi unanchor (một phép di chuyển bằng PivotTo).
function ModelKit.WeldToPrimary(model, unanchor)
	local root = model.PrimaryPart
	assert(root, "[ModelKit] model chưa có PrimaryPart")
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") and d ~= root then
			local w = Instance.new("WeldConstraint")
			w.Part0, w.Part1 = root, d
			w.Parent = d
		end
	end
	if unanchor then
		for _, d in ipairs(model:GetDescendants()) do
			if d:IsA("BasePart") then d.Anchored = false end
		end
		root.Anchored = false
	end
end

-- Chuẩn hoá kích thước: trục dài nhất = target studs; trả hệ số đã dùng.
function ModelKit.Normalize(model, targetLongest)
	local _, s0 = model:GetBoundingBox()
	local longest = math.max(s0.X, s0.Y, s0.Z)
	local k = targetLongest / longest
	model:ScaleTo(model:GetScale() * k)
	return k
end

-- Đặt đáy model chạm mặt đất tại (x, groundY, z).
function ModelKit.PlaceOnGround(model, x, groundY, z)
	local cf, size = model:GetBoundingBox()
	local bottomOffset = cf.Position.Y - size.Y / 2 - model:GetPivot().Position.Y
	model:PivotTo(CFrame.new(x, groundY - bottomOffset, z))
end

-- Báo cáo chấm model: số part, bbox, part mỏng, part trùng vị trí, so với spec.
-- spec = { Size = Vector3 (studs, ±tol), MinParts=, MaxParts=, MinThin=0.15 }
function ModelKit.Audit(model, spec)
	spec = spec or {}
	local parts, thin, neon, collide = 0, {}, 0, 0
	local minThin = spec.MinThin or 0.15
	local seen, dup = {}, 0
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") then
			parts += 1
			local s = d.Size
			if math.min(s.X, s.Y, s.Z) < minThin then thin[#thin + 1] = d.Name end
			if d.Material == Enum.Material.Neon then neon += 1 end
			if d.CanCollide then collide += 1 end
			local key = string.format("%.2f|%.2f|%.2f|%.1f|%.1f|%.1f", d.Position.X, d.Position.Y, d.Position.Z, s.X, s.Y, s.Z)
			if seen[key] then dup += 1 end
			seen[key] = true
		end
	end
	local _, size = model:GetBoundingBox()
	local issues = {}
	if spec.MinParts and parts < spec.MinParts then issues[#issues + 1] = ("quá ít part (%d < %d) → dễ ra khối hộp"):format(parts, spec.MinParts) end
	if spec.MaxParts and parts > spec.MaxParts then issues[#issues + 1] = ("quá nhiều part (%d > %d)"):format(parts, spec.MaxParts) end
	if #thin > 0 then issues[#issues + 1] = ("%d part mỏng hơn %.2f stud (mất chi tiết ở xa)"):format(#thin, minThin) end
	if dup > 0 then issues[#issues + 1] = ("%d part trùng hệt nhau (z-fighting)"):format(dup) end
	if collide > 4 then issues[#issues + 1] = ("%d part CanCollide (bom vật lý; chỉ 2-3 box rắn)"):format(collide) end
	if spec.Size then
		local tol = spec.Tol or 0.25
		for _, ax in ipairs({ "X", "Y", "Z" }) do
			local want, got = spec.Size[ax], size[ax]
			if math.abs(got - want) / want > tol then
				issues[#issues + 1] = ("trục %s: %.1f studs, spec %.1f (lệch >%d%%)"):format(ax, got, want, tol * 100)
			end
		end
	end
	return { parts = parts, size = size, neon = neon, collide = collide, issues = issues, ok = #issues == 0 }
end

function ModelKit.PrintAudit(report)
	print(("[ModelKit] parts=%d size=(%.1f, %.1f, %.1f) neon=%d collide=%d"):format(report.parts, report.size.X, report.size.Y, report.size.Z, report.neon, report.collide))
	if report.ok then print("[ModelKit] OK") else for _, m in ipairs(report.issues) do warn("[ModelKit] " .. m) end end
end

return ModelKit
