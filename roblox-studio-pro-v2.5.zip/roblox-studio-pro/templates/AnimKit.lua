--!nonstrict
-- AnimKit — animation procedural nhiều lớp cho Humanoid R15, R6, rig Part tuỳ ý (Motor6D/AnimationConstraint) — không cần publish.
--
-- Ý tưởng cốt lõi: pose viết bằng độ (Euler) TRONG KHUNG CỦA PART CHA ("torso space": X phải, Y lên, Z lùi; trước mặt = -Z).
-- Khi ghi vào khớp: Transform = C0⁻¹ · Δ · C0  → cùng một clip chạy đúng trên R15 (C0 ~ identity), R6 (C0 xoay 90°) và rig tuỳ ý.
--
-- Từ vựng khớp (rig-neutral): Root Waist Neck LShoulder LElbow LWrist RShoulder RElbow RWrist LHip LKnee LAnkle RHip RKnee RAnkle
-- R6 không có Elbow/Knee/Wrist/Ankle/Waist → AnimKit gấp tương đương (xem FOLD) hoặc bỏ qua; rig Generic dùng thẳng tên khớp thật.
--
-- Dùng:  local rig = AnimKit.Rig(character)         -- tự nhận R15 / R6 / Generic
--        local player = AnimKit.Player(rig)         -- tự bind PreSimulation
--        local h = player:Play(Clips.SwordCombo1, { Layer = 2, FadeIn = 0.08 })
--        player:Play(Clips.RifleHold, { Layer = 3, Mask = AnimKit.Masks.Upper, Additive = false })
--        player:Destroy() khi xong (hoặc rig/model bị destroy → tự dọn).

local RunService = game:GetService("RunService")

local AnimKit = {}

-- ===== Từ vựng và bản đồ rig =====
local MAP_R15 = {
	Root = "Root", Waist = "Waist", Neck = "Neck",
	LShoulder = "LeftShoulder", LElbow = "LeftElbow", LWrist = "LeftWrist",
	RShoulder = "RightShoulder", RElbow = "RightElbow", RWrist = "RightWrist",
	LHip = "LeftHip", LKnee = "LeftKnee", LAnkle = "LeftAnkle",
	RHip = "RightHip", RKnee = "RightKnee", RAnkle = "RightAnkle",
}
local MAP_R6 = {
	Root = "RootJoint", Neck = "Neck",
	LShoulder = "Left Shoulder", RShoulder = "Right Shoulder", LHip = "Left Hip", RHip = "Right Hip",
}
-- R6 không có gối/khuỷu: gấp một phần vào khớp cha (hệ số nhân góc pitch) để chân/tay không cứng đơ.
local FOLD_R6 = { LKnee = { "LHip", -0.35 }, RKnee = { "RHip", -0.35 }, LElbow = { "LShoulder", 0.25 }, RElbow = { "RShoulder", 0.25 }, Waist = { "Root", 1 } }

AnimKit.Masks = {
	Upper = { Waist = true, Neck = true, LShoulder = true, LElbow = true, LWrist = true, RShoulder = true, RElbow = true, RWrist = true },
	Lower = { Root = true, LHip = true, LKnee = true, LAnkle = true, RHip = true, RKnee = true, RAnkle = true },
	Arms = { LShoulder = true, LElbow = true, LWrist = true, RShoulder = true, RElbow = true, RWrist = true },
	RightArm = { RShoulder = true, RElbow = true, RWrist = true },
	LeftArm = { LShoulder = true, LElbow = true, LWrist = true },
	Legs = { LHip = true, LKnee = true, LAnkle = true, RHip = true, RKnee = true, RAnkle = true },
}

-- ===== Toán thuần (test bằng luau CLI) =====
local EASE = {
	lin = function(a) return a end,
	inn = function(a) return a * a * a end,
	out = function(a) return 1 - (1 - a) ^ 3 end,
	inout = function(a) return a < 0.5 and 4 * a ^ 3 or 1 - (-2 * a + 2) ^ 3 / 2 end,
	snap = function(a) return a >= 1 and 1 or 0 end,        -- giữ pose tới mốc kế (stepped) — dùng cho impact/cắt đột ngột
	back = function(a) local c1 = 1.70158; local c3 = c1 + 1; return 1 + c3 * (a - 1) ^ 3 + c1 * (a - 1) ^ 2 end, -- vọt rồi về (overshoot)
}
AnimKit.Ease = EASE

-- Lấy mẫu một track: keys = { {t=, r={x,y,z} độ, p={x,y,z} stud, e="ease đến mốc này"}, ... }. Trả r, p (bảng số).
function AnimKit.SampleTrack(keys, t)
	local n = #keys
	local function pack(k) return k.r or { 0, 0, 0 }, k.p or { 0, 0, 0 } end
	if t <= keys[1].t then return pack(keys[1]) end
	if t >= keys[n].t then return pack(keys[n]) end
	for i = 1, n - 1 do
		local a, b = keys[i], keys[i + 1]
		if t >= a.t and t <= b.t then
			local span = b.t - a.t
			local raw = span > 0 and (t - a.t) / span or 1
			local k = (EASE[b.e or "inout"] or EASE.inout)(raw)
			local ra, pa = pack(a)
			local rb, pb = pack(b)
			return { ra[1] + (rb[1] - ra[1]) * k, ra[2] + (rb[2] - ra[2]) * k, ra[3] + (rb[3] - ra[3]) * k },
				{ pa[1] + (pb[1] - pa[1]) * k, pa[2] + (pb[2] - pa[2]) * k, pa[3] + (pb[3] - pa[3]) * k }
		end
	end
	return pack(keys[n])
end

-- Kiểm clip: mốc tăng dần, tên khớp hợp lệ, clip Loop thì pose cuối = pose đầu (không giật khi lặp).
local VOCAB = {}
for k in pairs(MAP_R15) do VOCAB[k] = true end
function AnimKit.ValidateClip(clip, allowGeneric)
	local errs = {}
	if not clip.Duration or clip.Duration <= 0 then errs[#errs + 1] = "thiếu Duration" end
	for joint, keys in pairs(clip.Tracks or {}) do
		if not allowGeneric and not VOCAB[joint] then errs[#errs + 1] = "khớp lạ: " .. tostring(joint) end
		for i = 2, #keys do
			if keys[i].t < keys[i - 1].t then errs[#errs + 1] = joint .. ": mốc " .. i .. " lùi thời gian" end
		end
		if keys[#keys].t > (clip.Duration or 0) + 1e-6 then errs[#errs + 1] = joint .. ": mốc cuối vượt Duration" end
		if clip.Loop then
			local a, b = keys[1], keys[#keys]
			local ra, rb = a.r or { 0, 0, 0 }, b.r or { 0, 0, 0 }
			for i = 1, 3 do
				if math.abs(ra[i] - rb[i]) > 0.5 then errs[#errs + 1] = ("%s: clip Loop nhưng pose cuối ≠ đầu (trục %d: %.1f vs %.1f)"):format(joint, i, ra[i], rb[i]); break end
			end
		end
	end
	return errs
end

-- Spring tắt dần (secondary motion/follow-through): freq Hz, damp 1 = tới đích không vọt, <1 vọt.
local Spring = {}
Spring.__index = Spring
function Spring.new(freq, damp, x0)
	return setmetatable({ w = (freq or 4) * 2 * math.pi, z = damp or 0.6, x = x0 or 0, v = 0 }, Spring)
end
function Spring:Step(target, dt)
	local steps = math.max(1, math.ceil(dt / 0.004)) -- chia nhỏ để ổn định khi dt lớn
	local h = dt / steps
	for _ = 1, steps do
		local a = self.w * self.w * (target - self.x) - 2 * self.z * self.w * self.v
		self.v += a * h
		self.x += self.v * h
	end
	return self.x
end
AnimKit.Spring = Spring

-- IK hai xương (tay/chân), vector = {x,y,z}. shoulder→target, độ dài l1,l2, pole = hướng khuỷu/gối muốn hướng về.
-- Trả { elbow = {..}, tip = {..}, reached = bool, d1 = hướng xương 1, d2 = hướng xương 2 }.
local function sub(a, b) return { a[1] - b[1], a[2] - b[2], a[3] - b[3] } end
local function add(a, b) return { a[1] + b[1], a[2] + b[2], a[3] + b[3] } end
local function mul(a, s) return { a[1] * s, a[2] * s, a[3] * s } end
local function dotv(a, b) return a[1] * b[1] + a[2] * b[2] + a[3] * b[3] end
local function norm(a) local m = math.sqrt(dotv(a, a)); if m < 1e-9 then return { 0, -1, 0 }, 0 end return { a[1] / m, a[2] / m, a[3] / m }, m end
function AnimKit.SolveTwoBone(root, target, l1, l2, pole)
	local dir, dist = norm(sub(target, root))
	local reached = true
	local maxReach = (l1 + l2) * 0.9999
	local minReach = math.abs(l1 - l2) * 1.0001 + 1e-4
	local d = dist
	if d > maxReach then d = maxReach; reached = false end
	if d < minReach then d = minReach; reached = false end
	-- góc tại root giữa xương 1 và đường tới đích (định lý cos)
	local cosA = (l1 * l1 + d * d - l2 * l2) / (2 * l1 * d)
	cosA = math.clamp(cosA, -1, 1)
	local sinA = math.sqrt(1 - cosA * cosA)
	-- thành phần của pole vuông góc với dir
	local pp = sub(pole, mul(dir, dotv(pole, dir)))
	local pn, pm = norm(pp)
	if pm < 1e-6 then pn = { 0, 0, 1 } if math.abs(dir[3]) > 0.9 then pn = { 1, 0, 0 } end
		pn = norm(sub(pn, mul(dir, dotv(pn, dir)))) end
	local d1 = add(mul(dir, cosA), mul(pn, sinA))
	local elbow = add(root, mul(d1, l1))
	local tipPos = add(root, mul(dir, d))
	local d2 = norm(sub(tipPos, elbow))
	return { elbow = elbow, tip = tipPos, reached = reached, d1 = d1, d2 = d2, dist = d }
end

-- ===== Roblox: Rig =====
local function newSignal() local e = Instance.new("BindableEvent"); return e end

function AnimKit.Rig(model)
	local joints = {}
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("Motor6D") or d:IsA("AnimationConstraint") then joints[d.Name] = d end
	end
	local kind = "Generic"
	if joints["RootJoint"] and joints["Right Hip"] then kind = "R6"
	elseif joints["RightKnee"] or joints["LeftKnee"] then kind = "R15" end
	local map = (kind == "R15" and MAP_R15) or (kind == "R6" and MAP_R6) or nil
	local rig = { Model = model, Kind = kind, Joints = joints, _dirty = {} }

	-- Tìm khớp theo tên từ vựng (hoặc tên thật với Generic).
	function rig:Joint(name)
		local real = map and map[name] or name
		return joints[real]
	end
	function rig:Has(name) return self:Joint(name) ~= nil end

	-- Ghi Δ (CFrame, trong khung part cha) vào khớp: Transform = C0⁻¹·Δ·C0.
	function rig:Apply(name, delta)
		local j = self:Joint(name)
		if not j then return false end
		local c0 = j.C0
		j.Transform = c0:Inverse() * delta * c0
		self._dirty[name] = true
		return true
	end
	function rig:Reset()
		for name in pairs(self._dirty) do
			local j = self:Joint(name)
			if j then j.Transform = CFrame.identity end
		end
		table.clear(self._dirty)
	end
	return rig
end

-- Biến một model toàn WeldConstraint/Weld thành rig Motor6D (để animate "part rig" như súng, robot, rồng).
-- parentOf = { [tênPartCon] = tênPartCha } hoặc nil để tự suy ra từ weld (PrimaryPart là gốc, duyệt BFS).
function AnimKit.Rigify(model, parentOf)
	local root = model.PrimaryPart
	assert(root, "[AnimKit.Rigify] model cần PrimaryPart")
	local adj = {}
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("WeldConstraint") and d.Part0 and d.Part1 then
			adj[d.Part0] = adj[d.Part0] or {}; adj[d.Part1] = adj[d.Part1] or {}
			table.insert(adj[d.Part0], { d.Part1, d }); table.insert(adj[d.Part1], { d.Part0, d })
		end
	end
	local seen, queue, made = { [root] = true }, { root }, {}
	while #queue > 0 do
		local p = table.remove(queue, 1)
		for _, e in ipairs(adj[p] or {}) do
			local child, weld = e[1], e[2]
			if not seen[child] then
				seen[child] = true
				queue[#queue + 1] = child
				local cha = p
				if parentOf and parentOf[child.Name] and model:FindFirstChild(parentOf[child.Name], true) then cha = model:FindFirstChild(parentOf[child.Name], true) end
				local m = Instance.new("Motor6D")
				m.Name = child.Name
				m.Part0, m.Part1 = cha, child
				m.C0 = cha.CFrame:ToObjectSpace(child.CFrame) -- pose hiện tại là pose nghỉ
				m.C1 = CFrame.identity
				weld:Destroy()
				m.Parent = cha
				made[#made + 1] = m
			end
		end
	end
	for _, p in ipairs(model:GetDescendants()) do if p:IsA("BasePart") and p ~= root then p.Anchored = false end end
	return made
end

-- ===== Player nhiều lớp =====
local function mirrorName(n)
	if n:sub(1, 1) == "L" and VOCAB[n] then return "R" .. n:sub(2) end
	if n:sub(1, 1) == "R" and VOCAB[n] and n ~= "Root" then return "L" .. n:sub(2) end
	return n
end

function AnimKit.Player(rig)
	local P = { rig = rig, handles = {}, TimeScale = 1 }
	local conn

	function P:Play(clip, opts)
		opts = opts or {}
		local h = {
			clip = clip, t = opts.Start or 0, speed = opts.Speed or 1, layer = opts.Layer or 1, weight = opts.Weight or 1,
			fadeIn = opts.FadeIn or 0.12, fadeOut = opts.FadeOut or 0.12, additive = opts.Additive or false, mask = opts.Mask,
			mirror = opts.Mirror or false, loop = opts.Loop == nil and clip.Loop or opts.Loop, onEvent = opts.OnEvent,
			age = 0, stopping = false, fadeOutT = 0, fired = {}, alive = true, done = Instance.new("BindableEvent"),
		}
		h.Finished = h.done.Event
		function h:Stop(fade) if not self.stopping then self.stopping = true; self.fadeOut = fade or self.fadeOut end end
		function h:AdjustSpeed(s) self.speed = s end
		function h:AdjustWeight(w) self.weight = w end
		self.handles[#self.handles + 1] = h
		table.sort(self.handles, function(a, b) return a.layer < b.layer end)
		if not conn then
			conn = RunService.PreSimulation:Connect(function(dt) self:_update(dt) end)
		end
		return h
	end

	function P:StopAll(fade) for _, h in ipairs(self.handles) do h:Stop(fade) end end

	function P:_update(dt)
		local model = rig.Model
		if not model or not model.Parent then self:Destroy(); return end
		dt *= self.TimeScale
		local acc, touched = {}, {}
		for i = #self.handles, 1, -1 do
			local h = self.handles[i]
			h.age += dt
			h.t += dt * h.speed
			local dur = h.clip.Duration
			local ended = false
			if h.loop then
				if h.t >= dur then h.t %= dur; h.fired = {} end
			elseif h.t >= dur then
				h.t = dur; ended = true
			end
			-- hệ số mờ vào/ra
			local fade = h.fadeIn > 0 and math.min(1, h.age / h.fadeIn) or 1
			if h.stopping then
				h.fadeOutT += dt
				fade *= h.fadeOut > 0 and math.max(0, 1 - h.fadeOutT / h.fadeOut) or 0
				if fade <= 0 then ended = true end
			end
			if ended and not h.loop and not h.stopping then h.stopping = true; h.fadeOutT = 0 end -- clip một lần: giữ pose cuối rồi mờ ra
			-- sự kiện
			for ei, ev in ipairs(h.clip.Events or {}) do
				if not h.fired[ei] and h.t >= ev.t then
					h.fired[ei] = true
					if h.onEvent then local ok, err = pcall(h.onEvent, ev.name, ev); if not ok then warn("[AnimKit] event lỗi:", err) end end
				end
			end
			if fade <= 0 and h.stopping then
				h.alive = false
				h.done:Fire()
				h.done:Destroy()
				table.remove(self.handles, i)
			else
				h._fade = fade
			end
		end
		-- trộn theo layer tăng dần (self.handles đã sort)
		for _, h in ipairs(self.handles) do
			local w = h.weight * (h._fade or 1)
			for joint, keys in pairs(h.clip.Tracks) do
				local jn = joint
				if h.mirror then jn = mirrorName(joint) end
				if not h.mask or h.mask[jn] then
					local r, p = AnimKit.SampleTrack(keys, h.t)
					local rx, ry, rz, px = r[1], r[2], r[3], p[1]
					if h.mirror then ry, rz, px = -ry, -rz, -px end
					local cf = CFrame.new(px, p[2], p[3]) * CFrame.Angles(math.rad(rx), math.rad(ry), math.rad(rz))
					local prev = acc[jn] or CFrame.identity
					if h.additive then acc[jn] = prev * CFrame.identity:Lerp(cf, w)
					else acc[jn] = prev:Lerp(cf, w) end
					touched[jn] = true
				end
			end
		end
		-- Gấp R6 (không có khớp gối/khuỷu) rồi ghi
		local pitchFold = {}
		if rig.Kind == "R6" then
			for name, f in pairs(FOLD_R6) do
				local cf = acc[name]
				if cf and not rig:Has(name) then
					local x = cf:ToEulerAnglesXYZ()
					pitchFold[f[1]] = (pitchFold[f[1]] or 0) + x * f[2]
				end
			end
		end
		for name, cf in pairs(acc) do
			if pitchFold[name] then cf = cf * CFrame.Angles(pitchFold[name], 0, 0) end
			rig:Apply(name, cf)
		end
		for name, add in pairs(pitchFold) do
			if not acc[name] then rig:Apply(name, CFrame.Angles(add, 0, 0)) end
		end
		-- khớp lần trước có mà lần này không còn clip nào chạm → trả về pose nghỉ
		for name in pairs(rig._dirty) do
			if not acc[name] and not pitchFold[name] then
				local j = rig:Joint(name)
				if j then j.Transform = CFrame.identity end
				rig._dirty[name] = nil
			end
		end
	end

	function P:Destroy()
		if conn then conn:Disconnect(); conn = nil end
		for _, h in ipairs(self.handles) do if h.done then h.done:Destroy() end end
		table.clear(self.handles)
		rig:Reset()
	end
	return P
end

-- Hitstop toàn bộ: đóng băng player trong `dur` giây rồi trả tốc độ.
function AnimKit.HitStop(player, dur, scale)
	local old = player.TimeScale
	player.TimeScale = scale or 0
	task.delay(dur, function() player.TimeScale = old end)
end

-- ===== IK tay/chân (R15 và rig Generic có đủ 3 khớp) =====
-- side: "L"/"R"; limb: "Arm"/"Leg". targetWorld: Vector3 thế giới (vị trí cổ tay/cổ chân mong muốn); poleWorld: hướng khuỷu/gối.
-- Gọi MỖI PreSimulation SAU Player (ghi đè khớp của chi đó). Trả ok, reached|lý do.
local function rotOnly(cf) return cf - cf.Position end

function AnimKit.AimLimb(rig, side, limb, targetWorld, poleWorld)
	local j1n = side .. (limb == "Arm" and "Shoulder" or "Hip")
	local j2n = side .. (limb == "Arm" and "Elbow" or "Knee")
	local j3n = side .. (limb == "Arm" and "Wrist" or "Ankle")
	local j1, j2, j3 = rig:Joint(j1n), rig:Joint(j2n), rig:Joint(j3n)
	if not (j1 and j2 and j3) then return false, "thiếu khớp (R6 không có khuỷu/gối: dùng Player + clip thay vì IK)" end
	local parent = j1.Part0
	-- Pose nghỉ, toạ độ trong khung part cha của khớp 1:
	local Q0 = j1.C0 * j1.C1:Inverse()               -- khung part xương 1 ở pose nghỉ
	local S = j1.C0.Position                          -- vị trí khớp 1
	local E = (Q0 * j2.C0).Position                  -- vị trí khớp 2
	local Q1 = Q0 * j2.C0 * j2.C1:Inverse()          -- khung part xương 2 ở pose nghỉ
	local W = (Q1 * j3.C0).Position                  -- vị trí khớp 3 (cổ tay/cổ chân)
	local l1, l2 = (E - S).Magnitude, (W - E).Magnitude
	if l1 < 1e-3 or l2 < 1e-3 then return false, "không đo được độ dài xương" end
	local restDir = (E - S).Unit
	local pframe = parent.CFrame
	local tl = pframe:PointToObjectSpace(targetWorld)
	local pl = pframe:VectorToObjectSpace(poleWorld - pframe.Position)
	local sol = AnimKit.SolveTwoBone({ S.X, S.Y, S.Z }, { tl.X, tl.Y, tl.Z }, l1, l2, { pl.X, pl.Y, pl.Z })
	local function v3(t) return Vector3.new(t[1], t[2], t[3]) end
	local function fromTo(a, b)
		local axis = a:Cross(b)
		if axis.Magnitude < 1e-6 then
			if a:Dot(b) > 0 then return CFrame.identity end
			local perp = math.abs(a.X) < 0.9 and Vector3.xAxis or Vector3.yAxis
			return CFrame.fromAxisAngle(a:Cross(perp).Unit, math.pi)
		end
		return CFrame.fromAxisAngle(axis.Unit, math.acos(math.clamp(a:Dot(b), -1, 1)))
	end
	local d1, d2 = v3(sol.d1), v3(sol.d2)
	local dS = fromTo(restDir, d1)                           -- xương 1: từ hướng nghỉ tới d1 (khung cha)
	local dEP = fromTo(d1, d2)                               -- xương 2 quay thêm (khung cha)
	local q0 = rotOnly(Q0)
	local dE = q0:Inverse() * dS:Inverse() * dEP * dS * q0   -- đưa về khung part xương 1 (suy dẫn trong docs/animation-advanced.md)
	rig:Apply(j1n, dS)
	rig:Apply(j2n, dE)
	return true, sol.reached
end

return AnimKit
