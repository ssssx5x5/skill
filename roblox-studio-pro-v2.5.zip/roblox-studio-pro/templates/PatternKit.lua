--!nonstrict
-- PatternKit — các "khuôn" dựng hình lặp lại / cong bằng Part: xếp vòng tròn, vòm voxel nhiều lớp màu, khối cầu voxel (mây), dấu cộng, weld.
-- Dùng khi ảnh mẫu có: vòm cầu vồng, cụm N nòng quanh trục, mây khối, hoa văn đối xứng — thứ mà hộp thẳng đơn lẻ làm sai.
-- Quy ước: mọi hàm nhận CFrame `center` (khung cục bộ: X phải, Y lên, Z lùi; trước = −Z); đơn vị = studs.
-- Chạy được trong sandbox (scripts/sandbox.py) lẫn Studio. Toán vòm/vòng được test ở scripts/test_sandbox.py.

local PatternKit = {}

local function mk(parent, name, size, cf, color, material, shape)
	local p = Instance.new("Part")
	p.Name = name
	p.Size = size
	p.CFrame = cf
	p.Color = color
	p.Material = material or Enum.Material.SmoothPlastic
	p.Anchored = true
	p.CanCollide = false
	p.TopSurface = Enum.SurfaceType.Smooth
	p.BottomSurface = Enum.SurfaceType.Smooth
	if shape then p.Shape = shape end
	p.Parent = parent
	return p
end
PatternKit.Part = mk

-- Vị trí N phần tử quanh trục cục bộ Z: góc 0 = ĐỈNH (+Y), tăng dần theo chiều kim đồng hồ khi nhìn TỪ PHÍA TRƯỚC (từ −Z nhìn vào).
-- Trả về mảng { {i=, deg=, offset=Vector3 (trong khung center), cf=CFrame (đã nhân center)} }.
function PatternKit.RadialSlots(n: number, radius: number, center: CFrame?, startDeg: number?)
	local out = {}
	local base = center or CFrame.new()
	for i = 0, n - 1 do
		local deg = (startDeg or 0) + 360 * i / n
		local a = math.rad(deg)
		-- nhìn từ phía trước (từ −Z): +X nằm bên TRÁI ảnh, nên "theo kim đồng hồ" nghĩa là đỉnh → bên trái(+X)
		local off = Vector3.new(radius * math.sin(a), radius * math.cos(a), 0)
		table.insert(out, { i = i + 1, deg = deg, offset = off, cf = base * CFrame.new(off) })
	end
	return out
end

-- Vòm voxel: các khối lập phương `voxel` nằm trong vành [inner, outer] của nửa trên (hoặc cả vòng nếu half=false) mặt phẳng XY cục bộ.
-- Màu theo dải từ ngoài vào trong: bands = {Color3,...} (1 dải dày = (outer-inner)/#bands).
-- depth = bề dày theo Z. Trả { parts=, count= }.
function PatternKit.VoxelArch(parent, o)
	local center = o.center or CFrame.new()
	local outer, inner, v = o.outer, o.inner, o.voxel or (o.outer - o.inner) / #o.bands
	local bands, depth = o.bands, o.depth or v
	local half = o.half ~= false
	local parts = {}
	local n = math.ceil(outer / v)
	for j = (half and 0 or -n), n do
		for i = -n, n do
			local x, y = (i + 0.0) * v, (j + 0.5) * v
			local r = math.sqrt(x * x + y * y)
			if r >= inner and r <= outer then
				local t = (r - inner) / (outer - inner)
				local b = math.clamp(#bands - math.floor(t * #bands), 1, #bands) -- ngoài cùng = dải đầu tiên
				table.insert(parts, mk(parent, "ArchVoxel", Vector3.new(v, v, depth), center * CFrame.new(x, y, 0), bands[b], o.material))
			end
		end
	end
	return { parts = parts, count = #parts }
end

-- Khối cầu voxel (mây, bụi, đá tròn): gộp các ô liền nhau theo trục X thành một thanh để giảm số part.
function PatternKit.VoxelBlob(parent, o)
	local center = o.center or CFrame.new()
	local r, v = o.radius, o.voxel
	local s = o.scale or Vector3.new(1, 1, 1)   -- bóp méo thành elip
	local parts = {}
	local n = math.ceil(r / v)
	for k = -n, n do
		for j = -n, n do
			local run0 = nil
			for i = -n, n + 1 do
				local inside = false
				if i <= n then
					local x, y, z = i * v / s.X, j * v / s.Y, k * v / s.Z
					inside = x * x + y * y + z * z <= r * r
				end
				if inside and not run0 then run0 = i end
				if (not inside) and run0 then
					local len = (i - run0) * v
					local cx = ((run0 + i - 1) / 2) * v
					local col = o.color
					if o.colorFn then col = o.colorFn(cx, j * v, k * v) end
					table.insert(parts, mk(parent, "BlobVoxel", Vector3.new(len, v, v), center * CFrame.new(cx, j * v, k * v), col, o.material))
					run0 = nil
				end
			end
		end
	end
	return { parts = parts, count = #parts }
end

-- Dấu cộng (cộng hồng ở đuôi súng, thập tự...) nằm trong mặt phẳng XY cục bộ.
function PatternKit.Plus(parent, center: CFrame, arm: number, thick: number, depth: number, color: Color3, material)
	local a = mk(parent, "PlusH", Vector3.new(arm, thick, depth), center, color, material)
	local b = mk(parent, "PlusV", Vector3.new(thick, arm, depth), center, color, material)
	return { a, b }
end

-- Thanh nối giữa hai điểm (đường chéo/thanh nối): hộp dài nằm giữa a và b.
function PatternKit.Rod(parent, a: Vector3, b: Vector3, thick: number, color: Color3, material, round: boolean?)
	local d = (b - a)
	local len = d.Magnitude
	local cf = CFrame.lookAt((a + b) / 2, b)
	if round then
		-- Cylinder có trục X: xoay để trục X trùng hướng a→b
		local c = CFrame.lookAt((a + b) / 2, b) * CFrame.Angles(0, math.rad(90), 0)
		return mk(parent, "Rod", Vector3.new(len, thick, thick), c, color, material, Enum.PartType.Cylinder)
	end
	return mk(parent, "Rod", Vector3.new(thick, thick, len), cf, color, material)
end

-- Weld mọi part vào root (WeldConstraint). Gọi SAU khi mọi CFrame đã đặt xong (đặt CFrame sau weld là bẫy).
function PatternKit.WeldAll(parts, root: BasePart, anchoredRoot: boolean?)
	for _, p in ipairs(parts) do
		if p ~= root then
			local w = Instance.new("WeldConstraint")
			w.Part0, w.Part1, w.Parent = root, p, p
		end
	end
	for _, p in ipairs(parts) do p.Anchored = false end
	if anchoredRoot then root.Anchored = true end
end

return PatternKit
