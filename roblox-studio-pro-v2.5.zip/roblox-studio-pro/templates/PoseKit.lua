--!nonstrict
-- PoseKit — pose procedural cho rig R15 (ghi vào AnimationConstraint.Transform trong PreSimulation).
-- Mỗi hàm Pose.* nhận phase 0..1 (hoặc t) và trả bảng { [tênKhớp] = CFrame offset }.
-- Dùng: PoseKit.Play(character, PoseKit.Walk, { Speed = 1.2 }) → trả hàm Stop().
-- Nhớ: translation làm rời chi → giữ ≤ 0.8 studs, đưa sải chân vào ROTATION (xem assets.md).

local RunService = game:GetService("RunService")

local PoseKit = {}
local rad = math.rad
local function R(x, y, z) return CFrame.Angles(rad(x or 0), rad(y or 0), rad(z or 0)) end

-- Chu kỳ đi bộ R15. phase 0..1. amp nhân biên độ.
function PoseKit.Walk(phase, amp)
	amp = amp or 1
	local s = math.sin(phase * 2 * math.pi)
	local c = math.cos(phase * 2 * math.pi)
	return {
		RightHip = R(s * 35 * amp), LeftHip = R(-s * 35 * amp),
		RightKnee = R(math.max(0, -c) * 45 * amp), LeftKnee = R(math.max(0, c) * 45 * amp),
		RightShoulder = R(-s * 28 * amp), LeftShoulder = R(s * 28 * amp),
		RightElbow = R(-15 * amp), LeftElbow = R(-15 * amp),
		Waist = R(0, s * 5 * amp, 0), Root = CFrame.new(0, math.abs(c) * 0.15 * amp, 0),
	}
end

function PoseKit.Idle(phase, amp)
	amp = amp or 1
	local s = math.sin(phase * 2 * math.pi)
	return { Waist = R(s * 1.5 * amp), RightShoulder = R(0, 0, -4 - s * 1.5), LeftShoulder = R(0, 0, 4 + s * 1.5), Neck = R(-s * 1) }
end

-- Vung kiếm chém xuống: phase 0 (giơ) → 0.4 (chém) → 1 (hồi). Dùng với Play(..., { Loop = false }).
function PoseKit.SwordSlash(phase)
	local function ease(t) return 1 - (1 - t) ^ 3 end
	local wind = math.clamp(phase / 0.3, 0, 1)
	local hit = math.clamp((phase - 0.3) / 0.2, 0, 1)
	local back = math.clamp((phase - 0.6) / 0.4, 0, 1)
	local k = ease(wind) * (1 - ease(hit)) + (1 - ease(back)) * ease(hit) * 0 -- giơ → chém
	local arm = -150 * ease(wind) + 190 * ease(hit)
	arm = arm * (1 - ease(back))
	return {
		RightShoulder = R(arm, 0, -20 * k), RightElbow = R(-40 * (1 - ease(hit))),
		Waist = R(-8 * ease(wind) + 20 * ease(hit) * (1 - ease(back)), 15 * ease(hit) * (1 - ease(back)), 0),
		Root = CFrame.new(0, 0, -1.2 * ease(hit) * (1 - ease(back))),
	}
end

-- Nhảy-vòng/ngồi (crouch) tĩnh để kết thúc skill.
function PoseKit.Crouch(_, amp)
	amp = amp or 1
	return { RightHip = R(-70 * amp), LeftHip = R(-70 * amp), RightKnee = R(100 * amp), LeftKnee = R(100 * amp), Root = CFrame.new(0, -1.1 * amp, 0) }
end

-- Chạy pose: ghi Transform mỗi PreSimulation. opts: Speed (chu kỳ/giây), Amp, Loop (mặc định true), Duration.
function PoseKit.Play(character: Model, poseFn, opts)
	opts = opts or {}
	local joints = {}
	for _, d in ipairs(character:GetDescendants()) do
		if d:IsA("AnimationConstraint") then joints[d.Name] = d end
	end
	if next(joints) == nil then warn("[PoseKit] không có AnimationConstraint (rig R15?)"); return function() end end
	local t0 = os.clock()
	local conn
	local function stop()
		if conn then conn:Disconnect(); conn = nil end
		for _, j in pairs(joints) do if j.Parent then j.Transform = CFrame.identity end end
	end
	conn = RunService.PreSimulation:Connect(function()
		if not character.Parent then stop() return end
		local t = (os.clock() - t0)
		local phase = (t * (opts.Speed or 1)) % 1
		if opts.Loop == false then
			phase = math.clamp(t / (opts.Duration or 1), 0, 1)
			if phase >= 1 then stop() return end
		end
		local pose = poseFn(phase, opts.Amp)
		for name, cf in pairs(pose) do
			local j = joints[name]
			if j then j.Transform = cf end
		end
	end)
	return stop
end

return PoseKit
