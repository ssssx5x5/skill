--!strict
-- Orient: phép toán hướng/xoay cho Roblox. Trước = −Z, phải = +X, lên = +Y.
local Orient = {}

-- Hướng chuẩn theo lời
Orient.Dir = {
	Forward = Vector3.new(0, 0, -1), Back = Vector3.new(0, 0, 1),
	Right = Vector3.new(1, 0, 0), Left = Vector3.new(-1, 0, 0),
	Up = Vector3.new(0, 1, 0), Down = Vector3.new(0, -1, 0),
}

-- Pha hai hướng: cos(deg)*chính + sin(deg)*phụ ("trước và hơi lên" = 30°)
function Orient.Blend(main: Vector3, secondary: Vector3, deg: number): Vector3
	local r = math.rad(deg)
	return (main.Unit * math.cos(r) + secondary.Unit * math.sin(r)).Unit
end

-- Xoay vật sao cho trục "mũi" (tip, hệ vật) chỉ đúng hướng dir; giữ up gần upHint nhất
function Orient.PointAxis(position: Vector3, tipAxis: Vector3, dir: Vector3, upHint: Vector3?): CFrame
	local up = upHint or Vector3.yAxis
	local look = CFrame.lookAt(Vector3.zero, dir, if math.abs(dir.Unit:Dot(up.Unit)) > 0.999 then Vector3.zAxis else up)
	-- khung vật: kéo tipAxis về −Z rồi áp look
	local tip = tipAxis.Unit
	local fromTip = CFrame.lookAt(Vector3.zero, tip, if math.abs(tip.Y) > 0.9 then Vector3.zAxis else Vector3.yAxis)
	return CFrame.new(position) * (look * fromTip:Inverse()).Rotation
end

-- Kiểm tra sau khi dựng: trục của part có chỉ đúng hướng mong muốn (sai số độ)
function Orient.AssertAxis(part: BasePart, localAxis: Vector3, wantDir: Vector3, tolDeg: number?): boolean
	local actual = part.CFrame:VectorToWorldSpace(localAxis.Unit)
	local ang = math.deg(math.acos(math.clamp(actual:Dot(wantDir.Unit), -1, 1)))
	if ang > (tolDeg or 2) then
		warn(string.format("[Orient] %s lệch %.1f° so với hướng mong muốn", part:GetFullName(), ang))
		return false
	end
	return true
end

-- Grip = HandRel⁻¹ · RGA (HandRel = CFrame mong muốn của vật trong khung bàn tay)
function Orient.GripFromHandRel(handRel: CFrame, rightGripAttachment: CFrame): CFrame
	return handRel:Inverse() * rightGripAttachment
end

return Orient
