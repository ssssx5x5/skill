local fails = 0
local function check(name, cond) if cond then print("[PASS] " .. name) else fails += 1; print("[FAIL] " .. name) end end

check("number hợp lệ", Validate.number(5, 0, 10) == 5)
check("number NaN bị chặn", Validate.number(0 / 0, 0, 10) == nil)
check("number inf bị chặn", Validate.number(math.huge, 0, 10) == nil)
check("number ngoài khoảng", Validate.number(11, 0, 10) == nil)
check("number sai kiểu", Validate.number("5", 0, 10) == nil)
check("integer 2.5 bị chặn", Validate.integer(2.5, 0, 10) == nil)
check("string quá dài", Validate.string(string.rep("a", 50), 20) == nil)
check("string pattern", Validate.string("abc_1", 20, "^[%w_]+$") == "abc_1" and Validate.string("a b", 20, "^[%w_]+$") == nil)
check("oneOf", Validate.oneOf("Dash", { "Fireball", "Dash" }) == "Dash" and Validate.oneOf("Hack", { "Fireball", "Dash" }) == nil)

local cd = Validate.newCooldown(1)
check("cooldown lần đầu qua", cd("a", 0) == true)
check("cooldown chặn trong 1s", cd("a", 0.5) == false)
check("cooldown qua sau 1s", cd("a", 1.2) == true)
check("cooldown key khác độc lập", cd("b", 0.5) == true)

local rl = Validate.newRateLimit(3, 1)
check("rate 3 lần đầu", rl("u", 0) and rl("u", 0.1) and rl("u", 0.2))
check("rate lần 4 bị chặn", rl("u", 0.3) == false)
check("rate sau cửa sổ qua lại", rl("u", 1.5) == true)

if fails > 0 then error("test fail: " .. fails) end
print("ALL PASS")
