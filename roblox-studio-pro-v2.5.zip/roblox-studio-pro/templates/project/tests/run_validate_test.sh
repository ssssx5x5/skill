#!/usr/bin/env bash
# Ghép Validate.lua (bỏ dòng `return Validate`) + test thành một file rồi chạy bằng luau CLI.
# Dùng: LUAU=/đường/dẫn/luau bash tests/run_validate_test.sh   (chạy từ thư mục templates/project/)
set -e
LUAU="${LUAU:-luau}"
T=$(mktemp --suffix=.lua)
{ echo "local Validate = (function()"; sed '$d' src/shared/Validate.lua | sed '/^--!strict/d'; echo "return Validate end)()"; cat tests/validate_body.lua; } > "$T"
"$LUAU" "$T"
