--!nonstrict
-- DataService — lưu dữ liệu an toàn mức cơ bản: UpdateAsync + retry + autosave + BindToClose + khoá phiên nhẹ.
-- Game thật nhiều người/dữ liệu quan trọng: dùng ProfileStore (xem references/networking-data.md).
local DataStoreService = game:GetService("DataStoreService")
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")

local DEFAULTS = { Coins = 0, Level = 1 } -- schema mặc định; thêm field mới ở đây, không đổi tên field cũ
local SCHEMA_VERSION = 1
local AUTOSAVE = 120
local LOCK_TIMEOUT = 90 -- giây: khoá phiên cũ hơn mức này coi như treo

local store = DataStoreService:GetDataStore("PlayerData_v1")
local cache: { [number]: { [string]: any } } = {}
local jobId = game.JobId ~= "" and game.JobId or "studio"

local DataService = {}

local function retry(fn, tries)
	local err
	for i = 1, tries or 4 do
		local ok, res = pcall(fn)
		if ok then return true, res end
		err = res
		task.wait(2 ^ i * 0.5)
	end
	return false, err
end

local function reconcile(data)
	for k, v in pairs(DEFAULTS) do if data[k] == nil then data[k] = v end end
	data._v = SCHEMA_VERSION
	return data
end

function DataService.Load(player: Player)
	local key = "u_" .. player.UserId
	local locked = false
	local ok, data = retry(function()
		return store:UpdateAsync(key, function(old)
			old = old or {}
			local lock = old._lock
			if lock and lock.job ~= jobId and os.time() - lock.t < LOCK_TIMEOUT then
				locked = true
				return nil -- server khác đang giữ: không ghi
			end
			locked = false
			old._lock = { job = jobId, t = os.time() }
			return old
		end)
	end)
	if not ok then warn("[DataService] load lỗi:", data); player:Kick("Không tải được dữ liệu, thử lại sau."); return end
	if locked then player:Kick("Dữ liệu đang được dùng ở server khác."); return end
	if not player.Parent then return end -- thoát giữa chừng
	cache[player.UserId] = reconcile(data or {})
	return cache[player.UserId]
end

function DataService.Get(player: Player)
	return cache[player.UserId]
end

function DataService.Save(player: Player, release: boolean?)
	local data = cache[player.UserId]
	if not data then return end
	local key = "u_" .. player.UserId
	local ok, err = retry(function()
		return store:UpdateAsync(key, function(old)
			old = old or {}
			if old._lock and old._lock.job ~= jobId and os.time() - old._lock.t < LOCK_TIMEOUT then return nil end
			local out = table.clone(data)
			out._lock = (not release) and { job = jobId, t = os.time() } or nil
			return out
		end)
	end)
	if not ok then warn("[DataService] save lỗi:", err) end
end

function DataService.Start()
	Players.PlayerAdded:Connect(function(p) DataService.Load(p) end)
	for _, p in ipairs(Players:GetPlayers()) do task.spawn(DataService.Load, p) end
	Players.PlayerRemoving:Connect(function(p)
		DataService.Save(p, true)
		cache[p.UserId] = nil
	end)
	task.spawn(function()
		while true do
			task.wait(AUTOSAVE)
			for _, p in ipairs(Players:GetPlayers()) do task.spawn(DataService.Save, p) end
		end
	end)
	game:BindToClose(function()
		if RunService:IsStudio() then return end
		for _, p in ipairs(Players:GetPlayers()) do DataService.Save(p, true) end
	end)
end

return DataService
