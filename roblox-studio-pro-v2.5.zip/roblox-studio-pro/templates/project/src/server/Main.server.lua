--!nonstrict
-- Bootstrap server: require service theo thứ tự, mỗi remote đi qua Validate.
local RS = game:GetService("ReplicatedStorage")
local Remotes = require(RS.Shared.Remotes)
local Validate = require(RS.Shared.Validate)
local DataService = require(script.Parent.DataService)

DataService.Start()

local SKILLS = { "Fireball", "Dash" } -- danh sách skill hợp lệ (name contract)
local cooldown = Validate.newCooldown(0.5)
local rate = Validate.newRateLimit(8, 2)

Remotes.Get("UseSkill").OnServerEvent:Connect(function(player, skill, aimPos)
	local now = os.clock()
	if not rate(tostring(player.UserId), now) then return end
	local name = Validate.oneOf(skill, SKILLS)
	if not name then return end
	if typeof(aimPos) ~= "Vector3" then return end
	if not cooldown(player.UserId .. ":" .. name, now) then return end
	local char = player.Character
	local root = char and char:FindFirstChild("HumanoidRootPart")
	if not root then return end
	if (aimPos - root.Position).Magnitude > 200 then return end -- khoảng cách hợp lý
	-- Server quyết kết quả; client chỉ nhận lệnh PHÁT hiệu ứng.
	Remotes.Get("FxPlay"):FireAllClients(name, aimPos, player.UserId)
end)
