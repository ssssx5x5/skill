--!nonstrict
-- Bootstrap client: nhận lệnh phát VFX từ server, gửi ý định (không gửi kết quả).
local RS = game:GetService("ReplicatedStorage")
local UIS = game:GetService("UserInputService")
local Remotes = require(RS.Shared.Remotes)
local VFX = require(RS.Shared.VFXKit) -- copy templates/VFXKit.lua vào src/shared/

VFX.AutoQuality()

Remotes.Get("FxPlay").OnClientEvent:Connect(function(name, pos)
	if name == "Fireball" then VFX.Explosion(pos, { Scale = 1 }) end
	if name == "Dash" then VFX.Impact(pos, Color3.fromRGB(150, 200, 255)) end
end)

UIS.InputBegan:Connect(function(input, gp)
	if gp then return end
	if input.KeyCode == Enum.KeyCode.E then
		local cam = workspace.CurrentCamera
		local hit = workspace:Raycast(cam.CFrame.Position, cam.CFrame.LookVector * 150)
		Remotes.Get("UseSkill"):FireServer("Fireball", hit and hit.Position or (cam.CFrame.Position + cam.CFrame.LookVector * 50))
	end
end)
