--!strict
-- Validate — kiểm tham số remote. Pure Luau (không dùng API Roblox) nên test được bằng `luau`/Lune.
-- Nguyên tắc: client gửi Ý ĐỊNH, server kiểm kiểu, khoảng, cooldown, khoảng cách.
local Validate = {}

function Validate.number(v: any, min: number, max: number): number?
	if type(v) ~= "number" or v ~= v or v == math.huge or v == -math.huge then return nil end -- chặn NaN/inf
	if v < min or v > max then return nil end
	return v
end

function Validate.integer(v: any, min: number, max: number): number?
	local n = Validate.number(v, min, max)
	if n and n == math.floor(n) then return n end
	return nil
end

function Validate.string(v: any, maxLen: number, pattern: string?): string?
	if type(v) ~= "string" or #v == 0 or #v > maxLen then return nil end
	if pattern and not string.match(v, pattern) then return nil end
	return v
end

function Validate.oneOf(v: any, allowed: { string }): string?
	for _, a in ipairs(allowed) do if v == a then return v end end
	return nil
end

-- Cooldown theo key (vd userId .. ":" .. tên remote). `now` truyền vào để test được.
function Validate.newCooldown(seconds: number)
	local last: { [string]: number } = {}
	return function(key: string, now: number): boolean
		local prev = last[key]
		if prev and now - prev < seconds then return false end
		last[key] = now
		return true
	end
end

-- Cửa sổ trượt: tối đa `max` lần trong `window` giây (chống spam remote).
function Validate.newRateLimit(max: number, window: number)
	local hist: { [string]: { number } } = {}
	return function(key: string, now: number): boolean
		local h = hist[key] or {}
		hist[key] = h
		local i = 1
		while h[i] and now - h[i] > window do i += 1 end
		if i > 1 then
			local nh = {}
			for k = i, #h do nh[#nh + 1] = h[k] end
			h = nh
			hist[key] = h
		end
		if #h >= max then return false end
		h[#h + 1] = now
		return true
	end
end

return Validate
