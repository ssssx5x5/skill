--!nonstrict
-- VFXKit — thư viện hiệu ứng dùng lại (ModuleScript, đặt ở ReplicatedStorage; gọi từ CLIENT).
-- Mọi hàm: không rò instance (Debris), không dùng wait(), có tham số Scale, tự giảm chất lượng theo Quality.
-- Dùng:  local VFX = require(ReplicatedStorage.VFXKit)
--        VFX.Explosion(Vector3.new(0, 5, 0), { Scale = 2 })

local Debris = game:GetService("Debris")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local Lighting = game:GetService("Lighting")
local Workspace = game:GetService("Workspace")

local VFX = {}

-- ===== Cấu hình =====
VFX.Quality = 1 -- 0.25..1 ; nhân số hạt/mảnh. Gọi VFX.AutoQuality() để tự chỉnh.
local MAX_ACTIVE_PARTS = 400 -- ngân sách part hiệu ứng cùng lúc
local active = 0

local folder = Workspace:FindFirstChild("_VFX")
if not folder then
	folder = Instance.new("Folder")
	folder.Name = "_VFX"
	folder.Parent = Workspace
end

-- ===== Tiện ích lõi =====
local function clamp01(x: number): number
	return math.clamp(x, 0, 1)
end

local EASE = {
	out = function(t) return 1 - (1 - t) ^ 3 end,
	inn = function(t) return t ^ 3 end,
	lin = function(t) return t end,
	inout = function(t) return t < 0.5 and 4 * t ^ 3 or 1 - (-2 * t + 2) ^ 3 / 2 end,
}
VFX.Ease = EASE

-- Part hiệu ứng: neon, không va chạm, không bóng, bị dọn tự động.
local function fxPart(shape: Enum.PartType, cf: CFrame, size: Vector3, color: Color3, life: number, mat: Enum.Material?)
	if active >= MAX_ACTIVE_PARTS then return nil end -- vượt ngân sách thì bỏ, không lag
	local p = Instance.new("Part")
	p.Shape = shape
	p.Anchored, p.CanCollide, p.CanTouch, p.CanQuery, p.CastShadow = true, false, false, false, false
	p.Material = mat or Enum.Material.Neon
	p.Color = color
	p.Size = size
	p.CFrame = cf
	p.TopSurface, p.BottomSurface = Enum.SurfaceType.Smooth, Enum.SurfaceType.Smooth
	p.Parent = folder -- set Parent CUỐI
	active += 1
	Debris:AddItem(p, life + 0.5)
	task.delay(life + 0.5, function() active = math.max(0, active - 1) end)
	return p
end

-- Chạy hàm f(alpha 0..1) trong `dur` giây bằng MỘT kết nối Heartbeat (không chuỗi task.wait).
function VFX.Drive(dur: number, f: (number, number) -> (), onDone: (() -> ())?)
	local t0 = os.clock()
	local conn
	conn = RunService.Heartbeat:Connect(function()
		local t = os.clock() - t0
		local a = clamp01(t / dur)
		local ok, err = pcall(f, a, t)
		if not ok then warn("[VFXKit] Drive lỗi:", err) a = 1 end
		if a >= 1 then
			conn:Disconnect()
			if onDone then onDone() end
		end
	end)
	return conn
end

-- Tween thuộc tính 1 instance rồi tự dọn.
function VFX.Tween(inst: Instance, dur: number, props: { [string]: any }, style: Enum.EasingStyle?, dir: Enum.EasingDirection?)
	local tw = TweenService:Create(inst, TweenInfo.new(dur, style or Enum.EasingStyle.Quad, dir or Enum.EasingDirection.Out), props)
	tw:Play()
	return tw
end

-- ===== Ánh sáng tức thời =====
function VFX.LightFlash(pos: Vector3, color: Color3, brightness: number, range: number, dur: number)
	local host = fxPart(Enum.PartType.Ball, CFrame.new(pos), Vector3.one * 0.2, color, dur)
	if not host then return end
	host.Transparency = 1
	local l = Instance.new("PointLight")
	l.Color, l.Brightness, l.Range, l.Shadows = color, brightness, range, false
	l.Parent = host
	VFX.Tween(l, dur, { Brightness = 0, Range = 0 }, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
end

-- ===== Hình khối =====
-- Quả cầu neon nở ra rồi mờ.
function VFX.Ball(pos: Vector3, radius: number, color: Color3, dur: number, endColor: Color3?)
	local p = fxPart(Enum.PartType.Ball, CFrame.new(pos), Vector3.one * 0.5, color, dur)
	if not p then return end
	local c1 = endColor or color
	VFX.Drive(dur, function(a)
		local e = EASE.out(a)
		p.Size = Vector3.one * math.max(0.5, radius * 2 * e)
		p.Color = color:Lerp(c1, e)
		p.Transparency = clamp01((a - 0.3) / 0.7)
	end)
	return p
end

-- Vòng sóng nở trên mặt phẳng (Cylinder dẹt; trục tròn của Cylinder là X nên xoay 90° quanh Z).
function VFX.Ring(pos: Vector3, maxRadius: number, dur: number, color: Color3?, thick: number?, normal: Vector3?)
	local th = thick or 0.6
	local n = (normal or Vector3.yAxis).Unit
	local base = CFrame.lookAt(pos, pos + n) * CFrame.Angles(0, math.pi / 2, 0)
	local p = fxPart(Enum.PartType.Cylinder, base, Vector3.new(th, 1, 1), color or Color3.new(1, 1, 1), dur)
	if not p then return end
	VFX.Drive(dur, function(a)
		local d = math.max(1, maxRadius * 2 * EASE.out(a))
		p.Size = Vector3.new(th, d, d)
		p.Transparency = a ^ 1.5
	end)
	return p
end

-- Mảnh vỡ/tia lửa văng theo đạn đạo (tự tính, không dùng physics → rẻ, không đồng bộ mạng).
function VFX.Shards(pos: Vector3, count: number, speed: number, dur: number, color: Color3, size: number?, gravity: number?, dirBias: Vector3?)
	count = math.max(1, math.floor(count * VFX.Quality))
	local g = gravity or 60
	local rng = Random.new()
	for _ = 1, count do
		local dir = (rng:NextUnitVector() + (dirBias or Vector3.zero)).Unit
		local v0 = dir * speed * rng:NextNumber(0.5, 1)
		local s = (size or 0.6) * rng:NextNumber(0.6, 1.4)
		local p = fxPart(Enum.PartType.Block, CFrame.new(pos), Vector3.new(s, s * 0.35, s * 0.35), color, dur)
		if not p then break end
		local spin = CFrame.Angles(rng:NextNumber(-8, 8), rng:NextNumber(-8, 8), rng:NextNumber(-8, 8))
		local rot = CFrame.identity
		VFX.Drive(dur, function(a, t)
			local x = pos + v0 * t + Vector3.new(0, -0.5 * g * t * t, 0)
			rot = rot * CFrame.Angles(spin.X * 0.016, spin.Y * 0.016, spin.Z * 0.016)
			p.CFrame = CFrame.new(x) * rot
			p.Transparency = clamp01((a - 0.6) / 0.4)
		end)
	end
end

-- Sét giữa a và b: nhiều đoạn lệch ngẫu nhiên, hai đầu bám đúng, giật lại mỗi frame.
function VFX.Lightning(a: Vector3, b: Vector3, dur: number, color: Color3?, thick: number?, segs: number?, jag: number?)
	local n = segs or 12
	local th = thick or 0.35
	local col = color or Color3.fromRGB(170, 200, 255)
	local parts = {}
	for i = 1, n do
		local p = fxPart(Enum.PartType.Block, CFrame.new(a), Vector3.new(th, th, 1), col, dur)
		if not p then break end
		parts[i] = p
	end
	if #parts == 0 then return end
	local fwd = (b - a)
	local len = fwd.Magnitude
	local f = fwd.Unit
	local right = f:Cross(Vector3.yAxis)
	if right.Magnitude < 1e-3 then right = f:Cross(Vector3.xAxis) end
	right = right.Unit
	local up = right:Cross(f).Unit
	local rng = Random.new()
	local amp = jag or math.max(1, len * 0.08)
	VFX.Drive(dur, function(alpha)
		local pts = { a }
		for i = 1, n - 1 do
			local t = i / n
			local taper = math.sin(math.pi * t)
			pts[#pts + 1] = a + f * (len * t) + right * (rng:NextNumber(-1, 1) * amp * taper) + up * (rng:NextNumber(-1, 1) * amp * taper)
		end
		pts[#pts + 1] = b
		for i, p in ipairs(parts) do
			local p0, p1 = pts[i], pts[i + 1]
			local d = (p1 - p0).Magnitude
			p.Size = Vector3.new(th * (1 - alpha * 0.6), th * (1 - alpha * 0.6), math.max(0.05, d))
			p.CFrame = CFrame.lookAt((p0 + p1) / 2, p1)
			p.Transparency = clamp01((alpha - 0.5) * 2)
		end
	end)
end

-- Vết chém cong (Beam cong) — gọi với cung từ `from` tới `to`, độ cong `bend` (studs).
function VFX.Slash(from: Vector3, to: Vector3, bend: number, dur: number, color: Color3?, width: number?)
	local mid = (from + to) / 2 + Vector3.yAxis * bend
	local h0 = fxPart(Enum.PartType.Ball, CFrame.new(from), Vector3.one * 0.1, Color3.new(), dur)
	local h1 = fxPart(Enum.PartType.Ball, CFrame.new(to), Vector3.one * 0.1, Color3.new(), dur)
	if not h0 or not h1 then return end
	h0.Transparency, h1.Transparency = 1, 1
	local a0, a1 = Instance.new("Attachment"), Instance.new("Attachment")
	a0.Parent, a1.Parent = h0, h1
	local beam = Instance.new("Beam")
	beam.Attachment0, beam.Attachment1 = a0, a1
	beam.Color = ColorSequence.new(color or Color3.new(1, 1, 1))
	beam.Width0, beam.Width1 = (width or 3), 0
	beam.LightEmission, beam.FaceCamera = 1, true
	beam.CurveSize0, beam.CurveSize1 = bend, -bend
	beam.Segments = 20
	beam.Transparency = NumberSequence.new(0)
	beam.Parent = h0
	VFX.Drive(dur, function(a)
		beam.Transparency = NumberSequence.new(clamp01(a ^ 2))
		beam.Width0 = (width or 3) * (1 - a)
	end)
	_ = mid
end

-- ===== Màn hình =====
-- Rung camera: dịch camera (không rung nhân vật). Tắt dần tuyến tính.
local shakeUntil, shakeAmp = 0, 0
local shakeConn
function VFX.Shake(amp: number, dur: number)
	local cam = Workspace.CurrentCamera
	if not cam then return end
	shakeAmp = math.max(shakeAmp, amp)
	shakeUntil = math.max(shakeUntil, os.clock() + dur)
	local t0, d0 = os.clock(), dur
	if shakeConn then return end
	local rng = Random.new()
	shakeConn = RunService:BindToRenderStep("VFXKitShake", Enum.RenderPriority.Camera.Value + 1, function()
		local now = os.clock()
		if now >= shakeUntil then
			RunService:UnbindFromRenderStep("VFXKitShake")
			shakeConn, shakeAmp = nil, 0
			return
		end
		local k = clamp01((shakeUntil - now) / math.max(d0, 0.05))
		local o = Vector3.new(rng:NextNumber(-1, 1), rng:NextNumber(-1, 1), 0) * shakeAmp * k
		cam.CFrame = cam.CFrame * CFrame.new(o)
		_ = t0
	end)
	shakeConn = true
end

-- Chớp trắng toàn màn (ScreenGui tạm, không chặn input).
function VFX.ScreenFlash(color: Color3, peak: number, dur: number)
	local pg = game:GetService("Players").LocalPlayer and game:GetService("Players").LocalPlayer:FindFirstChildOfClass("PlayerGui")
	if not pg then return end
	local gui = Instance.new("ScreenGui")
	gui.IgnoreGuiInset, gui.ResetOnSpawn, gui.DisplayOrder = true, false, 100
	local f = Instance.new("Frame")
	f.Size, f.BackgroundColor3, f.BackgroundTransparency, f.BorderSizePixel = UDim2.fromScale(1, 1), color, 1 - peak, 0
	f.Active = false
	f.Parent = gui
	gui.Parent = pg
	Debris:AddItem(gui, dur + 0.3)
	VFX.Tween(f, dur, { BackgroundTransparency = 1 })
end

-- Xung Bloom/ColorCorrection tạm thời rồi khôi phục (nhớ giá trị gốc → không bị kẹt).
function VFX.BloomPulse(intensity: number, dur: number)
	local b = Instance.new("BloomEffect")
	b.Intensity, b.Size, b.Threshold = intensity, 30, 0.8
	b.Parent = Lighting
	Debris:AddItem(b, dur + 0.3)
	VFX.Tween(b, dur, { Intensity = 0 })
end

-- Hitstop: đóng băng animation đang chạy trong `dur` giây rồi trả tốc độ.
function VFX.HitStop(humanoid: Humanoid, dur: number)
	local animator = humanoid:FindFirstChildOfClass("Animator")
	if not animator then return end
	local tracks = animator:GetPlayingAnimationTracks()
	for _, t in ipairs(tracks) do t:AdjustSpeed(0) end
	task.delay(dur, function()
		for _, t in ipairs(tracks) do
			if t.IsPlaying then t:AdjustSpeed(1) end
		end
	end)
end

-- ===== Particle emitter nhanh =====
-- preset: "Fire" | "Smoke" | "Sparks" | "Dust" | "Aura" | "Heal"
local PRESETS = {
	Fire = { Rate = 40, Lifetime = NumberRange.new(0.6, 1.1), Speed = NumberRange.new(3, 6), Accel = Vector3.new(0, 8, 0), Spread = Vector2.new(10, 10),
		Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1.5), NumberSequenceKeypoint.new(1, 0) }),
		Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 220, 90)), ColorSequenceKeypoint.new(0.5, Color3.fromRGB(255, 120, 30)), ColorSequenceKeypoint.new(1, Color3.fromRGB(120, 20, 10)) }),
		Light = 1, Tex = "rbxasset://textures/particles/fire_main.dds" },
	Smoke = { Rate = 12, Lifetime = NumberRange.new(2, 3.5), Speed = NumberRange.new(2, 8), Accel = Vector3.new(0, 4, 0), Spread = Vector2.new(30, 30), Drag = 2,
		Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 3), NumberSequenceKeypoint.new(1, 12) }),
		Color = ColorSequence.new(Color3.fromRGB(70, 70, 75)), Light = 0, Tex = "rbxasset://textures/particles/smoke_main.dds", Transp0 = 0.3 },
	Sparks = { Rate = 0, Lifetime = NumberRange.new(0.3, 0.8), Speed = NumberRange.new(30, 80), Accel = Vector3.new(0, -80, 0), Spread = Vector2.new(180, 180),
		Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.5), NumberSequenceKeypoint.new(1, 0) }),
		Color = ColorSequence.new(Color3.fromRGB(255, 200, 100)), Light = 1, Tex = "rbxasset://textures/particles/sparkles_main.dds", Velocity = true },
	Dust = { Rate = 0, Lifetime = NumberRange.new(1, 2), Speed = NumberRange.new(5, 15), Accel = Vector3.new(0, 1, 0), Spread = Vector2.new(60, 60), Drag = 3,
		Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 2), NumberSequenceKeypoint.new(1, 6) }),
		Color = ColorSequence.new(Color3.fromRGB(150, 130, 105)), Light = 0, Tex = "rbxasset://textures/particles/smoke_main.dds", Transp0 = 0.4 },
	Aura = { Rate = 30, Lifetime = NumberRange.new(1, 1.5), Speed = NumberRange.new(0, 1), Accel = Vector3.new(0, 3, 0), Spread = Vector2.new(180, 180),
		Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.6), NumberSequenceKeypoint.new(1, 0) }),
		Color = ColorSequence.new(Color3.fromRGB(150, 120, 255)), Light = 1, Tex = "rbxasset://textures/particles/sparkles_main.dds" },
	Heal = { Rate = 20, Lifetime = NumberRange.new(1, 1.6), Speed = NumberRange.new(1, 3), Accel = Vector3.new(0, 6, 0), Spread = Vector2.new(30, 30),
		Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.5), NumberSequenceKeypoint.new(1, 0) }),
		Color = ColorSequence.new(Color3.fromRGB(120, 255, 160)), Light = 1, Tex = "rbxasset://textures/particles/sparkles_main.dds" },
}

-- Texture tuỳ chỉnh (sinh bằng scripts/gen_vfx_textures.py rồi upload). Để trống = dùng texture có sẵn của engine.
-- VFX.SetTextures({ Fire = "rbxassetid://<id thật>", Smoke = "...", Sparks = "...", Aura = "..." })
function VFX.SetTextures(map)
	for preset, id in pairs(map) do
		if PRESETS[preset] and type(id) == "string" and id ~= "" then PRESETS[preset].Tex = id
		else warn("[VFXKit] SetTextures bỏ qua '" .. tostring(preset) .. "'") end
	end
end

-- Flipbook: bật lưới 4x4 cho emitter (texture là sheet từ fire_flipbook/smoke_flipbook).
function VFX.UseFlipbook(emitter, loop)
	emitter.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
	emitter.FlipbookMode = loop and Enum.ParticleFlipbookMode.Loop or Enum.ParticleFlipbookMode.OneShot
	emitter.FlipbookStartRandom = true
end

-- Trả ParticleEmitter gắn vào `parent` (Part/Attachment). Tự điều chỉnh Rate theo Quality.
function VFX.Emitter(parent: Instance, preset: string, scale: number?, overrides: { [string]: any }?)
	local d = PRESETS[preset]
	assert(d, "[VFXKit] preset không có: " .. tostring(preset))
	local s = scale or 1
	local e = Instance.new("ParticleEmitter")
	e.Texture = d.Tex
	e.Rate = d.Rate * VFX.Quality
	e.Lifetime, e.Speed = d.Lifetime, NumberRange.new(d.Speed.Min * s, d.Speed.Max * s)
	e.Acceleration, e.SpreadAngle = d.Accel, d.Spread
	e.Drag = d.Drag or 0
	e.LightEmission = d.Light
	e.Color = d.Color
	local keys = {}
	for _, k in ipairs(d.Size.Keypoints) do keys[#keys + 1] = NumberSequenceKeypoint.new(k.Time, k.Value * s) end
	e.Size = NumberSequence.new(keys)
	local t0 = d.Transp0 or 0
	e.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, t0), NumberSequenceKeypoint.new(0.7, t0 + (1 - t0) * 0.3), NumberSequenceKeypoint.new(1, 1) })
	if d.Velocity then e.Orientation = Enum.ParticleOrientation.VelocityParallel end
	e.Rotation, e.RotSpeed = NumberRange.new(0, 360), NumberRange.new(-60, 60)
	if overrides then
		for k, v in pairs(overrides) do
			local ok, err = pcall(function() (e :: any)[k] = v end)
			if not ok then warn("[VFXKit] override '" .. k .. "' lỗi:", err) end
		end
	end
	e.Parent = parent
	return e
end

-- Bắn một đợt hạt rồi dọn host.
function VFX.Burst(pos: Vector3, preset: string, count: number, scale: number?, life: number?)
	local host = fxPart(Enum.PartType.Ball, CFrame.new(pos), Vector3.one * 0.2, Color3.new(), (life or 4))
	if not host then return end
	host.Transparency = 1
	local e = VFX.Emitter(host, preset, scale, { Rate = 0 })
	e:Emit(math.max(1, math.floor(count * VFX.Quality)))
end

-- ===== Công thức ghép sẵn (frame: instant → body → detail → feel → cleanup) =====
function VFX.Explosion(pos: Vector3, opts: { Scale: number?, Color: Color3? }?)
	local s = opts and opts.Scale or 1
	local c = opts and opts.Color or Color3.fromRGB(255, 140, 40)
	local up = pos + Vector3.new(0, 2 * s, 0)
	VFX.LightFlash(up, c, 3, 22 * s, 0.5) -- đo thực tế: Brightness 9/Range 16 làm trắng viewport → giữ ≤3
	VFX.Ball(up, 7 * s, Color3.fromRGB(255, 240, 200), 0.8, Color3.fromRGB(255, 110, 30))
	VFX.Ring(pos + Vector3.new(0, 0.3, 0), 24 * s, 0.7, Color3.fromRGB(255, 200, 140), 1.2 * s)
	VFX.Shards(up, 30, 60 * s, 1.4, c, 0.7 * s, 70)
	VFX.Burst(up, "Sparks", 60, s, 2)
	VFX.Burst(up, "Smoke", 14, s, 5)
	local cam = Workspace.CurrentCamera
	local dist = cam and (cam.CFrame.Position - pos).Magnitude or 0
	VFX.Shake(1.2 * s * clamp01(1 - dist / (60 * s)), 0.5)
end

function VFX.Impact(pos: Vector3, color: Color3?, scale: number?)
	local s = scale or 1
	local c = color or Color3.new(1, 1, 1)
	VFX.LightFlash(pos, c, 3, 9 * s, 0.15)
	VFX.Ring(pos, 6.5 * s, 0.25, c, 0.4, nil) -- 6.5 studs: 12 studs làm trắng màn
	VFX.Burst(pos, "Sparks", 20, s, 1.5)
	VFX.Shake(0.4 * s, 0.2)
end

function VFX.Beam(a: Vector3, b: Vector3, dur: number, color: Color3?, width: number?)
	VFX.Lightning(a, b, dur, color, width or 0.5, 8, 0.6)
end

-- ===== Tự chỉnh Quality theo FPS (gọi 1 lần ở client) =====
function VFX.AutoQuality()
	local acc, n = 0, 0
	local conn
	conn = RunService.Heartbeat:Connect(function(dt)
		acc += dt n += 1
		if n >= 90 then
			local fps = n / acc
			VFX.Quality = fps > 50 and 1 or (fps > 35 and 0.6 or 0.3)
			acc, n = 0, 0
		end
	end)
	return conn
end

-- ===== Tự kiểm (gọi VFX.SelfTest() trong Command Bar lúc Play) =====
function VFX.SelfTest()
	local pos = Vector3.new(0, 10, 0)
	local before = #folder:GetChildren()
	VFX.Explosion(pos, { Scale = 1 })
	task.wait(0.2)
	local mid = #folder:GetChildren()
	print(("[VFXKit] part hiệu ứng trước=%d giữa=%d (phải >0 sau khi nổ)"):format(before, mid))
	task.wait(8)
	print(("[VFXKit] sau 8s còn=%d (phải về ~%d, nếu không là rò)"):format(#folder:GetChildren(), before))
end

return VFX
