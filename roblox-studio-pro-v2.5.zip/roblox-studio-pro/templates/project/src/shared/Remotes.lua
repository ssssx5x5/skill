--!nonstrict
-- Remotes — khai báo remote MỘT chỗ (name contract). Server tạo, client chờ có timeout.
local RS = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local NAMES = { Events = { "UseSkill", "FxPlay" }, Functions = { "GetProfile" } } -- thêm tên ở đây, nơi duy nhất

local Remotes = {}
local folder

if RunService:IsServer() then
	folder = Instance.new("Folder")
	folder.Name = "Remotes"
	for _, n in ipairs(NAMES.Events) do local r = Instance.new("RemoteEvent"); r.Name = n; r.Parent = folder end
	for _, n in ipairs(NAMES.Functions) do local r = Instance.new("RemoteFunction"); r.Name = n; r.Parent = folder end
	folder.Parent = RS
else
	folder = RS:WaitForChild("Remotes", 15) -- có timeout: không treo vĩnh viễn im lặng
	if not folder then warn("[Remotes] không thấy thư mục Remotes sau 15s (server chưa require module này?)") end
end

function Remotes.Get(name: string)
	local r = folder and folder:FindFirstChild(name)
	if not r then warn("[Remotes] thiếu remote '" .. name .. "'") end
	return r
end

return Remotes
