--!nonstrict
-- UIKit — thư viện UI/HUD dùng lại (client). Không cần asset: chỉ Frame/UIStroke/UIGradient/UICorner/TextLabel.
-- Nguyên tắc: Scale thay Offset, UIScale theo màn hình, không chặn input (Active=false cho lớp trang trí), mọi tween có dọn.
-- Dùng:  local UI = require(RS.UIKit);  local root = UI.Root("HUD")
--        local bar = UI.Bar(root, { Size = UDim2.fromScale(0.25, 0.035), Position = UDim2.fromScale(0.03, 0.92), Color = UI.Theme.Danger })
--        bar:Set(0.6)   -- thanh mất máu có vệt "trễ" đỏ

local TweenService = game:GetService("TweenService")
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")
local Workspace = game:GetService("Workspace")
local Debris = game:GetService("Debris")

local UI = {}

UI.Theme = {
	Bg = Color3.fromRGB(18, 20, 26), Panel = Color3.fromRGB(28, 31, 40), Stroke = Color3.fromRGB(70, 76, 96),
	Text = Color3.fromRGB(235, 238, 245), Dim = Color3.fromRGB(150, 156, 172),
	Accent = Color3.fromRGB(90, 170, 255), Good = Color3.fromRGB(90, 220, 140), Warn = Color3.fromRGB(255, 190, 80), Danger = Color3.fromRGB(255, 90, 90),
	Radius = UDim.new(0, 8), Font = Enum.Font.GothamMedium, FontBold = Enum.Font.GothamBold,
}
local T = UI.Theme

function UI.Tween(inst, dur, props, style, dir)
	local tw = TweenService:Create(inst, TweenInfo.new(dur, style or Enum.EasingStyle.Quad, dir or Enum.EasingDirection.Out), props)
	tw:Play()
	return tw
end

function UI.IsTouch() return UserInputService.TouchEnabled and not UserInputService.KeyboardEnabled end

-- ScreenGui gốc + UIScale theo chiều cao màn hình (1080 = 1.0). Mobile: giữ trong 0.7..1.2.
function UI.Root(name, displayOrder)
	local pg = Players.LocalPlayer:WaitForChild("PlayerGui", 10)
	local old = pg:FindFirstChild(name)
	if old then old:Destroy() end
	local gui = Instance.new("ScreenGui")
	gui.Name, gui.ResetOnSpawn, gui.IgnoreGuiInset, gui.DisplayOrder = name, false, false, displayOrder or 10
	gui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
	local sc = Instance.new("UIScale")
	sc.Parent = gui
	local cam = Workspace.CurrentCamera
	local function fit()
		local h = cam.ViewportSize.Y
		sc.Scale = math.clamp(h / 1080, UI.IsTouch() and 0.7 or 0.6, UI.IsTouch() and 1.2 or 1.4)
	end
	fit()
	cam:GetPropertyChangedSignal("ViewportSize"):Connect(fit)
	gui.Parent = pg
	return gui
end

local function corner(inst, r) local c = Instance.new("UICorner"); c.CornerRadius = r or T.Radius; c.Parent = inst; return c end
local function stroke(inst, col, th) local s = Instance.new("UIStroke"); s.Color = col or T.Stroke; s.Thickness = th or 1; s.ApplyStrokeMode = Enum.ApplyStrokeMode.Border; s.Parent = inst; return s end

function UI.Label(parent, text, opts)
	opts = opts or {}
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency, l.Text, l.TextColor3 = 1, text, opts.Color or T.Text
	l.Font, l.TextScaled, l.Size = opts.Bold and T.FontBold or T.Font, opts.Scaled ~= false, opts.Size or UDim2.fromScale(1, 1)
	l.Position, l.TextXAlignment = opts.Position or UDim2.new(), opts.Align or Enum.TextXAlignment.Center
	l.TextSize = opts.TextSize or 18
	l.Active = false
	l.Parent = parent
	return l
end

function UI.Panel(parent, opts)
	opts = opts or {}
	local f = Instance.new("Frame")
	f.BackgroundColor3, f.BackgroundTransparency, f.BorderSizePixel = opts.Color or T.Panel, opts.Transparency or 0.1, 0
	f.Size, f.Position, f.AnchorPoint = opts.Size or UDim2.fromScale(0.3, 0.3), opts.Position or UDim2.new(), opts.Anchor or Vector2.zero
	corner(f); stroke(f)
	f.Parent = parent
	return f
end

-- Nút: hover sáng, nhấn nhún (scale 0.96), click gọi onClick. Dùng được cả chuột lẫn cảm ứng.
function UI.Button(parent, text, onClick, opts)
	opts = opts or {}
	local b = Instance.new("TextButton")
	b.AutoButtonColor, b.Text, b.TextColor3, b.Font = false, text, T.Text, T.FontBold
	b.TextScaled, b.BackgroundColor3, b.BorderSizePixel = true, opts.Color or T.Accent, 0
	b.Size, b.Position, b.AnchorPoint = opts.Size or UDim2.fromScale(0.2, 0.08), opts.Position or UDim2.new(), opts.Anchor or Vector2.zero
	corner(b)
	local pad = Instance.new("UIPadding"); pad.PaddingTop, pad.PaddingBottom = UDim.new(0.2, 0), UDim.new(0.2, 0); pad.Parent = b
	local base = b.BackgroundColor3
	local scale = Instance.new("UIScale"); scale.Parent = b
	b.MouseEnter:Connect(function() UI.Tween(b, 0.1, { BackgroundColor3 = base:Lerp(Color3.new(1, 1, 1), 0.18) }) end)
	b.MouseLeave:Connect(function() UI.Tween(b, 0.12, { BackgroundColor3 = base }); UI.Tween(scale, 0.1, { Scale = 1 }) end)
	b.MouseButton1Down:Connect(function() UI.Tween(scale, 0.06, { Scale = 0.96 }) end)
	b.MouseButton1Up:Connect(function() UI.Tween(scale, 0.1, { Scale = 1 }, Enum.EasingStyle.Back) end)
	b.Activated:Connect(function() if onClick then local ok, err = pcall(onClick); if not ok then warn("[UIKit] onClick lỗi:", err) end end end)
	b.Parent = parent
	return b
end

-- Thanh tiến trình có "vệt trễ" (damage trail): Set(v 0..1) → thanh chính nhảy ngay, vệt mờ đuổi theo sau 0.35 s.
function UI.Bar(parent, opts)
	opts = opts or {}
	local holder = UI.Panel(parent, { Size = opts.Size, Position = opts.Position, Anchor = opts.Anchor, Color = T.Bg, Transparency = 0.2 })
	holder.ClipsDescendants = true
	local trail = Instance.new("Frame"); trail.BorderSizePixel = 0; trail.BackgroundColor3 = opts.TrailColor or Color3.fromRGB(255, 255, 255)
	trail.BackgroundTransparency, trail.Size = 0.35, UDim2.fromScale(1, 1); corner(trail); trail.Parent = holder
	local fill = Instance.new("Frame"); fill.BorderSizePixel = 0; fill.BackgroundColor3 = opts.Color or T.Good
	fill.Size = UDim2.fromScale(1, 1); corner(fill); fill.Parent = holder
	local g = Instance.new("UIGradient"); g.Rotation = 90
	g.Color = ColorSequence.new(Color3.new(1, 1, 1), Color3.fromRGB(190, 190, 190)); g.Parent = fill
	local label
	if opts.ShowText then label = UI.Label(holder, "", { Bold = true }); label.ZIndex = 5 end
	local bar = { Frame = holder, Value = 1 }
	function bar:Set(v, text)
		v = math.clamp(v, 0, 1)
		UI.Tween(fill, 0.08, { Size = UDim2.fromScale(v, 1) })
		if v < self.Value then
			task.delay(0.15, function() if trail.Parent then UI.Tween(trail, 0.35, { Size = UDim2.fromScale(v, 1) }) end end)
		else
			trail.Size = UDim2.fromScale(v, 1)
		end
		self.Value = v
		if label then label.Text = text or ("%d%%"):format(math.floor(v * 100 + 0.5)) end
	end
	return bar
end

-- Vòng hồi chiêu: Set(p 0..1) p=1 là sẵn sàng. Hai nửa gradient quay (kiểm bằng mắt lần đầu: chiều quay có thể cần đảo Rotation).
function UI.CooldownRing(parent, opts)
	opts = opts or {}
	local size = opts.Size or UDim2.fromOffset(64, 64)
	local holder = Instance.new("Frame")
	holder.BackgroundColor3, holder.BackgroundTransparency, holder.Size, holder.Position = T.Bg, 0.25, size, opts.Position or UDim2.new()
	holder.AnchorPoint = opts.Anchor or Vector2.zero
	corner(holder, UDim.new(1, 0)); stroke(holder, T.Stroke, 2)
	holder.Parent = parent
	local function half(rot)
		local f = Instance.new("Frame")
		f.BackgroundColor3, f.BackgroundTransparency, f.Size, f.BorderSizePixel = opts.Color or T.Accent, 0.1, UDim2.fromScale(1, 1), 0
		corner(f, UDim.new(1, 0))
		local g = Instance.new("UIGradient")
		g.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.5, 0), NumberSequenceKeypoint.new(0.501, 1), NumberSequenceKeypoint.new(1, 1) })
		g.Rotation = rot
		g.Parent = f
		f.Parent = holder
		return f, g
	end
	local rF, rG = half(0)
	local lF, lG = half(180)
	local label = UI.Label(holder, opts.Text or "", { Bold = true }); label.ZIndex = 5
	local ring = { Frame = holder }
	function ring:Set(p, text)
		p = math.clamp(p, 0, 1)
		rG.Rotation = math.clamp(p * 360, 0, 180)
		lF.Visible = p > 0.5
		lG.Rotation = 180 + math.clamp(p * 360 - 180, 0, 180)
		rF.BackgroundTransparency = p >= 1 and 0.55 or 0.1
		label.Text = text or (p >= 1 and "" or ("%.1f"):format((1 - p) * (opts.Cooldown or 0)))
	end
	return ring
end

-- Toast xếp chồng: kind = "info" | "good" | "warn" | "danger".
local toastHost
function UI.Toast(root, text, kind, dur)
	if not toastHost or not toastHost.Parent then
		toastHost = Instance.new("Frame")
		toastHost.BackgroundTransparency, toastHost.Size, toastHost.Position, toastHost.AnchorPoint = 1, UDim2.fromScale(0.3, 0.4), UDim2.fromScale(0.5, 0.1), Vector2.new(0.5, 0)
		toastHost.Active = false
		local lay = Instance.new("UIListLayout"); lay.Padding = UDim.new(0, 6); lay.HorizontalAlignment = Enum.HorizontalAlignment.Center; lay.Parent = toastHost
		toastHost.Parent = root
	end
	local col = ({ info = T.Accent, good = T.Good, warn = T.Warn, danger = T.Danger })[kind or "info"] or T.Accent
	local p = UI.Panel(toastHost, { Size = UDim2.new(1, 0, 0, 38), Transparency = 1 })
	p.BackgroundTransparency = 1
	local bar = Instance.new("Frame"); bar.BackgroundColor3, bar.BorderSizePixel, bar.Size = col, 0, UDim2.new(0, 4, 1, 0); corner(bar, UDim.new(0, 2)); bar.Parent = p
	local l = UI.Label(p, text, { Position = UDim2.fromOffset(12, 0), Size = UDim2.new(1, -16, 1, 0), Align = Enum.TextXAlignment.Left }); l.TextTransparency = 1
	UI.Tween(p, 0.2, { BackgroundTransparency = 0.1 }); UI.Tween(l, 0.2, { TextTransparency = 0 })
	task.delay(dur or 2.5, function()
		if not p.Parent then return end
		UI.Tween(p, 0.25, { BackgroundTransparency = 1 }); UI.Tween(l, 0.25, { TextTransparency = 1 })
		Debris:AddItem(p, 0.3)
	end)
	return p
end

-- Số sát thương bay lên trên đầu mục tiêu (BillboardGui). crit = to hơn, vàng.
function UI.DamageNumber(worldPos, amount, crit)
	local part = Instance.new("Part")
	part.Anchored, part.CanCollide, part.CanQuery, part.CanTouch, part.Transparency, part.Size, part.Position = true, false, false, false, 1, Vector3.one * 0.1, worldPos
	local bb = Instance.new("BillboardGui")
	bb.Size, bb.AlwaysOnTop, bb.StudsOffset = UDim2.fromOffset(crit and 150 or 100, crit and 56 or 38), true, Vector3.new(math.random(-10, 10) / 10, 0, 0)
	local l = UI.Label(bb, tostring(math.floor(amount + 0.5)) .. (crit and "!" or ""), { Bold = true, Color = crit and T.Warn or Color3.new(1, 1, 1) })
	local st = Instance.new("UIStroke"); st.Thickness, st.Color = 2, Color3.new(0, 0, 0); st.Parent = l
	bb.Parent = part
	part.Parent = Workspace
	Debris:AddItem(part, 1)
	local t0 = os.clock()
	local conn
	conn = RunService.RenderStepped:Connect(function()
		local a = (os.clock() - t0) / 0.9
		if a >= 1 or not part.Parent then conn:Disconnect(); return end
		bb.StudsOffset += Vector3.new(0, 0.05 * (1 - a) + 0.01, 0)
		l.TextTransparency = a ^ 3; st.Transparency = a ^ 3
		l.Size = UDim2.fromScale(1 + (crit and 0.3 or 0.1) * (1 - a), 1 + (crit and 0.3 or 0.1) * (1 - a))
	end)
end

-- Tâm ngắm động: spread (stud/pixel) nở khi bắn/chạy; Hit() chớp hitmarker.
function UI.Crosshair(root, opts)
	opts = opts or {}
	local holder = Instance.new("Frame")
	holder.BackgroundTransparency, holder.Size, holder.Position, holder.AnchorPoint = 1, UDim2.fromOffset(200, 200), UDim2.fromScale(0.5, 0.5), Vector2.new(0.5, 0.5)
	holder.Active = false; holder.Parent = root
	local col = opts.Color or Color3.new(1, 1, 1)
	local arms = {}
	local function arm(dx, dy)
		local f = Instance.new("Frame")
		f.BackgroundColor3, f.BorderSizePixel, f.AnchorPoint = col, 0, Vector2.new(0.5, 0.5)
		f.Size = (dx ~= 0) and UDim2.fromOffset(10, 2) or UDim2.fromOffset(2, 10)
		f.Parent = holder
		local s = Instance.new("UIStroke"); s.Thickness, s.Color = 1, Color3.new(0, 0, 0); s.Parent = f
		arms[#arms + 1] = { f = f, dx = dx, dy = dy }
	end
	arm(1, 0); arm(-1, 0); arm(0, 1); arm(0, -1)
	local dot = Instance.new("Frame"); dot.BackgroundColor3, dot.Size, dot.AnchorPoint, dot.Position, dot.BorderSizePixel = col, UDim2.fromOffset(3, 3), Vector2.new(0.5, 0.5), UDim2.fromScale(0.5, 0.5), 0
	dot.Parent = holder
	local cross = { spread = opts.Spread or 8, target = opts.Spread or 8 }
	local hit = {}
	for _, d in ipairs({ { 1, 1 }, { -1, 1 }, { 1, -1 }, { -1, -1 } }) do
		local f = Instance.new("Frame"); f.BackgroundColor3, f.BackgroundTransparency, f.BorderSizePixel = T.Danger, 1, 0
		f.Size, f.AnchorPoint, f.Position, f.Rotation = UDim2.fromOffset(12, 3), Vector2.new(0.5, 0.5), UDim2.new(0.5, d[1] * 12, 0.5, d[2] * 12), d[1] * d[2] * 45
		f.Parent = holder; hit[#hit + 1] = f
	end
	local conn = RunService.RenderStepped:Connect(function(dt)
		cross.spread += (cross.target - cross.spread) * math.min(1, dt * 14)
		for _, a in ipairs(arms) do a.f.Position = UDim2.new(0.5, a.dx * cross.spread, 0.5, a.dy * cross.spread) end
	end)
	function cross:SetSpread(px) self.target = px end
	function cross:Kick(px) self.spread += px end
	function cross:Hit(kill)
		for _, f in ipairs(hit) do
			f.BackgroundColor3 = kill and T.Danger or Color3.new(1, 1, 1)
			f.BackgroundTransparency = 0
			UI.Tween(f, 0.25, { BackgroundTransparency = 1 })
		end
	end
	function cross:Destroy() conn:Disconnect(); holder:Destroy() end
	return cross
end

-- Scope bắn tỉa: vòng đen quanh lỗ tròn giữa + chữ thập mảnh. Show()/Hide(). (UIStroke khổng lồ làm vành tối — kiểm bằng mắt lần đầu.)
function UI.Scope(root)
	local g = Instance.new("Frame")
	g.BackgroundTransparency, g.Size, g.Visible, g.Active = 1, UDim2.fromScale(1, 1), false, false
	g.Parent = root
	local diag = 3000
	local hole = Instance.new("Frame")
	hole.BackgroundTransparency, hole.AnchorPoint, hole.Position, hole.Size = 1, Vector2.new(0.5, 0.5), UDim2.fromScale(0.5, 0.5), UDim2.fromScale(0.62, 0)
	local ar = Instance.new("UIAspectRatioConstraint"); ar.AspectRatio = 1; ar.AspectType = Enum.AspectType.ScaleWithParentSize; ar.DominantAxis = Enum.DominantAxis.Height; ar.Parent = hole
	hole.Size = UDim2.fromScale(0, 0.86)
	corner(hole, UDim.new(1, 0))
	local st = Instance.new("UIStroke"); st.Color, st.Thickness, st.ApplyStrokeMode = Color3.new(0, 0, 0), diag, Enum.ApplyStrokeMode.Border; st.Parent = hole
	hole.Parent = g
	for _, d in ipairs({ { UDim2.fromScale(1, 0), UDim2.fromOffset(0, 2) }, { UDim2.fromOffset(2, 0), UDim2.fromScale(0, 1) } }) do
		local l = Instance.new("Frame"); l.BackgroundColor3, l.BorderSizePixel, l.AnchorPoint = Color3.new(0, 0, 0), 0, Vector2.new(0.5, 0.5)
		l.Position = UDim2.fromScale(0.5, 0.5)
		l.Size = d[1].X.Scale > 0 and UDim2.new(0.62, 0, 0, 1) or UDim2.new(0, 1, 0.86, 0)
		l.Parent = g
	end
	local scope = { Gui = g }
	function scope:Show() g.Visible = true end
	function scope:Hide() g.Visible = false end
	return scope
end

-- Viền tối (vignette) bằng 4 gradient — không cần asset. Set(0..1).
function UI.Vignette(root)
	local holder = Instance.new("Frame"); holder.BackgroundTransparency, holder.Size, holder.Active = 1, UDim2.fromScale(1, 1), false; holder.Parent = root
	local sides = {}
	for _, d in ipairs({ { UDim2.fromScale(1, 0.25), UDim2.fromScale(0, 0), 90 }, { UDim2.fromScale(1, 0.25), UDim2.fromScale(0, 0.75), 270 }, { UDim2.fromScale(0.2, 1), UDim2.fromScale(0, 0), 0 }, { UDim2.fromScale(0.2, 1), UDim2.fromScale(0.8, 0), 180 } }) do
		local f = Instance.new("Frame"); f.BackgroundColor3, f.BorderSizePixel, f.Size, f.Position, f.Active = Color3.new(0, 0, 0), 0, d[1], d[2], false
		local g = Instance.new("UIGradient"); g.Rotation = d[3]
		g.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) }); g.Parent = f
		f.BackgroundTransparency = 1
		f.Parent = holder; sides[#sides + 1] = f
	end
	local v = { Frame = holder }
	function v:Set(strength, color) for _, f in ipairs(sides) do f.BackgroundTransparency = 1 - math.clamp(strength, 0, 1); if color then f.BackgroundColor3 = color end end end
	return v
end

-- Đường tốc độ (speed lines) toả ra từ tâm; Pulse(intensity, dur). Dùng khi dash/sprint/rơi nhanh.
function UI.SpeedLines(root, count)
	local n = count or 28
	local holder = Instance.new("Frame"); holder.BackgroundTransparency, holder.Size, holder.Active, holder.ClipsDescendants = 1, UDim2.fromScale(1, 1), false, true
	holder.Parent = root
	local lines = {}
	for i = 1, n do
		local ang = (i / n) * 360
		local f = Instance.new("Frame"); f.BackgroundColor3, f.BorderSizePixel, f.AnchorPoint, f.Position = Color3.new(1, 1, 1), 0, Vector2.new(0, 0.5), UDim2.fromScale(0.5, 0.5)
		f.Rotation, f.BackgroundTransparency, f.Size = ang, 1, UDim2.fromScale(0.5, 0.003)
		local g = Instance.new("UIGradient"); g.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.6, 0.3), NumberSequenceKeypoint.new(1, 0) }); g.Parent = f
		f.Parent = holder; lines[i] = f
	end
	local sl = {}
	function sl:Pulse(intensity, dur)
		local rng = Random.new()
		for _, f in ipairs(lines) do
			f.Size = UDim2.fromScale(rng:NextNumber(0.2, 0.5), 0.002 + 0.004 * intensity * rng:NextNumber(0.4, 1))
			f.BackgroundTransparency = 1 - math.clamp(intensity, 0, 1) * rng:NextNumber(0.3, 0.8)
			UI.Tween(f, dur or 0.3, { BackgroundTransparency = 1 })
		end
	end
	return sl
end

return UI
