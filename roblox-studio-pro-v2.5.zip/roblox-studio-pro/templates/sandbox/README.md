# Sandbox kiểu Roblox Studio (ngoài Studio)

Chạy code Luau dựng model/animation bằng `luau` CLI trên một "Roblox giả" (`RbxStub.lua`), ghi lại cây Instance + CFrame thành `scene.json`, rồi vẽ ảnh nhiều góc để AI **tự xem và sửa**.
Lối vào duy nhất: `python scripts/sandbox.py` (xem `references/sandbox-loop.md`).

## Có gì trong RbxStub
Vector3/CFrame/Color3 đầy đủ phép toán (khớp `scripts/orient.py`, có test), Instance cây cha-con (Clone/Destroy/Find*/GetDescendants/Attribute), Model (PivotTo, ScaleTo, GetBoundingBox), Part (Block/Ball/Cylinder/Wedge; MeshPart/Union xấp xỉ bằng hộp), Weld/WeldConstraint/Motor6D (ghi nối, cảnh báo đặt CFrame sau khi weld), `task.wait/delay/spawn` có lịch giả lập, Heartbeat/TweenService (chạy tới đích), `--time/--snaps` cho ảnh chụp theo thời gian, `require` module (`--autolib` nạp toàn bộ `templates/*.lua`).

## Khác Roblox thật ở đâu (ĐỌC trước khi tin ảnh)
- **Không vật lý**: không rơi, không va chạm, không constraint động lực học; `Anchored=false` không tự rơi.
- **Không ánh sáng/PBR/bóng/Neon glow**: ảnh là bản vẽ phẳng có viền từng part để kiểm hình dạng, tỉ lệ, khe hở.
- **Không mesh/CSG/EditableMesh thật**: MeshPart, UnionOperation, CornerWedge vẽ bằng hộp; Wedge và Cylinder (trục X) theo trí nhớ Roblox — **VERIFY trong Studio**.
- `Part.Size` bị kẹp [0.05, 2048] và có cảnh báo; thuộc tính stub chưa biết trả `nil` (có thể là API sai tên hoặc stub thiếu).
- Humanoid, Animator, Sound, ParticleEmitter, GUI: có đối tượng nhưng **không chạy**.
- `WaitForChild` không có phần tử sẽ báo lỗi thay vì treo.
Kết luận: sandbox kiểm HÌNH DẠNG / TỈ LỆ / SỐ LƯỢNG / KẾT NỐI / LOGIC TĨNH; vẻ ngoài cuối cùng và chuyển động thật vẫn phải thử trong Studio.
