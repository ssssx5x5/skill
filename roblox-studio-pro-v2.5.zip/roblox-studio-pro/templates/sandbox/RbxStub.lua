-- RbxStub: Roblox giả (đủ để chạy code DỰNG MODEL / VFX / ANIMATION thủ tục ngoài Studio bằng luau CLI).
-- Không phải Roblox thật: không có vật lý, không render, không mạng. Ghi lại cây Instance + CFrame rồi xuất JSON để vẽ ảnh.
-- Quy ước giống Roblox: trước = −Z, phải = +X, lên = +Y; CFrame.Angles = Rx·Ry·Rz.
-- File này được ghép trước script người dùng bởi scripts/sandbox.py (mọi thứ là local → không cần quyền global).

local __MODULES = {}      -- tên → hàm nạp module (do sandbox.py điền)
local __LOG = {}
local __TIME = 0
local __SCALE_WARN = {}
local __print = print
local task      -- khai báo trước: Signal:Fire cần task.spawn

---------------------------------------------------------------- Vector3
local V3 = {}
V3.__index = function(t, k)
	if k == "Magnitude" then return math.sqrt(t.X * t.X + t.Y * t.Y + t.Z * t.Z) end
	if k == "Unit" then
		local m = math.sqrt(t.X * t.X + t.Y * t.Y + t.Z * t.Z)
		if m == 0 then return V3.new(0, 0, 0) end
		return V3.new(t.X / m, t.Y / m, t.Z / m)
	end
	return V3[k]
end
function V3.new(x, y, z) return setmetatable({ X = x or 0, Y = y or 0, Z = z or 0 }, V3) end
function V3:Dot(o) return self.X * o.X + self.Y * o.Y + self.Z * o.Z end
function V3:Cross(o) return V3.new(self.Y * o.Z - self.Z * o.Y, self.Z * o.X - self.X * o.Z, self.X * o.Y - self.Y * o.X) end
function V3:Lerp(o, a) return V3.new(self.X + (o.X - self.X) * a, self.Y + (o.Y - self.Y) * a, self.Z + (o.Z - self.Z) * a) end
function V3:Abs() return V3.new(math.abs(self.X), math.abs(self.Y), math.abs(self.Z)) end
function V3:Max(o) return V3.new(math.max(self.X, o.X), math.max(self.Y, o.Y), math.max(self.Z, o.Z)) end
function V3:Min(o) return V3.new(math.min(self.X, o.X), math.min(self.Y, o.Y), math.min(self.Z, o.Z)) end
function V3:FuzzyEq(o, e) e = e or 1e-5; return (self - o).Magnitude <= e end
function V3:Angle(o) local d = self.Unit:Dot(o.Unit); return math.acos(math.max(-1, math.min(1, d))) end
V3.__add = function(a, b) return V3.new(a.X + b.X, a.Y + b.Y, a.Z + b.Z) end
V3.__sub = function(a, b) return V3.new(a.X - b.X, a.Y - b.Y, a.Z - b.Z) end
V3.__mul = function(a, b)
	if type(a) == "number" then return V3.new(a * b.X, a * b.Y, a * b.Z) end
	if type(b) == "number" then return V3.new(a.X * b, a.Y * b, a.Z * b) end
	return V3.new(a.X * b.X, a.Y * b.Y, a.Z * b.Z)
end
V3.__div = function(a, b)
	if type(b) == "number" then return V3.new(a.X / b, a.Y / b, a.Z / b) end
	return V3.new(a.X / b.X, a.Y / b.Y, a.Z / b.Z)
end
V3.__unm = function(a) return V3.new(-a.X, -a.Y, -a.Z) end
V3.__eq = function(a, b) return a.X == b.X and a.Y == b.Y and a.Z == b.Z end
V3.__tostring = function(a) return string.format("%g, %g, %g", a.X + 0, a.Y + 0, a.Z + 0) end
V3.xAxis, V3.yAxis, V3.zAxis = V3.new(1, 0, 0), V3.new(0, 1, 0), V3.new(0, 0, 1)
V3.zero, V3.one = V3.new(0, 0, 0), V3.new(1, 1, 1)
local Vector3 = V3

local V2 = {}
V2.__index = function(t, k)
	if k == "Magnitude" then return math.sqrt(t.X * t.X + t.Y * t.Y) end
	if k == "Unit" then local m = math.sqrt(t.X * t.X + t.Y * t.Y); return V2.new(t.X / m, t.Y / m) end
	return V2[k]
end
function V2.new(x, y) return setmetatable({ X = x or 0, Y = y or 0 }, V2) end
V2.__add = function(a, b) return V2.new(a.X + b.X, a.Y + b.Y) end
V2.__sub = function(a, b) return V2.new(a.X - b.X, a.Y - b.Y) end
V2.__mul = function(a, b)
	if type(a) == "number" then return V2.new(a * b.X, a * b.Y) end
	if type(b) == "number" then return V2.new(a.X * b, a.Y * b) end
	return V2.new(a.X * b.X, a.Y * b.Y)
end
V2.__eq = function(a, b) return a.X == b.X and a.Y == b.Y end
V2.zero, V2.one = V2.new(0, 0), V2.new(1, 1)
local Vector2 = V2

---------------------------------------------------------------- Color3
local C3 = {}
C3.__index = C3
function C3.new(r, g, b) return setmetatable({ R = r or 0, G = g or 0, B = b or 0 }, C3) end
function C3.fromRGB(r, g, b) return C3.new((r or 0) / 255, (g or 0) / 255, (b or 0) / 255) end
function C3.fromHSV(h, s, v)
	local i = math.floor(h * 6); local f = h * 6 - i
	local p, q, t = v * (1 - s), v * (1 - f * s), v * (1 - (1 - f) * s)
	i = i % 6
	if i == 0 then return C3.new(v, t, p) elseif i == 1 then return C3.new(q, v, p) elseif i == 2 then return C3.new(p, v, t)
	elseif i == 3 then return C3.new(p, q, v) elseif i == 4 then return C3.new(t, p, v) else return C3.new(v, p, q) end
end
function C3.fromHex(s) s = s:gsub("#", ""); return C3.fromRGB(tonumber(s:sub(1, 2), 16), tonumber(s:sub(3, 4), 16), tonumber(s:sub(5, 6), 16)) end
function C3:Lerp(o, a) return C3.new(self.R + (o.R - self.R) * a, self.G + (o.G - self.G) * a, self.B + (o.B - self.B) * a) end
function C3:ToHSV()
	local r, g, b = self.R, self.G, self.B
	local mx, mn = math.max(r, g, b), math.min(r, g, b); local d = mx - mn
	local h = 0
	if d > 0 then
		if mx == r then h = ((g - b) / d) % 6 elseif mx == g then h = (b - r) / d + 2 else h = (r - g) / d + 4 end
		h = h / 6
	end
	return h, (mx == 0) and 0 or d / mx, mx
end
C3.__eq = function(a, b) return a.R == b.R and a.G == b.G and a.B == b.B end
C3.__tostring = function(a) return string.format("%g, %g, %g", a.R, a.G, a.B) end
local Color3 = C3

---------------------------------------------------------------- CFrame
local CF = {}
local function cfnew(x, y, z, a, b, c, d, e, f, g, h, i)
	return setmetatable({ X = x, Y = y, Z = z, m11 = a, m12 = b, m13 = c, m21 = d, m22 = e, m23 = f, m31 = g, m32 = h, m33 = i }, CF)
end
local function rotMul(a, b)
	return a.m11 * b.m11 + a.m12 * b.m21 + a.m13 * b.m31, a.m11 * b.m12 + a.m12 * b.m22 + a.m13 * b.m32, a.m11 * b.m13 + a.m12 * b.m23 + a.m13 * b.m33,
		a.m21 * b.m11 + a.m22 * b.m21 + a.m23 * b.m31, a.m21 * b.m12 + a.m22 * b.m22 + a.m23 * b.m32, a.m21 * b.m13 + a.m22 * b.m23 + a.m23 * b.m33,
		a.m31 * b.m11 + a.m32 * b.m21 + a.m33 * b.m31, a.m31 * b.m12 + a.m32 * b.m22 + a.m33 * b.m32, a.m31 * b.m13 + a.m32 * b.m23 + a.m33 * b.m33
end
local function quatToCF(x, y, z, qx, qy, qz, qw)
	local n = math.sqrt(qx * qx + qy * qy + qz * qz + qw * qw); qx, qy, qz, qw = qx / n, qy / n, qz / n, qw / n
	return cfnew(x, y, z,
		1 - 2 * (qy * qy + qz * qz), 2 * (qx * qy - qz * qw), 2 * (qx * qz + qy * qw),
		2 * (qx * qy + qz * qw), 1 - 2 * (qx * qx + qz * qz), 2 * (qy * qz - qx * qw),
		2 * (qx * qz - qy * qw), 2 * (qy * qz + qx * qw), 1 - 2 * (qx * qx + qy * qy))
end
local function lookCF(pos, look, up)
	local back = (-look).Unit
	local right = up:Cross(back)
	if right.Magnitude < 1e-9 then right = V3.new(1, 0, 0):Cross(back) ; if right.Magnitude < 1e-9 then right = V3.new(0, 0, 1):Cross(back) end end
	right = right.Unit
	local u = back:Cross(right)
	return cfnew(pos.X, pos.Y, pos.Z, right.X, u.X, back.X, right.Y, u.Y, back.Y, right.Z, u.Z, back.Z)
end
function CF.new(a, b, c, d, e, f, g, h, i, j, k, l)
	if a == nil then return cfnew(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1) end
	if type(a) == "table" then
		if b == nil then return cfnew(a.X, a.Y, a.Z, 1, 0, 0, 0, 1, 0, 0, 0, 1) end
		return lookCF(a, b - a, V3.new(0, 1, 0))
	end
	if d == nil then return cfnew(a, b, c, 1, 0, 0, 0, 1, 0, 0, 0, 1) end
	if e == nil then return nil end
	if h == nil then return quatToCF(a, b, c, d, e, f, g) end
	return cfnew(a, b, c, d, e, f, g, h, i, j, k, l)
end
CF.identity = cfnew(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1)
local function Rx(a) local c, s = math.cos(a), math.sin(a); return cfnew(0, 0, 0, 1, 0, 0, 0, c, -s, 0, s, c) end
local function Ry(a) local c, s = math.cos(a), math.sin(a); return cfnew(0, 0, 0, c, 0, s, 0, 1, 0, -s, 0, c) end
local function Rz(a) local c, s = math.cos(a), math.sin(a); return cfnew(0, 0, 0, c, -s, 0, s, c, 0, 0, 0, 1) end
local function cfmul(a, b)
	local m11, m12, m13, m21, m22, m23, m31, m32, m33 = rotMul(a, b)
	return cfnew(a.X + a.m11 * b.X + a.m12 * b.Y + a.m13 * b.Z, a.Y + a.m21 * b.X + a.m22 * b.Y + a.m23 * b.Z, a.Z + a.m31 * b.X + a.m32 * b.Y + a.m33 * b.Z, m11, m12, m13, m21, m22, m23, m31, m32, m33)
end
function CF.Angles(rx, ry, rz) return cfmul(cfmul(Rx(rx or 0), Ry(ry or 0)), Rz(rz or 0)) end
CF.fromEulerAnglesXYZ = CF.Angles
function CF.fromEulerAnglesYXZ(rx, ry, rz) return cfmul(cfmul(Ry(ry or 0), Rx(rx or 0)), Rz(rz or 0)) end
CF.fromOrientation = CF.fromEulerAnglesYXZ
function CF.fromAxisAngle(axis, ang)
	local a = axis.Unit; local c, s = math.cos(ang), math.sin(ang); local t = 1 - c
	return cfnew(0, 0, 0,
		t * a.X * a.X + c, t * a.X * a.Y - s * a.Z, t * a.X * a.Z + s * a.Y,
		t * a.X * a.Y + s * a.Z, t * a.Y * a.Y + c, t * a.Y * a.Z - s * a.X,
		t * a.X * a.Z - s * a.Y, t * a.Y * a.Z + s * a.X, t * a.Z * a.Z + c)
end
function CF.fromMatrix(pos, vx, vy, vz)
	vz = vz or vx:Cross(vy)
	return cfnew(pos.X, pos.Y, pos.Z, vx.X, vy.X, vz.X, vx.Y, vy.Y, vz.Y, vx.Z, vy.Z, vz.Z)
end
function CF.lookAt(at, look, up) return lookCF(at, look - at, up or V3.new(0, 1, 0)) end
function CF.lookAlong(at, dir, up) return lookCF(at, dir, up or V3.new(0, 1, 0)) end
function CF:Inverse()
	local x = -(self.m11 * self.X + self.m21 * self.Y + self.m31 * self.Z)
	local y = -(self.m12 * self.X + self.m22 * self.Y + self.m32 * self.Z)
	local z = -(self.m13 * self.X + self.m23 * self.Y + self.m33 * self.Z)
	return cfnew(x, y, z, self.m11, self.m21, self.m31, self.m12, self.m22, self.m32, self.m13, self.m23, self.m33)
end
function CF:PointToWorldSpace(p) return V3.new(self.X + self.m11 * p.X + self.m12 * p.Y + self.m13 * p.Z, self.Y + self.m21 * p.X + self.m22 * p.Y + self.m23 * p.Z, self.Z + self.m31 * p.X + self.m32 * p.Y + self.m33 * p.Z) end
function CF:VectorToWorldSpace(p) return V3.new(self.m11 * p.X + self.m12 * p.Y + self.m13 * p.Z, self.m21 * p.X + self.m22 * p.Y + self.m23 * p.Z, self.m31 * p.X + self.m32 * p.Y + self.m33 * p.Z) end
function CF:PointToObjectSpace(p) return self:Inverse():PointToWorldSpace(p) end
function CF:VectorToObjectSpace(p) return self:Inverse():VectorToWorldSpace(p) end
function CF:ToWorldSpace(o) return cfmul(self, o) end
function CF:ToObjectSpace(o) return cfmul(self:Inverse(), o) end
function CF:GetComponents() return self.X, self.Y, self.Z, self.m11, self.m12, self.m13, self.m21, self.m22, self.m23, self.m31, self.m32, self.m33 end
function CF:ToEulerAnglesXYZ()
	local ry = math.asin(math.max(-1, math.min(1, self.m13)))
	if math.abs(self.m13) < 0.999999 then return math.atan2(-self.m23, self.m33), ry, math.atan2(-self.m12, self.m11) end
	return math.atan2(self.m32, self.m22), ry, 0
end
function CF:ToOrientation()
	local rx = math.asin(math.max(-1, math.min(1, -self.m23)))
	if math.abs(self.m23) < 0.999999 then return rx, math.atan2(self.m13, self.m33), math.atan2(self.m21, self.m22) end
	return rx, math.atan2(-self.m31, self.m11), 0
end
CF.ToEulerAnglesYXZ = CF.ToOrientation
function CF:ToAxisAngle()
	local tr = self.m11 + self.m22 + self.m33
	local ang = math.acos(math.max(-1, math.min(1, (tr - 1) / 2)))
	if ang < 1e-9 then return V3.new(0, 1, 0), 0 end
	local ax = V3.new(self.m32 - self.m23, self.m13 - self.m31, self.m21 - self.m12)
	if ax.Magnitude < 1e-9 then
		-- góc ≈ π: lấy trục từ đường chéo
		local x = math.sqrt(math.max(0, (self.m11 + 1) / 2)); local y = math.sqrt(math.max(0, (self.m22 + 1) / 2)); local z = math.sqrt(math.max(0, (self.m33 + 1) / 2))
		return V3.new(x, y, z).Unit, ang
	end
	return ax.Unit, ang
end
function CF:Lerp(o, a)
	local rel = cfmul(CF.new(0, 0, 0, self.m11, self.m12, self.m13, self.m21, self.m22, self.m23, self.m31, self.m32, self.m33):Inverse(), CF.new(0, 0, 0, o.m11, o.m12, o.m13, o.m21, o.m22, o.m23, o.m31, o.m32, o.m33))
	local ax, ang = rel:ToAxisAngle()
	local r = cfmul(CF.new(0, 0, 0, self.m11, self.m12, self.m13, self.m21, self.m22, self.m23, self.m31, self.m32, self.m33), CF.fromAxisAngle(ax, ang * a))
	return cfnew(self.X + (o.X - self.X) * a, self.Y + (o.Y - self.Y) * a, self.Z + (o.Z - self.Z) * a, r.m11, r.m12, r.m13, r.m21, r.m22, r.m23, r.m31, r.m32, r.m33)
end
function CF:FuzzyEq(o, e)
	e = e or 1e-5
	return math.abs(self.X - o.X) + math.abs(self.Y - o.Y) + math.abs(self.Z - o.Z) + math.abs(self.m11 - o.m11) + math.abs(self.m12 - o.m12) + math.abs(self.m13 - o.m13) + math.abs(self.m21 - o.m21) + math.abs(self.m22 - o.m22) + math.abs(self.m23 - o.m23) + math.abs(self.m31 - o.m31) + math.abs(self.m32 - o.m32) + math.abs(self.m33 - o.m33) <= e
end
function CF:Orthonormalize() return self end
CF.__index = function(t, k)
	if k == "Position" then return V3.new(t.X, t.Y, t.Z) end
	if k == "RightVector" then return V3.new(t.m11, t.m21, t.m31) end
	if k == "UpVector" then return V3.new(t.m12, t.m22, t.m32) end
	if k == "LookVector" then return V3.new(-t.m13, -t.m23, -t.m33) end
	if k == "XVector" then return V3.new(t.m11, t.m21, t.m31) end
	if k == "YVector" then return V3.new(t.m12, t.m22, t.m32) end
	if k == "ZVector" then return V3.new(t.m13, t.m23, t.m33) end
	if k == "Rotation" then return cfnew(0, 0, 0, t.m11, t.m12, t.m13, t.m21, t.m22, t.m23, t.m31, t.m32, t.m33) end
	return CF[k]
end
CF.__mul = function(a, b)
	if getmetatable(b) == V3 then return a:PointToWorldSpace(b) end
	return cfmul(a, b)
end
CF.__add = function(a, v) return cfnew(a.X + v.X, a.Y + v.Y, a.Z + v.Z, a.m11, a.m12, a.m13, a.m21, a.m22, a.m23, a.m31, a.m32, a.m33) end
CF.__sub = function(a, v) return cfnew(a.X - v.X, a.Y - v.Y, a.Z - v.Z, a.m11, a.m12, a.m13, a.m21, a.m22, a.m23, a.m31, a.m32, a.m33) end
CF.__eq = function(a, b) return a:FuzzyEq(b, 0) end
CF.__tostring = function(a) return string.format("%g, %g, %g, %g, %g, %g, %g, %g, %g, %g, %g, %g", a:GetComponents()) end
local CFrame = CF

---------------------------------------------------------------- tiện ích giá trị khác
local function plainValue(name) -- UDim2/UDim/NumberRange…: bảng trơ, đủ để script không vỡ
	local T = {}
	T.__index = T
	return T
end
local UDim = { new = function(s, o) return { Scale = s or 0, Offset = o or 0 } end }
local UDim2 = {
	new = function(xs, xo, ys, yo) return { X = UDim.new(xs, xo), Y = UDim.new(ys, yo) } end,
	fromScale = function(x, y) return { X = UDim.new(x, 0), Y = UDim.new(y, 0) } end,
	fromOffset = function(x, y) return { X = UDim.new(0, x), Y = UDim.new(0, y) } end,
}
local NumberRange = { new = function(a, b) return { Min = a, Max = b or a } end }
local NumberSequenceKeypoint = { new = function(t, v, e) return { Time = t, Value = v, Envelope = e or 0 } end }
local ColorSequenceKeypoint = { new = function(t, c) return { Time = t, Value = c } end }
local NumberSequence = { new = function(a, b)
	if type(a) == "table" then return { Keypoints = a } end
	return { Keypoints = { NumberSequenceKeypoint.new(0, a), NumberSequenceKeypoint.new(1, b or a) } }
end }
local ColorSequence = { new = function(a, b)
	if getmetatable(a) == C3 then return { Keypoints = { ColorSequenceKeypoint.new(0, a), ColorSequenceKeypoint.new(1, b or a) } } end
	return { Keypoints = a }
end }
local TweenInfo = { new = function(t, style, dir, rep, rev, delay) return { Time = t or 1, EasingStyle = style, EasingDirection = dir, RepeatCount = rep or 0, Reverses = rev or false, DelayTime = delay or 0 } end }
local Rect = { new = function(a, b, c, d) return { Min = a, Max = b } end }
local Ray = { new = function(o, d) return { Origin = o, Direction = d } end }
local Random = {}
Random.__index = Random
function Random.new(seed)
	local s = ((seed or 0) * 2654435761 + 12345) % 2147483648
	return setmetatable({ s = s }, Random)
end
function Random:_next() self.s = (self.s * 1103515245 + 12345) % 2147483648; return self.s / 2147483648 end
function Random:NextNumber(a, b) if a == nil then return self:_next() end return a + (b - a) * self:_next() end
function Random:NextInteger(a, b) return a + math.floor(self:_next() * (b - a + 1)) end
function Random:NextUnitVector()
	local z = self:_next() * 2 - 1; local t = self:_next() * 2 * math.pi; local r = math.sqrt(1 - z * z)
	return V3.new(r * math.cos(t), r * math.sin(t), z)
end

---------------------------------------------------------------- Enum
local __enumItems = {}
local Enum = setmetatable({}, { __index = function(t, enumName)
	local e = setmetatable({}, { __index = function(et, itemName)
		local key = enumName .. "." .. tostring(itemName)
		if not __enumItems[key] then
			__enumItems[key] = setmetatable({ Name = tostring(itemName), EnumType = enumName }, { __tostring = function() return "Enum." .. key end })
		end
		return __enumItems[key]
	end })
	rawset(t, enumName, e)
	return e
end })

---------------------------------------------------------------- Signal
local Signal = {}
Signal.__index = Signal
function Signal.new() return setmetatable({ fns = {} }, Signal) end
function Signal:Connect(fn)
	local rec = { fn = fn, Connected = true }
	table.insert(self.fns, rec)
	local sig = self
	rec.Disconnect = function() rec.Connected = false end
	return rec
end
Signal.Once = Signal.Connect
function Signal:Wait() return end
function Signal:Fire(...)
	for _, r in ipairs(self.fns) do if r.Connected then task.spawn(r.fn, ...) end end
end
local SIGNALS = { Touched = 1, TouchEnded = 1, Changed = 1, ChildAdded = 1, ChildRemoved = 1, DescendantAdded = 1, DescendantRemoving = 1, AncestryChanged = 1, Destroying = 1,
	Died = 1, Heartbeat = 1, RenderStepped = 1, Stepped = 1, PreSimulation = 1, PostSimulation = 1, PreRender = 1, PlayerAdded = 1, PlayerRemoving = 1, Activated = 1,
	MouseButton1Click = 1, InputBegan = 1, InputEnded = 1, Completed = 1, Triggered = 1, OnServerEvent = 1, OnClientEvent = 1, CharacterAdded = 1, Equipped = 1, Unequipped = 1 }

---------------------------------------------------------------- Instance
local DATA = setmetatable({}, { __mode = "k" })
local CLASS_PARENT = {
	Part = "BasePart", WedgePart = "BasePart", CornerWedgePart = "BasePart", TrussPart = "BasePart", SpawnLocation = "Part", Seat = "Part", VehicleSeat = "Part",
	MeshPart = "BasePart", UnionOperation = "BasePart", NegateOperation = "BasePart", BasePart = "PVInstance", Model = "PVInstance", PVInstance = "Instance",
	Folder = "Instance", Weld = "JointInstance", Motor6D = "JointInstance", JointInstance = "Instance", WeldConstraint = "Instance",
	PointLight = "Light", SpotLight = "Light", SurfaceLight = "Light", Light = "Instance", Workspace = "Model", ParticleEmitter = "Instance", Beam = "Instance", Trail = "Instance",
	Attachment = "Instance", SpecialMesh = "Instance", Decal = "Instance", Texture = "Instance", Sound = "Instance",
}
local IS_PART = { Part = 1, WedgePart = 1, CornerWedgePart = 1, TrussPart = 1, SpawnLocation = 1, Seat = 1, VehicleSeat = 1, MeshPart = 1, UnionOperation = 1, NegateOperation = 1 }

local function isA(class, name)
	local c = class
	while c do
		if c == name then return true end
		c = CLASS_PARENT[c]
	end
	return name == "Instance"
end

local Instance = {}
local IM = {}   -- phương thức
local function newInstance(class)
	local inst = {}
	DATA[inst] = { class = class, name = class, parent = nil, children = {}, props = {}, attrs = {}, signals = {}, scale = 1 }
	setmetatable(inst, Instance.__mt)
	return inst
end
local function dataOf(i) return DATA[i] end
local function isInstance(v) return type(v) == "table" and DATA[v] ~= nil end

local function fullName(i)
	local parts, c = {}, i
	while c do
		if DATA[c].class ~= "DataModel" then table.insert(parts, 1, DATA[c].name) end
		c = DATA[c].parent
	end
	return table.concat(parts, ".")
end

local function setParent(inst, p)
	local d = DATA[inst]
	if d.parent then
		local sib = DATA[d.parent].children
		local idx = table.find(sib, inst)
		if idx then table.remove(sib, idx) end
		local ps = DATA[d.parent].signals.ChildRemoved
		if ps then ps:Fire(inst) end
	end
	d.parent = p
	if p then
		table.insert(DATA[p].children, inst)
		local ps = DATA[p].signals.ChildAdded
		if ps then ps:Fire(inst) end
	end
end

local function partDefaults(class)
	local size = Vector3.new(2, 1, 2)
	if class == "WedgePart" or class == "CornerWedgePart" then size = Vector3.new(2, 2, 2) end
	return { Size = size, CFrame = CFrame.new(0, 0, 0), Color = Color3.new(0.63, 0.64, 0.63), Material = Enum.Material.Plastic, Transparency = 0, Reflectance = 0,
		Anchored = false, CanCollide = true, CanQuery = true, CanTouch = true, Massless = false, Shape = Enum.PartType.Block, PivotOffset = CFrame.new(0, 0, 0) }
end

function Instance.new(class, parent)
	local inst = newInstance(class)
	local d = DATA[inst]
	if IS_PART[class] then
		for k, v in pairs(partDefaults(class)) do d.props[k] = v end
		if class == "SpawnLocation" or class == "Seat" then d.props.Size = Vector3.new(6, 1, 6) end
	elseif class == "Model" or class == "Folder" then
		-- trống
	elseif class == "Motor6D" or class == "Weld" then
		d.props.C0, d.props.C1 = CFrame.new(0, 0, 0), CFrame.new(0, 0, 0)
	elseif class == "SpecialMesh" then
		d.props.Scale, d.props.Offset, d.props.MeshType = Vector3.new(1, 1, 1), Vector3.new(0, 0, 0), Enum.MeshType.FileMesh
	elseif class == "Attachment" then
		d.props.CFrame = CFrame.new(0, 0, 0)
	end
	if parent then setParent(inst, parent) end
	return inst
end

local function allParts(root, out)
	out = out or {}
	for _, c in ipairs(DATA[root].children) do
		if isA(DATA[c].class, "BasePart") then table.insert(out, c) end
		allParts(c, out)
	end
	return out
end

local function partsUnder(root)
	local out = {}
	if isA(DATA[root].class, "BasePart") then table.insert(out, root) end
	allParts(root, out)
	return out
end

local function aabbOf(parts)
	local mn, mx = nil, nil
	for _, p in ipairs(parts) do
		local d = DATA[p]; local cf, sz = d.props.CFrame, d.props.Size
		for sx = -1, 1, 2 do for sy = -1, 1, 2 do for sz2 = -1, 1, 2 do
			local w = cf:PointToWorldSpace(Vector3.new(sx * sz.X / 2, sy * sz.Y / 2, sz2 * sz.Z / 2))
			if not mn then mn, mx = w, w else mn, mx = mn:Min(w), mx:Max(w) end
		end end end
	end
	return mn, mx
end

local function pivotOf(inst)
	local d = DATA[inst]
	if isA(d.class, "BasePart") then return d.props.CFrame * (d.props.PivotOffset or CFrame.new(0, 0, 0)) end
	local pp = d.props.PrimaryPart
	if pp then return DATA[pp].props.CFrame * (DATA[pp].props.PivotOffset or CFrame.new(0, 0, 0)) end
	local parts = partsUnder(inst)
	if #parts == 0 then return CFrame.new(0, 0, 0) end
	local mn, mx = aabbOf(parts)
	return CFrame.new((mn + mx) / 2)
end

local function pivotTo(inst, target)
	local delta = target * pivotOf(inst):Inverse()
	for _, p in ipairs(partsUnder(inst)) do
		local pd = DATA[p]
		pd.props.CFrame = delta * pd.props.CFrame
	end
end

local NOOP = { ApplyImpulse = 1, ApplyAngularImpulse = 1, SetNetworkOwner = 1, SetNetworkOwnershipAuto = 1, MakeJoints = 1, BreakJoints = 1, Play = 1, Stop = 1, Pause = 1,
	Emit = 1, Resume = 1, SetPartCollisionGroup = 1, Sleep = 1 }

local GETTERS = {}
local SETTERS = {}

Instance.__mt = {}
Instance.__mt.__index = function(inst, k)
	local d = DATA[inst]
	if k == "ClassName" then return d.class end
	if k == "Name" then return d.name end
	if k == "Parent" then return d.parent end
	local g = GETTERS[k]
	if g then
		local r = g(inst, d)
		if r ~= nil then return r end
	end
	local pv = d.props[k]
	if pv ~= nil then return pv end
	local m = IM[k]
	if m then return m end
	if NOOP[k] then return function() end end
	if SIGNALS[k] then
		if not d.signals[k] then d.signals[k] = Signal.new() end
		return d.signals[k]
	end
	for _, c in ipairs(d.children) do if DATA[c].name == k then return c end end
	if d.class == "Workspace" or d.class == "Folder" or d.class == "ServiceContainer" then
		if __MODULES[k] then
			local ref = Instance.new("ModuleScript"); DATA[ref].name = k; DATA[ref].props.__module = k; return ref
		end
	end
	return nil
end
Instance.__mt.__newindex = function(inst, k, v)
	local d = DATA[inst]
	if k == "Parent" then setParent(inst, v); return end
	if k == "Name" then d.name = v; return end
	local s = SETTERS[k]
	if s and s(inst, d, v) then return end
	d.props[k] = v
end
Instance.__mt.__tostring = function(inst) return DATA[inst].name end

GETTERS.Position = function(inst, d) if d.props.CFrame and isA(d.class, "BasePart") then return d.props.CFrame.Position end end
SETTERS.Position = function(inst, d, v)
	if isA(d.class, "BasePart") then local c = d.props.CFrame; d.props.CFrame = CFrame.new(v) * c.Rotation; return true end
end
GETTERS.Orientation = function(inst, d)
	if isA(d.class, "BasePart") then local rx, ry, rz = d.props.CFrame:ToOrientation(); return Vector3.new(math.deg(rx), math.deg(ry), math.deg(rz)) end
end
SETTERS.Orientation = function(inst, d, v)
	if isA(d.class, "BasePart") then d.props.CFrame = CFrame.new(d.props.CFrame.Position) * CFrame.fromOrientation(math.rad(v.X), math.rad(v.Y), math.rad(v.Z)); return true end
end
GETTERS.Rotation = GETTERS.Orientation
SETTERS.Rotation = SETTERS.Orientation
GETTERS.AssemblyLinearVelocity = function() return Vector3.new(0, 0, 0) end
GETTERS.Velocity = GETTERS.AssemblyLinearVelocity
GETTERS.CFrame = nil
SETTERS.CFrame = function(inst, d, v)
	-- Cảnh báo bẫy kinh điển: đặt CFrame SAU khi đã weld. Roblox thật kéo cả assembly; stub không mô phỏng.
	if isA(d.class, "BasePart") then
		if d.hasWeld and d.parent and not __SCALE_WARN[inst] then
			__SCALE_WARN[inst] = true
			table.insert(__LOG, "WARN|" .. fullName(inst) .. ": đặt CFrame sau khi đã có Weld/Motor6D — Roblox thật có thể kéo cả assembly đi, sandbox KHÔNG mô phỏng (đặt vị trí TRƯỚC khi weld, hoặc dùng PivotTo cho cả model)")
		end
		d.props.CFrame = v; return true
	end
end
SETTERS.Size = function(inst, d, v)
	if isA(d.class, "BasePart") then
		d.props.Size = Vector3.new(math.clamp(v.X, 0.001, 2048), math.clamp(v.Y, 0.001, 2048), math.clamp(v.Z, 0.001, 2048)); return true
	end
end
local function onJoint(inst, d, which, v)
	d.props[which] = v
	if v and isInstance(v) then DATA[v].hasWeld = true end
	if d.props.Part0 and d.props.Part1 and not d.props.__rel then
		d.props.__rel = DATA[d.props.Part0].props.CFrame:ToObjectSpace(DATA[d.props.Part1].props.CFrame)
	end
	return true
end
SETTERS.Part0 = function(inst, d, v) return onJoint(inst, d, "Part0", v) end
SETTERS.Part1 = function(inst, d, v) return onJoint(inst, d, "Part1", v) end

function IM.GetChildren(inst) return table.clone(DATA[inst].children) end
function IM.GetDescendants(inst)
	local out = {}
	local function rec(i) for _, c in ipairs(DATA[i].children) do table.insert(out, c); rec(c) end end
	rec(inst)
	return out
end
function IM.IsA(inst, name) return isA(DATA[inst].class, name) end
function IM.FindFirstChild(inst, name, recursive)
	for _, c in ipairs(DATA[inst].children) do if DATA[c].name == name then return c end end
	if recursive then for _, c in ipairs(DATA[inst].children) do local r = IM.FindFirstChild(c, name, true); if r then return r end end end
	local k = nil
	if DATA[inst].class == "Folder" or DATA[inst].class == "ServiceContainer" or DATA[inst].class == "Workspace" then
		if __MODULES[name] then return inst[name] end
	end
	return nil
end
function IM.WaitForChild(inst, name, timeout)
	local c = IM.FindFirstChild(inst, name)
	if c == nil then table.insert(__LOG, "WARN|WaitForChild('" .. tostring(name) .. "') trên " .. fullName(inst) .. " không có — Roblox thật sẽ treo (hoặc trả nil nếu có timeout)") end
	return c
end
function IM.FindFirstChildOfClass(inst, cls) for _, c in ipairs(DATA[inst].children) do if DATA[c].class == cls then return c end end return nil end
function IM.FindFirstChildWhichIsA(inst, cls, rec)
	for _, c in ipairs(DATA[inst].children) do if isA(DATA[c].class, cls) then return c end end
	if rec then for _, c in ipairs(DATA[inst].children) do local r = IM.FindFirstChildWhichIsA(c, cls, true); if r then return r end end end
	return nil
end
function IM.GetFullName(inst) return fullName(inst) end
function IM.IsDescendantOf(inst, anc) local c = DATA[inst].parent; while c do if c == anc then return true end c = DATA[c].parent end return false end
function IM.IsAncestorOf(inst, desc) return IM.IsDescendantOf(desc, inst) end
function IM.Destroy(inst) setParent(inst, nil); DATA[inst].destroyed = true end
function IM.ClearAllChildren(inst) for _, c in ipairs(table.clone(DATA[inst].children)) do IM.Destroy(c) end end
function IM.SetAttribute(inst, k, v) DATA[inst].attrs[k] = v end
function IM.GetAttribute(inst, k) return DATA[inst].attrs[k] end
function IM.GetAttributes(inst) return table.clone(DATA[inst].attrs) end
function IM.GetPropertyChangedSignal(inst, name) local d = DATA[inst]; local key = "pc_" .. name; if not d.signals[key] then d.signals[key] = Signal.new() end return d.signals[key] end
function IM.Clone(inst)
	local map = {}
	local function rec(src, parent)
		local d = DATA[src]
		local n = newInstance(d.class)
		local nd = DATA[n]
		nd.name = d.name
		for k, v in pairs(d.props) do nd.props[k] = v end
		for k, v in pairs(d.attrs) do nd.attrs[k] = v end
		nd.scale = d.scale
		map[src] = n
		if parent then setParent(n, parent) end
		for _, c in ipairs(d.children) do rec(c, n) end
		return n
	end
	local r = rec(inst, nil)
	for _, n in pairs(map) do -- ánh xạ lại Part0/Part1/PrimaryPart về bản sao
		local nd = DATA[n]
		for _, key in ipairs({ "Part0", "Part1", "PrimaryPart" }) do
			local ref = nd.props[key]
			if ref and map[ref] then nd.props[key] = map[ref]; DATA[map[ref]].hasWeld = DATA[ref].hasWeld end
		end
	end
	return r
end
function IM.GetPivot(inst) return pivotOf(inst) end
function IM.PivotTo(inst, cf) pivotTo(inst, cf) end
function IM.MoveTo(inst, pos) pivotTo(inst, CFrame.new(pos) * pivotOf(inst).Rotation) end
function IM.SetPrimaryPartCFrame(inst, cf) pivotTo(inst, cf) end
function IM.GetBoundingBox(inst)
	local parts = partsUnder(inst)
	if #parts == 0 then return CFrame.new(0, 0, 0), Vector3.new(0, 0, 0) end
	local mn, mx = aabbOf(parts)
	return CFrame.new((mn + mx) / 2), mx - mn
end
function IM.GetExtentsSize(inst) local _, s = IM.GetBoundingBox(inst); return s end
function IM.GetScale(inst) return DATA[inst].scale end
function IM.ScaleTo(inst, s)
	local d = DATA[inst]; local k = s / d.scale; local pv = pivotOf(inst)
	for _, p in ipairs(partsUnder(inst)) do
		local pd = DATA[p]; local rel = pv:ToObjectSpace(pd.props.CFrame)
		pd.props.Size = pd.props.Size * k
		pd.props.CFrame = pv * (CFrame.new(rel.Position * k) * rel.Rotation)
	end
	d.scale = s
end
function IM.GetMass(inst) local s = DATA[inst].props.Size; return s and s.X * s.Y * s.Z or 0 end
function IM.GetTouchingParts() return {} end
function IM.GetConnectedParts() return {} end
function IM.GetJoints() return {} end
function IM.Raycast() return nil end
function IM.IsDescendantOfWorkspace() return true end

---------------------------------------------------------------- game, services, task
local Workspace = newInstance("Workspace"); DATA[Workspace].name = "Workspace"
local function service(name)
	local s = newInstance("ServiceContainer"); DATA[s].name = name; return s
end
local game = newInstance("DataModel"); DATA[game].name = "game"
local SERVICES = { Workspace = Workspace }
setParent(Workspace, game)
for _, n in ipairs({ "ReplicatedStorage", "ServerStorage", "ServerScriptService", "StarterGui", "StarterPlayer", "Lighting", "SoundService", "ReplicatedFirst" }) do
	SERVICES[n] = service(n); setParent(SERVICES[n], game)
end
local function mkService(name, tbl) tbl.__name = name; SERVICES[name] = tbl end

-- ---- scheduler
local __WAITERS = {}   -- { time=, co= }
local __TWEENS = {}
local __HB = {}        -- callbacks Heartbeat/RenderStepped...
local function resumeCo(co, ...)
	local ok, err = coroutine.resume(co, ...)
	if not ok then table.insert(__LOG, "ERR|" .. tostring(err)) end
end
task = {}
function task.wait(t)
	t = t or 0.0166667
	local co = coroutine.running()
	table.insert(__WAITERS, { time = __TIME + t, co = co })
	coroutine.yield()
	return t
end
function task.spawn(f, ...)
	local co = type(f) == "thread" and f or coroutine.create(f)
	resumeCo(co, ...)
	return co
end
function task.defer(f, ...) return task.spawn(f, ...) end
function task.delay(t, f, ...)
	local args = table.pack(...)
	local co = coroutine.create(function() f(table.unpack(args, 1, args.n)) end)
	table.insert(__WAITERS, { time = __TIME + t, co = co })
	return co
end
function task.cancel(co) for i = #__WAITERS, 1, -1 do if __WAITERS[i].co == co then table.remove(__WAITERS, i) end end end
function task.desynchronize() end
function task.synchronize() end
local function wait(t) return task.wait(t), __TIME end
local function delay(t, f) return task.delay(t, f) end
local function spawn(f) return task.spawn(f) end

local function hbSignal(name)
	local s = Signal.new()
	local connect = s.Connect
	s.Connect = function(self, fn) local r = connect(self, fn); table.insert(__HB, r); return r end
	s.Once = s.Connect
	s.Wait = function() return task.wait() end
	return s
end
local RunService = { Heartbeat = hbSignal(), RenderStepped = hbSignal(), Stepped = hbSignal(), PreSimulation = hbSignal(), PostSimulation = hbSignal(), PreRender = hbSignal() }
function RunService:IsServer() return true end
function RunService:IsClient() return false end
function RunService:IsStudio() return true end
function RunService:IsRunning() return true end
function RunService:BindToRenderStep(name, pri, fn) local r = RunService.RenderStepped:Connect(function(dt) fn(dt) end) end
function RunService:UnbindFromRenderStep() end
mkService("RunService", RunService)

local TweenService = {}
function TweenService:Create(inst, info, goals)
	local tw = { _inst = inst, _info = info, _goals = goals, PlaybackState = "Begin" }
	local sigs = { Completed = Signal.new() }
	tw.Completed = sigs.Completed
	function tw:Play()
		local start = {}
		for k, _ in pairs(goals) do start[k] = inst[k] end
		table.insert(__TWEENS, { tw = tw, inst = inst, goals = goals, start = start, t0 = __TIME + (info.DelayTime or 0), dur = math.max(info.Time or 1, 1e-6) })
	end
	function tw:Cancel() for i = #__TWEENS, 1, -1 do if __TWEENS[i].tw == tw then table.remove(__TWEENS, i) end end end
	tw.Pause = tw.Cancel
	function tw:Destroy() tw:Cancel() end
	return tw
end
mkService("TweenService", TweenService)
local function lerpAny(a, b, t)
	if type(a) == "number" then return a + (b - a) * t end
	local ok, r = pcall(function() return a:Lerp(b, t) end)
	if ok then return r end
	return t >= 1 and b or a
end
local function stepTweens()
	for i = #__TWEENS, 1, -1 do
		local tw = __TWEENS[i]
		if __TIME >= tw.t0 then
			local a = math.min(1, (__TIME - tw.t0) / tw.dur)
			for k, g in pairs(tw.goals) do tw.inst[k] = lerpAny(tw.start[k], g, a) end
			if a >= 1 then table.remove(__TWEENS, i); tw.tw.Completed:Fire(Enum.PlaybackState.Completed) end
		end
	end
end
mkService("Debris", { AddItem = function() end })
mkService("Players", { LocalPlayer = nil, PlayerAdded = Signal.new(), PlayerRemoving = Signal.new(), GetPlayers = function() return {} end })
mkService("UserInputService", { InputBegan = Signal.new(), InputEnded = Signal.new(), TouchEnabled = false, GetMouseLocation = function() return Vector2.new(0, 0) end })
mkService("CollectionService", { AddTag = function() end, HasTag = function() return false end, GetTagged = function() return {} end })
mkService("HttpService", { GenerateGUID = function() return "00000000-0000-0000-0000-000000000000" end })
mkService("ContentProvider", { PreloadAsync = function() end })
mkService("PhysicsService", { RegisterCollisionGroup = function() end, CollisionGroupSetCollidable = function() end })
mkService("MarketplaceService", {})
mkService("ReplicatedFirst", {})

setmetatable(game, { __index = function(t, k)
	if k == "GetService" then return function(self, n) return Instance.__service(n) end end
	local s = SERVICES[k]
	if s then return s end
	return Instance.__mt.__index(t, k)
end, __newindex = Instance.__mt.__newindex, __tostring = function() return "game" end })
Instance.__service = function(name)
	local s = SERVICES[name]
	if s == nil then
		table.insert(__LOG, "WARN|GetService('" .. tostring(name) .. "') chưa được giả lập — trả về bảng rỗng")
		s = {}; SERVICES[name] = s
	end
	return s
end
local workspace = Workspace
local script = newInstance("Script"); DATA[script].name = "Script"; setParent(script, SERVICES.ServerScriptService)

local function typeof_(v)
	local t = type(v)
	if t ~= "table" then return t end
	if DATA[v] then return "Instance" end
	local mt = getmetatable(v)
	if mt == V3 then return "Vector3" elseif mt == V2 then return "Vector2" elseif mt == CF then return "CFrame" elseif mt == C3 then return "Color3"
	elseif mt == Signal then return "RBXScriptSignal" end
	if mt and mt.__tostring and tostring(v):sub(1, 5) == "Enum." then return "EnumItem" end
	return "table"
end
local typeof = typeof_

local function require_(m)
	if isInstance(m) and DATA[m].props.__module then
		local name = DATA[m].props.__module
		local rec = __MODULES[name]
		if rec.loaded == nil then rec.loaded = true; rec.value = rec.fn() end
		return rec.value
	end
	if type(m) == "string" and __MODULES[m] then
		local rec = __MODULES[m]
		if rec.loaded == nil then rec.loaded = true; rec.value = rec.fn() end
		return rec.value
	end
	error("[sandbox] require: không tìm thấy module " .. tostring(m) .. " (thêm bằng --lib hoặc --autolib)")
end

local function print_(...)
	local parts = table.pack(...)
	for i = 1, parts.n do parts[i] = tostring(parts[i]) end
	table.insert(__LOG, "LOG|" .. table.concat(parts, "\t", 1, parts.n))
end
local print = print_
local function warn_(...)
	local parts = table.pack(...)
	for i = 1, parts.n do parts[i] = tostring(parts[i]) end
	table.insert(__LOG, "WARN|" .. table.concat(parts, "\t", 1, parts.n))
end

local warn = warn_
local require = require_
local function tick() return 1.7e9 + __TIME end
local function time() return __TIME end

---------------------------------------------------------------- Sandbox: chạy, chụp, xuất JSON
local Sandbox = {}
local function jstr(s)
	return '"' .. tostring(s):gsub('[%c"\\]', function(c)
		if c == '"' then return '\\"' elseif c == "\\" then return "\\\\" elseif c == "\n" then return "\\n" elseif c == "\t" then return "\\t" end
		return string.format("\\u%04x", string.byte(c))
	end) .. '"'
end
local function jn(n) if n ~= n or n == math.huge or n == -math.huge then return "0" end return string.format("%.6g", n) end
local function jcf(cf) return "[" .. table.concat({ jn(cf.X), jn(cf.Y), jn(cf.Z), jn(cf.m11), jn(cf.m12), jn(cf.m13), jn(cf.m21), jn(cf.m22), jn(cf.m23), jn(cf.m31), jn(cf.m32), jn(cf.m33) }, ",") .. "]" end
local function jv3(v) return "[" .. jn(v.X) .. "," .. jn(v.Y) .. "," .. jn(v.Z) .. "]" end
local function jcol(c) return "[" .. jn(c.R) .. "," .. jn(c.G) .. "," .. jn(c.B) .. "]" end

local function snapshot()
	local parts, nodes, joints, extras = {}, {}, {}, {}
	local ids = {}          -- Instance → số thứ tự part (tên part có thể trùng nên dùng id)
	local order = {}
	local function collect(i)
		for _, c in ipairs(DATA[i].children) do
			if isA(DATA[c].class, "BasePart") then table.insert(order, c); ids[c] = #order - 1 end
			collect(c)
		end
	end
	collect(Workspace)
	for _, c in ipairs(order) do
		local d = DATA[c]
		local cls = d.class
		local p = d.props
		local shape = "Block"
		if cls == "WedgePart" then shape = "Wedge" elseif cls == "CornerWedgePart" then shape = "CornerWedge"
		elseif cls == "MeshPart" then shape = "Mesh" elseif cls == "UnionOperation" or cls == "NegateOperation" then shape = "Union"
		elseif p.Shape and p.Shape.Name then shape = p.Shape.Name end
		local mesh = nil
		for _, ch in ipairs(d.children) do
			if DATA[ch].class == "SpecialMesh" then
				local md = DATA[ch].props
				mesh = '{"type":' .. jstr(md.MeshType and md.MeshType.Name or "FileMesh") .. ',"scale":' .. jv3(md.Scale) .. ',"offset":' .. jv3(md.Offset) .. ',"id":' .. jstr(md.MeshId or "") .. "}"
			end
		end
		table.insert(parts, '{"id":' .. ids[c] .. ',"path":' .. jstr(fullName(c)) .. ',"name":' .. jstr(d.name) .. ',"class":' .. jstr(cls) .. ',"shape":' .. jstr(shape) ..
			',"size":' .. jv3(p.Size) .. ',"cf":' .. jcf(p.CFrame) .. ',"color":' .. jcol(p.Color) .. ',"material":' .. jstr(p.Material and p.Material.Name or "Plastic") ..
			',"transparency":' .. jn(p.Transparency or 0) .. ',"reflectance":' .. jn(p.Reflectance or 0) .. ',"anchored":' .. tostring(p.Anchored and true or false) ..
			',"canCollide":' .. tostring(p.CanCollide and true or false) .. (mesh and (',"mesh":' .. mesh) or "") .. "}")
	end
	local function walk(i)
		for _, c in ipairs(DATA[i].children) do
			local d = DATA[c]
			local cls = d.class
			if cls == "Model" or cls == "Folder" then
				table.insert(nodes, '{"path":' .. jstr(fullName(c)) .. ',"class":' .. jstr(cls) .. ',"scale":' .. jn(d.scale) .. "}")
			elseif cls == "WeldConstraint" or cls == "Weld" or cls == "Motor6D" then
				local p0, p1 = d.props.Part0, d.props.Part1
				table.insert(joints, '{"kind":' .. jstr(cls) .. ',"path":' .. jstr(fullName(c)) .. ',"p0":' .. (p0 and ids[p0] or -1) .. ',"p1":' .. (p1 and ids[p1] or -1) .. "}")
			elseif cls == "PointLight" or cls == "SpotLight" or cls == "SurfaceLight" then
				table.insert(extras, '{"kind":"light","path":' .. jstr(fullName(c)) .. ',"brightness":' .. jn(d.props.Brightness or 1) .. ',"range":' .. jn(d.props.Range or 8) .. "}")
			elseif cls == "ParticleEmitter" or cls == "Beam" or cls == "Trail" then
				table.insert(extras, '{"kind":' .. jstr(cls) .. ',"path":' .. jstr(fullName(c)) .. "}")
			end
			walk(c)
		end
	end
	walk(Workspace)
	return '{"t":' .. jn(__TIME) .. ',"parts":[' .. table.concat(parts, ",") .. '],"nodes":[' .. table.concat(nodes, ",") .. '],"joints":[' .. table.concat(joints, ",") .. '],"extras":[' .. table.concat(extras, ",") .. "]}"
end

-- Chạy hàm main trong coroutine, chạy khung hình đến khi hết việc hoặc hết thời gian; chụp tại các mốc snaps.
function Sandbox.run(main, opts)
	opts = opts or {}
	local dt = opts.dt or (1 / 30)
	local untilT = opts.time or 0
	local snaps = opts.snaps or {}
	table.sort(snaps)
	local frames = {}
	local si = 1
	local co = coroutine.create(main)
	resumeCo(co)
	local maxT = 120
	local function pending() return #__WAITERS > 0 or #__TWEENS > 0 end
	local function takeSnaps()
		while si <= #snaps and snaps[si] <= __TIME + 1e-9 do table.insert(frames, snapshot()); si += 1 end
	end
	takeSnaps()
	while (__TIME < untilT or pending() or si <= #snaps) and __TIME < maxT do
		if si > #snaps and not (__TIME < untilT or pending()) then break end
		__TIME += dt
		stepTweens()
		-- đánh thức coroutine đến hạn
		table.sort(__WAITERS, function(a, b) return a.time < b.time end)
		while #__WAITERS > 0 and __WAITERS[1].time <= __TIME + 1e-9 do
			local w = table.remove(__WAITERS, 1)
			resumeCo(w.co)
		end
		if __TIME <= untilT + 1e-9 then
			for i = #__HB, 1, -1 do
				local r = __HB[i]
				if r.Connected then local ok, err = pcall(r.fn, dt) ; if not ok then table.insert(__LOG, "ERR|" .. tostring(err)) end else table.remove(__HB, i) end
			end
		end
		takeSnaps()
	end
	if #snaps == 0 then table.insert(frames, snapshot()) elseif #frames == 0 then table.insert(frames, snapshot()) end
	-- đảm bảo có khung cuối nếu snaps rỗng đã chụp; nếu có snaps, thêm khung cuối "final"
	return frames
end

function Sandbox.emit(frames)
	__print("<<<SCENE")
	__print('{"frames":[' .. table.concat(frames, ",") .. '],"log":[' .. (function()
		local t = {}
		for _, l in ipairs(__LOG) do table.insert(t, jstr(l)) end
		return table.concat(t, ",")
	end)() .. '],"time":' .. jn(__TIME) .. "}")
	__print("SCENE>>>")
end
