--!nonstrict
-- SoundKit — phát âm thanh nhiều lớp, 3D, có pitch ngẫu nhiên, EQ/reverb, trễ theo khoảng cách (CLIENT).
-- Không tự bịa asset id: điền id thật vào SoundKit.Ids (từ scripts/synth_sfx.py đã upload, hoặc Toolbox). Chưa có id → warn 1 lần, không crash.
--
--   local Snd = require(RS.SoundKit)
--   Snd.Ids.explosion = { "rbxassetid://<id>" }            -- nhiều id = biến thể, chọn ngẫu nhiên mỗi lần
--   Snd.Play("explosion", Vector3.new(0, 5, 0))            -- preset nhiều lớp (xem PRESETS)
--   local beam = Snd.Loop("laser_beam_loop", part)          -- vòng lặp có fade; beam:Stop()
--   Snd.Missing()                                           -- in những tên còn thiếu id

local SoundService = game:GetService("SoundService")
local Debris = game:GetService("Debris")
local Workspace = game:GetService("Workspace")

local SK = {}
SK.Ids = {}            -- name -> { "rbxassetid://...", ... }
SK.SPEED = 700         -- studs/s: tốc độ âm thanh dùng cho trễ theo khoảng cách (nổ xa nghe trễ)
SK.MasterVolume = 1

-- Preset: mỗi lớp = { sample = tênTrongIds, vol, pitch = {min,max}, delay (s), eq = {Low,Mid,High dB}, reverb = {Decay, Mix}, distort, maxDist }
-- Nhiều lớp từ CÙNG một mẫu với pitch/EQ khác nhau cho tiếng "dày" (thump trầm + crack sáng + đuôi vọng).
local PRESETS = {
	explosion = {
		{ sample = "explosion", vol = 1.0, pitch = { 0.92, 1.05 }, maxDist = 900 },
		{ sample = "explosion", vol = 0.7, pitch = { 0.55, 0.65 }, eq = { 6, -4, -12 }, maxDist = 1200 },          -- sub-thump (hạ cao độ, nhấn trầm)
		{ sample = "impact_hit", vol = 0.5, pitch = { 0.5, 0.6 }, delay = 0.02, eq = { 8, -6, -10 }, maxDist = 600 },
		{ sample = "explosion", vol = 0.35, pitch = { 1.3, 1.5 }, delay = 0.12, eq = { -10, 0, 4 }, maxDist = 700 }, -- mảnh vỡ/lách tách
	},
	rifle = {
		{ sample = "gunshot_rifle", vol = 1.0, pitch = { 0.96, 1.05 }, maxDist = 600 },
		{ sample = "impact_hit", vol = 0.25, pitch = { 1.4, 1.6 }, eq = { -12, 0, 6 }, maxDist = 400 },
	},
	sniper = {
		{ sample = "sniper_shot", vol = 1.0, pitch = { 0.97, 1.03 }, maxDist = 1500, reverb = { Decay = 3, Mix = 0.2 } },
		{ sample = "gunshot_rifle", vol = 0.5, pitch = { 0.6, 0.7 }, eq = { 6, -2, -10 }, maxDist = 1500 },
	},
	laser = {
		{ sample = "laser_shot", vol = 0.9, pitch = { 0.95, 1.1 }, maxDist = 500 },
		{ sample = "whoosh", vol = 0.25, pitch = { 1.4, 1.7 }, delay = 0.02, maxDist = 300 },
	},
	charge = { { sample = "plasma_charge", vol = 0.9, pitch = { 1, 1 }, maxDist = 300 } },
	teleport = { { sample = "teleport", vol = 0.9, pitch = { 0.95, 1.05 }, maxDist = 400 } },
	hit = { { sample = "impact_hit", vol = 0.9, pitch = { 0.9, 1.15 }, maxDist = 300 } },
	bolt = { { sample = "bolt_action", vol = 0.8, pitch = { 0.98, 1.02 }, maxDist = 200 } },
	click = { { sample = "ui_click", vol = 0.6, pitch = { 0.97, 1.05 }, ui = true } },
	ping = { { sample = "ui_ping", vol = 0.6, pitch = { 1, 1 }, ui = true } },
}
SK.Presets = PRESETS

local warned = {}
local function pick(list) return list[math.random(1, #list)] end

local function idFor(name)
	local ids = SK.Ids[name]
	if not ids or #ids == 0 then
		if not warned[name] then warned[name] = true; warn("[SoundKit] chưa có id cho '" .. name .. "' — gán SoundKit.Ids." .. name .. " = { 'rbxassetid://...' }") end
		return nil
	end
	return pick(ids)
end

function SK.Missing()
	local seen = {}
	for _, layers in pairs(PRESETS) do for _, l in ipairs(layers) do seen[l.sample] = true end end
	local out = {}
	for name in pairs(seen) do if not SK.Ids[name] or #SK.Ids[name] == 0 then out[#out + 1] = name end end
	table.sort(out)
	print("[SoundKit] còn thiếu id: " .. (#out > 0 and table.concat(out, ", ") or "(không)"))
	return out
end

local function addEffects(sound, layer, dist)
	-- EQ: lớp tự khai + giảm treble theo khoảng cách (xa nghe "đục")
	local low, mid, high = (layer.eq and layer.eq[1]) or 0, (layer.eq and layer.eq[2]) or 0, (layer.eq and layer.eq[3]) or 0
	high -= math.clamp(dist / 40, 0, 14)
	if low ~= 0 or mid ~= 0 or high ~= 0 then
		local eq = Instance.new("EqualizerSoundEffect")
		eq.LowGain, eq.MidGain, eq.HighGain = low, mid, high
		eq.Parent = sound
	end
	if layer.reverb then
		local r = Instance.new("ReverbSoundEffect")
		r.DecayTime, r.WetLevel = layer.reverb.Decay or 2, -6 + (layer.reverb.Mix or 0.2) * 12
		r.Parent = sound
	end
	if layer.distort then
		local d = Instance.new("DistortionSoundEffect"); d.Level = layer.distort; d.Parent = sound
	end
end

-- Phát preset (hoặc một mẫu đơn nếu name không phải preset). where = Vector3 | BasePart | Attachment | nil (2D).
function SK.Play(name, where, opts)
	opts = opts or {}
	local layers = PRESETS[name] or { { sample = name, vol = 1, pitch = { 1, 1 } } }
	local host, pos
	if typeof(where) == "Vector3" then pos = where
	elseif typeof(where) == "Instance" then
		if where:IsA("BasePart") then host, pos = where, where.Position
		elseif where:IsA("Attachment") then host, pos = where, where.WorldPosition end
	end
	local cam = Workspace.CurrentCamera
	local dist = (pos and cam) and (cam.CFrame.Position - pos).Magnitude or 0
	local tempPart
	if pos and not host then
		tempPart = Instance.new("Part")
		tempPart.Anchored, tempPart.CanCollide, tempPart.CanQuery, tempPart.CanTouch, tempPart.Transparency, tempPart.Size = true, false, false, false, 1, Vector3.one * 0.2
		tempPart.Position = pos
		tempPart.Parent = Workspace
		host = tempPart
	end
	local latest = 0
	for _, layer in ipairs(layers) do
		local id = idFor(layer.sample)
		if id then
			local delay = (layer.delay or 0) + (pos and dist / SK.SPEED or 0)
			local s = Instance.new("Sound")
			s.SoundId = id
			s.Volume = (layer.vol or 1) * (opts.Volume or 1) * SK.MasterVolume
			local p = layer.pitch or { 1, 1 }
			local pitch = (p[1] + math.random() * (p[2] - p[1])) * (opts.Pitch or 1)
			if pitch ~= 1 then local ps = Instance.new("PitchShiftSoundEffect"); ps.Octave = pitch; ps.Parent = s end
			-- PitchShift giữ tốc độ; để đổi cả tốc độ (hạ cao độ + kéo dài) dùng PlaybackSpeed:
			s.PlaybackSpeed = layer.speedWithPitch and pitch or 1
			s.RollOffMode = Enum.RollOffMode.InverseTapered
			s.RollOffMinDistance = layer.minDist or 12
			s.RollOffMaxDistance = layer.maxDist or 300
			addEffects(s, layer, dist)
			if layer.ui or not host then s.Parent = SoundService else s.Parent = host end
			task.delay(delay, function()
				if s.Parent then s:Play() end
			end)
			latest = math.max(latest, delay + 6)
			Debris:AddItem(s, delay + 8)
		end
	end
	if tempPart then Debris:AddItem(tempPart, latest + 1) end
end

-- Vòng lặp (tia laser, động cơ, aura): fade in; trả đối tượng có :Stop(fade) và :SetPitch(x).
function SK.Loop(name, parent, volume)
	local id = idFor(name)
	if not id then return { Stop = function() end, SetPitch = function() end } end
	local s = Instance.new("Sound")
	s.SoundId, s.Looped, s.Volume = id, true, 0
	s.RollOffMode, s.RollOffMaxDistance = Enum.RollOffMode.InverseTapered, 250
	local ps = Instance.new("PitchShiftSoundEffect"); ps.Parent = s
	s.Parent = parent or SoundService
	s:Play()
	game:GetService("TweenService"):Create(s, TweenInfo.new(0.15), { Volume = (volume or 0.8) * SK.MasterVolume }):Play()
	return {
		Sound = s,
		SetPitch = function(_, x) ps.Octave = x end,
		Stop = function(_, fade)
			local f = fade or 0.2
			game:GetService("TweenService"):Create(s, TweenInfo.new(f), { Volume = 0 }):Play()
			Debris:AddItem(s, f + 0.1)
		end,
	}
end

-- Bước chân theo chất liệu sàn: SK.Ids["step_Grass"], ["step_Concrete"]... ; gọi mỗi bước (từ marker animation hoặc theo nhịp chạy).
local STEP_ALIASES = { Plastic = "Concrete", SmoothPlastic = "Concrete", Slate = "Concrete", Brick = "Concrete", Cobblestone = "Concrete",
	Ground = "Dirt", Mud = "Dirt", Sand = "Sand", Snow = "Snow", Grass = "Grass", Wood = "Wood", WoodPlanks = "Wood", Metal = "Metal", DiamondPlate = "Metal", CorrodedMetal = "Metal" }
function SK.Footstep(humanoid, volume)
	local mat = humanoid.FloorMaterial
	if mat == Enum.Material.Air then return end
	local key = STEP_ALIASES[mat.Name] or "Concrete"
	local root = humanoid.RootPart
	if not root then return end
	SK.Play("step_" .. key, root.Position - Vector3.new(0, 2.5, 0), { Volume = (volume or 0.5) * (humanoid.WalkSpeed > 20 and 1.3 or 1), Pitch = 0.9 + math.random() * 0.2 })
end

return SK
