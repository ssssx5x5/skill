# Báo cáo QA Model

**Tên model:**
**Mục đích/phong cách:**
**Kích thước và đơn vị:**
**File / vị trí:**

## Giả định
-

## Kiểm tra đã thực hiện
- `qa_check.py` (số mảnh, tris, ERROR/WARN):
- Sandbox Blender (góc × ánh sáng, contact sheet):
- Silhouette/góc nhìn:
- Bounds/tỷ lệ so với rig 5 studs:
- Điểm nối/phần rời:
- Mesh/topology:
- UV/vật liệu:
- Sandbox Roblox (`roblox_sandbox.lua`) / import vào môi trường đích:
- Playtest (nếu model có chức năng):

## Bảng điểm
| Nhận diện | Tỉ lệ | Mối nối | Mọi góc | Vật liệu | Kỹ thuật | Trong game | Tổng |
|---|---|---|---|---|---|---|---|
| /2 | /2 | /2 | /2 | /2 | /2 | /2 | /14 |

## Vòng sửa
| Vòng | Lỗi | Cách sửa | Kết quả |
|---|---|---|---|

## Lỗi phát hiện và xử lý
| Mức độ | Vị trí/vấn đề | Cách sửa | Trạng thái |
|---|---|---|---|

## Checklist
Tham chiếu: `references/acceptance.md`

## Kết luận
**Trạng thái:** Đạt / Chưa đạt / Chưa kiểm chứng
**Còn lại:**
