-- PixelShapes — phần BỔ SUNG cho PatternKit: Raster (lưới ô → Part gộp run), Annulus/Disc (vành khuyên, đĩa), PixelArt (mặt cười/biểu tượng từ chuỗi ký tự).
-- Vòm cầu vồng, N vật quanh trục, khối cầu/mây, dấu cộng, thanh nối, weld: dùng PatternKit (VoxelArch, RadialSlots, VoxelBlob, Plus, Rod, WeldAll).
-- Chạy được cả trong Studio lẫn sandbox. Các ô liền nhau cùng màu được gộp thành MỘT Part (ít part, vẫn đúng hình).
-- Quy ước mặt phẳng: u = RightVector (+X cục bộ), v = UpVector (+Y), độ sâu dọc ±Z cục bộ; mặt trước của Origin quay về −Z.
-- Nhìn từ PHÍA TRƯỚC (camera ở −Z nhìn vào) thì phải của vật nằm bên TRÁI người nhìn, nên PixelArt đã đảo cột để hình đọc đúng khi nhìn từ phía trước.
--
--   local PS = require(RS.PixelShapes)
--   PS.PixelArt(model, { Origin = CFrame.new(0, 0, -3), Vox = 0.2, Depth = 0.1, Rows = { "..#..#..", ".p....p." }, Palette = { ["#"] = dark, p = pink } })
--   PS.Annulus(model, { Origin = CFrame.new(0, 0, 2), Vox = 0.25, Depth = 0.8, OuterR = 3, InnerR = 2.2, Color = purple })
local PS = {}

local function mk(parent, name, size, cf, color, opts)
	local p = Instance.new("Part")
	p.Name = name; p.Size = size; p.CFrame = cf; p.Color = color
	p.Anchored = (opts and opts.Anchored) or false
	p.CanCollide = false
	p.TopSurface = Enum.SurfaceType.Smooth; p.BottomSurface = Enum.SurfaceType.Smooth
	p.Material = (opts and opts.Material) or Enum.Material.SmoothPlastic
	p.Parent = parent
	return p
end
PS.Part = mk

-- Raster: duyệt lưới ô (u,v) trong Bounds; Sample(u,v) trả Color3 hoặc nil; gộp run ngang cùng màu thành một Part. Trả số Part.
-- opts: Origin(CFrame), Vox(stud/ô), Depth(stud), Bounds = {u0,u1,v0,v1} (stud, quanh Origin), Sample, Name, Material, Anchored
function PS.Raster(parent, opts)
	local vox, depth, org = opts.Vox, opts.Depth, opts.Origin or CFrame.new()
	local u0, u1, v0, v1 = opts.Bounds[1], opts.Bounds[2], opts.Bounds[3], opts.Bounds[4]
	local n = 0
	local j0, j1 = math.floor(v0 / vox), math.ceil(v1 / vox) - 1
	local i0, i1 = math.floor(u0 / vox), math.ceil(u1 / vox) - 1
	for j = j0, j1 do
		local runStart, runColor = nil, nil
		local function flush(iEnd)
			if runStart then
				local w = (iEnd - runStart + 1) * vox
				local cu = (runStart + iEnd + 1) / 2 * vox
				mk(parent, opts.Name or "Voxel", Vector3.new(w, vox, depth), org * CFrame.new(cu, (j + 0.5) * vox, 0), runColor, opts)
				n += 1
			end
			runStart, runColor = nil, nil
		end
		for i = i0, i1 do
			local c = opts.Sample((i + 0.5) * vox, (j + 0.5) * vox)
			if c ~= runColor or c == nil then
				flush(i - 1)
				if c ~= nil then runStart, runColor = i, c end
			end
		end
		flush(i1)
	end
	return n
end

-- Vành khuyên phẳng (vòng kẹp nòng, viền): trục vuông góc mặt phẳng u-v của Origin
function PS.Annulus(parent, o)
	local R = o.OuterR
	return PS.Raster(parent, {
		Origin = o.Origin, Vox = o.Vox, Depth = o.Depth, Name = o.Name or "Ring", Material = o.Material, Anchored = o.Anchored, Bounds = { -R, R, -R, R },
		Sample = function(u, v)
			local r = math.sqrt(u * u + v * v)
			if r <= R and r >= o.InnerR then return o.Color end
			return nil
		end,
	})
end

function PS.Disc(parent, o)
	return PS.Annulus(parent, { Origin = o.Origin, Vox = o.Vox, Depth = o.Depth, OuterR = o.R, InnerR = 0, Color = o.Color, Name = o.Name or "Disc", Material = o.Material, Anchored = o.Anchored })
end

-- Pixel-art: Rows = {"..R..", ".RRR."}, Palette = {R = Color3}; ký tự không có trong Palette = ô trống. Cột đã đảo để đọc đúng khi nhìn từ phía TRƯỚC.
function PS.PixelArt(parent, o)
	local rows, pal, vox = o.Rows, o.Palette, o.Vox
	local nr, nc = #rows, 0
	for _, r in ipairs(rows) do nc = math.max(nc, #r) end
	local org = o.Origin or CFrame.new()
	local n = 0
	for ri, row in ipairs(rows) do
		local y = (nr / 2 - ri + 0.5) * vox
		local c = 1
		while c <= #row do
			local ch = row:sub(c, c)
			if pal[ch] then
				local e = c
				while e < #row and row:sub(e + 1, e + 1) == ch do e += 1 end
				local xl, xr = (nc / 2 - (c - 1)) * vox, (nc / 2 - e) * vox
				mk(parent, o.Name or "Pixel", Vector3.new((e - c + 1) * vox, vox, o.Depth), org * CFrame.new((xl + xr) / 2, y, 0), pal[ch], o)
				n += 1
				c = e + 1
			else
				c += 1
			end
		end
	end
	return n
end

return PS
