--!nonstrict
-- AssemblyGuard — đảm bảo model nhiều part (sniper, xe, robot...) KHÔNG rời nhau.
-- 3 lớp bảo vệ:
--   1) XÂY THEO Ổ NỐI (socket): mỗi mối ghép đặt part B sao cho điểm nối của B trùng điểm nối của A → liền theo cấu trúc, không phụ thuộc mắt.
--   2) KIỂM BẰNG SỐ: đồ thị tiếp xúc hình học (SAT giữa các hộp có hướng) + đồ thị weld + số assembly vật lý. Phải đúng 1 cụm.
--   3) CHỮA: weld các cặp đang chạm; báo (hoặc tự kéo) cụm lơ lửng về phía thân chính.
-- Phần toán thuần (Core) test được bằng luau CLI. Phần Roblox ở dưới.

local AG = {}
local Core = {}
AG.Core = Core

-- ===== Core: toán thuần, vector = {x,y,z} =====
local function dot(a, b) return a[1] * b[1] + a[2] * b[2] + a[3] * b[3] end
local function cross(a, b) return { a[2] * b[3] - a[3] * b[2], a[3] * b[1] - a[1] * b[3], a[1] * b[2] - a[2] * b[1] } end
local function len(a) return math.sqrt(dot(a, a)) end

-- obb = { c = {x,y,z}, axes = { {..},{..},{..} } (đơn vị, trực giao), h = {hx,hy,hz} (nửa kích thước) }
-- Trả về độ tách lớn nhất theo 15 trục SAT: > 0 là khoảng hở (cận dưới của khoảng cách thật), <= 0 là chạm/xuyên (|giá trị| = độ xuyên nhỏ nhất).
function Core.separation(A, B)
	local d = { B.c[1] - A.c[1], B.c[2] - A.c[2], B.c[3] - A.c[3] }
	local best = -math.huge
	local function test(L)
		local m = len(L)
		if m < 1e-6 then return end -- trục suy biến (hai cạnh song song)
		local u = { L[1] / m, L[2] / m, L[3] / m }
		local rA = A.h[1] * math.abs(dot(A.axes[1], u)) + A.h[2] * math.abs(dot(A.axes[2], u)) + A.h[3] * math.abs(dot(A.axes[3], u))
		local rB = B.h[1] * math.abs(dot(B.axes[1], u)) + B.h[2] * math.abs(dot(B.axes[2], u)) + B.h[3] * math.abs(dot(B.axes[3], u))
		local sep = math.abs(dot(d, u)) - (rA + rB)
		if sep > best then best = sep end
	end
	for i = 1, 3 do test(A.axes[i]); test(B.axes[i]) end
	for i = 1, 3 do for j = 1, 3 do test(cross(A.axes[i], B.axes[j])) end end
	return best
end

-- Union-find: n nút, edges = { {i,j}, ... } → danh sách cụm (mỗi cụm là list chỉ số) và nhãn từng nút.
function Core.components(n, edges)
	local parent = {}
	for i = 1, n do parent[i] = i end
	local function find(x)
		while parent[x] ~= x do parent[x] = parent[parent[x]]; x = parent[x] end
		return x
	end
	for _, e in ipairs(edges) do
		local a, b = find(e[1]), find(e[2])
		if a ~= b then parent[a] = b end
	end
	local groups, label, order = {}, {}, {}
	for i = 1, n do
		local r = find(i)
		if not groups[r] then groups[r] = {}; order[#order + 1] = r end
		table.insert(groups[r], i)
		label[i] = r
	end
	local out = {}
	for _, r in ipairs(order) do out[#out + 1] = groups[r] end
	table.sort(out, function(a, b) return #a > #b end) -- cụm lớn nhất = thân chính
	return out, label
end

-- Khoảng cách tối thiểu giữa hai cụm theo SAT; trả (gap, i, j).
function Core.nearestPair(obbs, groupA, groupB)
	local best, bi, bj = math.huge, nil, nil
	for _, i in ipairs(groupA) do
		for _, j in ipairs(groupB) do
			local s = Core.separation(obbs[i], obbs[j])
			if s < best then best, bi, bj = s, i, j end
		end
	end
	return best, bi, bj
end

-- ===== Roblox =====
local function obbOf(p)
	local cf, s = p.CFrame, p.Size
	local r, u, l = cf.RightVector, cf.UpVector, cf.LookVector
	return { c = { cf.X, cf.Y, cf.Z }, axes = { { r.X, r.Y, r.Z }, { u.X, u.Y, u.Z }, { l.X, l.Y, l.Z } }, h = { s.X / 2, s.Y / 2, s.Z / 2 } }
end

local function collectParts(model)
	local parts = {}
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") then parts[#parts + 1] = d end
	end
	return parts
end

-- Đồ thị tiếp xúc hình học: cạnh khi khoảng hở ≤ tol (mặc định 0.05 stud).
local function contactEdges(parts, obbs, tol)
	local edges = {}
	for i = 1, #parts do
		for j = i + 1, #parts do
			if Core.separation(obbs[i], obbs[j]) <= tol then edges[#edges + 1] = { i, j } end
		end
	end
	return edges
end

-- Đồ thị weld/joint: WeldConstraint, Weld, ManualWeld, Motor6D, RigidConstraint(attachment), AnimationConstraint, Snap...
local function weldEdges(parts)
	local index = {}
	for i, p in ipairs(parts) do index[p] = i end
	local edges = {}
	for _, p in ipairs(parts) do
		for _, d in ipairs(p:GetChildren()) do
			local a, b
			if d:IsA("WeldConstraint") or d:IsA("JointInstance") then a, b = d.Part0, d.Part1
			elseif d:IsA("AnimationConstraint") or d:IsA("RigidConstraint") then
				a = d.Attachment0 and d.Attachment0.Parent
				b = d.Attachment1 and d.Attachment1.Parent
			end
			if a and b and index[a] and index[b] then edges[#edges + 1] = { index[a], index[b] } end
		end
	end
	return edges
end

-- Báo cáo toàn vẹn. opts: Tol (hở cho phép, 0.05), MaxPenetrationRatio (0.6: xuyên sâu hơn 60% kích thước nhỏ nhất = nghi sai vị trí).
function AG.Check(model, opts)
	opts = opts or {}
	local tol = opts.Tol or 0.05
	local parts = collectParts(model)
	local n = #parts
	if n == 0 then return { ok = false, issues = { "model rỗng" } } end
	local obbs = {}
	for i, p in ipairs(parts) do obbs[i] = obbOf(p) end

	local contact = contactEdges(parts, obbs, tol)
	local cGroups = Core.components(n, contact)
	local weld = weldEdges(parts)
	local wGroups = Core.components(n, weld)

	local issues = {}
	local floating = {}
	for gi = 2, #cGroups do
		local gap, i, j = Core.nearestPair(obbs, cGroups[gi], cGroups[1])
		local names = {}
		for k = 1, math.min(4, #cGroups[gi]) do names[#names + 1] = parts[cGroups[gi][k]].Name end
		floating[#floating + 1] = { group = cGroups[gi], gap = gap, a = i, b = j, names = names }
		issues[#issues + 1] = ("RỜI HÌNH HỌC: cụm %d part (%s...) cách thân chính %.2f stud (cặp %s ↔ %s)"):format(#cGroups[gi], table.concat(names, ","), gap, parts[i].Name, parts[j].Name)
	end
	if #wGroups > 1 then
		issues[#issues + 1] = ("RỜI VẬT LÝ: %d cụm weld khác nhau — khi unanchor các cụm sẽ rơi/trôi riêng (chạy AG.Heal)"):format(#wGroups)
	end
	-- xuyên sâu bất thường
	local deep = 0
	for _, e in ipairs(contact) do
		local s = Core.separation(obbs[e[1]], obbs[e[2]])
		local mn = math.min(parts[e[1]].Size.X, parts[e[1]].Size.Y, parts[e[1]].Size.Z, parts[e[2]].Size.X, parts[e[2]].Size.Y, parts[e[2]].Size.Z)
		if -s > mn * (opts.MaxPenetrationRatio or 0.6) and mn > 0.2 then deep += 1 end
	end
	-- Assembly vật lý (chỉ có nghĩa khi có part không anchored)
	local roots, anyUnanchored = {}, false
	for _, p in ipairs(parts) do
		if not p.Anchored then anyUnanchored = true; roots[p:GetRootPart() or p] = true end
	end
	local assemblies = 0
	for _ in pairs(roots) do assemblies += 1 end
	if anyUnanchored and assemblies > 1 then issues[#issues + 1] = ("%d assembly vật lý riêng biệt (mong đợi 1)"):format(assemblies) end

	return {
		ok = #issues == 0, issues = issues, parts = n, contactGroups = #cGroups, weldGroups = #wGroups,
		assemblies = assemblies, deepOverlaps = deep, floating = floating, _parts = parts, _obbs = obbs, _cGroups = cGroups,
	}
end

-- Chữa: weld mọi cặp đang chạm (nếu chưa cùng cụm weld); tuỳ chọn Snap kéo cụm lơ lửng (≤ SnapMax) về chạm thân chính.
function AG.Heal(model, opts)
	opts = opts or {}
	local rep = AG.Check(model, opts)
	if rep.parts == nil then return rep end
	local parts, obbs = rep._parts, rep._obbs

	if opts.Snap then
		for _, f in ipairs(rep.floating) do
			if f.gap > 0 and f.gap <= (opts.SnapMax or 3) then
				local pa, pb = parts[f.a], parts[f.b] -- a: trong cụm lơ lửng, b: thân chính
				local dir = (pb.Position - pa.Position)
				if dir.Magnitude > 1e-4 then
					local move = dir.Unit * f.gap
					for _, idx in ipairs(f.group) do parts[idx].CFrame += move end
					print(("[AssemblyGuard] kéo cụm (%s...) %.2f stud về thân chính"):format(f.names[1], f.gap))
				end
			end
		end
		rep = AG.Check(model, opts)
		parts, obbs = rep._parts, rep._obbs
	end

	local made = 0
	local tol = opts.Tol or 0.05
	local _, wlabel = Core.components(#parts, weldEdges(parts))
	for i = 1, #parts do
		for j = i + 1, #parts do
			if wlabel[i] ~= wlabel[j] and Core.separation(obbs[i], obbs[j]) <= tol then
				local w = Instance.new("WeldConstraint")
				w.Name = "AGWeld"
				w.Part0, w.Part1 = parts[i], parts[j]
				w.Parent = parts[i]
				made += 1
				local li, lj = wlabel[i], wlabel[j]
				for k = 1, #parts do if wlabel[k] == lj then wlabel[k] = li end end
			end
		end
	end
	local final = AG.Check(model, opts)
	final.weldsAdded = made
	return final
end

function AG.Print(rep)
	print(("[AssemblyGuard] parts=%d cụm-hình-học=%d cụm-weld=%d assembly=%d xuyên-sâu=%d weld-thêm=%s"):format(
		rep.parts or 0, rep.contactGroups or 0, rep.weldGroups or 0, rep.assemblies or 0, rep.deepOverlaps or 0, tostring(rep.weldsAdded or 0)))
	if rep.ok then print("[AssemblyGuard] OK — model liền một khối") else for _, m in ipairs(rep.issues) do warn("[AssemblyGuard] " .. m) end end
end

-- ===== XÂY THEO Ổ NỐI =====
-- spec = {
--   Root = "receiver",
--   Parts = { receiver = { Size = Vector3, Color = ..., Material = ..., Shape = Enum.PartType.Block, Mesh = nil }, ... },
--   Joins = { -- B được đặt sao cho điểm sb (toạ độ cục bộ của B) trùng điểm sa (toạ độ cục bộ của A); rot = CFrame xoay B quanh điểm nối
--     { a = "receiver", sa = Vector3.new(0, 0, -2), b = "barrel", sb = Vector3.new(0, 0, 3), rot = CFrame.Angles(0,0,0), gap = 0 },
--   },
-- }
-- Thứ tự Joins phải đi từ Root ra (mỗi mối nối A đã được đặt). Trả Model đã weld, PrimaryPart = Root.
function AG.Build(parent, spec, origin)
	local model = Instance.new("Model")
	model.Name = spec.Name or "Assembled"
	local placed = {}
	local function make(name)
		local d = spec.Parts[name]
		assert(d, "[AssemblyGuard] thiếu part '" .. tostring(name) .. "' trong Parts")
		local p = Instance.new("Part")
		p.Name, p.Size = name, d.Size
		p.Shape = d.Shape or Enum.PartType.Block
		p.Color, p.Material = d.Color or Color3.fromRGB(80, 80, 85), d.Material or Enum.Material.SmoothPlastic
		p.Anchored, p.CanCollide, p.CanQuery, p.CanTouch, p.CastShadow = true, false, false, false, true
		p.TopSurface, p.BottomSurface = Enum.SurfaceType.Smooth, Enum.SurfaceType.Smooth
		return p
	end
	local root = make(spec.Root)
	root.CFrame = origin or CFrame.new(0, 10, 0)
	placed[spec.Root] = root
	root.Parent = model
	model.PrimaryPart = root
	for idx, j in ipairs(spec.Joins) do
		local A = placed[j.a]
		assert(A, ("[AssemblyGuard] mối nối #%d: part cha '%s' chưa được đặt — sắp Joins đi từ Root ra"):format(idx, tostring(j.a)))
		local B = placed[j.b] or make(j.b)
		local socketA = A.CFrame * CFrame.new(j.sa or Vector3.zero)
		local gap = j.gap and Vector3.new(0, 0, j.gap) or Vector3.zero
		B.CFrame = socketA * (j.rot or CFrame.identity) * CFrame.new(gap) * CFrame.new(-(j.sb or Vector3.zero))
		B.Parent = model
		placed[j.b] = B
		local w = Instance.new("WeldConstraint")
		w.Name = "Join_" .. j.a .. "_" .. j.b
		w.Part0, w.Part1 = A, B
		w.Parent = B
	end
	model.Parent = parent
	return model
end

return AG
