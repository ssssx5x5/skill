--!nonstrict
-- KnifeKit — vật thể CONG có kiểm chứng: karambit, hawkbill, liềm (sickle). Hình học là DỮ LIỆU THUẦN (mảng số) → test và render được ngoài Studio.
--
-- KHUNG TOẠ ĐỘ CỦA DAO (local, đơn vị studs sau khi nhân Scale):
--   +Y  = từ đuôi (nhẫn) lên đầu cán, tới gốc lưỡi
--   −Z  = HƯỚNG LƯỠI CONG RA (mặt lưỡi/phía cạnh sắc, "trước")     +Z = phía sống dao ("sau")
--   X   = độ dày (hai má cán), mặt phẳng cong của lưỡi là mặt phẳng YZ
--   Cạnh sắc nằm ở MẶT LÕM (trong), sống ở MẶT LỒI (ngoài) — đúng karambit thật. Mũi chỉ về −Z và hơi xuống −Y (θ > 90°).
--
-- Hai chế độ:  mode = "Parts" (mặc định, Block thuần, kiểm bằng SAT, dùng được mọi nơi)
--              mode = "Mesh"  (lưới đùn mịn: lưỡi mài phẳng, cán elip, nhẫn xuyến — cần EditableMesh, placement PHẢI kiểm bằng mắt lần đầu)
--
-- Dùng:  local spec = KnifeKit.Karambit({ Scale = 0.16 })       -- spec.parts (Parts) hoặc spec.meshes (Mesh)
--        local model = KnifeKit.Build(workspace, spec, CFrame.new(0, 6, 0))

local Knife = {}

-- ===== Preset (đơn vị cm trong spec; Scale = studs mỗi cm) =====
local PRESETS = {
	Karambit = { HandleLen = 10.5, HandleW = 2.7, HandleT = 2.3, BladeArc = 9.0, Sweep = 100, BladeW = 3.3, Taper = 1.7, SpineT = 0.5,
		Ring = true, RingR = 2.1, RingTube = 0.38, RingThick = 0.62, Scale = 0.16 },
	Hawkbill = { HandleLen = 11.0, HandleW = 2.6, HandleT = 2.2, BladeArc = 12.5, Sweep = 82, BladeW = 3.0, Taper = 1.4, SpineT = 0.5,
		Ring = true, RingR = 2.0, RingTube = 0.36, RingThick = 0.6, Scale = 0.16 },
	Sickle = { HandleLen = 14.0, HandleW = 2.6, HandleT = 2.4, BladeArc = 24.0, Sweep = 170, BladeW = 3.4, Taper = 1.2, SpineT = 0.4,
		Ring = false, Scale = 0.14 },
}

local function copy(t) local o = {}; for k, v in pairs(t) do o[k] = v end return o end
local function cross(a, b) return { a[2] * b[3] - a[3] * b[2], a[3] * b[1] - a[1] * b[3], a[1] * b[2] - a[2] * b[1] } end
local function unit(a) local m = math.sqrt(a[1] ^ 2 + a[2] ^ 2 + a[3] ^ 2); return { a[1] / m, a[2] / m, a[3] / m } end

-- 2D (u = dọc cán lên, v = hướng "trước") → 3D local: (x, y, z) = (x, u, −v)
local function P3(u, v, x) return { x or 0, u, -v } end
local function D3(du, dv) return { 0, du, -dv } end

-- Số đoạn lưỡi để sai lệch dây cung < tol (cm): sagitta = R(1−cos(dφ/2)).
local function segmentsFor(Rs, theta, tol)
	local dphi = 2 * math.acos(math.max(-1, 1 - tol / Rs))
	return math.min(48, math.max(8, math.ceil(theta / dphi)))
end

-- ===== Hình học lưỡi (giải tích, dùng chung cho Parts/Mesh/test) =====
-- Trả hàm mô tả lưỡi: width(φ), spine(φ), edge(φ) ở toạ độ 2D (u,v), cùng thông số tâm cong.
function Knife.BladeGeometry(p)
	local theta = math.rad(p.Sweep)
	local Rs = p.BladeArc / theta
	local hw = p.HandleW / 2
	local C = { p.HandleLen, -hw + Rs }       -- tâm cong (u,v): sống bắt đầu ở v = −hw (thẳng hàng mặt sau cán)
	local function width(phi) return p.BladeW * (1 - (phi / theta) ^ p.Taper) end
	local function spine(phi) return { C[1] + Rs * math.sin(phi), C[2] - Rs * math.cos(phi) } end
	local function edge(phi) local re = Rs - width(phi); return { C[1] + re * math.sin(phi), C[2] - re * math.cos(phi) } end
	return { theta = theta, Rs = Rs, C = C, width = width, spine = spine, edge = edge, hw = hw }
end

-- Điểm (u,v) có nằm trong vùng lưỡi thật không (để test độ phủ).
function Knife.InBlade(g, u, v)
	local du, dv = u - g.C[1], v - g.C[2]
	local r = math.sqrt(du * du + dv * dv)
	local phi = math.atan2(du, -dv)        -- vì S = C + R(sinφ, −cosφ)
	if phi < 0 or phi > g.theta then return false end
	return r <= g.Rs + 1e-9 and r >= g.Rs - g.width(phi) - 1e-9
end

-- φ_i dày hơn về phía mũi để mũi nhọn thật (không bị cụt).
local function phiList(theta, n)
	local list = {}
	for i = 0, n do list[#list + 1] = theta * (1 - (1 - i / n) ^ 1.6) end
	return list
end

-- ===== Spec chế độ Parts =====
local function partsSpec(p, g)
	local parts = {}
	local function add(name, group, c, axes, size, color, mat) parts[#parts + 1] = { name = name, group = group, kind = "Block", c = c, axes = axes, size = size, color = color, mat = mat } end
	local X = { 1, 0, 0 }
	local steel, black, ringc = { 0.72, 0.74, 0.78 }, { 0.09, 0.1, 0.11 }, { 0.14, 0.14, 0.15 }

	-- Cán: lõi thép + 2 má (G10) theo 5 đoạn có độ phình (palm swell). Trục dài = Y.
	local H = p.HandleLen
	local swell = { 0.92, 1.0, 1.06, 1.0, 0.94 }
	local segLen = H / #swell
	local ax = { { 1, 0, 0 }, { 0, 1, 0 }, { 0, 0, 1 } }
	for i, s in ipairs(swell) do
		local u0 = (i - 1) * segLen
		local w = p.HandleW * s
		add("liner" .. i, "handle", { 0, u0 + segLen / 2, 0 }, ax, { p.HandleT * 0.34, segLen * 1.04, w }, steel, "Metal")
		add("scaleL" .. i, "handle", { p.HandleT * 0.34 / 2 + p.HandleT * 0.33 / 2, u0 + segLen / 2, 0 }, ax, { p.HandleT * 0.33, segLen * 1.04, w }, black, "SmoothPlastic")
		add("scaleR" .. i, "handle", { -(p.HandleT * 0.34 / 2 + p.HandleT * 0.33 / 2), u0 + segLen / 2, 0 }, ax, { p.HandleT * 0.33, segLen * 1.04, w }, black, "SmoothPlastic")
	end

	-- Lưỡi: các đoạn theo cung. Mỗi đoạn = phần sống (dày, 60% bề rộng) + phần cạnh (mỏng, 40%).
	local n = segmentsFor(g.Rs, g.theta, 0.012)
	local phis = phiList(g.theta, n)
	for i = 1, n do
		local p0, p1 = phis[i], phis[i + 1]
		local pm = (p0 + p1) / 2
		local wm = g.width(pm)
		local S0, S1 = g.spine(p0), g.spine(p1)
		local chord = math.sqrt((S1[1] - S0[1]) ^ 2 + (S1[2] - S0[2]) ^ 2) * 1.03
		-- hướng từ sống vào tâm cong (sống → cạnh) tại góc giữa, trong 2D: (−sin, +cos)·… theo (u,v)
		local wdir2 = { -math.sin(pm), math.cos(pm) }
		local Wd = unit(D3(wdir2[1], wdir2[2]))
		local Zd = cross(X, Wd)                 -- trục dài của đoạn (tiếp tuyến, ±)
		local axes = { X, Wd, Zd }
		local sm = g.spine(pm)
		local frac1 = 0.6                       -- sống chiếm 60%
		local function centerAt(depth) -- depth = khoảng từ sống theo hướng cạnh (cm)
			return P3(sm[1] + wdir2[1] * depth, sm[2] + wdir2[2] * depth, 0)
		end
		local wS, wE = wm * frac1, wm * (1 - frac1)
		-- hai đoạn chồng nhẹ 0.02 cm để không hở
		add("bladeSpine" .. i, "blade", centerAt(wS / 2), axes, { p.SpineT, wS + 0.02, chord }, steel, "Metal")
		add("bladeEdge" .. i, "blade", centerAt(wS + wE / 2), axes, { p.SpineT * 0.4, wE + 0.02, chord }, steel, "Metal")
	end

	-- Chốt xoay (Block nhỏ, không dùng Cylinder để khỏi lệ thuộc trục)
	add("pivot", "handle", { p.HandleT / 2 + 0.05, H - 0.9, 0 }, ax, { 0.12, 0.9, 0.9 }, { 0.6, 0.6, 0.62 }, "Metal")

	-- Nhẫn: N đoạn Block quanh vòng tròn trong mặt phẳng YZ, tâm ở (u = −R + 0.9, v = 0)
	if p.Ring then
		local R = p.RingR
		local cu = -R + 0.9
		local m = 16
		local chord = 2 * R * math.sin(math.pi / m) * 1.06
		for i = 0, m - 1 do
			local a = i / m * 2 * math.pi
			-- vị trí trên vòng: (u,v) = (cu + R cos a, R sin a); hướng hướng-kính trong 3D
			local rad3 = unit(D3(math.cos(a), math.sin(a)))
			local axesR = { X, rad3, cross(X, rad3) }
			add("ring" .. (i + 1), "ring", P3(cu + R * math.cos(a), R * math.sin(a), 0), axesR, { p.RingThick, p.RingTube * 2, chord }, ringc, "Metal")
		end
	end
	return parts
end

-- ===== Spec chế độ Mesh =====
local function meshSpec(p, g, GeoKit)
	local Raw = GeoKit.Raw
	local meshes = {}
	-- Lưỡi: dải đùn A=sống, B=cạnh; mài phẳng từ sống (dày) sang cạnh (rất mỏng)
	local n = segmentsFor(g.Rs, g.theta, 0.01) * 2
	local phis = phiList(g.theta, n)
	local A, B, ha, hb = {}, {}, {}, {}
	for i, phi in ipairs(phis) do
		local s, e = g.spine(phi), g.edge(phi)
		A[i], B[i] = P3(s[1], s[2], 0), P3(e[1], e[2], 0)
		local t = phi / g.theta
		ha[i] = (p.SpineT / 2) * (1 - 0.92 * t ^ 2) + 1e-4
		hb[i] = 0.02 + 1e-4
	end
	meshes[#meshes + 1] = { name = "blade", mesh = Raw.ExtrudeStrip(A, B, { 1, 0, 0 }, ha, hb), color = { 0.72, 0.74, 0.78 }, mat = "Metal" }

	-- Cán: ống elip dọc +Y; rx theo Z (bề rộng trước-sau), ry theo X (độ dày). up0 = +X → right = −Z, up = +X (đã suy dẫn).
	local path, rx, ry = {}, {}, {}
	local m = 24
	for i = 0, m do
		local t = i / m
		local u = -0.2 + (p.HandleLen + 0.4) * t
		path[#path + 1] = { 0, u, 0 }
		local swell = 1 + 0.07 * math.sin(math.pi * t) - 0.06 * math.exp(-((t - 0.3) / 0.05) ^ 2) * 0 -- phình nhẹ giữa cán
		rx[#rx + 1] = (p.HandleW / 2) * swell
		ry[#ry + 1] = (p.HandleT / 2) * swell
	end
	meshes[#meshes + 1] = { name = "handle", mesh = Raw.SweepEllipse(path, rx, ry, 20, { 1, 0, 0 }), color = { 0.09, 0.1, 0.11 }, mat = "SmoothPlastic" }

	if p.Ring then
		local R = p.RingR
		local cu = -R + 0.9
		-- mặt phẳng nhẫn = YZ: u-axis = +Y, v-axis = −Z (v dương = "trước")
		meshes[#meshes + 1] = { name = "ring", mesh = Raw.Torus({ 0, cu, 0 }, { 0, 1, 0 }, { 0, 0, -1 }, R, p.RingTube, p.RingThick / 2, 40, 10), color = { 0.14, 0.14, 0.15 }, mat = "Metal" }
	end
	return meshes
end

-- ===== API =====
local function scaleSpec(spec, s)
	for _, pt in ipairs(spec.parts or {}) do
		for i = 1, 3 do pt.c[i] *= s; pt.size[i] *= s end
	end
	for _, m in ipairs(spec.meshes or {}) do
		for _, v in ipairs(m.mesh.verts) do v[1] *= s; v[2] *= s; v[3] *= s end
	end
	for k, v in pairs(spec.meta) do
		if k == "tipDir" then continue end -- hướng đơn vị: không scale
		if type(v) == "table" then for i = 1, #v do v[i] *= s end elseif type(v) == "number" and k:match("Len$") then spec.meta[k] = v * s end
	end
end

-- name: "Karambit" | "Hawkbill" | "Sickle". overrides: bảng ghi đè tham số (cm) + Scale + mode. GeoKit chỉ cần cho mode "Mesh".
function Knife.Create(name, overrides, GeoKit)
	local p = copy(assert(PRESETS[name], "[KnifeKit] preset lạ: " .. tostring(name)))
	for k, v in pairs(overrides or {}) do p[k] = v end
	local mode = p.mode or "Parts"
	local g = Knife.BladeGeometry(p)
	local spec = { name = name, mode = mode, params = p, frame = "Y=đuôi→đầu cán; −Z=lưỡi cong ra; X=dày" }
	local tip2 = g.spine(g.theta)
	spec.meta = {
		tip = P3(tip2[1], tip2[2], 0),
		tipDir = unit(D3(math.cos(g.theta), math.sin(g.theta))),    -- hướng mũi (đơn vị, không scale)
		totalLen = p.HandleLen + (p.Ring and (2 * p.RingR - 0.9) or 0),
		bladeArcLen = p.BladeArc,
	}
	if mode == "Mesh" then
		assert(GeoKit, "[KnifeKit] mode Mesh cần truyền GeoKit")
		spec.meshes = meshSpec(p, g, GeoKit)
		spec.parts = {}
		-- chốt xoay vẫn là Part
		spec.parts[1] = { name = "pivot", group = "handle", kind = "Block", c = { p.HandleT / 2 + 0.05, p.HandleLen - 0.9, 0 }, axes = { { 1, 0, 0 }, { 0, 1, 0 }, { 0, 0, 1 } }, size = { 0.12, 0.9, 0.9 }, color = { 0.6, 0.6, 0.62 }, mat = "Metal" }
	else
		spec.parts = partsSpec(p, g)
	end
	scaleSpec(spec, p.Scale)
	spec.geometry = g
	spec.scale = p.Scale
	return spec
end

function Knife.Karambit(o, GeoKit) return Knife.Create("Karambit", o, GeoKit) end
function Knife.Hawkbill(o, GeoKit) return Knife.Create("Hawkbill", o, GeoKit) end
function Knife.Sickle(o, GeoKit) return Knife.Create("Sickle", o, GeoKit) end
Knife.Presets = PRESETS

-- ===== Dựng trong Roblox =====
-- origin: CFrame đặt gốc local của dao (đuôi cán, tâm). Trả Model; PrimaryPart = lõi cán đầu tiên. Weld mọi part vào cha gần nhất theo chuỗi.
function Knife.Build(parent, spec, origin, opts)
	opts = opts or {}
	local model = Instance.new("Model")
	model.Name = spec.name
	local list = {}
	for _, pt in ipairs(spec.parts) do
		local part = Instance.new("Part")
		part.Name = pt.name
		part.Size = Vector3.new(pt.size[1], pt.size[2], pt.size[3])
		local x, y = pt.axes[1], pt.axes[2]
		part.CFrame = (origin or CFrame.new(0, 6, 0)) * CFrame.fromMatrix(Vector3.new(pt.c[1], pt.c[2], pt.c[3]), Vector3.new(x[1], x[2], x[3]), Vector3.new(y[1], y[2], y[3]))
		part.Color = Color3.new(pt.color[1], pt.color[2], pt.color[3])
		part.Material = Enum.Material[pt.mat] or Enum.Material.SmoothPlastic
		part.Anchored, part.CanCollide, part.CanQuery, part.CanTouch, part.CastShadow = true, false, false, false, true
		part.TopSurface, part.BottomSurface = Enum.SurfaceType.Smooth, Enum.SurfaceType.Smooth
		part.Parent = model
		list[#list + 1] = { inst = part, group = pt.group, name = pt.name }
	end
	if spec.mode == "Mesh" and opts.GeoKit then
		for _, m in ipairs(spec.meshes) do
			local mp, why = opts.GeoKit.ToMeshPart(opts.GeoKit.Raw.ToData(m.mesh), model)
			if mp then
				mp.Name, mp.Color, mp.Material = m.name, Color3.new(m.color[1], m.color[2], m.color[3]), Enum.Material[m.mat] or Enum.Material.Metal
				mp.CanCollide, mp.CanQuery, mp.CanTouch = false, false, false
				mp.CFrame = (origin or CFrame.new(0, 6, 0)) -- VERIFY: gốc mesh có trùng pivot MeshPart không → kiểm bằng mắt lần đầu
				list[#list + 1] = { inst = mp, group = m.name, name = m.name }
			else
				warn("[KnifeKit] Mesh lỗi (" .. m.name .. "): " .. tostring(why) .. " — dùng mode Parts")
			end
		end
	end
	model.PrimaryPart = list[1] and list[1].inst
	if opts.AssemblyGuard then
		-- Weld theo TIẾP XÚC thật (SAT), rồi báo cáo toàn vẹn. Đây là đường khuyến nghị.
		local rep = opts.AssemblyGuard.Heal(model, { Tol = opts.Tol or 0.03 })
		opts.AssemblyGuard.Print(rep)
		model.Parent = parent
		return model, rep
	end
	-- Không có AssemblyGuard: weld chuỗi: mỗi part weld vào part trước đó CHẠM nó (tìm theo khoảng cách tâm gần nhất trong danh sách đã đặt) — Check/Heal của AssemblyGuard xác nhận lại.
	for i = 2, #list do
		local best, bd = nil, math.huge
		for j = 1, i - 1 do
			local d = (list[i].inst.Position - list[j].inst.Position).Magnitude
			if d < bd then best, bd = list[j].inst, d end
		end
		local w = Instance.new("WeldConstraint")
		w.Part0, w.Part1 = best, list[i].inst
		w.Parent = list[i].inst
	end
	model.Parent = parent
	return model
end

return Knife
