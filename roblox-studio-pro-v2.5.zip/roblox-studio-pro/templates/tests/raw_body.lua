local fails = 0
local function check(name, cond, info) if cond then print("[PASS] " .. name) else fails += 1; print("[FAIL] " .. name .. " " .. tostring(info or "")) end end
local near = function(a, b, rel) return math.abs(a - b) <= rel * math.max(1, math.abs(b)) end
local Raw = GeoKit.Raw

-- Torus: thể tích giải tích = 2π² R rr rn (tiết diện elip: π rr rn × chu vi 2πR)
local T = Raw.Torus({ 0, 0, 0 }, { 1, 0, 0 }, { 0, 1, 0 }, 3, 0.5, 0.4, 64, 24)
local vT = Raw.Validate(T)
check("torus kín", vT.closed and vT.manifold and vT.flippedEdges == 0, vT.boundaryEdges)
local polyK = (24 / (2 * math.pi)) * math.sin(2 * math.pi / 24) -- tiết diện là đa giác 24 cạnh, nhỏ hơn elip một hệ số
check("torus thể tích = giải tích × hệ số đa giác (0.2%)", near(vT.volume, 2 * math.pi ^ 2 * 3 * 0.5 * 0.4 * polyK, 0.002), vT.volume)
check("torus pháp tuyến hướng ra (V>0)", vT.volume > 0)
check("torus không tam giác suy biến", vT.degenerate == 0, vT.degenerate)

-- Sweep thẳng: thể tích = diện tích elip n-giác × dài
local path = {}
for i = 0, 10 do path[#path + 1] = { 0, 0, i } end
local S = Raw.SweepEllipse(path, { 1 }, { 0.5 }, 24)
local vS = Raw.Validate(S)
local area = 0.5 * 24 * 1 * 0.5 * math.sin(2 * math.pi / 24) -- diện tích đa giác nội tiếp elip
check("sweep kín", vS.closed and vS.manifold, vS.boundaryEdges)
check("sweep thể tích ≈ diện tích×dài (1%)", near(vS.volume, area * 10, 0.01), vS.volume)

-- Sweep cong (cung 90°) không xoắn: kín + thể tích dương
local arc = {}
for i = 0, 20 do local a = i / 20 * math.pi / 2; arc[#arc + 1] = { 5 * math.sin(a), 0, 5 * (1 - math.cos(a)) } end
local SC = Raw.SweepEllipse(arc, { 0.6 }, { 0.3 }, 16)
local vSC = Raw.Validate(SC)
check("sweep cong kín + V>0", vSC.closed and vSC.manifold and vSC.volume > 0, vSC.volume)

-- ExtrudeStrip: dải hình chữ nhật 4×2 dày 0.5 (ha=hb=0.25) → V = 4×2×0.5 = 4
local A, B, ha, hb = {}, {}, {}, {}
for i = 0, 8 do A[#A + 1] = { i * 0.5, 0, 0 }; B[#B + 1] = { i * 0.5, 2, 0 }; ha[#ha + 1] = 0.25; hb[#hb + 1] = 0.25 end
local E = Raw.ExtrudeStrip(A, B, { 0, 0, 1 }, ha, hb)
local vE = Raw.Validate(E)
check("strip kín + manifold", vE.closed and vE.manifold and vE.flippedEdges == 0, vE.boundaryEdges)
check("strip thể tích = 4", near(vE.volume, 4, 1e-6), vE.volume)

-- Strip có mũi nhọn (A_n == B_n) và mài phẳng (hb nhỏ): vẫn kín
local A2, B2, ha2, hb2 = {}, {}, {}, {}
for i = 0, 10 do
	local t = i / 10
	A2[#A2 + 1] = { t * 6, 0, 0 }
	B2[#B2 + 1] = { t * 6, 2 * (1 - t), 0 }
	ha2[#ha2 + 1] = 0.3 * (1 - t) + 1e-4
	hb2[#hb2 + 1] = 0.02 * (1 - t) + 1e-4
end
local E2 = Raw.Validate(Raw.ExtrudeStrip(A2, B2, { 0, 0, 1 }, ha2, hb2))
check("strip mũi nhọn + mài phẳng: kín", E2.closed and E2.manifold, ("bnd=%d nm=%d"):format(E2.boundaryEdges, E2.nonManifoldEdges))
check("strip mũi nhọn: V>0", E2.volume > 0, E2.volume)

-- Weld loại trùng
local W = Raw.Weld({ verts = { { 0, 0, 0 }, { 1, 0, 0 }, { 0, 1, 0 }, { 0, 0, 0 } }, tris = { { 1, 2, 3 }, { 4, 2, 3 } } }, 1e-6)
check("weld gộp đỉnh trùng", #W.verts == 3 and #W.tris == 2, #W.verts)

-- Validate bắt lưới hở (thiếu một mặt)
local open = { verts = { { 0, 0, 0 }, { 1, 0, 0 }, { 0, 1, 0 }, { 0, 0, 1 } }, tris = { { 1, 3, 2 }, { 1, 2, 4 }, { 2, 3, 4 } } }
check("lưới hở bị phát hiện", not Raw.Validate(open).closed)

if fails > 0 then error("test fail: " .. fails) end
print("ALL PASS")
