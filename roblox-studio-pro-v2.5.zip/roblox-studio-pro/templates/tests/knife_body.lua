local fails = 0
local function check(name, cond, info) if cond then print("[PASS] " .. name) else fails += 1; print("[FAIL] " .. name .. " " .. tostring(info or "")) end end
local Raw = GeoKit.Raw

local function obbOf(pt) return { c = pt.c, axes = pt.axes, h = { pt.size[1] / 2, pt.size[2] / 2, pt.size[3] / 2 } } end
local function insideOBB(o, p)
	local d = { p[1] - o.c[1], p[2] - o.c[2], p[3] - o.c[3] }
	for i = 1, 3 do
		local a = o.axes[i]
		if math.abs(d[1] * a[1] + d[2] * a[2] + d[3] * a[3]) > o.h[i] + 1e-9 then return false end
	end
	return true
end
local function dump(tag, spec)
	-- JSON thủ công cho scripts/render_geom.py
	local out = {}
	local function arr(a) local t = {}; for i, v in ipairs(a) do t[i] = string.format("%.5f", v) end return "[" .. table.concat(t, ",") .. "]" end
	local ps = {}
	for _, pt in ipairs(spec.parts) do
		ps[#ps + 1] = string.format('{"name":"%s","c":%s,"x":%s,"y":%s,"z":%s,"size":%s,"color":%s}', pt.name, arr(pt.c), arr(pt.axes[1]), arr(pt.axes[2]), arr(pt.axes[3]), arr(pt.size), arr(pt.color))
	end
	local ms = {}
	for _, m in ipairs(spec.meshes or {}) do
		local vs, ts = {}, {}
		for i, v in ipairs(m.mesh.verts) do vs[i] = arr(v) end
		for i, t in ipairs(m.mesh.tris) do ts[i] = "[" .. (t[1] - 1) .. "," .. (t[2] - 1) .. "," .. (t[3] - 1) .. "]" end
		ms[#ms + 1] = string.format('{"name":"%s","color":%s,"verts":[%s],"tris":[%s]}', m.name, arr(m.color), table.concat(vs, ","), table.concat(ts, ","))
	end
	print("JSON:" .. tag .. ":" .. '{"parts":[' .. table.concat(ps, ",") .. '],"meshes":[' .. table.concat(ms, ",") .. "]}")
end

for _, name in ipairs({ "Karambit", "Hawkbill", "Sickle" }) do
	local spec = Knife.Create(name, {})
	local g, s = spec.geometry, spec.scale
	local parts = spec.parts
	local tag = "[" .. name .. "] "

	-- 1) Hệ trục: trực chuẩn + thuận tay phải (x × y = z)
	local axOK = true
	for _, pt in ipairs(parts) do
		local x, y, z = pt.axes[1], pt.axes[2], pt.axes[3]
		local c = { x[2] * y[3] - x[3] * y[2], x[3] * y[1] - x[1] * y[3], x[1] * y[2] - x[2] * y[1] }
		local dxy = x[1] * y[1] + x[2] * y[2] + x[3] * y[3]
		for i = 1, 3 do if math.abs(c[i] - z[i]) > 1e-9 then axOK = false end end
		if math.abs(dxy) > 1e-9 then axOK = false end
		for _, a in ipairs(pt.axes) do if math.abs(math.sqrt(a[1] ^ 2 + a[2] ^ 2 + a[3] ^ 2) - 1) > 1e-9 then axOK = false end end
	end
	check(tag .. "trục trực chuẩn, thuận tay phải", axOK)

	-- 2) Liền khối: đồ thị tiếp xúc SAT (tol 0.02 stud) chỉ 1 cụm
	local obbs, edges = {}, {}
	for i, pt in ipairs(parts) do obbs[i] = obbOf(pt) end
	for i = 1, #parts do for j = i + 1, #parts do if Core.separation(obbs[i], obbs[j]) <= 0.02 then edges[#edges + 1] = { i, j } end end end
	local groups = Core.components(#parts, edges)
	local info = ""
	if #groups > 1 then local gap, a, b = Core.nearestPair(obbs, groups[2], groups[1]); info = ("cụm %d part, hở %.3f (%s↔%s)"):format(#groups[2], gap, parts[a].name, parts[b].name) end
	check(tag .. "liền khối (1 cụm tiếp xúc)", #groups == 1, info)
	check(tag .. "số part hợp lý 20..120", #parts >= 20 and #parts <= 120, #parts)

	-- 3) Độ phủ lưỡi thật (mặt phẳng x=0) và phần tràn ra ngoài
	local bl = {}
	for _, pt in ipairs(parts) do if pt.group == "blade" then bl[#bl + 1] = obbOf(pt) end end
	local inTrue, covered, inParts, spill = 0, 0, 0, 0
	local u0, u1, v0, v1 = -2, spec.params.HandleLen + g.Rs + 2, -g.Rs - 2, g.Rs + 4
	local step = 0.06
	local u = u0
	while u <= u1 do
		local v = v0
		while v <= v1 do
			local tr = Knife.InBlade(g, u, v)
			local p3 = { 0, u * s, -v * s }
			local inAny = false
			for _, o in ipairs(bl) do if insideOBB(o, p3) then inAny = true; break end end
			if tr then inTrue += 1; if inAny then covered += 1 end end
			if inAny then inParts += 1; if not tr then spill += 1 end end
			v += step
		end
		u += step
	end
	local cov, spl = covered / inTrue, spill / inTrue
	check(tag .. ("phủ lưỡi thật ≥ 97%% (đo %.1f%%)"):format(cov * 100), cov >= 0.97, cov)
	check(tag .. ("tràn ngoài lưỡi ≤ 12%% (đo %.1f%%)"):format(spl * 100), spl <= 0.12, spl)

	-- 4) Mũi: điểm xa nhất của part lưỡi theo hướng mũi ≈ mũi giải tích
	local td = spec.meta.tipDir
	local maxProj = -1e9
	for _, pt in ipairs(parts) do
		if pt.group == "blade" then
			for sx = -1, 1, 2 do for sy = -1, 1, 2 do for sz = -1, 1, 2 do
				local cnr = { pt.c[1], pt.c[2], pt.c[3] }
				for i = 1, 3 do for k = 1, 3 do cnr[k] += pt.axes[i][k] * (pt.size[i] / 2) * ({ sx, sy, sz })[i] end end
				maxProj = math.max(maxProj, cnr[1] * td[1] + cnr[2] * td[2] + cnr[3] * td[3])
			end end end
		end
	end
	local want = spec.meta.tip[1] * td[1] + spec.meta.tip[2] * td[2] + spec.meta.tip[3] * td[3]
	check(tag .. ("mũi: lệch theo hướng mũi ≤ 0.15 stud (đo %.3f)"):format(math.abs(maxProj - want)), math.abs(maxProj - want) <= 0.15, maxProj - want)

	-- 5) Ngữ nghĩa hướng: mũi cong ra −Z; xuống −Y khi θ>90°; nhẫn nằm dưới cán; cạnh sắc ở mặt lõm
	local th = math.rad(spec.params.Sweep)
	check(tag .. "mũi chỉ về phía trước (−Z): z<0", td[3] < 0, td[3])
	check(tag .. "hướng mũi = (0, cosθ, −sinθ) chính xác", math.abs(td[2] - math.cos(th)) < 1e-9 and math.abs(td[3] + math.sin(th)) < 1e-9 and td[1] == 0)
	check(tag .. "mũi hướng xuống (−Y) khi Sweep>90°", (spec.params.Sweep > 90) == (td[2] < 0), td[2])
	if spec.params.Ring then
		local ringMaxY = -1e9
		for _, pt in ipairs(parts) do if pt.group == "ring" then ringMaxY = math.max(ringMaxY, pt.c[2]) end end
		check(tag .. "nhẫn nằm dưới đầu cán", ringMaxY < spec.params.HandleLen * s * 0.2, ringMaxY)
	end
	local C3 = { 0, g.C[1] * s, -g.C[2] * s }
	local edgeOK = true
	for i = 1, 60 do
		local sp, ed = parts["bladeSpine" .. i], parts["bladeEdge" .. i]
	end
	local nearEdge, nearSpine, cnt = 0, 0, 0
	local function dist(a, b) return math.sqrt((a[1] - b[1]) ^ 2 + (a[2] - b[2]) ^ 2 + (a[3] - b[3]) ^ 2) end
	local byName = {}
	for _, pt in ipairs(parts) do byName[pt.name] = pt end
	local i = 1
	while byName["bladeSpine" .. i] do
		cnt += 1
		if dist(byName["bladeEdge" .. i].c, C3) >= dist(byName["bladeSpine" .. i].c, C3) then edgeOK = false end
		i += 1
	end
	check(tag .. ("cạnh sắc ở mặt lõm (gần tâm cong hơn sống) — %d đoạn"):format(cnt), edgeOK and cnt >= 8, cnt)

	-- 6) Đối xứng qua mặt phẳng x=0 (các má cán)
	local symOK = true
	for _, pt in ipairs(parts) do
		if math.abs(pt.c[1]) > 1e-9 and pt.group ~= "handle" then symOK = false end
	end
	for k = 1, 5 do
		local L, R = byName["scaleL" .. k], byName["scaleR" .. k]
		if not (L and R and math.abs(L.c[1] + R.c[1]) < 1e-9 and math.abs(L.c[2] - R.c[2]) < 1e-9) then symOK = false end
	end
	check(tag .. "đối xứng hai má cán, lưỡi nằm trên x=0", symOK)

	if name == "Karambit" then dump("karambit_parts", spec) end

	-- 7) Chế độ Mesh: lưới kín, V>0, đỉnh lưỡi nằm trong vùng thật, thể tích khớp chế độ Parts
	local ms = Knife.Create(name, { mode = "Mesh" }, GeoKit)
	local meshOK, allIn, bladeVolMesh = true, true, 0
	for _, m in ipairs(ms.meshes) do
		local v = Raw.Validate(m.mesh)
		if not (v.closed and v.manifold and v.volume > 0 and v.degenerate == 0) then
			meshOK = false
			print(("  mesh %s: closed=%s manifold=%s V=%.3f degenerate=%d bnd=%d"):format(m.name, tostring(v.closed), tostring(v.manifold), v.volume, v.degenerate, v.boundaryEdges))
		end
		if m.name == "blade" then
			bladeVolMesh = v.volume
			for _, vt in ipairs(m.mesh.verts) do
				local uu, vv = vt[2] / s, -vt[3] / s
				if not Knife.InBlade(g, uu, vv) then
					-- tolerance trên biên (điểm nằm đúng trên sống/cạnh)
					local du, dv = uu - g.C[1], vv - g.C[2]
					local r = math.sqrt(du * du + dv * dv)
					local phi = math.atan2(du, -dv)
					if not (phi >= -1e-6 and phi <= g.theta + 1e-6 and r <= g.Rs + 1e-6 and r >= g.Rs - g.width(math.clamp(phi, 0, g.theta)) - 1e-6) then allIn = false end
				end
			end
		end
	end
	check(tag .. "Mesh: mọi lưới kín, manifold, V>0, không suy biến", meshOK)
	check(tag .. "Mesh: mọi đỉnh lưỡi nằm trong vùng lưỡi thật", allIn)
	local volParts = 0
	for _, pt in ipairs(parts) do if pt.group == "blade" then volParts += pt.size[1] * pt.size[2] * pt.size[3] end end
	local ratio = bladeVolMesh / volParts
	check(tag .. ("thể tích lưỡi Mesh/Parts trong 0.45..1.1 (đo %.2f)"):format(ratio), ratio > 0.45 and ratio < 1.1, ratio)
	if name == "Karambit" then dump("karambit_mesh", ms) end
end

if fails > 0 then error("test fail: " .. fails) end
print("ALL PASS")
