local fails = 0
local function check(name, cond, info) if cond then print("[PASS] " .. name) else fails += 1; print("[FAIL] " .. name .. " " .. tostring(info or "")) end end
local function box(cx, cy, cz, hx, hy, hz, axes)
	return { c = { cx, cy, cz }, h = { hx, hy, hz }, axes = axes or { { 1, 0, 0 }, { 0, 1, 0 }, { 0, 0, 1 } } }
end
local near = function(a, b) return math.abs(a - b) < 1e-6 end

-- Hộp AABB: hở 0.5 theo X
local A = box(0, 0, 0, 1, 1, 1)
check("hở 0.5 theo X", near(Core.separation(A, box(2.5, 0, 0, 1, 1, 1)), 0.5), Core.separation(A, box(2.5, 0, 0, 1, 1, 1)))
check("chạm mặt = 0", near(Core.separation(A, box(2, 0, 0, 1, 1, 1)), 0))
check("xuyên 0.3 → -0.3", near(Core.separation(A, box(1.7, 0, 0, 1, 1, 1)), -0.3), Core.separation(A, box(1.7, 0, 0, 1, 1, 1)))
-- hở chéo: lệch X và Y cùng 0.4 → SAT là cận dưới (0.4), khoảng cách thật 0.566
check("hở chéo là cận dưới ≤ thật", Core.separation(A, box(2.4, 2.4, 0, 1, 1, 1)) <= 0.5657 + 1e-6)
-- hộp xoay 45° quanh Z đặt cạnh: đỉnh hộp xoay cách tâm sqrt2*h
local s2 = math.sqrt(0.5)
local R45 = { { s2, s2, 0 }, { -s2, s2, 0 }, { 0, 0, 1 } }
local gapx = 1 + math.sqrt(2) * 1 -- chạm đỉnh: tâm cách 1 + sqrt2
check("xoay 45° chạm đỉnh = 0", math.abs(Core.separation(A, box(gapx, 0, 0, 1, 1, 1, R45))) < 1e-6, Core.separation(A, box(gapx, 0, 0, 1, 1, 1, R45)))
check("xoay 45° hở 0.2", math.abs(Core.separation(A, box(gapx + 0.2, 0, 0, 1, 1, 1, R45)) - 0.2) < 1e-6)

-- Cụm: chuỗi 1-2-3 và cô lập 4, cặp 5-6
local groups = Core.components(6, { { 1, 2 }, { 2, 3 }, { 5, 6 } })
check("3 cụm", #groups == 3, #groups)
check("cụm lớn nhất trước", #groups[1] == 3 and #groups[2] == 2 and #groups[3] == 1)

-- Mô phỏng "sniper": thân + nòng + ống ngắm + báng; ống ngắm lơ lửng 0.4 phía trên → phải bị phát hiện
local parts = {
	receiver = box(0, 0, 0, 0.5, 0.6, 3),
	barrel = box(0, 0.1, -5.5, 0.2, 0.2, 2.5),
	stock = box(0, -0.3, 4.2, 0.4, 0.8, 1.2),
	scope = box(0, 1.4, 0, 0.35, 0.35, 1.2), -- đáy scope y=1.05, đỉnh receiver y=0.6 → hở 0.45
}
local names = { "receiver", "barrel", "stock", "scope" }
local obbs = {}; for i, n in ipairs(names) do obbs[i] = parts[n] end
local edges = {}
for i = 1, 4 do for j = i + 1, 4 do if Core.separation(obbs[i], obbs[j]) <= 0.05 then edges[#edges + 1] = { i, j } end end end
local g = Core.components(4, edges)
check("scope lơ lửng bị phát hiện (2 cụm)", #g == 2 and #g[2] == 1 and names[g[2][1]] == "scope", #g)
local gap, a, b = Core.nearestPair(obbs, g[2], g[1])
check("khoảng hở scope→receiver ≈ 0.45", math.abs(gap - 0.45) < 1e-6, gap)
parts.scope = box(0, 0.95, 0, 0.35, 0.35, 1.2) -- hạ xuống chạm (đáy 0.6)
obbs[4] = parts.scope
edges = {}
for i = 1, 4 do for j = i + 1, 4 do if Core.separation(obbs[i], obbs[j]) <= 0.05 then edges[#edges + 1] = { i, j } end end end
check("sau khi hạ: 1 cụm", #Core.components(4, edges) == 1)

if fails > 0 then error("test fail: " .. fails) end
print("ALL PASS")
