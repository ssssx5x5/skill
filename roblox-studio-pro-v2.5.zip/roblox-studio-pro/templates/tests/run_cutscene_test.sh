#!/usr/bin/env bash
# Test phần toán thuần của CutsceneKit (Segment/Validate/Ease). Chạy từ templates/:  LUAU=<luau> bash tests/run_cutscene_test.sh
# Chỉ lấy phần trước "-- ===== Phần Roblox =====" nên không cần API Roblox.
set -e
LUAU="${LUAU:-luau}"
T=$(mktemp --suffix=.lua)
{ echo "local Cut = (function()"; sed -n '/^local Cut = {}/,/^-- ===== Phần Roblox =====/p' CutsceneKit.lua | sed '$d'; echo "return Cut end)()"; cat tests/cutscene_body.lua; } > "$T"
"$LUAU" "$T"
