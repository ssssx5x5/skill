local fails = 0
local function check(name, cond, info) if cond then print("[PASS] " .. name) else fails += 1; print("[FAIL] " .. name .. " " .. tostring(info or "")) end end
local near = function(a, b, e) return math.abs(a - b) < (e or 1e-6) end

-- SampleTrack
local keys = { { t = 0, r = { 0, 0, 0 } }, { t = 1, r = { 90, 0, 0 }, e = "lin" }, { t = 2, r = { 0, 0, 0 }, e = "lin" } }
local r = AnimKit.SampleTrack(keys, 0.5); check("lin giữa 0..1 = 45°", near(r[1], 45), r[1])
r = AnimKit.SampleTrack(keys, 1.5); check("lin giữa 1..2 = 45°", near(r[1], 45), r[1])
r = AnimKit.SampleTrack(keys, -3); check("trước mốc đầu", r[1] == 0)
r = AnimKit.SampleTrack(keys, 9); check("sau mốc cuối", r[1] == 0)
local snap = { { t = 0, r = { 0, 0, 0 } }, { t = 1, r = { 50, 0, 0 }, e = "snap" } }
r = AnimKit.SampleTrack(snap, 0.99); check("snap giữ pose cũ tới mốc", r[1] == 0)
local bk = { { t = 0, r = { 0, 0, 0 } }, { t = 1, r = { 100, 0, 0 }, e = "back" } }
local over = false
for i = 0, 100 do if AnimKit.SampleTrack(bk, i / 100)[1] > 100.01 then over = true end end
check("back có vọt qua đích", over)

-- ValidateClip
check("clip hợp lệ", #AnimKit.ValidateClip({ Duration = 1, Tracks = { RShoulder = { { t = 0 }, { t = 1 } } } }) == 0)
check("khớp lạ bị bắt", #AnimKit.ValidateClip({ Duration = 1, Tracks = { Foo = { { t = 0 }, { t = 1 } } } }) == 1)
check("Loop pose cuối≠đầu bị bắt", #AnimKit.ValidateClip({ Duration = 1, Loop = true, Tracks = { RHip = { { t = 0, r = { 0, 0, 0 } }, { t = 1, r = { 30, 0, 0 } } } } }) == 1)
check("mốc lùi bị bắt", #AnimKit.ValidateClip({ Duration = 2, Tracks = { RHip = { { t = 1 }, { t = 0.5 } } } }) >= 1)

-- Spring: tới đích; ζ<1 vọt, ζ=1 không vọt
local s1 = AnimKit.Spring.new(3, 1.0, 0)
local maxv = 0
for _ = 1, 600 do maxv = math.max(maxv, s1:Step(1, 1 / 60)) end
check("spring ζ=1 hội tụ", near(s1.x, 1, 1e-3), s1.x)
check("spring ζ=1 không vọt", maxv <= 1.0005, maxv)
local s2 = AnimKit.Spring.new(3, 0.3, 0)
local peak = 0
for _ = 1, 600 do peak = math.max(peak, s2:Step(1, 1 / 60)) end
check("spring ζ=0.3 có vọt", peak > 1.1, peak)
local s3 = AnimKit.Spring.new(3, 1, 0); s3:Step(1, 0.5)
check("spring ổn định với dt lớn", s3.x == s3.x and s3.x < 5)

-- IK 2 xương: độ dài giữ nguyên, tới đích khi với tới được
local function len(a, b) return math.sqrt((a[1] - b[1]) ^ 2 + (a[2] - b[2]) ^ 2 + (a[3] - b[3]) ^ 2) end
local root = { 0, 0, 0 }
local sol = AnimKit.SolveTwoBone(root, { 0.6, -1.2, -0.8 }, 1.0, 1.0, { 0, 0, 1 })
check("IK reached", sol.reached)
check("IK |root-elbow| = l1", near(len(root, sol.elbow), 1.0, 1e-6), len(root, sol.elbow))
check("IK |elbow-tip| = l2", near(len(sol.elbow, sol.tip), 1.0, 1e-6), len(sol.elbow, sol.tip))
check("IK tip = target", near(len(sol.tip, { 0.6, -1.2, -0.8 }), 0, 1e-6))
local far = AnimKit.SolveTwoBone(root, { 0, -5, 0 }, 1, 1, { 0, 0, 1 })
check("IK quá xa: reached=false, duỗi thẳng", not far.reached and near(far.dist, 2, 1e-3))
check("IK elbow hướng về pole", AnimKit.SolveTwoBone(root, { 0, -1.5, 0 }, 1, 1, { 0, 0, 1 }).elbow[3] > 0.1)
check("IK elbow pole ngược", AnimKit.SolveTwoBone(root, { 0, -1.5, 0 }, 1, 1, { 0, 0, -1 }).elbow[3] < -0.1)

-- Clip library (nếu có): mọi clip phải hợp lệ
if Clips then
	local n, bad = 0, 0
	for name, clip in pairs(Clips) do
		if type(clip) == "table" and clip.Tracks then
			n += 1
			local errs = AnimKit.ValidateClip(clip)
			if #errs > 0 then bad += 1; print("[FAIL] clip " .. name .. ": " .. table.concat(errs, "; ")) end
		end
	end
	check(("%d clip hợp lệ"):format(n), bad == 0 and n > 0, bad)
end
if fails > 0 then error("test fail: " .. fails) end
print("ALL PASS")
