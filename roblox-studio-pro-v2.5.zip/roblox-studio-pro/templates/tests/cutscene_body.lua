local fails = 0
local function check(name, cond, info) if cond then print("[PASS] " .. name) else fails += 1; print("[FAIL] " .. name .. " " .. tostring(info or "")) end end
local keys = { { t = 0 }, { t = 2, ease = "lin" }, { t = 6, ease = "lin" } }
local i, j, a = Cut.Segment(keys, -1); check("trước mốc đầu", i == 1 and j == 1 and a == 0)
i, j, a = Cut.Segment(keys, 1); check("giữa đoạn 1 (lin)", i == 1 and j == 2 and math.abs(a - 0.5) < 1e-9, a)
i, j, a = Cut.Segment(keys, 4); check("giữa đoạn 2 (lin)", i == 2 and j == 3 and math.abs(a - 0.5) < 1e-9, a)
i, j, a = Cut.Segment(keys, 99); check("sau mốc cuối", i == 3 and j == 3 and a == 0)
local k2 = { { t = 0 }, { t = 4, ease = "inout" } }
i, j, a = Cut.Segment(k2, 2); check("inout tại 0.5 = 0.5", math.abs(a - 0.5) < 1e-9, a)
i, j, a = Cut.Segment(k2, 1); check("inout đầu chậm (<0.25)", a < 0.25, a)
check("Validate hợp lệ", #Cut.Validate(keys) == 0)
check("Validate 1 keyframe lỗi", #Cut.Validate({ { t = 0 } }) == 1)
check("Validate lùi thời gian", #Cut.Validate({ { t = 0 }, { t = 3 }, { t = 2 } }) == 1)
local mono = true; local prev = -1
for k = 0, 100 do local v = Cut.Ease.out(k / 100); if v < prev then mono = false end prev = v end
check("ease out đơn điệu", mono)
if fails > 0 then error("test fail: " .. fails) end
print("ALL PASS")
