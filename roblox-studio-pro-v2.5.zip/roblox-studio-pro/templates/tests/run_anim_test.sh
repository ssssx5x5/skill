#!/usr/bin/env bash
# Test toán thuần của AnimKit (+ kiểm mọi clip trong AnimClips). Chạy từ templates/:  LUAU=<luau> bash tests/run_anim_test.sh
set -e
LUAU="${LUAU:-luau}"
T=$(mktemp --suffix=.lua)
{
  echo "local AnimKit = (function()"
  # Lấy phần trước '-- ===== Roblox: Rig =====' và bỏ các dòng cần API Roblox (RunService)
  sed -n '/^local AnimKit = {}/,/^-- ===== Roblox: Rig =====/p' AnimKit.lua | sed '$d'
  echo "return AnimKit end)()"
  if [ -f AnimClips.lua ]; then echo "local Clips = (function()"; sed 's/^local AnimKit = .*$//' AnimClips.lua; echo "end)()"; fi
  cat tests/anim_body.lua
} > "$T"
"$LUAU" "$T"
