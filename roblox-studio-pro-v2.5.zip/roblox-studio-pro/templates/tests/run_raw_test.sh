#!/usr/bin/env bash
# Test GeoKit.Raw (lưới kín, thể tích giải tích). Chạy từ templates/:  LUAU=<luau> bash tests/run_raw_test.sh
set -e
LUAU="${LUAU:-luau}"
T=$(mktemp --suffix=.lua)
{ echo "local GeoKit = (function()"; sed '$d' GeoKit.lua; echo "return GeoKit end)()"; cat tests/raw_body.lua; } > "$T"
"$LUAU" "$T"
