#!/usr/bin/env bash
# Test KnifeKit (karambit/hawkbill/sickle) ngoài Studio. Chạy từ templates/:  LUAU=<luau> bash tests/run_knife_test.sh [dump_dir]
# Nếu truyền dump_dir: ghi JSON để scripts/render_geom.py vẽ ảnh kiểm.
set -e
LUAU="${LUAU:-luau}"
T=$(mktemp --suffix=.lua)
{
  echo "local Core = {}"
  sed -n '/^local function dot/,/^-- ===== Roblox =====/p' AssemblyGuard.lua | sed '$d'
  echo "local GeoKit = (function()"; sed '$d' GeoKit.lua; echo "return GeoKit end)()"
  echo "local Knife = (function()"; sed '$d' KnifeKit.lua; echo "return Knife end)()"
  cat tests/knife_body.lua
} > "$T"
OUT=$("$LUAU" "$T" 2>&1) || RC=$?
echo "$OUT" | grep -v '^JSON:'
if [ -n "$1" ]; then
  mkdir -p "$1"
  echo "$OUT" | grep '^JSON:' | while IFS= read -r line; do tag=$(echo "$line" | cut -d: -f2); echo "${line#JSON:$tag:}" > "$1/$tag.json"; done
fi
exit ${RC:-0}
