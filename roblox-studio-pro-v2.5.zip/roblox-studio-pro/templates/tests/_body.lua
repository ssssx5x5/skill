local fails = 0
local function check(name, cond, info)
	if cond then print("[PASS] " .. name) else fails += 1; print("[FAIL] " .. name .. " " .. tostring(info or "")) end
end

-- Ellipsoid: điểm phải nằm trên bề mặt (sai số < 1e-6) và pháp tuyến đơn vị.
local a, b, c = 4, 2, 3
local worst = 0
for _, d in ipairs(GeoKit.Fibonacci(200)) do
	local P, n = GeoKit.EllipsoidSurface(a, b, c, d)
	worst = math.max(worst, GeoKit.EllipsoidError(a, b, c, P), math.abs(n.Magnitude - 1))
end
check("ellipsoid 200 điểm trên bề mặt", worst < 1e-6, worst)

-- Fibonacci phân bố đều: tổng vector ≈ 0.
local sum = Vector3.zero
for _, d in ipairs(GeoKit.Fibonacci(500)) do sum = sum + d end
check("fibonacci cân bằng", sum.Magnitude < 1.0, sum.Magnitude)

-- Lathe: số tam giác = 2 * sides * (n-1) ; mọi đỉnh đúng bán kính.
local lathe = GeoKit.Lathe({ { 1, 0 }, { 2, 1 }, { 1.5, 2 }, { 0.5, 3 } }, 12)
check("lathe số tam giác", #lathe.tris == 2 * 12 * 3, #lathe.tris)
local rOK = true
for i = 1, 12 do local v = lathe.verts[12 + i]; if math.abs(math.sqrt(v.X ^ 2 + v.Z ^ 2) - 2) > 1e-6 then rOK = false end end
check("lathe bán kính hàng 2", rOK)

-- Loft elip: chỉ số tam giác hợp lệ, pháp tuyến đơn vị.
local secs = {}
for i = 0, 4 do secs[#secs + 1] = GeoKit.EllipseSection(Vector3.new(0, 0, i * 2), 1 + i * 0.2, 0.8, 10) end
local loft = GeoKit.Loft(secs)
local idxOK = true
for _, t in ipairs(loft.tris) do for k = 1, 3 do if t[k] < 1 or t[k] > #loft.verts then idxOK = false end end end
check("loft chỉ số hợp lệ", idxOK)
check("loft số tam giác", #loft.tris == 2 * 10 * 4, #loft.tris)

-- Sweep: số mặt cắt = số điểm path; không NaN.
local path = GeoKit.CatmullRom({ Vector3.new(0, 0, 0), Vector3.new(2, 3, 0), Vector3.new(5, 4, 1), Vector3.new(8, 2, 2) }, 6)
local sw = GeoKit.Sweep(path, { 1, 0.8, 0.5, 0.2 }, 8)
local nanOK = true
for _, v in ipairs(sw.verts) do if v.X ~= v.X or v.Y ~= v.Y or v.Z ~= v.Z then nanOK = false end end
check("sweep không NaN", nanOK)
check("sweep số đỉnh", #sw.verts == #path * 8, #sw.verts)
local st = GeoKit.Stats(sw)
check("stats tam giác", st.triangles == #sw.tris)

print(fails == 0 and "ALL PASS" or ("FAILS: " .. fails))
if fails > 0 then error("test fail") end
