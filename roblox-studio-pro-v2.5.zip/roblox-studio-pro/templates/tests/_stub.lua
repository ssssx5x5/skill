-- Test toán thuần của GeoKit bằng luau CLI (không cần Studio):
--   luau tests/geokit_test.lua      (chạy từ thư mục templates/)
-- Vector3 giả tối thiểu — đủ cho các hàm "Data" của GeoKit.
local V = {}
V.__index = function(t, k)
	if k == "Magnitude" then return math.sqrt(t.X * t.X + t.Y * t.Y + t.Z * t.Z) end
	if k == "Unit" then local m = math.sqrt(t.X * t.X + t.Y * t.Y + t.Z * t.Z); return V.new(t.X / m, t.Y / m, t.Z / m) end
	return V[k]
end
function V.new(x, y, z) return setmetatable({ X = x or 0, Y = y or 0, Z = z or 0 }, V) end
function V:Dot(o) return self.X * o.X + self.Y * o.Y + self.Z * o.Z end
function V:Cross(o) return V.new(self.Y * o.Z - self.Z * o.Y, self.Z * o.X - self.X * o.Z, self.X * o.Y - self.Y * o.X) end
V.__add = function(a, b) return V.new(a.X + b.X, a.Y + b.Y, a.Z + b.Z) end
V.__sub = function(a, b) return V.new(a.X - b.X, a.Y - b.Y, a.Z - b.Z) end
V.__mul = function(a, b)
	if type(a) == "number" then return V.new(a * b.X, a * b.Y, a * b.Z) end
	if type(b) == "number" then return V.new(a.X * b, a.Y * b, a.Z * b) end
	return V.new(a.X * b.X, a.Y * b.Y, a.Z * b.Z)
end
V.__div = function(a, b) if type(b) == "number" then return V.new(a.X / b, a.Y / b, a.Z / b) end return V.new(a.X / b.X, a.Y / b.Y, a.Z / b.Z) end
V.__unm = function(a) return V.new(-a.X, -a.Y, -a.Z) end
V.yAxis, V.xAxis, V.zAxis, V.zero, V.one = V.new(0, 1, 0), V.new(1, 0, 0), V.new(0, 0, 1), V.new(0, 0, 0), V.new(1, 1, 1)
local Vector3 = V

