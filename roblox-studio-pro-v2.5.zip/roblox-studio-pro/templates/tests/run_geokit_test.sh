#!/usr/bin/env bash
# Chạy test GeoKit bằng luau CLI: ghép Vector3 giả + GeoKit + test thành một file tạm.
# Dùng:  LUAU=/đường/dẫn/luau bash tests/run_geokit_test.sh   (chạy từ thư mục templates/)
set -e
LUAU="${LUAU:-luau}"
T=$(mktemp --suffix=.lua)
{ cat tests/_stub.lua; echo "local GeoKit = (function()"; sed '$d' GeoKit.lua | sed 's/^local GeoKit = {}/local GeoKit = {}/'; echo "return GeoKit end)()"; cat tests/_body.lua; } > "$T"
"$LUAU" "$T"
