#!/usr/bin/env bash
# Test toán thuần của AssemblyGuard.Core. Chạy từ templates/:  LUAU=<luau> bash tests/run_assembly_test.sh
set -e
LUAU="${LUAU:-luau}"
T=$(mktemp --suffix=.lua)
{ echo "local Core = {}"; sed -n '/^local function dot/,/^-- ===== Roblox =====/p' AssemblyGuard.lua | sed '$d'; cat tests/assembly_body.lua; } > "$T"
"$LUAU" "$T"
