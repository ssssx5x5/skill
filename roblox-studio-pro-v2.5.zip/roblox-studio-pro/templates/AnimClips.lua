--!nonstrict
-- AnimClips — thư viện clip (rig-neutral, độ, khung part cha). Dùng với AnimKit.Player:Play(Clips.X, opts).
-- Quy ước trục (khung part cha; trước mặt = -Z, phải = +X, lên = +Y):
--   Vai/Hông  : x+ = đưa tay/chân RA TRƯỚC ; z+ = tay phải dang ra (tay trái dang = z−) ; y = xoay trong/ngoài
--   Khuỷu     : x+ = gập (cẳng tay lên trước)      Gối : x− = gập (cẳng chân ra sau)
--   Waist/Neck: x− = cúi về trước ; y+ = quay trái ; z+ = nghiêng phải
--   Root      : x− = chúi về trước (lộn tới = x giảm tới −360) ; p[2] = nâng/hạ người (stud, ≤ 0.8 cho chi, root thoải mái hơn)
-- R6: không có Elbow/Knee/Waist → AnimKit gấp tương đương; clip vẫn đọc được nhưng kém mượt hơn R15.
-- Mọi clip Loop có pose cuối = pose đầu (kiểm bằng tests/run_anim_test.sh).

local function K(t, x, y, z, e, py, pz, px) return { t = t, r = { x or 0, y or 0, z or 0 }, e = e, p = { px or 0, py or 0, pz or 0 } } end

local Clips = {}

-- ===== Di chuyển cơ bản =====
Clips.Idle = { Duration = 3, Loop = true, Tracks = {
	Waist = { K(0, -1, 0, 0), K(1.5, 1.5, 0, 0), K(3, -1, 0, 0) },
	RShoulder = { K(0, 4, 0, 6), K(1.5, 7, 0, 8), K(3, 4, 0, 6) },
	LShoulder = { K(0, 4, 0, -6), K(1.5, 7, 0, -8), K(3, 4, 0, -6) },
	RElbow = { K(0, 12), K(1.5, 16), K(3, 12) }, LElbow = { K(0, 12), K(1.5, 16), K(3, 12) },
	Neck = { K(0, 0, 0, 0), K(1.5, -2, 0, 0), K(3, 0, 0, 0) },
	Root = { K(0, 0, 0, 0, nil, 0), K(1.5, 0, 0, 0, nil, -0.05), K(3, 0, 0, 0, nil, 0) },
} }

Clips.Walk = { Duration = 0.9, Loop = true, Tracks = {
	RHip = { K(0, -28), K(0.225, 0), K(0.45, 28), K(0.675, 0), K(0.9, -28) },
	LHip = { K(0, 28), K(0.225, 0), K(0.45, -28), K(0.675, 0), K(0.9, 28) },
	RKnee = { K(0, -5), K(0.225, -8), K(0.45, -4), K(0.675, -48), K(0.9, -5) },
	LKnee = { K(0, -4), K(0.225, -48), K(0.45, -5), K(0.675, -8), K(0.9, -4) },
	RAnkle = { K(0, 8), K(0.45, -8), K(0.9, 8) }, LAnkle = { K(0, -8), K(0.45, 8), K(0.9, -8) },
	RShoulder = { K(0, 26, 0, 4), K(0.45, -26, 0, 4), K(0.9, 26, 0, 4) },
	LShoulder = { K(0, -26, 0, -4), K(0.45, 26, 0, -4), K(0.9, -26, 0, -4) },
	RElbow = { K(0, 10), K(0.45, 28), K(0.9, 10) }, LElbow = { K(0, 28), K(0.45, 10), K(0.9, 28) },
	Waist = { K(0, 0, 6, 0), K(0.45, 0, -6, 0), K(0.9, 0, 6, 0) },
	Root = { K(0, -3, 0, 0, nil, 0), K(0.225, -3, 0, 0, nil, 0.12), K(0.45, -3, 0, 0, nil, 0), K(0.675, -3, 0, 0, nil, 0.12), K(0.9, -3, 0, 0, nil, 0) },
} }

Clips.Run = { Duration = 0.6, Loop = true, Tracks = {
	RHip = { K(0, -50), K(0.15, -5), K(0.3, 50), K(0.45, 0), K(0.6, -50) },
	LHip = { K(0, 50), K(0.15, 0), K(0.3, -50), K(0.45, -5), K(0.6, 50) },
	RKnee = { K(0, -10), K(0.15, -20), K(0.3, -10), K(0.45, -95), K(0.6, -10) },
	LKnee = { K(0, -10), K(0.15, -95), K(0.3, -10), K(0.45, -20), K(0.6, -10) },
	RShoulder = { K(0, 45, 0, 8), K(0.3, -45, 0, 8), K(0.6, 45, 0, 8) },
	LShoulder = { K(0, -45, 0, -8), K(0.3, 45, 0, -8), K(0.6, -45, 0, -8) },
	RElbow = { K(0, 70), K(0.3, 95), K(0.6, 70) }, LElbow = { K(0, 95), K(0.3, 70), K(0.6, 95) },
	Waist = { K(0, -12, 10, 0), K(0.3, -12, -10, 0), K(0.6, -12, 10, 0) },
	Root = { K(0, -8, 0, 0, nil, 0), K(0.15, -8, 0, 0, nil, 0.25), K(0.3, -8, 0, 0, nil, 0), K(0.45, -8, 0, 0, nil, 0.25), K(0.6, -8, 0, 0, nil, 0) },
} }

Clips.Crouch = { Duration = 2, Loop = true, Tracks = {
	RHip = { K(0, -75), K(1, -72), K(2, -75) }, LHip = { K(0, -75), K(1, -72), K(2, -75) },
	RKnee = { K(0, -120), K(1, -118), K(2, -120) }, LKnee = { K(0, -120), K(1, -118), K(2, -120) },
	Waist = { K(0, -20), K(1, -18), K(2, -20) },
	Root = { K(0, 0, 0, 0, nil, -1.3), K(1, 0, 0, 0, nil, -1.28), K(2, 0, 0, 0, nil, -1.3) },
} }

-- ===== Cơ động khó =====
-- Lộn tới (forward roll): chúi + cuộn 360° + co gối; Root xoay quanh X.
Clips.Roll = { Duration = 0.75, Tracks = {
	Root = { K(0, 0, 0, 0, nil, 0), K(0.12, -25, 0, 0, "out", -0.6), K(0.4, -200, 0, 0, "lin", -1.3), K(0.65, -345, 0, 0, "lin", -0.8), K(0.75, -360, 0, 0, "out", 0) },
	RHip = { K(0, 0), K(0.12, -60, 0, 0, "out"), K(0.4, -110, 0, 0, "lin"), K(0.65, -60, 0, 0, "lin"), K(0.75, 0, 0, 0, "out") },
	LHip = { K(0, 0), K(0.12, -60, 0, 0, "out"), K(0.4, -110, 0, 0, "lin"), K(0.65, -60, 0, 0, "lin"), K(0.75, 0, 0, 0, "out") },
	RKnee = { K(0, 0), K(0.12, -70, 0, 0, "out"), K(0.4, -130, 0, 0, "lin"), K(0.65, -70, 0, 0, "lin"), K(0.75, 0, 0, 0, "out") },
	LKnee = { K(0, 0), K(0.12, -70, 0, 0, "out"), K(0.4, -130, 0, 0, "lin"), K(0.65, -70, 0, 0, "lin"), K(0.75, 0, 0, 0, "out") },
	RShoulder = { K(0, 0), K(0.12, 70, 0, 10, "out"), K(0.4, 100, 0, 10, "lin"), K(0.75, 0, 0, 0, "out") },
	LShoulder = { K(0, 0), K(0.12, 70, 0, -10, "out"), K(0.4, 100, 0, -10, "lin"), K(0.75, 0, 0, 0, "out") },
	RElbow = { K(0, 0), K(0.12, 90, 0, 0, "out"), K(0.4, 110, 0, 0, "lin"), K(0.75, 0, 0, 0, "out") },
	LElbow = { K(0, 0), K(0.12, 90, 0, 0, "out"), K(0.4, 110, 0, 0, "lin"), K(0.75, 0, 0, 0, "out") },
	Waist = { K(0, 0), K(0.12, -30, 0, 0, "out"), K(0.4, -50, 0, 0, "lin"), K(0.75, 0, 0, 0, "out") },
}, Events = { { t = 0.12, name = "Takeoff" }, { t = 0.7, name = "Land" } } }

-- Lộn sau (backflip): nhún → bật → xoay +360 quanh X → co gối ở đỉnh → hạ.
Clips.Backflip = { Duration = 0.9, Tracks = {
	Root = { K(0, 0, 0, 0, nil, 0), K(0.14, 8, 0, 0, "out", -0.9), K(0.28, 20, 0, 0, "out", 1.2), K(0.5, 200, 0, 0, "lin", 2.4), K(0.72, 340, 0, 0, "lin", 1.0), K(0.9, 360, 0, 0, "out", 0) },
	RHip = { K(0, 0), K(0.14, -40, 0, 0, "out"), K(0.28, 10, 0, 0, "out"), K(0.5, -95, 0, 0, "out"), K(0.72, -50, 0, 0, "out"), K(0.9, 0, 0, 0, "out") },
	LHip = { K(0, 0), K(0.14, -40, 0, 0, "out"), K(0.28, 10, 0, 0, "out"), K(0.5, -95, 0, 0, "out"), K(0.72, -50, 0, 0, "out"), K(0.9, 0, 0, 0, "out") },
	RKnee = { K(0, 0), K(0.14, -80, 0, 0, "out"), K(0.28, -5, 0, 0, "out"), K(0.5, -135, 0, 0, "out"), K(0.72, -60, 0, 0, "out"), K(0.9, 0, 0, 0, "out") },
	LKnee = { K(0, 0), K(0.14, -80, 0, 0, "out"), K(0.28, -5, 0, 0, "out"), K(0.5, -135, 0, 0, "out"), K(0.72, -60, 0, 0, "out"), K(0.9, 0, 0, 0, "out") },
	RShoulder = { K(0, 0), K(0.14, -30, 0, 8, "out"), K(0.28, 170, 0, 10, "out"), K(0.5, 80, 0, 10, "out"), K(0.9, 0, 0, 0, "out") },
	LShoulder = { K(0, 0), K(0.14, -30, 0, -8, "out"), K(0.28, 170, 0, -10, "out"), K(0.5, 80, 0, -10, "out"), K(0.9, 0, 0, 0, "out") },
	Waist = { K(0, 0), K(0.14, -15, 0, 0, "out"), K(0.5, -30, 0, 0, "out"), K(0.9, 0, 0, 0, "out") },
}, Events = { { t = 0.2, name = "Takeoff" }, { t = 0.86, name = "Land" } } }

Clips.Jump = { Duration = 0.6, Tracks = {
	Root = { K(0, 0, 0, 0, nil, 0), K(0.12, -4, 0, 0, "out", -0.5), K(0.3, 3, 0, 0, "out", 0.2), K(0.6, 0, 0, 0, "inout", 0) },
	RHip = { K(0, 0), K(0.12, -35, 0, 0, "out"), K(0.3, 15, 0, 0, "out"), K(0.6, 0, 0, 0, "inout") },
	LHip = { K(0, 0), K(0.12, -35, 0, 0, "out"), K(0.3, -10, 0, 0, "out"), K(0.6, 0, 0, 0, "inout") },
	RKnee = { K(0, 0), K(0.12, -60, 0, 0, "out"), K(0.3, -10, 0, 0, "out"), K(0.6, 0, 0, 0, "inout") },
	LKnee = { K(0, 0), K(0.12, -60, 0, 0, "out"), K(0.3, -50, 0, 0, "out"), K(0.6, 0, 0, 0, "inout") },
	RShoulder = { K(0, 0), K(0.12, -20, 0, 6, "out"), K(0.3, 150, 0, 25, "out"), K(0.6, 0, 0, 0, "inout") },
	LShoulder = { K(0, 0), K(0.12, -20, 0, -6, "out"), K(0.3, 150, 0, -25, "out"), K(0.6, 0, 0, 0, "inout") },
} }

Clips.Dodge = { Duration = 0.45, Tracks = {
	Root = { K(0, 0, 0, 0, nil, 0, 0, 0), K(0.1, 0, 0, -18, "out", -0.4, 0, 1.8), K(0.3, 0, 0, -18, "lin", -0.3, 0, 3.2), K(0.45, 0, 0, 0, "out", 0, 0, 3.4) },
	Waist = { K(0, 0), K(0.1, -12, 0, 10, "out"), K(0.45, 0, 0, 0, "out") },
	RHip = { K(0, 0), K(0.1, -30, 0, 0, "out"), K(0.3, 25, 0, 0, "lin"), K(0.45, 0, 0, 0, "out") },
	LHip = { K(0, 0), K(0.1, 20, 0, 0, "out"), K(0.3, -30, 0, 0, "lin"), K(0.45, 0, 0, 0, "out") },
	RKnee = { K(0, 0), K(0.1, -50, 0, 0, "out"), K(0.45, 0, 0, 0, "out") }, LKnee = { K(0, 0), K(0.1, -30, 0, 0, "out"), K(0.45, 0, 0, 0, "out") },
	RShoulder = { K(0, 0), K(0.1, 50, 0, 40, "out"), K(0.45, 0, 0, 0, "out") }, LShoulder = { K(0, 0), K(0.1, 30, 0, -50, "out"), K(0.45, 0, 0, 0, "out") },
} }

-- ===== Cận chiến =====
Clips.SwordCombo1 = { Duration = 0.7, Tracks = { -- chém chéo từ phải xuống trái
	RShoulder = { K(0, 5, 0, 8), K(0.18, 130, 25, 40, "out"), K(0.3, 30, -20, -10, "inn"), K(0.5, 20, -10, 0, "out"), K(0.7, 5, 0, 8, "inout") },
	RElbow = { K(0, 15), K(0.18, 70, 0, 0, "out"), K(0.3, 25, 0, 0, "inn"), K(0.7, 15, 0, 0, "inout") },
	LShoulder = { K(0, 5, 0, -8), K(0.18, -20, 0, -40, "out"), K(0.3, 25, 0, -20, "out"), K(0.7, 5, 0, -8, "inout") },
	Waist = { K(0, 0), K(0.18, 8, -28, 0, "out"), K(0.3, -10, 38, 0, "inn"), K(0.7, 0, 0, 0, "inout") },
	Root = { K(0, 0, 0, 0, nil, 0, 0), K(0.18, 4, -10, 0, "out", 0, 0.3), K(0.3, -6, 22, 0, "inn", -0.1, -0.9), K(0.7, 0, 0, 0, "inout", 0, 0) },
	RHip = { K(0, 0), K(0.18, 15, 0, 0, "out"), K(0.3, -25, 0, 0, "inn"), K(0.7, 0, 0, 0, "inout") },
	LHip = { K(0, 0), K(0.18, -20, 0, 0, "out"), K(0.3, 25, 0, 0, "inn"), K(0.7, 0, 0, 0, "inout") },
	RKnee = { K(0, 0), K(0.3, -25, 0, 0, "inn"), K(0.7, 0, 0, 0, "inout") }, LKnee = { K(0, 0), K(0.18, -15, 0, 0, "out"), K(0.7, 0, 0, 0, "inout") },
}, Events = { { t = 0.3, name = "Hit" } } }

Clips.SwordCombo2 = { Duration = 0.65, Tracks = { -- chém ngang trái→phải
	RShoulder = { K(0, 5, 0, 8), K(0.15, 80, -55, 70, "out"), K(0.3, 85, 55, 20, "inn"), K(0.65, 5, 0, 8, "inout") },
	RElbow = { K(0, 15), K(0.15, 50, 0, 0, "out"), K(0.3, 10, 0, 0, "inn"), K(0.65, 15, 0, 0, "inout") },
	Waist = { K(0, 0), K(0.15, 0, 40, 0, "out"), K(0.3, 0, -45, 0, "inn"), K(0.65, 0, 0, 0, "inout") },
	Root = { K(0, 0, 0, 0, nil, 0, 0), K(0.15, 0, 25, 0, "out", 0, 0), K(0.3, 0, -30, 0, "inn", 0, -0.7), K(0.65, 0, 0, 0, "inout", 0, 0) },
	LShoulder = { K(0, 5, 0, -8), K(0.3, -30, 0, -60, "out"), K(0.65, 5, 0, -8, "inout") },
}, Events = { { t = 0.3, name = "Hit" } } }

Clips.SwordCombo3 = { Duration = 1.0, Tracks = { -- chém bổ hai tay từ trên xuống, nặng
	RShoulder = { K(0, 5, 0, 8), K(0.3, 165, 0, 15, "out"), K(0.42, 40, 0, 0, "snap"), K(0.55, 38, 0, 0, "lin"), K(1.0, 5, 0, 8, "inout") },
	LShoulder = { K(0, 5, 0, -8), K(0.3, 160, 0, -15, "out"), K(0.42, 40, 0, 0, "snap"), K(0.55, 38, 0, 0, "lin"), K(1.0, 5, 0, -8, "inout") },
	RElbow = { K(0, 15), K(0.3, 40, 0, 0, "out"), K(0.42, 5, 0, 0, "snap"), K(1.0, 15, 0, 0, "inout") }, LElbow = { K(0, 15), K(0.3, 40, 0, 0, "out"), K(0.42, 5, 0, 0, "snap"), K(1.0, 15, 0, 0, "inout") },
	Waist = { K(0, 0), K(0.3, 12, 0, 0, "out"), K(0.42, -32, 0, 0, "snap"), K(0.55, -30, 0, 0, "lin"), K(1.0, 0, 0, 0, "inout") },
	Root = { K(0, 0, 0, 0, nil, 0, 0), K(0.3, 8, 0, 0, "out", 0.2, 0.4), K(0.42, -12, 0, 0, "snap", -0.7, -1.3), K(1.0, 0, 0, 0, "inout", 0, 0) },
	RHip = { K(0, 0), K(0.42, -55, 0, 0, "snap"), K(1.0, 0, 0, 0, "inout") }, LHip = { K(0, 0), K(0.42, 20, 0, 0, "snap"), K(1.0, 0, 0, 0, "inout") },
	RKnee = { K(0, 0), K(0.42, -80, 0, 0, "snap"), K(1.0, 0, 0, 0, "inout") },
}, Events = { { t = 0.42, name = "Hit" } } }

Clips.Kick = { Duration = 0.7, Tracks = { -- đá vòng cầu
	Root = { K(0, 0, 0, 0, nil, 0), K(0.2, 0, 70, 0, "out", 0), K(0.32, 0, 150, 0, "inn", 0), K(0.7, 0, 0, 0, "inout", 0) },
	RHip = { K(0, 0), K(0.2, 55, 0, 15, "out"), K(0.32, 95, 0, 35, "inn"), K(0.7, 0, 0, 0, "inout") },
	RKnee = { K(0, 0), K(0.2, -100, 0, 0, "out"), K(0.32, -5, 0, 0, "snap"), K(0.7, 0, 0, 0, "inout") },
	LHip = { K(0, 0), K(0.2, -12, 0, 0, "out"), K(0.7, 0, 0, 0, "inout") }, LKnee = { K(0, 0), K(0.2, -25, 0, 0, "out"), K(0.7, 0, 0, 0, "inout") },
	Waist = { K(0, 0), K(0.32, 10, -20, -18, "inn"), K(0.7, 0, 0, 0, "inout") },
	RShoulder = { K(0, 0), K(0.32, -35, 0, 55, "inn"), K(0.7, 0, 0, 0, "inout") }, LShoulder = { K(0, 0), K(0.32, 45, 0, -65, "inn"), K(0.7, 0, 0, 0, "inout") },
}, Events = { { t = 0.32, name = "Hit" } } }

Clips.GroundSlam = { Duration = 1.1, Tracks = { -- nhảy bổ xuống đất (kết hợp VFX Shockwave ở event Impact)
	Root = { K(0, 0, 0, 0, nil, 0), K(0.25, 10, 0, 0, "out", 0.2), K(0.5, -20, 0, 0, "inn", 0.1), K(0.62, -28, 0, 0, "snap", -1.0), K(1.1, 0, 0, 0, "inout", 0) },
	RShoulder = { K(0, 0), K(0.25, 175, 0, 12, "out"), K(0.62, 20, 0, 10, "snap"), K(1.1, 0, 0, 0, "inout") },
	LShoulder = { K(0, 0), K(0.25, 175, 0, -12, "out"), K(0.62, 20, 0, -10, "snap"), K(1.1, 0, 0, 0, "inout") },
	RHip = { K(0, 0), K(0.25, -30, 0, 0, "out"), K(0.62, -85, 0, 8, "snap"), K(1.1, 0, 0, 0, "inout") },
	LHip = { K(0, 0), K(0.25, -30, 0, 0, "out"), K(0.62, -70, 0, -8, "snap"), K(1.1, 0, 0, 0, "inout") },
	RKnee = { K(0, 0), K(0.25, -70, 0, 0, "out"), K(0.62, -110, 0, 0, "snap"), K(1.1, 0, 0, 0, "inout") },
	LKnee = { K(0, 0), K(0.25, -70, 0, 0, "out"), K(0.62, -90, 0, 0, "snap"), K(1.1, 0, 0, 0, "inout") },
	Waist = { K(0, 0), K(0.25, 15, 0, 0, "out"), K(0.62, -40, 0, 0, "snap"), K(1.1, 0, 0, 0, "inout") },
}, Events = { { t = 0.62, name = "Impact" } } }

Clips.Hurt = { Duration = 0.35, Tracks = {
	Waist = { K(0, 0), K(0.06, 22, 0, 6, "out"), K(0.35, 0, 0, 0, "inout") },
	Neck = { K(0, 0), K(0.06, 18, 0, -8, "out"), K(0.35, 0, 0, 0, "inout") },
	RShoulder = { K(0, 0), K(0.06, -25, 0, 30, "out"), K(0.35, 0, 0, 0, "inout") }, LShoulder = { K(0, 0), K(0.06, -25, 0, -30, "out"), K(0.35, 0, 0, 0, "inout") },
	Root = { K(0, 0, 0, 0, nil, 0, 0), K(0.06, 6, 0, 0, "out", 0, 0.5), K(0.35, 0, 0, 0, "inout", 0, 0) },
} }

Clips.Death = { Duration = 1.4, Tracks = {
	Root = { K(0, 0, 0, 0, nil, 0), K(0.3, 12, 0, 0, "out", -0.6), K(0.9, 78, 0, 0, "inn", -2.0), K(1.4, 90, 0, 0, "out", -2.6) },
	RHip = { K(0, 0), K(0.5, -35, 0, 10, "out"), K(1.4, -10, 0, 12, "out") }, LHip = { K(0, 0), K(0.5, -55, 0, -6, "out"), K(1.4, 5, 0, -14, "out") },
	RKnee = { K(0, 0), K(0.5, -70, 0, 0, "out"), K(1.4, -15, 0, 0, "out") }, LKnee = { K(0, 0), K(0.5, -45, 0, 0, "out"), K(1.4, -30, 0, 0, "out") },
	RShoulder = { K(0, 0), K(0.5, -30, 0, 70, "out"), K(1.4, 10, 0, 85, "out") }, LShoulder = { K(0, 0), K(0.5, 25, 0, -50, "out"), K(1.4, -5, 0, -75, "out") },
	Neck = { K(0, 0), K(0.9, 20, 0, 12, "out"), K(1.4, 12, 0, 18, "out") },
} }

-- ===== Súng =====
-- RifleHold: giữ súng hai tay (tay phải gần cò, trái đỡ ốp). Dùng Mask = AnimKit.Masks.Upper, Layer cao hơn Walk/Run.
Clips.RifleHold = { Duration = 2, Loop = true, Tracks = {
	RShoulder = { K(0, 62, -18, 12), K(1, 63, -18, 12), K(2, 62, -18, 12) },
	RElbow = { K(0, 70), K(1, 71), K(2, 70) },
	LShoulder = { K(0, 78, 30, -25), K(1, 79, 30, -25), K(2, 78, 30, -25) },
	LElbow = { K(0, 42), K(1, 43), K(2, 42) },
	Waist = { K(0, -2, 14, 0), K(1, -2, 14, 0), K(2, -2, 14, 0) },
	Neck = { K(0, 2, -10, 0), K(1, 2, -10, 0), K(2, 2, -10, 0) },
} }

-- Giật súng: dùng Additive = true, Layer cao nhất; phát lại mỗi phát bắn.
Clips.RifleRecoil = { Duration = 0.18, Tracks = {
	RShoulder = { K(0, 0), K(0.03, 9, 0, 0, "out"), K(0.18, 0, 0, 0, "out") },
	LShoulder = { K(0, 0), K(0.03, 7, 0, 0, "out"), K(0.18, 0, 0, 0, "out") },
	Waist = { K(0, 0), K(0.03, 4, 0, 0, "out"), K(0.18, 0, 0, 0, "out") },
	Root = { K(0, 0, 0, 0, nil, 0, 0), K(0.03, 2, 0, 0, "out", 0, 0.12), K(0.18, 0, 0, 0, "out", 0, 0) },
} }

-- Bắn tỉa: giữ súng áp vai, đầu nghiêng vào ống ngắm.
Clips.SniperAim = { Duration = 2.5, Loop = true, Tracks = {
	RShoulder = { K(0, 58, -22, 14), K(1.25, 59, -22, 14), K(2.5, 58, -22, 14) },
	RElbow = { K(0, 95), K(1.25, 96), K(2.5, 95) },
	LShoulder = { K(0, 68, 34, -22), K(1.25, 69, 34, -22), K(2.5, 68, 34, -22) },
	LElbow = { K(0, 55), K(1.25, 56), K(2.5, 55) },
	Waist = { K(0, -4, 20, 0), K(1.25, -4, 20, 0), K(2.5, -4, 20, 0) },
	Neck = { K(0, 4, -18, 8), K(1.25, 4, -18, 8), K(2.5, 4, -18, 8) },
	Root = { K(0, 0, 0, 0, nil, 0), K(1.25, 0, 0, 0, nil, -0.04), K(2.5, 0, 0, 0, nil, 0) }, -- nhịp thở
} }

-- Kéo khóa nòng (bolt action): nhấc cần → kéo lùi → đẩy tới → hạ cần. Phát với Mask = Masks.RightArm (Additive=false) khi nạp đạn.
Clips.SniperBolt = { Duration = 1.5, Tracks = {
	RShoulder = { K(0, 58, -22, 14), K(0.25, 62, -22, 30, "out"), K(0.6, 40, -22, 30, "inout"), K(1.0, 62, -22, 30, "inout"), K(1.25, 62, -22, 14, "out"), K(1.5, 58, -22, 14, "inout") },
	RElbow = { K(0, 95), K(0.25, 88, 0, 0, "out"), K(0.6, 128, 0, 0, "inout"), K(1.0, 88, 0, 0, "inout"), K(1.25, 95, 0, 0, "out"), K(1.5, 95, 0, 0, "inout") },
	RWrist = { K(0, 0), K(0.25, 0, 0, -55, "out"), K(1.0, 0, 0, -55, "lin"), K(1.25, 0, 0, 0, "out"), K(1.5, 0, 0, 0, "inout") },
	Waist = { K(0, -4, 20, 0), K(0.6, -4, 17, 0, "inout"), K(1.5, -4, 20, 0, "inout") },
}, Events = { { t = 0.25, name = "BoltUp" }, { t = 0.6, name = "BoltBack" }, { t = 1.0, name = "BoltForward" }, { t = 1.25, name = "BoltDown" } } }

Clips.Reload = { Duration = 1.6, Tracks = {
	LShoulder = { K(0, 78, 30, -25), K(0.3, 60, 10, -10, "out"), K(0.9, 55, 8, -8, "inout"), K(1.3, 78, 30, -25, "out"), K(1.6, 78, 30, -25, "inout") },
	LElbow = { K(0, 42), K(0.3, 100, 0, 0, "out"), K(0.9, 105, 0, 0, "inout"), K(1.3, 42, 0, 0, "out"), K(1.6, 42, 0, 0, "inout") },
	RShoulder = { K(0, 62, -18, 12), K(0.3, 58, -18, 12, "out"), K(1.6, 62, -18, 12, "inout") },
	Waist = { K(0, -2, 14, 0), K(0.3, -6, 8, 0, "out"), K(1.3, -2, 14, 0, "inout"), K(1.6, -2, 14, 0, "inout") },
}, Events = { { t = 0.3, name = "MagOut" }, { t = 0.9, name = "MagIn" }, { t = 1.3, name = "Chamber" } } }

return Clips
