--!nonstrict
-- CutsceneKit — timeline cutscene: camera keyframe + sự kiện theo thời gian, KHÔI PHỤC camera/điều khiển ở MỌI đường thoát.
-- ModuleScript, chạy trên CLIENT. Không dùng Tween.Completed:Wait (có thể không bao giờ fire) — một vòng RenderStep duy nhất.
--
-- local Cut = require(RS.CutsceneKit)
-- local h = Cut.Play({
--   Duration = 6,
--   Camera = {                       -- keyframe camera (t giây, CFrame, FOV tuỳ chọn, ease tuỳ chọn)
--     { t = 0,   cf = CFrame.lookAt(a, target), fov = 70 },
--     { t = 3,   cf = CFrame.lookAt(b, target), fov = 55, ease = "inout" },
--     { t = 6,   cf = CFrame.lookAt(c, target), fov = 70 },
--   },
--   Events = { { t = 2.5, fn = function() VFX.Explosion(pos) end } },   -- chạy đúng 1 lần
--   Letterbox = true, LockControls = true, Skippable = true,
-- })
-- h.Finished:Wait()   -- hoặc h.Skip() / h.Cancel()

local RunService = game:GetService("RunService")
local Players = game:GetService("Players")
local UIS = game:GetService("UserInputService")
local Workspace = game:GetService("Workspace")

local Cut = {}

-- ===== Phần toán thuần (có test bằng luau CLI) =====
local EASE = {
	lin = function(a) return a end,
	inn = function(a) return a * a * a end,
	out = function(a) return 1 - (1 - a) ^ 3 end,
	inout = function(a) return a < 0.5 and 4 * a ^ 3 or 1 - (-2 * a + 2) ^ 3 / 2 end,
}
Cut.Ease = EASE

-- Tìm cặp keyframe bao quanh t và hệ số alpha đã ease (kiểu dùng `ease` của keyframe ĐÍCH).
function Cut.Segment(keys, t)
	local n = #keys
	if t <= keys[1].t then return 1, 1, 0 end
	if t >= keys[n].t then return n, n, 0 end
	for i = 1, n - 1 do
		local a, b = keys[i], keys[i + 1]
		if t >= a.t and t <= b.t then
			local span = b.t - a.t
			local raw = span > 0 and (t - a.t) / span or 1
			return i, i + 1, (EASE[b.ease or "inout"] or EASE.inout)(raw)
		end
	end
	return n, n, 0
end

-- Kiểm hợp lệ danh sách keyframe: tăng dần theo t, có ít nhất 2 mốc. Trả danh sách lỗi.
function Cut.Validate(keys)
	local errs = {}
	if type(keys) ~= "table" or #keys < 2 then errs[#errs + 1] = "cần ≥ 2 keyframe camera"; return errs end
	for i = 2, #keys do
		if keys[i].t < keys[i - 1].t then errs[#errs + 1] = ("keyframe %d lùi thời gian (%.2f < %.2f)"):format(i, keys[i].t, keys[i - 1].t) end
	end
	return errs
end

-- ===== Phần Roblox =====
local function makeSignal()
	local ev = Instance.new("BindableEvent")
	return {
		Fire = function() ev:Fire() end,
		Wait = function() ev.Event:Wait() end,
		Connect = function(_, f) return ev.Event:Connect(f) end,
		Destroy = function() ev:Destroy() end,
	}
end

function Cut.Play(spec)
	local errs = spec.Camera and Cut.Validate(spec.Camera) or {}
	if #errs > 0 then warn("[CutsceneKit] " .. table.concat(errs, "; ")); return { Skip = function() end, Cancel = function() end, Finished = makeSignal() } end
	local cam = Workspace.CurrentCamera
	local player = Players.LocalPlayer
	local saved = { Type = cam.CameraType, CF = cam.CFrame, FOV = cam.FieldOfView, Subject = cam.CameraSubject }
	local controls
	if spec.LockControls ~= false then
		local ok, pm = pcall(function() return require(player:WaitForChild("PlayerScripts", 5):WaitForChild("PlayerModule", 5)) end)
		if ok and pm then controls = pm:GetControls(); controls:Disable() else warn("[CutsceneKit] không khoá được điều khiển (PlayerModule?) — tiếp tục") end
	end
	local gui
	if spec.Letterbox then
		gui = Instance.new("ScreenGui")
		gui.Name, gui.IgnoreGuiInset, gui.DisplayOrder, gui.ResetOnSpawn = "CutsceneBars", true, 90, false
		for _, top in ipairs({ true, false }) do
			local f = Instance.new("Frame")
			f.BackgroundColor3, f.BorderSizePixel, f.Active = Color3.new(), 0, false
			f.Size = UDim2.fromScale(1, 0.1)
			f.Position = top and UDim2.fromScale(0, 0) or UDim2.fromScale(0, 0.9)
			f.Parent = gui
		end
		gui.Parent = player:WaitForChild("PlayerGui", 10)
	end

	local finished = makeSignal()
	local done = false
	local t0 = os.clock()
	local fired = {}
	local skipConn
	local STEP = "CutsceneKit_" .. tostring(math.random(1, 1e9))

	-- Mọi đường thoát (hết giờ / Skip / Cancel / nhân vật chết / lỗi) đều đi qua cleanup một lần.
	local function cleanup(reason)
		if done then return end
		done = true
		pcall(function() RunService:UnbindFromRenderStep(STEP) end)
		if skipConn then skipConn:Disconnect() end
		cam.CameraType = saved.Type
		if saved.Type == Enum.CameraType.Custom or saved.Type == Enum.CameraType.Follow then
			cam.CameraSubject = saved.Subject
		end
		cam.FieldOfView = saved.FOV
		if controls then pcall(function() controls:Enable() end) end
		if gui then gui:Destroy() end
		-- Kiểm lại: camera đã khôi phục thật chưa (đọc lại, không tin phép gán)
		task.defer(function()
			if cam.CameraType ~= saved.Type then warn("[CutsceneKit] CameraType chưa khôi phục: " .. tostring(cam.CameraType)) end
		end)
		finished.Fire()
		print("[CutsceneKit] kết thúc: " .. tostring(reason))
	end

	cam.CameraType = Enum.CameraType.Scriptable
	local keys = spec.Camera
	local duration = spec.Duration or (keys and keys[#keys].t) or 1

	RunService:BindToRenderStep(STEP, Enum.RenderPriority.Camera.Value + 2, function()
		local ok, err = pcall(function()
			local t = os.clock() - t0
			if keys then
				local i, j, a = Cut.Segment(keys, t)
				local k0, k1 = keys[i], keys[j]
				cam.CFrame = k0.cf:Lerp(k1.cf, a)
				if k0.fov and k1.fov then cam.FieldOfView = k0.fov + (k1.fov - k0.fov) * a end
			end
			for idx, ev in ipairs(spec.Events or {}) do
				if not fired[idx] and t >= ev.t then
					fired[idx] = true
					local okE, errE = pcall(ev.fn)
					if not okE then warn("[CutsceneKit] event lỗi:", errE) end
				end
			end
			if t >= duration then cleanup("hết giờ") end
		end)
		if not ok then warn("[CutsceneKit] lỗi giữa chừng:", err); cleanup("lỗi") end
	end)

	if spec.Skippable then
		skipConn = UIS.InputBegan:Connect(function(input, gp)
			if not gp and (input.KeyCode == Enum.KeyCode.Space or input.KeyCode == Enum.KeyCode.Return) then cleanup("skip") end
		end)
	end
	local hum = player.Character and player.Character:FindFirstChildOfClass("Humanoid")
	if hum then hum.Died:Once(function() cleanup("nhân vật chết") end) end

	return {
		Finished = finished,
		Skip = function() cleanup("skip") end,
		Cancel = function() cleanup("cancel") end,
	}
end

return Cut
