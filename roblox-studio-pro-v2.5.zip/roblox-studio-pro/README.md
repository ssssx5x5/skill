# roblox-studio-pro v2.1

Nâng cấp từ roblox-studio v1.0. Mục tiêu: model, VFX và logic code cho Roblox Studio ở mức production, **có công cụ chạy được** thay vì chỉ có mô tả.

## Cài đặt
Giải nén thư mục `roblox-studio-pro/` vào thư mục skills của client bạn dùng (vd `~/.claude/skills/`). Kết quả: `.../skills/roblox-studio-pro/SKILL.md`. Khởi động lại để nạp.

## Mới trong v2.0
| Thêm | Nội dung |
|---|---|
| `templates/VFXKit.lua` | Thư viện VFX dùng lại: Explosion, Impact, Lightning, Slash, Ring, Shards, Emitter preset, Shake, ScreenFlash, BloomPulse, HitStop, AutoQuality, SelfTest; có ngân sách part + tự dọn |
| `templates/GeoKit.lua` | Lathe / Loft / Sweep / CatmullRom / Ellipsoid / Fibonacci / Tube / ToMeshPart — phần toán đã có test |
| `templates/ModelKit.lua` | Part/Wedge chuẩn, MirrorX, WeldToPrimary, Normalize, PlaceOnGround, **Audit** |
| `templates/PoseKit.lua` | Pose procedural R15: Walk, Idle, SwordSlash, Crouch |
| `templates/project/` | Rojo + Remotes + Validate (có test) + DataService + bootstrap + stylua/selene/rokit |
| `references/quality-loop.md` | Vòng chụp → đo → chấm → sửa, rubric M/V/C, ngân sách, mẫu báo cáo |
| `references/geometry-rigging.md` | Dựng creature/tàu/bình bằng code, rig, LOD |
| `references/templates-guide.md` | Cách dùng template, giới hạn đã biết |
| `references/studio-mcp-index.md` | Mục lục theo dòng cho file `studio-mcp.md` 2.600 dòng |
| `scripts/lint_luau.py` | Linter luật cứng của skill |
| `evals/` | 13 case + rubric để đo skill tốt lên hay tệ đi |
| `templates/CutsceneKit.lua` (v2.1) | Timeline camera + sự kiện, letterbox, khoá điều khiển, khôi phục ở mọi đường thoát; phần toán có test |
| `scripts/gen_vfx_textures.py` (v2.1) | Sinh 9 texture VFX trắng+alpha, gồm flipbook lửa/khói 4×4 |
| `references/vfx-textures-cutscene.md` (v2.1) | Quy trình texture → upload → gán, và dựng cutscene |
| Sửa | Gỡ phụ thuộc WorkBuddy; `check_docs.py` tách mảnh minh hoạ khỏi lỗi thật |

## Kiểm chứng đã làm / chưa làm
- Đã: `luau-compile` mọi template (0 lỗi); test toán GeoKit và Validate bằng luau CLI (ALL PASS); `check_docs.py` 0 lỗi (10 mảnh minh hoạ); lint templates 0 ERROR.
- **Chưa**: chạy VFXKit/ModelKit/PoseKit/GeoKit.ToMeshPart trong Roblox Studio thật. Lần đầu dùng chạy `VFX.SelfTest()` và báo kết quả thật.

## Công cụ ngoài
`luau`/`luau-compile` (github.com/luau-lang/luau/releases) cho test và `check_docs.py` (`LUAU_COMPILE=...`). Python 3.8+; `numpy` cho `extract_sprite.py`.

## v2.2 — thêm gì
- **Model không rời**: `AssemblyGuard` (SAT + weld + đếm assembly), `sim_assembly.py` chạy ngoài Studio.
- **Vật cong** (karambit/hawkbill/sickle): `KnifeKit` + `GeoKit.Raw`, kiểm phủ/tràn/lưới kín bằng số, `render_geom.py` xuất ảnh.
- **Hiểu hướng & góc xoay**: `spatial-language.md`, `orient.py` (Việt/Anh, 26 test), `Orient.lua`.
- **Animation khó**: `AnimKit` + `AnimClips` (20 clip, R6/R15/Part, IK, layer).
- **VFX / UI / Âm thanh**: `VFXKit` mở rộng, `UIKit`, `SoundKit` + `synth_sfx.py`.
- Chạy toàn bộ test: các `templates/tests/run_*_test.sh` (cần `luau`).

## v2.3 — Sandbox + hiểu ảnh
- `scripts/sandbox.py` + `templates/sandbox/RbxStub.lua` + `rbx_render.py`: chạy code dựng model ngoài Studio → ảnh nhiều góc, `inspect`, `--expect` (`scene_check.py`), `--time/--snaps` cho animation. Tự kiểm: `python scripts/test_sandbox.py`.
- `scripts/imgread.py` (sheet/palette/measure/grid/ascii/scan/overlay/compare) + `scripts/ref_analyze.py` (swatches, crop lưới, compare tự nhận lật gương): hiểu ảnh mẫu bằng số. Tự kiểm: `python scripts/imgread.py selftest`, `python scripts/ref_analyze.py selftest`.
- `templates/PatternKit.lua` (VoxelArch, RadialSlots, VoxelBlob, Plus, Rod, WeldAll) + `templates/PixelShapes.lua` (Annulus, Disc, PixelArt, Raster); mẫu `examples/MinigunRainbow.lua` + `examples/minigun_expect.json`.
- Cài: `pip install numpy pillow scipy` rồi `python scripts/sandbox.py install-luau`.

## v2.4 — Model Builder + hợp nhất Model Quality Pipeline
Vấn đề: AI tự gõ toạ độ/góc → part sai chỗ, sai xoay, sai tỉ lệ, sửa/render rất lâu; model tốt trong Blender nhưng yếu ở Roblox.
- `scripts/mb.py` (**Model Builder**): dựng bằng quan hệ (`on/inside/mate/beside/rod/path/arc/bezier/rotate_about/mirror/array_*`), cm→stud, nhóm, ràng buộc; một mô tả → `scene.json` + `build.lua` (Roblox, weld theo quan hệ) + `blender.py` + `report.md` + `views.png` (6 góc + người mẫu 5 stud).
- `scripts/mbcheck.py`: kiểm chung không phụ thuộc loại vật: lơ lửng (kèm vector dịch), part ẩn, z-fight, mỏng, thế đứng, đối xứng, ngân sách, kích thước thật, ràng buộc.
- `scripts/dimdb.py` + `references/dimensions.json`: 60 họ vật thể, khoảng cm min–typ–max + tỉ lệ giữa đặc trưng; `style` nới dung sai (cách điệu). Dữ liệu gần đúng, chưa đối chiếu từng mục với tiêu chuẩn chính thức.
- `scripts/texgen.py`: 16 kiểu texture PBR tileable (albedo/normal/roughness/metalness/ao + preview, tự kiểm seam).
- MQP đã hợp nhất: `references/model-pipeline.md` (9 cổng, vòng sửa ≤5, chấm /14), `model-acceptance.md`, `model-defects.md`, `templates/model-report.md`, và các script Blender/Studio `qa_check.py`, `sandbox_blender.py`, `roblox_sandbox.lua` (từ bản MQP của bạn).
- Tự kiểm: `python scripts/test_mb.py` (16 PASS: toán neo/xoay 1205 phép thử ngẫu nhiên, bắt lỗi, Luau khứ hồi, Blender qua bpy giả), `python scripts/texgen.py selftest` (16 PASS).
- **Chưa kiểm chứng:** chạy trên Blender thật (không có Blender ở môi trường dựng; chỉ kiểm hình học bằng bpy giả), Roblox Studio thật, và các script MQP gốc.
