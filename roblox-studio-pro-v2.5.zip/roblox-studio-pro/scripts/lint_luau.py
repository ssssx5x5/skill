#!/usr/bin/env python3
"""Lint luật cứng của skill lên file/thư mục .lua|.luau — bắt thứ mà compiler không bắt.

    python scripts/lint_luau.py <file-hoặc-thư-mục> [--strict]

Mã thoát 1 nếu có ERROR (hoặc WARN khi --strict). Chỉ dùng thư viện chuẩn.
"""
import os
import re
import sys

# (mức, regex, thông điệp)
RULES = [
    ("ERROR", r"(?<![\w.:])wait\s*\(", "dùng task.wait() thay cho wait()"),
    ("ERROR", r"(?<![\w.:])spawn\s*\(", "dùng task.spawn() thay cho spawn()"),
    ("ERROR", r"(?<![\w.:])delay\s*\(", "dùng task.delay() thay cho delay()"),
    ("ERROR", r"local\s+(warn|print|error|type|next|select|tick|pairs|ipairs|tostring|tonumber)\s*=", "che tên hàm global (bug im lặng)"),
    ("ERROR", r"SetPrimaryPartCFrame", "deprecated: dùng Model:PivotTo()"),
    ("WARN", r"Instance\.new\(\s*\"[A-Za-z]+\"\s*,\s*\w+", "Instance.new(class, parent) chậm — set Parent SAU CÙNG"),
    ("ERROR", r"Instance\.new\(\s*\"(BodyVelocity|BodyGyro|BodyPosition|BodyForce|BodyAngularVelocity|BodyThrust)\"", "deprecated: dùng LinearVelocity/AlignOrientation/AlignPosition"),
    ("ERROR", r"Humanoid\s*:\s*LoadAnimation|humanoid\s*:\s*LoadAnimation", "deprecated: dùng Animator:LoadAnimation"),
    ("WARN", r"\.Completed\s*:\s*Wait\s*\(", "Tween.Completed:Wait() có thể không bao giờ fire — dùng vòng Heartbeat + Lerp hoặc timeout"),
    ("WARN", r"WaitForChild\(\s*[^,()]+\)", "WaitForChild không timeout có thể treo vĩnh viễn im lặng"),
    ("WARN", r"rbxassetid://\s*(0|1234567890|123456789)\b", "asset id có vẻ bịa/placeholder — ghi rõ trong Config"),
    ("WARN", r"\bmath\.noise\(\s*-?\d+\s*,\s*-?\d+(\s*,\s*-?\d+)?\s*\)", "math.noise với số nguyên luôn trả 0 — nhân hệ số lẻ"),
    ("WARN", r"\.Touched:Connect", "Touched dễ bị exploit/nhiễu — cân nhắc raycast/Overlap + kiểm trên server"),
    ("WARN", r"OnServerEvent\s*:\s*Connect\s*\(\s*function\s*\(\s*player\s*\)", "handler remote không nhận tham số — chắc chắn không cần validate?"),
    ("WARN", r"while\s+true\s+do\s*$", "vòng lặp vô hạn: chắc có task.wait và điều kiện thoát/disconnect?"),
]
COMMENT = re.compile(r"--(?!\[\[).*$")

def scan_file(path):
    out = []
    try:
        lines = open(path, encoding="utf-8", errors="replace").read().splitlines()
    except OSError as e:
        return [("ERROR", path, 0, f"không đọc được: {e}")]
    has_ss = any("OnServerEvent" in l for l in lines)
    has_validate = any(re.search(r"typeof\(|type\(|Validate\.|math\.clamp", l) for l in lines)
    in_block = False
    for i, raw in enumerate(lines, 1):
        s = raw
        if "--[[" in s: in_block = True
        if in_block:
            if "]]" in s: in_block = False
            continue
        code = COMMENT.sub("", s)
        # bỏ nội dung chuỗi đơn giản để giảm false positive
        code_ns = re.sub(r'"[^"\\]*(\\.[^"\\]*)*"', '""', code)
        for lvl, rx, msg in RULES:
            target = code if "rbxassetid" in rx or "Instance" in rx else code_ns
            if re.search(rx, target):
                out.append((lvl, path, i, msg))
    if has_ss and not has_validate:
        out.append(("WARN", path, 0, "có OnServerEvent nhưng không thấy bước kiểm tham số (typeof/Validate/clamp)"))
    return out

def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    strict = "--strict" in sys.argv
    if not args:
        print(__doc__); sys.exit(2)
    files = []
    for a in args:
        if os.path.isdir(a):
            for r, _, fs in os.walk(a):
                files += [os.path.join(r, f) for f in fs if f.endswith((".lua", ".luau"))]
        else:
            files.append(a)
    errs = warns = 0
    for f in sorted(files):
        for lvl, p, ln, msg in scan_file(f):
            print(f"[{lvl}] {p}:{ln} {msg}")
            errs += lvl == "ERROR"; warns += lvl == "WARN"
    print(f"[DONE ] {len(files)} file, {errs} ERROR, {warns} WARN")
    sys.exit(1 if errs or (strict and warns) else 0)

if __name__ == "__main__":
    main()
