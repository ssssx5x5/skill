"""Model QA check cho Blender (2.93+ / 3.x / 4.x).

Chạy trong Blender (Text Editor hoặc headless):
    blender -b model.blend --python qa_check.py -- --collection MyModel --max-tris 20000 --gap 0.02 --report qa.json --exit-code

Kiểm tra:
  - Mỗi mảnh liền (island) của mọi object có chạm phần chính không (phát hiện phần lơ lửng / khe hở),
    kèm vector cần dịch để đóng khe.
  - Tổng triangle và triangle từng object so với ngân sách.
  - Cạnh hở (non-manifold), mặt diện tích 0, pháp tuyến ngược.
  - Thiếu UV, thiếu vật liệu, object bị ẩn, scale âm, transform chưa apply.
  - Bounds tổng và độ cao đáy (model có đứng trên z=0 không).
Với --exit-code: trả mã thoát 1 khi có lỗi mức ERROR (dùng được trong CI/headless).
"""
import bpy
import bmesh
import sys
import json
import argparse
from mathutils import Vector
from mathutils.bvhtree import BVHTree


def parse_args():
    argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    p = argparse.ArgumentParser()
    p.add_argument("--collection", default=None, help="Tên collection; bỏ trống = mọi mesh đang hiện")
    p.add_argument("--max-tris", type=int, default=20000, help="Ngân sách triangle mỗi object")
    p.add_argument("--gap", type=float, default=0.02, help="Khoảng cách tối đa vẫn coi là chạm (đơn vị Blender)")
    p.add_argument("--report", default=None, help="Đường dẫn file JSON báo cáo")
    p.add_argument("--exit-code", action="store_true", help="Thoát Blender với mã 1 khi có ERROR (cho CI)")
    return p.parse_args(argv)


def mesh_objects(coll_name):
    if coll_name:
        coll = bpy.data.collections.get(coll_name)
        if coll is None:
            raise SystemExit(f"Không tìm thấy collection '{coll_name}'")
        objs = coll.all_objects
    else:
        objs = bpy.context.scene.objects
    return [o for o in objs if o.type == "MESH"]


def world_bmesh(obj, depsgraph):
    """BMesh đã áp modifier và chuyển sang toạ độ world."""
    ev = obj.evaluated_get(depsgraph)
    me = ev.to_mesh()
    bm = bmesh.new()
    bm.from_mesh(me)
    has_uv = len(me.uv_layers) > 0
    ev.to_mesh_clear()
    bm.transform(obj.matrix_world)
    bm.verts.ensure_lookup_table()
    bm.faces.ensure_lookup_table()
    bm.normal_update()
    return bm, has_uv


def islands(bm):
    """Tách các mảnh liền theo cạnh; trả list (verts, polys) đã đánh lại chỉ số."""
    seen = set()
    result = []
    for v in bm.verts:
        if v.index in seen:
            continue
        stack, comp = [v], []
        seen.add(v.index)
        while stack:
            cur = stack.pop()
            comp.append(cur)
            for e in cur.link_edges:
                o = e.other_vert(cur)
                if o.index not in seen:
                    seen.add(o.index)
                    stack.append(o)
        ids = {x.index for x in comp}
        faces = {f for x in comp for f in x.link_faces}
        remap = {i: n for n, i in enumerate(sorted(ids))}
        verts = [bm.verts[i].co.copy() for i in sorted(ids)]
        polys = [[remap[x.index] for x in f.verts] for f in faces]
        result.append((verts, polys))
    return result


def piece_distance(a, b):
    """Khoảng cách gần nhất giữa hai mảnh và vector dịch a để chạm b (0 nếu giao nhau)."""
    if a["tree"].overlap(b["tree"]):
        return 0.0, Vector((0, 0, 0))
    best, move = float("inf"), Vector((0, 0, 0))
    for src, dst, sign in ((a, b, 1), (b, a, -1)):
        for co in src["verts"]:
            hit = dst["tree"].find_nearest(co)
            if hit[0] is not None and hit[3] < best:
                best = hit[3]
                move = (hit[0] - co) * sign
    return best, move


def bbox_near(a, b, gap):
    return all(a["min"][i] - gap <= b["max"][i] and b["min"][i] - gap <= a["max"][i] for i in range(3))


def check_contacts(pieces, gap):
    """Gom các mảnh chạm nhau thành nhóm; mảnh ngoài nhóm chính = lơ lửng."""
    n = len(pieces)
    parent = list(range(n))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    for i in range(n):
        for j in range(i + 1, n):
            if find(i) != find(j) and bbox_near(pieces[i], pieces[j], gap):
                d, _ = piece_distance(pieces[i], pieces[j])
                if d <= gap:
                    parent[find(i)] = find(j)

    groups = {}
    for i in range(n):
        groups.setdefault(find(i), []).append(i)
    main = max(groups.values(), key=lambda g: sum(pieces[k]["size"] for k in g))
    issues = []
    for g in groups.values():
        if g is main:
            continue
        best = None
        for i in g:
            for j in main:
                d, mv = piece_distance(pieces[i], pieces[j])
                if best is None or d < best[0]:
                    best = (d, mv, i, j)
        d, mv, i, j = best
        issues.append({
            "level": "ERROR",
            "type": "floating",
            "piece": pieces[i]["name"],
            "nearest": pieces[j]["name"],
            "distance": round(d, 4),
            "move_to_close": [round(c, 4) for c in mv],
            "group_size": len(g),
        })
    return issues


def check_object(obj, bm, has_uv, max_tris):
    issues = []
    name = obj.name
    tris = sum(len(f.verts) - 2 for f in bm.faces)
    if tris > max_tris:
        issues.append({"level": "ERROR", "type": "tri_budget", "object": name, "tris": tris, "max": max_tris})
    open_edges = sum(1 for e in bm.edges if not e.is_manifold and not e.is_wire)
    if open_edges:
        issues.append({"level": "WARN", "type": "open_edges", "object": name, "count": open_edges,
                       "hint": "Đóng lỗ hoặc thêm Solidify nếu là mặt mỏng; bật DoubleSided khi import"})
    zero = sum(1 for f in bm.faces if f.calc_area() < 1e-8)
    if zero:
        issues.append({"level": "WARN", "type": "zero_area_faces", "object": name, "count": zero})
    # Pháp tuyến ngược: mesh kín mà thể tích âm => mặt quay vào trong
    if open_edges == 0 and len(bm.faces) and bm.calc_volume(signed=True) < 0:
        issues.append({"level": "ERROR", "type": "inverted_normals", "object": name,
                       "hint": "Recalculate Outside (Shift+N)"})
    if not has_uv:
        issues.append({"level": "WARN", "type": "no_uv", "object": name})
    if not obj.material_slots or all(s.material is None for s in obj.material_slots):
        issues.append({"level": "WARN", "type": "no_material", "object": name})
    if obj.hide_get() or obj.hide_render:
        issues.append({"level": "WARN", "type": "hidden", "object": name})
    s = obj.scale
    if s.x * s.y * s.z < 0:
        issues.append({"level": "ERROR", "type": "negative_scale", "object": name, "hint": "Apply scale (Ctrl+A)"})
    elif any(abs(c - 1) > 1e-4 for c in s):
        issues.append({"level": "INFO", "type": "unapplied_scale", "object": name, "scale": list(s)})
    return issues, tris


def main():
    args = parse_args()
    depsgraph = bpy.context.evaluated_depsgraph_get()
    objs = mesh_objects(args.collection)
    issues, pieces, total_tris = [], [], 0
    lo = Vector((float("inf"),) * 3)
    hi = Vector((float("-inf"),) * 3)

    for obj in objs:
        bm, has_uv = world_bmesh(obj, depsgraph)
        obj_issues, tris = check_object(obj, bm, has_uv, args.max_tris)
        issues += obj_issues
        total_tris += tris
        for k, (verts, polys) in enumerate(islands(bm)):
            if not polys:
                continue
            mn = Vector([min(v[i] for v in verts) for i in range(3)])
            mx = Vector([max(v[i] for v in verts) for i in range(3)])
            lo = Vector([min(lo[i], mn[i]) for i in range(3)])
            hi = Vector([max(hi[i], mx[i]) for i in range(3)])
            pieces.append({
                "name": f"{obj.name}#{k}",
                "verts": verts,
                "tree": BVHTree.FromPolygons(verts, polys),
                "min": mn, "max": mx,
                "size": (mx - mn).length,
            })
        bm.free()

    if len(pieces) > 1:
        issues += check_contacts(pieces, args.gap)

    report = {
        "collection": args.collection,
        "objects": len(objs),
        "pieces": len(pieces),
        "total_tris": total_tris,
        "bounds_min": [round(c, 3) for c in lo] if pieces else None,
        "bounds_max": [round(c, 3) for c in hi] if pieces else None,
        "size": [round(hi[i] - lo[i], 3) for i in range(3)] if pieces else None,
        "issues": issues,
    }
    if pieces and abs(lo.z) > args.gap:
        issues.append({"level": "INFO", "type": "base_not_at_zero", "min_z": round(lo.z, 4),
                       "hint": "Đáy model nên nằm ở z=0 để đặt lên mặt đất"})

    errors = sum(1 for i in issues if i["level"] == "ERROR")
    print(f"== QA: {len(objs)} object, {len(pieces)} mảnh, {total_tris} tris, size {report['size']}")
    for i in issues:
        print(f"[{i['level']}] {i['type']}: " + ", ".join(f"{k}={v}" for k, v in i.items() if k not in ('level', 'type')))
    print("== KẾT QUẢ:", "CHƯA ĐẠT" if errors else "Không có lỗi ERROR (vẫn phải xem ảnh)")

    if args.report:
        with open(args.report, "w", encoding="utf-8") as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
    if args.exit_code:
        sys.exit(1 if errors else 0)
    return report


if __name__ == "__main__":
    main()
