#!/usr/bin/env python3
"""Vẽ ảnh kiểm hình học (Part dạng hộp có hướng + lưới tam giác) từ JSON, ngoài Studio — để NHÌN model trước khi giao.

    python scripts/render_geom.py in.json out.png [--views side,front,top,iso] [--title "..."]

JSON: {"parts":[{"name","c":[x,y,z],"x":[..],"y":[..],"z":[..],"size":[sx,sy,sz],"color":[r,g,b]}], "meshes":[{"name","color","verts","tris"}]}
Quy ước hệ trục giống Roblox: X phải, Y lên, Z lùi (trước = −Z). View:
  side  = nhìn dọc trục X (hiện mặt phẳng YZ; trước −Z ở BÊN PHẢI ảnh)   front = nhìn dọc −Z (XY)   top = nhìn từ +Y xuống (XZ; trước −Z ở TRÊN)
  iso   = góc 3/4. Vẽ painter's algorithm + đổ bóng phẳng — đủ để thấy hình dạng, tỉ lệ, khe hở, lệch hướng; KHÔNG phải render đẹp.
"""
import argparse
import json
import sys

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import PolyCollection

LIGHT = np.array([0.35, 0.8, 0.5]); LIGHT /= np.linalg.norm(LIGHT)


def box_faces(p):
    c = np.array(p["c"], float); ax = [np.array(p[k], float) for k in "xyz"]; h = np.array(p["size"], float) / 2
    corners = {}
    for sx in (-1, 1):
        for sy in (-1, 1):
            for sz in (-1, 1):
                corners[(sx, sy, sz)] = c + ax[0] * h[0] * sx + ax[1] * h[1] * sy + ax[2] * h[2] * sz
    faces = []
    for i, s in enumerate((-1, 1)):
        for axis in range(3):
            idx = [(a, b) for a in (-1, 1) for b in (-1, 1)]
            quad = []
            for a, b in [(-1, -1), (1, -1), (1, 1), (-1, 1)]:
                key = [0, 0, 0]; key[axis] = s; o = [k for k in range(3) if k != axis]; key[o[0]] = a; key[o[1]] = b
                quad.append(corners[tuple(key)])
            n = ax[axis] * s
            faces.append((np.array(quad), n))
    return faces


def tri_faces(m):
    v = np.array(m["verts"], float); t = np.array(m["tris"], int)
    out = []
    for a, b, c in t:
        n = np.cross(v[b] - v[a], v[c] - v[a]); ln = np.linalg.norm(n)
        out.append((np.array([v[a], v[b], v[c]]), n / ln if ln > 0 else n))
    return out


VIEWS = {
    "side": (np.array([0, 0, -1.0]), lambda p: (-p[:, 2], p[:, 1]), lambda p: p[:, 0]),           # ngang = −Z (trước → phải), dọc = Y; sâu = X
    "front": (np.array([0, 0, -1.0]), lambda p: (p[:, 0], p[:, 1]), lambda p: -p[:, 2]),
    "top": (np.array([0, 1.0, 0]), lambda p: (p[:, 0], -p[:, 2]), lambda p: p[:, 1]),
    "iso": (None, None, None),
}


def project(view, pts):
    if view == "iso":
        az, el = np.radians(35), np.radians(25)
        R = np.array([[np.cos(az), 0, np.sin(az)], [0, 1, 0], [-np.sin(az), 0, np.cos(az)]])
        E = np.array([[1, 0, 0], [0, np.cos(el), -np.sin(el)], [0, np.sin(el), np.cos(el)]])
        q = pts @ R.T @ E.T
        return q[:, 0], q[:, 1], -q[:, 2]
    _, f, d = VIEWS[view]
    x, y = f(pts)
    return x, y, d(pts)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("inp"); ap.add_argument("out")
    ap.add_argument("--views", default="side,front,top,iso")
    ap.add_argument("--title", default="")
    a = ap.parse_args()
    data = json.load(open(a.inp, encoding="utf-8"))
    items = []
    for p in data.get("parts", []):
        col = np.array(p["color"], float)
        for quad, n in box_faces(p): items.append((quad, n, col))
    for m in data.get("meshes", []):
        col = np.array(m["color"], float)
        for tri, n in tri_faces(m): items.append((tri, n, col))
    if not items: sys.exit("không có hình học")
    views = a.views.split(",")
    fig, axes = plt.subplots(1, len(views), figsize=(5.2 * len(views), 5.4), facecolor="#14161c")
    if len(views) == 1: axes = [axes]
    allp = np.concatenate([q for q, _, _ in items])
    for axx, view in zip(axes, views):
        polys, cols, depth = [], [], []
        for quad, n, col in items:
            x, y, d = project(view, quad)
            # Cắt bỏ mặt quay lưng (chỉ cho box; lưới giữ cả hai để thấy lỗi)
            polys.append(np.column_stack([x, y])); depth.append(d.mean())
            if view == "iso":
                shade = 0.35 + 0.65 * abs(float(n @ LIGHT))
            else:
                shade = 0.35 + 0.65 * abs(float(n @ LIGHT))
            cols.append(np.clip(col * shade, 0, 1))
        order = np.argsort(depth)
        pc = PolyCollection([polys[i] for i in order], facecolors=[cols[i] for i in order], edgecolors=[(0, 0, 0, 0.35)] * len(order), linewidths=0.3)
        axx.add_collection(pc)
        x, y, _ = project(view, allp)
        pad = 0.08 * max(np.ptp(x), np.ptp(y), 1e-6)
        axx.set_xlim(x.min() - pad, x.max() + pad); axx.set_ylim(y.min() - pad, y.max() + pad)
        axx.set_aspect("equal"); axx.set_facecolor("#1c1f27"); axx.set_title(view, color="#cfd3dc", fontsize=11)
        axx.tick_params(colors="#6b7080", labelsize=7)
        for s in axx.spines.values(): s.set_color("#3a3f4d")
        axx.grid(True, color="#2a2e3a", linewidth=0.4)
    if a.title: fig.suptitle(a.title, color="#e6e9f0", fontsize=12)
    fig.tight_layout()
    fig.savefig(a.out, dpi=110, facecolor=fig.get_facecolor())
    print(f"[OK] {a.out} ({len(items)} mặt)")


if __name__ == "__main__":
    main()
