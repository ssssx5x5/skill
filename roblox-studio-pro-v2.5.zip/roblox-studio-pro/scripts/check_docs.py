#!/usr/bin/env python3
"""Trich moi khoi ```lua trong tai lieu cua skill va bien dich bang luau-compile.

Dung khi sua SKILL.md hoac references/*.md: bao dam moi doan code mau van hop le
sau khi sua. Khong chay duoc code, chi kiem cu phap.

    python scripts/check_docs.py
    python scripts/check_docs.py --luau C:/path/luau-compile.exe
    python scripts/check_docs.py --dir C:/path/to/skill

Mac dinh: --dir la thu muc cha cua scripts/, --luau tim trong PATH hoac
bien moi truong LUAU_COMPILE, hoac luau-compile trong PATH

Ma thoat 1 neu co khoi loi.
"""
import argparse
import glob
import io
import os
import re
import shutil
import subprocess
import sys
import tempfile

BLOCK = re.compile(r"```lua\n(.*?)```", re.S)


def find_luau(explicit):
    if explicit:
        return explicit
    env = os.environ.get("LUAU_COMPILE")
    if env:
        return env
    for name in ("luau-compile", "luau-compile.exe"):
        p = shutil.which(name)
        if p:
            return p
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", default=os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    ap.add_argument("--luau", default=None)
    ap.add_argument("-v", "--verbose", action="store_true")
    args = ap.parse_args()

    luau = find_luau(args.luau)
    if not luau or not os.path.exists(luau):
        print("[SKIP ] khong tim thay luau-compile; truyen --luau duong/dan")
        return 0

    files = [os.path.join(args.dir, "SKILL.md")]
    files += sorted(glob.glob(os.path.join(args.dir, "references", "*.md")))

    tmpdir = tempfile.mkdtemp(prefix="skillchk_")
    out = os.path.join(tmpdir, "block.lua")
    total = bad = frags = 0
    failed = []

    for path in files:
        if not os.path.exists(path):
            continue
        rel = os.path.relpath(path, args.dir)
        src = io.open(path, encoding="utf-8").read()
        for i, body in enumerate(BLOCK.findall(src)):
            total += 1
            io.open(out, "w", encoding="utf-8", newline="\n").write(body)
            r = subprocess.run([luau, out], capture_output=True)
            frag = re.search(r"continue statement must be inside a loop|Expected 'end'|got '\.\.\.'|got '\['|got 'and'|got <eof>", (r.stderr or b"").decode(errors="replace"))
            if r.returncode != 0 and frag:
                frags += 1  # mảnh code minh hoạ (không phải chương trình đầy đủ) — không tính là lỗi
                if args.verbose:
                    print("[frag ] %s #%d" % (rel, i))
            elif r.returncode != 0:
                bad += 1
                err = (r.stderr or b"").decode(errors="replace").strip().splitlines()
                head = err[0] if err else "?"
                failed.append((rel, i, head))
                print("[ERROR] %s #%d :: %s" % (rel, i, head[:150]))
            elif args.verbose:
                print("[ok   ] %s #%d" % (rel, i))

    print("[DONE ] %d khoi lua, %d loi, %d manh minh hoa" % (total, bad, frags))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
