#!/usr/bin/env python3
"""Sandbox Roblox ngoài Studio: chạy code Luau DỰNG MODEL / animation → scene.json → ảnh nhiều góc → AI tự xem và sửa.

    python scripts/sandbox.py run build.lua --render out.png [--views front,left,top,iso] [--front=negz]
        [--autolib] [--lib X.lua ...] [--time 2 --snaps 0,0.5,1] [--json scene.json] [--outline] [--ids]
    python scripts/sandbox.py inspect scene.json          # cây, kích thước, cụm rời, weld, cảnh báo
    python scripts/sandbox.py install-luau                 # tải luau CLI từ GitHub nếu máy chưa có

Cơ chế: ghép templates/sandbox/RbxStub.lua (Roblox giả) + các module + script của bạn → luau CLI → in JSON giữa <<<SCENE ... SCENE>>>.
Module: --autolib nạp mọi templates/*.lua để `require(RS.GeoKit)` / `require(script.Parent.AnimKit)` chạy được.
KHÔNG phải Roblox thật: không vật lý/render engine; xem templates/sandbox/README.md (mục "Khác Roblox thật ở đâu").
"""
import argparse
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
TEMPLATES = os.path.join(ROOT, "templates")
STUB = os.path.join(TEMPLATES, "sandbox", "RbxStub.lua")
CACHE = os.path.join(os.path.expanduser("~"), ".cache", "rbx-sandbox")


def find_luau():
    for c in [os.environ.get("LUAU"), shutil.which("luau"), os.path.join(CACHE, "luau"), os.path.join(CACHE, "luau.exe")]:
        if c and os.path.isfile(c):
            return c
    return None


def install_luau():
    os.makedirs(CACHE, exist_ok=True)
    plat = sys.platform
    name = "luau-ubuntu.zip" if plat.startswith("linux") else ("luau-macos.zip" if plat == "darwin" else "luau-windows.zip")
    url = f"https://github.com/luau-lang/luau/releases/latest/download/{name}"
    z = os.path.join(CACHE, name)
    print("tải", url)
    urllib.request.urlretrieve(url, z)
    with zipfile.ZipFile(z) as f:
        f.extractall(CACHE)
    for fn in ("luau", "luau.exe"):
        p = os.path.join(CACHE, fn)
        if os.path.isfile(p):
            os.chmod(p, 0o755)
            print("[OK]", p)
            return p
    sys.exit("không thấy file luau sau khi giải nén")


def module_name(path):
    return os.path.splitext(os.path.basename(path))[0]


def build_program(user_src, libs, time_s, snaps, dt):
    parts = [open(STUB, encoding="utf-8").read()]
    for lib in libs:
        src = open(lib, encoding="utf-8").read()
        # module trả về giá trị ở cuối file; bọc trong hàm để nạp lười
        parts.append(f'__MODULES[{json.dumps(module_name(lib))}] = {{ fn = function()\n{src}\nend }}\n')
    snap_lua = "{" + ",".join(str(s) for s in snaps) + "}"
    parts.append("local __main = function()\n" + user_src + "\nend\n")
    parts.append(f"local __frames = Sandbox.run(__main, {{ time = {time_s}, snaps = {snap_lua}, dt = {dt} }})\nSandbox.emit(__frames)\n")
    return "\n".join(parts)


def run_luau(prog, luau):
    with tempfile.NamedTemporaryFile("w", suffix=".lua", delete=False, encoding="utf-8") as f:
        f.write(prog)
        tmp = f.name
    try:
        r = subprocess.run([luau, tmp], capture_output=True, text=True, timeout=300)
    finally:
        try:
            os.unlink(tmp)
        except OSError:
            pass
    return r


def parse_scene(stdout):
    m = re.search(r"<<<SCENE\n(.*?)\nSCENE>>>", stdout, re.S)
    if not m:
        return None
    return json.loads(m.group(1))


def report_log(scene):
    errs = warns = 0
    for l in scene.get("log", []):
        kind, _, msg = l.partition("|")
        if kind == "ERR":
            errs += 1
            print(f"[ERR ] {msg}")
        elif kind == "WARN":
            warns += 1
            print(f"[WARN] {msg}")
        else:
            print(f"  {msg}")
    return errs, warns


def cmd_run(a):
    luau = find_luau()
    if not luau:
        sys.exit("Chưa có luau CLI. Chạy: python scripts/sandbox.py install-luau  (hoặc đặt biến LUAU=/đường/dẫn/luau)")
    libs = list(a.lib or [])
    if a.autolib:
        for fn in sorted(os.listdir(TEMPLATES)):
            if fn.endswith(".lua"):
                libs.append(os.path.join(TEMPLATES, fn))
    snaps = [float(x) for x in a.snaps.split(",")] if a.snaps else []
    user_src = open(a.script, encoding="utf-8").read()
    prog = build_program(user_src, libs, a.time, snaps, a.dt)
    r = run_luau(prog, luau)
    scene = parse_scene(r.stdout)
    if r.returncode != 0 or scene is None:
        print(r.stdout[-2000:])
        print(r.stderr[-3000:], file=sys.stderr)
        sys.exit("[ERR ] script/luau lỗi (xem trên). Lỗi cú pháp/runtime của chính script thường nằm ở dòng đầu stderr.")
    errs, warns = report_log(scene)
    out_json = a.json or os.path.splitext(a.render or "scene.png")[0] + ".json"
    json.dump(scene, open(out_json, "w", encoding="utf-8"))
    last = scene["frames"][-1]
    print(f"[OK] {len(last['parts'])} part, {len(last['nodes'])} model/folder, {len(last['joints'])} joint, {len(scene['frames'])} khung → {out_json}")
    if a.render:
        cmd = [sys.executable, "-I", os.path.join(HERE, "rbx_render.py"), out_json, a.render, "--views", a.views, f"--front={a.front}"]
        if a.outline:
            cmd.append("--outline")
        if a.ids:
            cmd.append("--ids")
        if a.frame is not None:
            cmd += ["--frame", str(a.frame)]
        subprocess.run(cmd, check=True)
    bad = 0
    if a.expect:
        spec = importlib.util.spec_from_file_location("scene_check", os.path.join(HERE, "scene_check.py")); sc = importlib.util.module_from_spec(spec); spec.loader.exec_module(sc)
        bad = sc.run_check(scene, a.expect, a.front)
    if errs or bad:
        sys.exit(1)


def obb_axes(cf):
    return [(cf[3], cf[6], cf[9]), (cf[4], cf[7], cf[10]), (cf[5], cf[8], cf[11])]


def separation(pa, pb):
    """Khoảng hở ≤ thực (cận dưới) giữa hai hộp có hướng bằng SAT; <0 nghĩa là chồng lấn."""
    import numpy as np
    def box(p):
        cf = p["cf"]; c = np.array(cf[:3]); ax = np.array([[cf[3], cf[6], cf[9]], [cf[4], cf[7], cf[10]], [cf[5], cf[8], cf[11]]]); h = np.array(p["size"]) / 2
        return c, ax, h
    ca, aa, ha = box(pa); cb, ab, hb = box(pb)
    t = cb - ca
    axes = [aa[i] for i in range(3)] + [ab[i] for i in range(3)]
    for i in range(3):
        for j in range(3):
            x = np.cross(aa[i], ab[j])
            if np.linalg.norm(x) > 1e-9:
                axes.append(x / np.linalg.norm(x))
    best = -1e9
    for x in axes:
        ra = sum(ha[i] * abs(aa[i] @ x) for i in range(3)); rb = sum(hb[i] * abs(ab[i] @ x) for i in range(3))
        best = max(best, abs(t @ x) - ra - rb)
    return best


def cmd_inspect(a):
    scene = json.load(open(a.json, encoding="utf-8"))
    fr = scene["frames"][-1 if a.frame is None else a.frame]
    parts = fr["parts"]
    import numpy as np
    if not parts:
        sys.exit("scene rỗng")
    mn = np.full(3, 1e9); mx = np.full(3, -1e9)
    for p in parts:
        cf = p["cf"]; c = np.array(cf[:3]); ax = np.array([[cf[3], cf[6], cf[9]], [cf[4], cf[7], cf[10]], [cf[5], cf[8], cf[11]]]); h = np.array(p["size"]) / 2
        ext = np.abs(ax) @ h
        mn = np.minimum(mn, c - ext); mx = np.maximum(mx, c + ext)
    size = mx - mn
    print(f"Số part: {len(parts)} | hộp bao: {size[0]:.2f} × {size[1]:.2f} × {size[2]:.2f} studs (X×Y×Z) | tâm ({', '.join(f'{float(v):.2f}' for v in (mn+mx)/2)})")
    shapes = {}
    for p in parts:
        shapes[p["shape"]] = shapes.get(p["shape"], 0) + 1
    print("Hình dạng:", ", ".join(f"{k}:{v}" for k, v in sorted(shapes.items())))
    cols = {}
    for p in parts:
        k = tuple(int(round(c * 255)) for c in p["color"]); cols[k] = cols.get(k, 0) + 1
    print("Màu hay dùng:", ", ".join(f"#{r:02x}{g:02x}{b:02x}×{n}" for (r, g, b), n in sorted(cols.items(), key=lambda kv: -kv[1])[:8]))
    # cụm rời: chạm/chồng lấn (gap ≤ tol) HOẶC nối bằng joint
    n = len(parts); par = list(range(n))
    def find(i):
        while par[i] != i:
            par[i] = par[par[i]]; i = par[i]
        return i
    for j in fr["joints"]:
        if j["p0"] >= 0 and j["p1"] >= 0:
            par[find(j["p0"])] = find(j["p1"])
    weld_comp = len({find(i) for i in range(n)})
    par2 = list(par)
    def find2(i):
        while par2[i] != i:
            par2[i] = par2[par2[i]]; i = par2[i]
        return i
    for i in range(n):
        for k in range(i + 1, n):
            if find2(i) != find2(k) and separation(parts[i], parts[k]) <= a.tol:
                par2[find2(i)] = find2(k)
    touch_comp = len({find2(i) for i in range(n)})
    print(f"Weld/joint nối thành {weld_comp} assembly vật lý; chạm hình học (khe ≤ {a.tol}) nối thành {touch_comp} cụm")
    if weld_comp > 1:
        print("  [CẢNH BÁO] model có >1 assembly: các cụm sẽ RỜI NHAU khi Anchored=false. Weld thêm hoặc dùng AssemblyGuard.Build")
    if touch_comp > 1:
        print("  [CẢNH BÁO] có part không chạm gì cả (trôi lơ lửng về hình học)")
    print("Cây:")
    for nd in fr["nodes"]:
        print("  ", nd["path"], f"({nd['class']})")
    for l in scene.get("log", []):
        if l.startswith("WARN") or l.startswith("ERR"):
            print("  !", l)
    sys.exit(0 if weld_comp == 1 and touch_comp == 1 else 2)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run")
    r.add_argument("script"); r.add_argument("--render"); r.add_argument("--json")
    r.add_argument("--views", default="front,left,top,iso"); r.add_argument("--front", default="-z")
    r.add_argument("--autolib", action="store_true"); r.add_argument("--lib", action="append")
    r.add_argument("--time", type=float, default=0.0); r.add_argument("--snaps", default=""); r.add_argument("--dt", type=float, default=1 / 30)
    r.add_argument("--expect", help="expect.json: kiểm tỉ lệ/số lượng/màu/liền khối (xem scripts/scene_check.py)"); r.add_argument("--outline", action="store_true"); r.add_argument("--ids", action="store_true"); r.add_argument("--frame", type=int)
    i = sub.add_parser("inspect")
    i.add_argument("json"); i.add_argument("--tol", type=float, default=0.03); i.add_argument("--frame", type=int)
    sub.add_parser("install-luau")
    a = ap.parse_args()
    if a.cmd == "run":
        cmd_run(a)
    elif a.cmd == "inspect":
        cmd_inspect(a)
    else:
        install_luau()


if __name__ == "__main__":
    main()
