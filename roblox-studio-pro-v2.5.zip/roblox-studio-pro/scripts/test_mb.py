#!/usr/bin/env python3
"""Test model builder: toán học neo/xoay, kiểm tra hình học, dimdb, Luau (chạy bằng luau CLI nếu có), Blender (bpy GIẢ để kiểm ma trận)."""
import json, os, shutil, subprocess, sys, tempfile, types
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import mb, dimdb, mbcheck
ok = bad = 0
def chk(c, msg):
    global ok, bad
    if c: ok += 1; print("PASS", msg)
    else: bad += 1; print("FAIL", msg)

chk(mb.selftest() == 0, "mb.selftest (200 vòng ngẫu nhiên: euler, look_rot, on(), mirror)")

# ---- check bắt lỗi
m = mb.Model("t"); a = m.box("a", (2, 1, 2), at=(0, 0.5, 0)); b = m.box("b", (1, 1, 1), at=(0, 3, 0)); r = m.check()
chk(any("LƠ LỬNG" in e for e in r["errors"]), "bắt part lơ lửng + gợi ý vector dịch")
m = mb.Model("t"); a = m.box("a", (2, 1, 2), at=(0, 0.5, 0)); c = m.box("c", (2, 1, 2), at=(0, 0.5, 0), color="#FF0000"); r = m.check()
chk(any("ẨN" in w for w in r["warnings"]) or any("Z-FIGHT" in w for w in r["warnings"]), "bắt part ẩn / z-fight")
m = mb.Model("t"); a = m.box("a", (2, 1, 2), at=(0, 0.5, 0)); b = m.on(m.box("b", (2, 1, 2)), a, "top"); r = m.check()
chk(not r["errors"] and not any("Z-FIGHT" in w for w in r["warnings"]), "xếp chồng bằng on(): sạch lỗi, không z-fight giả")
m = mb.Model("t"); a = m.box("a", (2, 1, 2), at=(0, 0.5, 0)); m.symmetry = "x"; m.box("b", (0.5, 0.5, 0.5), at=(1.5, 1.2, 0)); r = m.check()
chk(any("ĐỐI XỨNG" in e for e in r["errors"]), "bắt thiếu cặp đối xứng")
m = mb.Model("t"); a = m.box("a", (1, 1, 1), at=(0, .5, 0)); b = m.on(m.box("b", (1, 1, 1)), a, "right", gap=0.3); m.expect("touch", a, b); r = m.check()
chk(any("RÀNG BUỘC touch" in e for e in r["errors"]), "ràng buộc touch bắt khe hở")
# ---- dimdb: bắt kích thước sai
f, rows = dimdb.check("chair", {"height": 4}, {"back_above_seat": 3.5, "seat_height": 1.3})
chk(any(x[3].startswith("FAIL") for x in rows), "dimdb bắt lưng ghế quá cao (tổng quát: theo tỉ lệ/khoảng thật)")
f, rows = dimdb.check("chair", {"height": 4}, {"back_above_seat": 3.5, "seat_height": 1.3}, style="exaggerated")
chk(dimdb.find("ghế") == "chair" and dimdb.find("xe hơi") == "car", "dimdb tra alias tiếng Việt")
# ---- mb.mirror/rotate_about với part xoay bất kỳ: sát nhau vẫn chạm
m = mb.Model("t"); p = m.box("p", (1, 2, 1), at=(1, 1, 0)); q = m.on(m.box("q", (0.4, 0.4, 2)), p, "top", rot=(0, 30, 0)); mm = m.mirror([p, q], "x")
g = mbcheck.sat_gap(mm[0], mm[1]); chk(abs(g) < 1e-6, f"mirror giữ quan hệ chạm ({g:.1e})")
# ---- trụ theo trục thế giới: on() dùng mặt top thật
m2 = mb.Model("t"); base = m2.cyl("b", 0.3, 2, axis="y", at=(0, .15, 0)); col = m2.on(m2.cyl("c", 2, 0.3, axis="y"), base, "top")
chk(abs(col.pos[1] - (0.3 + 1.0)) < 1e-9 and abs(m2.scene()["frames"][0]["parts"][0]["size"][0] - 0.3) < 1e-9, "cyl(axis=y): top đúng hướng thế giới, backend xuất size/CFrame Roblox đúng")
# ---- Luau
luau = os.environ.get("LUAU") or shutil.which("luau")
m = mb.Model("Tst"); a = m.box("a", (2, 1, 2), at=(0, .5, 0)); b = m.on(m.box("b", (1, 1, 1), color="#FF8800", material="Wood"), a, "top", rot=(0, 45, 0)); m.cyl("c", 2, 0.5, axis="y", at=(5, 1, 0)); m.wedge("w", (1, 1, 1), at=(7, .5, 0))
m.save(tempfile.mkdtemp(), render=False)
src = m.luau()
if luau:
    sandbox = os.path.join(HERE, "sandbox.py"); tmp = tempfile.mkdtemp(); fp = os.path.join(tmp, "b.lua"); open(fp, "w").write(src.replace("return model", ""))
    r = subprocess.run([sys.executable, sandbox, "run", fp, "--json", os.path.join(tmp, "s.json")], capture_output=True, text=True, env={**os.environ, "LUAU": luau})
    chk(r.returncode == 0, "Luau sinh ra chạy được trong sandbox: " + r.stdout.strip().splitlines()[-1] if r.stdout.strip() else r.stderr[-200:])
    if r.returncode == 0:
        sc = json.load(open(os.path.join(tmp, "s.json")))["frames"][0]; mine = m.scene()["frames"][0]
        by = {p["name"]: p for p in sc["parts"]}; good = True
        for p in [x for x in mine["parts"] if not x["name"].startswith("_REF")]:
            q = by.get(p["name"]); good &= q is not None and np.allclose(q["cf"], p["cf"], atol=1e-3) and np.allclose(q["size"], p["size"], atol=1e-3) and q["shape"] == p["shape"]
        chk(good, "Luau cho đúng CFrame/Size/Shape từng part so với scene của mb (vòng khứ hồi)")
        chk(len(sc["joints"]) >= 1, "Luau tạo WeldConstraint")
else: print("SKIP Luau (không có luau CLI)")
# ---- Blender với bpy giả: kiểm hình học thế giới == Roblox → MAP
class FakeMat: pass
class Coll:
    def __init__(s): s.objects = types.SimpleNamespace(link=lambda o: LINKED.append(o)); 
LINKED = []
class Mesh:
    def __init__(s, n): s.name = n; s.materials = []
    def from_pydata(s, v, e, f): s.v = np.array(v, float); s.f = f
    def update(s): pass
class Obj:
    def __init__(s, n, d): s.name = n; s.data = d; s.matrix_world = None
bpy = types.ModuleType("bpy")
bpy.data = types.SimpleNamespace(
    collections=types.SimpleNamespace(new=lambda n: Coll()), meshes=types.SimpleNamespace(new=lambda n: Mesh(n)),
    objects=types.SimpleNamespace(new=lambda n, d: Obj(n, d)),
    materials=types.SimpleNamespace(get=lambda n: None, new=lambda n: types.SimpleNamespace(use_nodes=False, node_tree=types.SimpleNamespace(nodes=types.SimpleNamespace(get=lambda k: types.SimpleNamespace(inputs=__import__("collections").defaultdict(lambda: types.SimpleNamespace(default_value=None))), new=lambda t: None), links=types.SimpleNamespace(new=lambda a, b: None)))),
    images=types.SimpleNamespace(load=lambda p: None))
bpy.context = types.SimpleNamespace(scene=types.SimpleNamespace(collection=types.SimpleNamespace(children=types.SimpleNamespace(link=lambda c: None))))
mu = types.ModuleType("mathutils")
class Matrix:
    def __init__(s, rows): s.a = np.array(rows, float)
    @staticmethod
    def Diagonal(d): return Matrix(np.diag(d))
    def __matmul__(s, o): return Matrix(s.a @ o.a)
mu.Matrix = Matrix; sys.modules["bpy"] = bpy; sys.modules["mathutils"] = mu
exec(compile(m.blender(), "blender.py", "exec"), {"__name__": "x"})
chk(len(LINKED) == 4, "bpy script tạo đủ 4 object")
rend = __import__("rbx_render")
good = True
for o, p in zip(LINKED, m.real_parts()):
    if p.shape == "Ball" or True:
        sp = m.scene()["frames"][0]["parts"][m.parts.index(p)]; V, _ = rend.part_tris(sp, set()); cf = sp["cf"]
        Vr = V.reshape(-1, 3) @ np.array(cf[3:12]).reshape(3, 3).T + np.array(cf[:3])                                 # đỉnh thế giới Roblox, theo renderer
        Vb = np.array([(o.matrix_world.a @ np.append(v, 1))[:3] for v in o.data.v])
        # so bao hộp: mapped Roblox AABB == Blender AABB
        want = (Vr @ mb.MAP.T); lo1, hi1 = want.min(0), want.max(0); lo2, hi2 = Vb.min(0), Vb.max(0)
        if p.shape in ("Block",): good &= np.allclose(lo1, lo2, atol=1e-6) and np.allclose(hi1, hi2, atol=1e-6)
        else: good &= np.allclose((lo1 + hi1) / 2, (lo2 + hi2) / 2, atol=1e-6) and np.allclose(hi1 - lo1, hi2 - lo2, atol=0.35 * max(hi1 - lo1))
chk(good, "Blender: bao hộp/tâm của từng object khớp hình học Roblox qua MAP (bpy giả)")
chk(abs(np.linalg.det(LINKED[0].matrix_world.a[:3, :3])) > 0 and np.linalg.det(mb.MAP) > 0, "ma trận Blender không lật tay (det>0)")
print(f"\ntest_mb: {ok} PASS, {bad} FAIL"); sys.exit(1 if bad else 0)
