#!/usr/bin/env python3
"""Sinh texture PBR procedural TILEABLE (numpy + PIL): albedo, normal, roughness, metalness, ao + ảnh xem trước (tile 2×2 + cầu).

    python scripts/texgen.py list
    python scripts/texgen.py make <kiểu> --out DIR [--size 512] [--seed 1] [--color #8B5A2B] [--scale 1.0] [--wear 0.3] [--name tên]
    python scripts/texgen.py selftest
Kết quả: DIR/<tên>_albedo.png, _normal.png (OpenGL, +Y lên; Roblox NormalMap dùng cùng quy ước), _roughness.png, _metalness.png, _ao.png, _preview.png

Roblox: (1) KHÔNG cần upload: dùng Enum.Material (bảng `material_for`) + Color — rẻ nhất, tile sẵn. (2) Texture/Decal trên Part: upload ảnh lên
Creator Hub (thủ công; sandbox không upload được), dán id, đặt StudsPerTileU/V. (3) SurfaceAppearance (CHỈ MeshPart): ColorMap/NormalMap/RoughnessMap/MetalnessMap.
Texture ≤1024 (khuyên 512), nên tileable. Blender: mb.py blender(tex_dir=DIR) tự nối các map vào Principled BSDF.
"""
import argparse
import os
import sys

import numpy as np
from PIL import Image

KINDS = {}
ENUM = {"wood": "Wood", "planks": "WoodPlanks", "stone": "Slate", "cobble": "Cobblestone", "brick": "Brick", "tile": "Marble", "metal_brushed": "Metal",
        "metal_plate": "DiamondPlate", "fabric": "Fabric", "concrete": "Concrete", "leather": "Fabric", "grass": "Grass", "sand": "Sand", "rust": "CorrodedMetal",
        "rubber": "Plastic", "plastic": "SmoothPlastic"}


def material_for(kind): return ENUM.get(kind, "Plastic")


def reg(f): KINDS[f.__name__[2:]] = f; return f


def rng_(seed): return np.random.default_rng(seed)


def fnoise(n, rng, beta=2.0, cutoff=None):
    """Nhiễu 1/f^beta TUẦN HOÀN (qua FFT) trong [0,1] — tileable tự nhiên."""
    w = rng.normal(size=(n, n)); F = np.fft.fft2(w)
    fy = np.fft.fftfreq(n)[:, None]; fx = np.fft.fftfreq(n)[None, :]; r = np.sqrt(fx ** 2 + fy ** 2); r[0, 0] = 1
    F = F / (r ** (beta / 2))
    if cutoff: F = F * (r < cutoff)
    F[0, 0] = 0; o = np.real(np.fft.ifft2(F)); o -= o.min(); return o / max(o.max(), 1e-9)


def octaves(n, rng, base=4, count=5, gain=0.5):
    out = np.zeros((n, n)); amp = 1.0; tot = 0
    for o in range(count):
        out += amp * fnoise(n, rng, 2.2, cutoff=min(0.5, base * (2 ** o) / n)); tot += amp; amp *= gain
    out /= tot; out -= out.min(); return out / max(out.max(), 1e-9)


def hexrgb(h): h = h.lstrip("#"); return np.array([int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)])


def normal_from_height(h, strength=2.0):
    gx = (np.roll(h, -1, 1) - np.roll(h, 1, 1)) * strength * h.shape[0] / 64; gy = (np.roll(h, -1, 0) - np.roll(h, 1, 0)) * strength * h.shape[0] / 64
    n = np.stack([-gx, gy, np.ones_like(h)], -1); n /= np.linalg.norm(n, axis=-1, keepdims=True)
    return n * 0.5 + 0.5


def ao_from_height(h): return np.clip(1 - 0.8 * np.clip((np.roll(h, 1, 0) + np.roll(h, -1, 0) + np.roll(h, 1, 1) + np.roll(h, -1, 1)) / 4 - h, 0, 1) * 6, 0.3, 1)


def tintmap(base, h, var=0.25, dark=0.55): return np.clip(base * (dark + (1 - dark) * h[..., None]) * (1 + var * (h[..., None] - 0.5)), 0, 1)


def pack(albedo, height, rough, metal, normal_strength=2.0):
    return {"albedo": albedo, "height": height, "normal": normal_from_height(height, normal_strength), "roughness": np.clip(rough, 0, 1), "metalness": np.clip(metal, 0, 1), "ao": ao_from_height(height)}


@reg
def t_wood(n, seed, color, scale, wear):
    r = rng_(seed); y, x = np.mgrid[0:n, 0:n] / n; k = max(1, int(round(6 * scale)))
    warp = octaves(n, r, 3, 3); rings = np.sin(2 * np.pi * (k * (x + 0.06 * warp)) + 0.9 * octaves(n, r, 6, 3)); g = 0.5 + 0.5 * rings
    fiber = fnoise(n, r, 1.2) ; h = 0.6 * g + 0.4 * (1 - fiber)
    a = tintmap((color if color is not None else hexrgb("#8B5A2B")), h, 0.5, 0.6); return pack(a, h * 0.5, 0.65 + 0.2 * fiber, np.zeros((n, n)), 1.2)


@reg
def t_planks(n, seed, color, scale, wear):
    r = rng_(seed); base = t_wood(n, seed, color, scale, wear); k = max(2, int(round(4 * scale))); y, x = np.mgrid[0:n, 0:n]
    idx = (y * k // n); gap = ((y % (n // k)) < max(2, n // 128)) ; tone = r.uniform(0.8, 1.15, k)[idx]
    a = base["albedo"] * tone[..., None]; a[gap] *= 0.35; h = base["height"].copy(); h[gap] = 0
    shift = (r.integers(0, n, k))[idx]; return pack(np.clip(a, 0, 1), h, base["roughness"], base["metalness"], 3)


def cells(n, rng, count):
    pts = rng.uniform(0, 1, (count, 2)); y, x = np.mgrid[0:n, 0:n] / n; d1 = np.full((n, n), 9.0); d2 = np.full((n, n), 9.0); idx = np.zeros((n, n), int)
    for i, (py, px) in enumerate(pts):
        best = np.full((n, n), 9.0)
        for oy in (-1, 0, 1):
            for ox in (-1, 0, 1): best = np.minimum(best, np.hypot(y - py + oy, x - px + ox))
        m = best < d1; d2 = np.where(m, d1, np.minimum(d2, best)); idx = np.where(m, i, idx); d1 = np.minimum(d1, best)
    return d1, d2, idx


@reg
def t_stone(n, seed, color, scale, wear):
    r = rng_(seed); cnt = max(6, int(24 * scale * scale)); d1, d2, idx = cells(n, r, cnt); edge = np.clip((d2 - d1) * n / 6, 0, 1)
    tone = r.uniform(0.75, 1.1, cnt)[idx]; nz = octaves(n, r, 8, 4); h = edge * (0.6 + 0.4 * nz)
    a = tintmap((color if color is not None else hexrgb("#8A8A8E")), nz, 0.4, 0.6) * tone[..., None] * (0.55 + 0.45 * edge[..., None]); return pack(np.clip(a, 0, 1), h, 0.8 - 0.2 * nz, np.zeros((n, n)), 3)


@reg
def t_cobble(n, seed, color, scale, wear): return t_stone(n, seed, (color if color is not None else hexrgb("#777166")), scale * 1.6, wear)


@reg
def t_brick(n, seed, color, scale, wear):
    r = rng_(seed); rows = max(3, int(round(8 * scale))); cols = max(2, rows // 2); y, x = np.mgrid[0:n, 0:n]; rh = n // rows; cw = n // cols
    ri = y // rh; xo = (x + (ri % 2) * cw // 2) % n; ci = xo // cw; ly = y % rh; lx = xo % cw; mortar = max(2, n // 100)
    inside = (ly >= mortar) & (lx >= mortar); tone = r.uniform(0.75, 1.15, (rows, cols))[ri % rows, ci % cols]; nz = octaves(n, r, 10, 4)
    a = np.where(inside[..., None], tintmap((color if color is not None else hexrgb("#9C4A32")), nz, 0.5, 0.6) * tone[..., None], hexrgb("#B9B2A6") * (0.7 + 0.3 * nz)[..., None])
    h = np.where(inside, 0.7 + 0.3 * nz, 0.0); return pack(np.clip(a, 0, 1), h, np.where(inside, 0.85, 0.95), np.zeros((n, n)), 3)


@reg
def t_tile(n, seed, color, scale, wear):
    r = rng_(seed); k = max(2, int(round(4 * scale))); y, x = np.mgrid[0:n, 0:n]; s = n // k; g = max(2, n // 128)
    inside = ((y % s) >= g) & ((x % s) >= g); nz = octaves(n, r, 4, 3); tone = r.uniform(0.92, 1.05, (k, k))[(y // s) % k, (x // s) % k]
    a = np.where(inside[..., None], (color if color is not None else hexrgb("#D8D4CC")) * (0.9 + 0.1 * nz[..., None]) * tone[..., None], hexrgb("#5D5B58"))
    return pack(np.clip(a, 0, 1), inside.astype(float) * 0.5, np.where(inside, 0.25, 0.9), np.zeros((n, n)), 2)


@reg
def t_metal_brushed(n, seed, color, scale, wear):
    r = rng_(seed); line = fnoise(n, r, 0.3)[:, :1] * np.ones((1, n)); fine = 0.5 * line + 0.5 * octaves(n, r, 2, 2); h = fine * 0.2
    base = color if color is not None else hexrgb("#B8BCC2"); a = np.clip(base * (0.85 + 0.25 * fine[..., None]), 0, 1)
    wr = octaves(n, r, 12, 3) * wear; return pack(a * (1 - 0.25 * wr[..., None]), h, 0.28 + 0.25 * fine + 0.3 * wr, np.ones((n, n)) * (1 - 0.3 * wr), 0.8)


@reg
def t_metal_plate(n, seed, color, scale, wear):
    r = rng_(seed); k = max(2, int(round(6 * scale))); y, x = np.mgrid[0:n, 0:n] / n
    def tri(u): return np.abs((u * k) % 1 - 0.5) * 2
    h = np.clip(1 - 3 * np.abs(tri(x + y) - tri(x - y)), 0, 1) * 0.5 + 0.2 * octaves(n, r, 8, 3)
    base = color if color is not None else hexrgb("#9EA3AA"); return pack(np.clip(base * (0.7 + 0.5 * h[..., None]), 0, 1), h, 0.35 + 0.2 * (1 - h), np.ones((n, n)) * 0.9, 4)


@reg
def t_rust(n, seed, color, scale, wear):
    r = rng_(seed); nz = octaves(n, r, 5, 5); m = np.clip((nz - 0.45) * 3, 0, 1); steel = hexrgb("#7A7D80"); ru = color if color is not None else hexrgb("#8A4A25")
    a = steel * (1 - m[..., None]) + ru * (0.7 + 0.5 * octaves(n, r, 16, 3)[..., None]) * m[..., None]; return pack(np.clip(a, 0, 1), nz * 0.6, 0.45 + 0.5 * m, 1 - m, 2.5)


@reg
def t_fabric(n, seed, color, scale, wear):
    r = rng_(seed); k = max(8, int(round(64 * scale))); y, x = np.mgrid[0:n, 0:n] / n
    w = 0.5 + 0.25 * np.sin(2 * np.pi * k * x) + 0.25 * np.sin(2 * np.pi * k * y); w = w * (0.85 + 0.3 * fnoise(n, r, 0.5)); h = w * 0.5
    return pack(np.clip((color if color is not None else hexrgb("#7A8CB0")) * (0.6 + 0.6 * w[..., None]), 0, 1), h, 0.95 * np.ones((n, n)), np.zeros((n, n)), 1.5)


@reg
def t_leather(n, seed, color, scale, wear):
    r = rng_(seed); d1, d2, idx = cells(n, r, max(40, int(300 * scale * scale))); crease = np.clip((d2 - d1) * n / 4, 0, 1); nz = octaves(n, r, 16, 3); h = 0.6 * crease + 0.4 * nz
    return pack(np.clip((color if color is not None else hexrgb("#5A3522")) * (0.6 + 0.6 * h[..., None]), 0, 1), h * 0.6, 0.5 + 0.3 * (1 - crease), np.zeros((n, n)), 2)


@reg
def t_concrete(n, seed, color, scale, wear):
    r = rng_(seed); nz = 0.6 * octaves(n, r, 6, 5) + 0.4 * fnoise(n, r, 0.8); pits = (fnoise(n, r, 0.2) > 0.97).astype(float)
    a = np.clip((color if color is not None else hexrgb("#9A9A96")) * (0.75 + 0.4 * nz[..., None]) * (1 - 0.4 * pits[..., None]), 0, 1); return pack(a, nz * 0.5 - pits * 0.3 + 0.3, 0.88 + 0.1 * nz, np.zeros((n, n)), 1.5)


@reg
def t_grass(n, seed, color, scale, wear):
    r = rng_(seed); nz = octaves(n, r, 6, 4); bl = fnoise(n, r, 0.4); a = np.clip((color if color is not None else hexrgb("#4E8A36")) * (0.55 + 0.7 * bl[..., None]) * (0.85 + 0.3 * nz[..., None]), 0, 1)
    return pack(a, bl, 0.9 * np.ones((n, n)), np.zeros((n, n)), 1.5)


@reg
def t_sand(n, seed, color, scale, wear):
    r = rng_(seed); g = fnoise(n, r, 0.2); ripple = 0.5 + 0.5 * np.sin(2 * np.pi * 8 * scale * (np.mgrid[0:n, 0:n][1] / n + 0.1 * octaves(n, r, 3, 3))); h = 0.5 * ripple + 0.5 * g
    return pack(np.clip((color if color is not None else hexrgb("#D9C48F")) * (0.8 + 0.3 * h[..., None]), 0, 1), h * 0.4, np.ones((n, n)), np.zeros((n, n)), 1.2)


@reg
def t_rubber(n, seed, color, scale, wear):
    r = rng_(seed); g = fnoise(n, r, 0.3); return pack(np.clip((color if color is not None else hexrgb("#2A2A2C")) * (0.85 + 0.3 * g[..., None]), 0, 1), g * 0.2, 0.8 + 0.15 * g, np.zeros((n, n)), 1)


@reg
def t_plastic(n, seed, color, scale, wear):
    r = rng_(seed); g = octaves(n, r, 3, 2); return pack(np.clip((color if color is not None else hexrgb("#C23B3B")) * (0.97 + 0.06 * g[..., None]), 0, 1), g * 0.05, 0.3 + 0.1 * g, np.zeros((n, n)), 0.5)


def to_img(a):
    a = np.asarray(a); a = a if a.ndim == 3 else np.repeat(a[..., None], 3, -1); return Image.fromarray((np.clip(a, 0, 1) * 255).astype(np.uint8))


def lit(maps, n=256):
    """Xem trước: tile 2×2 (kiểm seam) + cầu có đèn dùng albedo/normal/roughness/metalness."""
    A = maps["albedo"]; tile = np.tile(A, (2, 2, 1)); tile = np.array(Image.fromarray((tile * 255).astype(np.uint8)).resize((n * 2, n * 2))) / 255
    yy, xx = np.mgrid[0:n, 0:n]; u = (xx - n / 2) / (n / 2.1); v = (n / 2 - yy) / (n / 2.1); rr = u ** 2 + v ** 2; m = rr <= 1; z = np.sqrt(np.clip(1 - rr, 0, 1))
    N = np.stack([u, v, z], -1); T = np.array(Image.fromarray((maps["normal"] * 255).astype(np.uint8)).resize((n, n))) / 255 * 2 - 1
    N = N + 0.6 * np.stack([T[..., 0], T[..., 1], np.zeros((n, n))], -1); N /= np.linalg.norm(N, axis=-1, keepdims=True)
    Lg = np.array([-0.5, 0.6, 0.62]); Lg /= np.linalg.norm(Lg); d = np.clip(N @ Lg, 0, 1)[..., None]
    Ar = np.array(Image.fromarray((A * 255).astype(np.uint8)).resize((n, n))) / 255; ro = np.array(Image.fromarray((maps["roughness"] * 255).astype(np.uint8)).resize((n, n))) / 255; me = np.array(Image.fromarray((maps["metalness"] * 255).astype(np.uint8)).resize((n, n))) / 255
    H = Lg + np.array([0, 0, 1.0]); H /= np.linalg.norm(H); sh = 2 / np.clip(ro, 0.05, 1) ** 2; spec = (np.clip(N @ H, 0, 1) ** sh)[..., None] * (1 - ro[..., None]) * (0.3 + 0.7 * me[..., None])
    col = Ar * (1 - me[..., None] * 0.8) * (0.15 + 0.85 * d) + spec * (1 - 0.5 * me[..., None] * (1 - Ar)); sph = np.where(m[..., None], col, 0.12)
    out = np.zeros((n * 2, n * 3, 3)); out[:, :n * 2] = tile; out[:n, n * 2:] = sph; out[n:, n * 2:] = np.array(Image.fromarray((maps["normal"] * 255).astype(np.uint8)).resize((n, n))) / 255
    return to_img(out)


def make(kind, out, size=512, seed=1, color=None, scale=1.0, wear=0.3, name=None, preview=True):
    if kind not in KINDS: raise SystemExit(f"kiểu không có: {kind}. Có: {', '.join(KINDS)}")
    if size & (size - 1) or size > 1024: print("! Roblox khuyên 512/1024 (luỹ thừa của 2, ≤1024)")
    c = hexrgb(color) if isinstance(color, str) else color
    maps = KINDS[kind](size, seed, c, scale, wear); nm = name or kind; os.makedirs(out, exist_ok=True); paths = {}
    for k in ("albedo", "normal", "roughness", "metalness", "ao"):
        p = os.path.join(out, f"{nm}_{k}.png"); to_img(maps[k]).save(p); paths[k] = p
    if preview: p = os.path.join(out, f"{nm}_preview.png"); lit(maps).save(p); paths["preview"] = p
    return paths, maps


def seam_error(a):
    """Độ nhảy tại mép lặp (cột/hàng cuối → đầu) chia cho độ nhảy LỚN NHẤT giữa 2 cột/hàng kề nhau bên trong. ≤1 → liền mạch."""
    a = np.asarray(a, float); e = lambda x, y: np.abs(x - y).mean()
    ref = max(max(e(a[:, i], a[:, i + 1]) for i in range(a.shape[1] - 1)), max(e(a[i], a[i + 1]) for i in range(a.shape[0] - 1)), 1e-9)
    return max(e(a[:, -1], a[:, 0]), e(a[-1], a[0])) / ref


def selftest():
    bad = 0
    for k in KINDS:
        _, m = make(k, "/tmp/_tg", 128, 3, None, 1.0, 0.3, k, preview=True)
        s = seam_error(m["albedo"].mean(-1)); ok = s <= 1.05 and all(np.isfinite(m[x]).all() for x in m) and m["normal"].shape == (128, 128, 3)
        print(("PASS" if ok else "FAIL"), k, f"seam×{s:.2f}"); bad += not ok
    sys.exit(1 if bad else 0)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter); sp = ap.add_subparsers(dest="c")
    sp.add_parser("list"); sp.add_parser("selftest")
    m = sp.add_parser("make"); m.add_argument("kind"); m.add_argument("--out", required=True); m.add_argument("--size", type=int, default=512); m.add_argument("--seed", type=int, default=1)
    m.add_argument("--color"); m.add_argument("--scale", type=float, default=1.0); m.add_argument("--wear", type=float, default=0.3); m.add_argument("--name")
    a = ap.parse_args()
    if a.c == "list":
        for k in KINDS: print(f"{k:14s} → Enum.Material.{material_for(k)}")
    elif a.c == "make":
        p, _ = make(a.kind, a.out, a.size, a.seed, a.color, a.scale, a.wear, a.name)
        for k, v in p.items(): print(k, v)
    elif a.c == "selftest": selftest()
    else: ap.print_help()


if __name__ == "__main__":
    main()
