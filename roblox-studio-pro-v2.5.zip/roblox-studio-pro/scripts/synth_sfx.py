#!/usr/bin/env python3
"""Tổng hợp SFX game bằng toán (không cần thư viện âm thanh): laser, nổ, súng, bắn tỉa, khóa nòng, plasma, whoosh, UI...

    python scripts/synth_sfx.py --out sfx [--ogg] [--analyze] [--only laser_shot,explosion]

Ghi WAV 44.1 kHz 16-bit mono (và OGG nếu --ogg và có ffmpeg). Roblox nhận .mp3/.ogg: dùng --ogg khi upload.
Mỗi hiệu ứng có biến thể ngẫu nhiên theo --seed (đặt tên _v1.._vN bằng --variants N) để tránh nghe lặp.
--analyze in số đo: độ dài, RMS, đỉnh, tần số trọng tâm đầu/cuối, tỉ lệ năng lượng tần thấp — để kiểm "nghe có hợp lý" bằng số.
Upload: Creator Hub → Assets (cần xác minh danh tính, kiểm duyệt có thể mất vài phút), hoặc Studio Asset Manager → Bulk Import.
Giới hạn thật: đây là âm thanh tổng hợp "trung tính, dùng được", không thay mẫu thu thật; muốn chân thực hơn → ghép với asset Toolbox qua SoundKit (lớp layer).
"""
import argparse
import os
import subprocess
import sys
import wave
import zlib

import numpy as np
from scipy.signal import butter, sosfilt, fftconvolve

SR = 44100


def t_axis(dur): return np.arange(int(SR * dur)) / SR


def env_ad(n, attack, decay_exp):
    t = np.arange(n) / SR
    a = np.clip(t / max(attack, 1e-4), 0, 1)
    return a * np.exp(-t * decay_exp)


def lp(x, fc, order=2):
    return sosfilt(butter(order, min(fc, SR / 2 - 100), "low", fs=SR, output="sos"), x)


def hp(x, fc, order=2):
    return sosfilt(butter(order, fc, "high", fs=SR, output="sos"), x)


def bp(x, f1, f2, order=2):
    return sosfilt(butter(order, [f1, min(f2, SR / 2 - 100)], "band", fs=SR, output="sos"), x)


def sweep_lp(x, f_start, f_end, dur):
    """Lowpass có cutoff đổi theo thời gian: chia khối 256 mẫu, mỗi khối một bộ lọc (giữ trạng thái)."""
    out = np.zeros_like(x)
    zi = None
    block = 256
    n = len(x)
    for i in range(0, n, block):
        frac = min(1, (i / SR) / dur)
        fc = f_start * (f_end / f_start) ** frac
        sos = butter(2, max(30, min(fc, SR / 2 - 100)), "low", fs=SR, output="sos")
        seg = x[i:i + block]
        if zi is None or zi.shape != (sos.shape[0], 2):
            zi = np.zeros((sos.shape[0], 2))
        y, zi = sosfilt(sos, seg, zi=zi)
        out[i:i + block] = y
    return out


def chirp(dur, f0, f1, curve="exp"):
    t = t_axis(dur)
    if curve == "exp":
        k = (f1 / f0) ** (1 / dur)
        phase = 2 * np.pi * f0 * (k ** t - 1) / np.log(k)
    else:
        phase = 2 * np.pi * (f0 * t + (f1 - f0) * t ** 2 / (2 * dur))
    return np.sin(phase), phase


def reverb(x, rt60, wet, rng, predelay=0.0, damp=6000):
    n = int(SR * rt60)
    ir = rng.standard_normal(n) * np.exp(-6.9 * np.arange(n) / (SR * rt60))
    ir = lp(ir, damp)
    ir[: int(SR * 0.004)] *= np.linspace(0, 1, int(SR * 0.004))
    ir /= np.sqrt(np.sum(ir ** 2)) + 1e-9
    y = fftconvolve(x, ir)[: len(x) + n]
    if predelay:
        y = np.concatenate([np.zeros(int(SR * predelay)), y])
    out = np.zeros(max(len(x), len(y)))
    out[: len(x)] += x * (1 - wet)
    out[: len(y)] += y * wet * 1.8
    return out


def norm(x, peak=0.89):
    m = np.max(np.abs(x)) + 1e-9
    return x / m * peak


def fade(x, ms=4):
    n = int(SR * ms / 1000)
    x = x.copy()
    x[:n] *= np.linspace(0, 1, n)
    x[-n:] *= np.linspace(1, 0, n)
    return x


def mix(*layers):
    n = max(len(l[0]) + int(SR * l[1]) for l in layers)
    out = np.zeros(n)
    for sig, delay, gain in layers:
        i = int(SR * delay)
        out[i:i + len(sig)] += sig * gain
    return out


# ===== Hiệu ứng =====
def laser_shot(rng):
    j = rng.uniform(0.92, 1.1)
    dur = 0.38
    s, ph = chirp(dur, 2600 * j, 260 * j)
    body = s * env_ad(len(s), 0.002, 7)
    h2 = np.sin(2 * ph * 1.0) * 0.35 * env_ad(len(s), 0.002, 11)
    saw = (2 * ((ph / (2 * np.pi)) % 1) - 1) * 0.18 * env_ad(len(s), 0.002, 9)
    click = hp(rng.standard_normal(int(SR * 0.012)), 3000) * np.exp(-np.arange(int(SR * 0.012)) / (SR * 0.002))
    x = mix((body + h2 + saw, 0, 1.0), (click, 0, 0.5))
    return norm(fade(reverb(x, 0.35, 0.15, rng)))


def laser_beam_loop(rng):
    dur = 1.6
    t = t_axis(dur)
    wob = np.sin(2 * np.pi * 7 * t) * 14 + np.sin(2 * np.pi * 13 * t) * 5
    f = 190 + wob
    ph = 2 * np.pi * np.cumsum(f) / SR
    saw = 2 * ((ph / (2 * np.pi)) % 1) - 1
    core = lp(saw, 1800) * 0.5 + np.sin(ph * 0.5) * 0.4
    hiss = bp(rng.standard_normal(len(t)), 3000, 9000) * (0.07 + 0.05 * np.sin(2 * np.pi * 11 * t))
    sizz = np.sin(2 * np.pi * (1800 + 400 * np.sin(2 * np.pi * 3 * t)) * t) * 0.06
    x = core + hiss + sizz
    # vòng lặp liền: crossfade 80 ms cuối vào đầu
    xf = int(SR * 0.08)
    x[:xf] = x[:xf] * np.linspace(0, 1, xf) + x[-xf:] * np.linspace(1, 0, xf)
    return norm(x[:-xf])


def plasma_charge(rng):
    dur = 1.6
    t = t_axis(dur)
    f = 110 * (1200 / 110) ** (t / dur) ** 1.6
    ph = 2 * np.pi * np.cumsum(f) / SR
    trem = 0.6 + 0.4 * np.sin(2 * np.pi * (4 + 18 * (t / dur) ** 2) * t)
    x = (np.sin(ph) + 0.4 * np.sin(2 * ph)) * trem * (0.2 + 0.8 * (t / dur) ** 1.5)
    x += hp(rng.standard_normal(len(t)), 2500) * 0.05 * (t / dur) ** 2
    return norm(fade(x, 10))


def explosion(rng):
    j = rng.uniform(0.9, 1.1)
    dur = 3.2
    n = int(SR * dur)
    t = t_axis(dur)
    noise = rng.standard_normal(n)
    body = sweep_lp(noise, 5000 * j, 70, 1.4) * np.exp(-t * 1.5) * (1 - np.exp(-t / 0.004))
    crack = hp(noise, 1500) * np.exp(-t * 55) * 0.9
    f = 75 * np.exp(-t * 1.6) + 28
    thump = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 1.9) * 1.4
    # tiếng lách tách của mảnh vỡ rơi: xung ngẫu nhiên thưa, lọc dải
    imp = (rng.random(n) < (0.0015 * np.exp(-t * 0.9))).astype(float) * rng.standard_normal(n)
    debris = bp(imp, 1200, 6000) * 1.6 * (t > 0.25)
    x = body * 1.1 + crack + thump + debris * 0.5
    x = reverb(x, 1.6, 0.35, rng, damp=3500)
    x = np.tanh(x * 1.3)  # nén mềm: nổ "dày"
    return norm(fade(x, 8))


def gunshot_rifle(rng):
    dur = 1.1
    n = int(SR * dur)
    t = t_axis(dur)
    noise = rng.standard_normal(n)
    crack = hp(noise, 2000) * np.exp(-t * 320)
    body = sweep_lp(noise, 3500, 250, 0.18) * np.exp(-t * 22)
    thump = np.sin(2 * np.pi * np.cumsum(130 * np.exp(-t * 14) + 45) / SR) * np.exp(-t * 16)
    x = crack * 1.0 + body * 0.9 + thump * 0.8
    x = reverb(x, 0.9, 0.3, rng, damp=4500)
    return norm(fade(np.tanh(x * 1.4), 5))


def sniper_shot(rng):
    dur = 3.4
    n = int(SR * dur)
    t = t_axis(dur)
    noise = rng.standard_normal(n)
    crack = hp(noise, 1800) * np.exp(-t * 260) * 1.2
    body = sweep_lp(noise, 4000, 120, 0.4) * np.exp(-t * 9)
    thump = np.sin(2 * np.pi * np.cumsum(95 * np.exp(-t * 9) + 32) / SR) * np.exp(-t * 7) * 1.5
    x = crack + body * 0.9 + thump
    # vọng xa: bản sao trễ 0.32 s, mờ, thêm đuôi dài
    echo = lp(x, 1800) * 0.35
    x = mix((x, 0, 1.0), (echo, 0.32, 1.0), (lp(echo, 900), 0.61, 0.5))
    x = reverb(x, 2.4, 0.42, rng, damp=3000)
    return norm(fade(np.tanh(x * 1.2), 8))


def bolt_action(rng):
    def click(f, dur=0.03, gain=1.0):
        m = int(SR * dur)
        s = bp(rng.standard_normal(m), f * 0.7, f * 1.4) * np.exp(-np.arange(m) / (SR * dur * 0.25))
        return s * gain
    def slide(dur=0.22):
        m = int(SR * dur)
        s = bp(rng.standard_normal(m), 1500, 3800) * np.hanning(m) * 0.35
        return s * (1 + 0.5 * np.sin(2 * np.pi * 90 * np.arange(m) / SR))
    parts = [(click(2400, 0.04, 0.9), 0.00, 1), (slide(0.2), 0.08, 1), (click(1800, 0.05, 1.0), 0.32, 1),
             (click(3200, 0.03, 0.7), 0.55, 1), (slide(0.22), 0.62, 1), (click(1500, 0.06, 1.2), 0.9, 1), (click(2600, 0.04, 0.8), 1.02, 1)]
    x = mix(*parts)
    return norm(fade(reverb(x, 0.35, 0.18, rng)))


def impact_hit(rng):
    dur = 0.4
    n = int(SR * dur)
    t = t_axis(dur)
    thud = np.sin(2 * np.pi * np.cumsum(160 * np.exp(-t * 30) + 55) / SR) * np.exp(-t * 18)
    snap = bp(rng.standard_normal(n), 600, 4000) * np.exp(-t * 60)
    return norm(fade(thud * 1.2 + snap * 0.7))


def whoosh(rng):
    dur = 0.55
    n = int(SR * dur)
    t = t_axis(dur)
    noise = rng.standard_normal(n)
    out = np.zeros(n)
    block = 512
    for i in range(0, n, block):
        frac = (i / SR) / dur
        fc = 400 * (5000 / 400) ** np.sin(np.pi * frac)
        out[i:i + block] = bp(noise[i:i + block].copy(), max(100, fc * 0.6), fc * 1.5, 1)
    return norm(fade(out * np.sin(np.pi * t / dur) ** 1.5, 20))


def teleport(rng):
    dur = 0.9
    t = t_axis(dur)
    s1, _ = chirp(dur, 300, 3200, "lin")
    s2, _ = chirp(dur, 450, 4800, "lin")
    x = (s1 + 0.7 * s2) * np.sin(np.pi * t / dur) ** 0.7 + hp(rng.standard_normal(len(t)), 5000) * 0.05
    return norm(fade(reverb(x, 0.7, 0.3, rng)))


def ui_click(rng):
    t = t_axis(0.06)
    return norm(fade(np.sin(2 * np.pi * 1400 * t) * np.exp(-t * 90) + 0.4 * np.sin(2 * np.pi * 2800 * t) * np.exp(-t * 140), 1), 0.6)


def ui_ping(rng):
    t = t_axis(0.5)
    x = (np.sin(2 * np.pi * 880 * t) + 0.5 * np.sin(2 * np.pi * 1320 * t) + 0.25 * np.sin(2 * np.pi * 1760 * t)) * np.exp(-t * 7)
    return norm(fade(x, 2), 0.6)


EFFECTS = {
    "laser_shot": laser_shot, "laser_beam_loop": laser_beam_loop, "plasma_charge": plasma_charge, "explosion": explosion,
    "gunshot_rifle": gunshot_rifle, "sniper_shot": sniper_shot, "bolt_action": bolt_action, "impact_hit": impact_hit,
    "whoosh": whoosh, "teleport": teleport, "ui_click": ui_click, "ui_ping": ui_ping,
}


def centroid(x, sr=SR):
    if len(x) < 256: return 0.0
    spec = np.abs(np.fft.rfft(x * np.hanning(len(x))))
    freqs = np.fft.rfftfreq(len(x), 1 / sr)
    return float((spec * freqs).sum() / (spec.sum() + 1e-9))


def analyze(name, x):
    n = len(x)
    seg = int(SR * 0.12)
    c0 = centroid(x[:seg])
    c1 = centroid(x[max(0, n // 2 - seg // 2): n // 2 + seg // 2])
    first = x[: int(SR * 0.5)]
    spec = np.abs(np.fft.rfft(first)) ** 2
    fr = np.fft.rfftfreq(len(first), 1 / SR)
    low = float(spec[fr < 200].sum() / (spec.sum() + 1e-9))
    rms = float(np.sqrt(np.mean(x ** 2)))
    peak = float(np.max(np.abs(x)))
    clip = float(np.mean(np.abs(x) > 0.999))
    tail = float(np.sqrt(np.mean(x[-int(SR * 0.05):] ** 2)))
    return dict(name=name, dur=n / SR, rms=rms, peak=peak, clip=clip, c_start=c0, c_mid=c1, low200=low, tail_rms=tail)


def write_wav(path, x):
    pcm = (np.clip(x, -1, 1) * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="sfx")
    ap.add_argument("--seed", type=int, default=11)
    ap.add_argument("--variants", type=int, default=1)
    ap.add_argument("--only", default="")
    ap.add_argument("--ogg", action="store_true")
    ap.add_argument("--analyze", action="store_true")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    names = [n for n in a.only.split(",") if n] or list(EFFECTS)
    bad = [n for n in names if n not in EFFECTS]
    if bad: sys.exit("không có: " + ",".join(bad))
    for name in names:
        for v in range(1, a.variants + 1):
            rng = np.random.default_rng(a.seed * 1000 + v * 17 + zlib.crc32(name.encode()) % 997)
            x = EFFECTS[name](rng).astype(np.float64)
            fn = name if a.variants == 1 else f"{name}_v{v}"
            p = os.path.join(a.out, fn + ".wav")
            write_wav(p, x)
            line = f"[OK] {p} {len(x)/SR:.2f}s"
            if a.ogg:
                try:
                    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", p, "-c:a", "libvorbis", "-q:a", "5", p[:-4] + ".ogg"], check=True)
                    line += " +ogg"
                except Exception as e:
                    line += f" (ogg lỗi: {e})"
            print(line)
            if a.analyze:
                m = analyze(fn, x)
                print("     " + " ".join(f"{k}={v:.3f}" if isinstance(v, float) else f"{k}={v}" for k, v in m.items() if k != "name"))


if __name__ == "__main__":
    main()
