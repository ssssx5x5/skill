"""Sandbox xem model trong Blender: sàn lưới, người mẫu tham chiếu tỉ lệ, 3 kiểu ánh sáng, 6 góc chụp.

Chạy:
    blender -b model.blend --python sandbox_blender.py -- --collection MyModel --out D:/qa/MyModel --unit-height 5

Tạo collection "_QA_Sandbox" riêng (không lẫn vào model), render ảnh:
    <out>/<view>_<light>.png  với view = front, back, left, right, iso, iso_back, top, low
và một ảnh contact sheet nếu có Pillow. Xoá sandbox: chạy lại với --clean.
"""
import bpy
import sys
import os
import math
import argparse
from mathutils import Vector

SANDBOX = "_QA_Sandbox"


def parse_args():
    argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    p = argparse.ArgumentParser()
    p.add_argument("--collection", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--unit-height", type=float, default=5.0, help="Chiều cao người mẫu tham chiếu (Roblox: 5 studs)")
    p.add_argument("--size", type=int, default=768)
    p.add_argument("--lights", default="day,overcast,night")
    p.add_argument("--views", default="front,back,left,right,iso,iso_back,top,low")
    p.add_argument("--clean", action="store_true")
    p.add_argument("--engine", choices=["eevee", "cycles"], default="eevee",
                   help="cycles = CPU, dùng khi máy không có GPU hoặc EEVEE bị crash")
    return p.parse_args(argv)


def clean():
    coll = bpy.data.collections.get(SANDBOX)
    if coll:
        for o in list(coll.all_objects):
            bpy.data.objects.remove(o, do_unlink=True)
        bpy.data.collections.remove(coll)


def model_bounds(coll):
    pts = [o.matrix_world @ Vector(c) for o in coll.all_objects if o.type == "MESH" for c in o.bound_box]
    if not pts:
        raise SystemExit("Collection không có mesh")
    lo = Vector([min(p[i] for p in pts) for i in range(3)])
    hi = Vector([max(p[i] for p in pts) for i in range(3)])
    return lo, hi


def mat(name, rgb, rough=0.8):
    m = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    m.use_nodes = True
    bsdf = m.node_tree.nodes.get("Principled BSDF")
    bsdf.inputs["Base Color"].default_value = (*rgb, 1)
    bsdf.inputs["Roughness"].default_value = rough
    return m


def link(obj, coll):
    for c in obj.users_collection:
        c.objects.unlink(obj)
    coll.objects.link(obj)


def build(lo, hi, unit_h):
    coll = bpy.data.collections.new(SANDBOX)
    bpy.context.scene.collection.children.link(coll)
    span = max(hi.x - lo.x, hi.y - lo.y, unit_h) * 4
    # Sàn ở đáy model, có lưới 1 đơn vị để đọc kích thước
    bpy.ops.mesh.primitive_grid_add(x_subdivisions=int(span), y_subdivisions=int(span), size=span,
                                    location=((lo.x + hi.x) / 2, (lo.y + hi.y) / 2, lo.z - 0.001))
    floor = bpy.context.object
    floor.name = "QA_Floor"
    floor.data.materials.append(mat("QA_FloorMat", (0.45, 0.47, 0.5)))
    wire = floor.modifiers.new("Wire", "WIREFRAME")
    wire.thickness = 0.02
    wire.use_replace = False
    link(floor, coll)
    # Người mẫu tham chiếu đặt cạnh model, không chồng lên
    x = hi.x + max(1.0, unit_h * 0.4)
    bpy.ops.mesh.primitive_cylinder_add(radius=unit_h * 0.12, depth=unit_h * 0.8,
                                        location=(x, (lo.y + hi.y) / 2, lo.z + unit_h * 0.4))
    body = bpy.context.object
    bpy.ops.mesh.primitive_uv_sphere_add(radius=unit_h * 0.1,
                                         location=(x, (lo.y + hi.y) / 2, lo.z + unit_h * 0.9))
    head = bpy.context.object
    for o, n in ((body, "QA_RefBody"), (head, "QA_RefHead")):
        o.name = n
        o.data.materials.append(mat("QA_RefMat", (0.9, 0.55, 0.2)))
        link(o, coll)
    return coll


LIGHTS = {
    # tên: (năng lượng sun, góc nâng độ, màu sun, màu trời, cường độ trời)
    "day": (4.0, 55, (1.0, 0.96, 0.9), (0.55, 0.7, 1.0), 1.0),
    "overcast": (0.8, 80, (1.0, 1.0, 1.0), (0.8, 0.82, 0.85), 1.6),
    "night": (0.3, 30, (0.6, 0.7, 1.0), (0.05, 0.07, 0.15), 0.4),
}


def set_light(coll, key):
    energy, elev, sun_col, sky_col, sky_str = LIGHTS[key]
    sun = bpy.data.objects.get("QA_Sun")
    if sun is None:
        sun = bpy.data.objects.new("QA_Sun", bpy.data.lights.new("QA_Sun", "SUN"))
        coll.objects.link(sun)
    sun.data.energy = energy
    sun.data.color = sun_col
    sun.rotation_euler = (math.radians(90 - elev), 0, math.radians(35))
    world = bpy.context.scene.world or bpy.data.worlds.new("QA_World")
    bpy.context.scene.world = world
    world.use_nodes = True
    bg = world.node_tree.nodes.get("Background")
    bg.inputs["Color"].default_value = (*sky_col, 1)
    bg.inputs["Strength"].default_value = sky_str


VIEWS = {
    # tên: (yaw độ, pitch độ); yaw 0 = nhìn từ phía trước (-Y)
    "front": (0, 5), "back": (180, 5), "left": (-90, 5), "right": (90, 5),
    "iso": (35, 30), "iso_back": (215, 30), "top": (0, 89), "low": (30, -8),
}


def place_camera(coll, lo, hi, view):
    cam = bpy.data.objects.get("QA_Cam")
    if cam is None:
        cam = bpy.data.objects.new("QA_Cam", bpy.data.cameras.new("QA_Cam"))
        coll.objects.link(cam)
    cam.data.lens = 50
    bpy.context.scene.camera = cam
    yaw, pitch = (math.radians(a) for a in VIEWS[view])
    center = (lo + hi) / 2
    radius = (hi - lo).length / 2
    # Khoảng cách để cả bounding sphere nằm trong khung (FOV dọc ~ sensor 36mm, lens 50)
    fov = 2 * math.atan(18 / cam.data.lens)
    dist = radius / math.sin(fov / 2) * 1.1
    direction = Vector((math.sin(yaw) * math.cos(pitch), -math.cos(yaw) * math.cos(pitch), math.sin(pitch)))
    cam.location = center + direction * dist
    cam.rotation_euler = (-direction).to_track_quat("-Z", "Y").to_euler()
    cam.data.clip_end = dist * 10


def render(path, size, engine):
    sc = bpy.context.scene
    if engine == "cycles":
        # Dùng được trên máy/server không có GPU (EEVEE, Workbench cần OpenGL/GPU)
        sc.render.engine = "CYCLES"
        sc.cycles.device = "CPU"
        sc.cycles.samples = 32
    else:
        engines = [e.identifier for e in bpy.types.RenderSettings.bl_rna.properties["engine"].enum_items]
        sc.render.engine = "BLENDER_EEVEE_NEXT" if "BLENDER_EEVEE_NEXT" in engines else "BLENDER_EEVEE"
    sc.render.resolution_x = sc.render.resolution_y = size
    sc.render.film_transparent = False
    sc.render.filepath = path
    bpy.ops.render.render(write_still=True)


def contact_sheet(paths, out_path, cols=4):
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        print("Không có Pillow, bỏ qua contact sheet")
        return
    ims = [Image.open(p) for p in paths]
    w, h = ims[0].size
    rows = math.ceil(len(ims) / cols)
    sheet = Image.new("RGB", (w * cols, h * rows), (20, 20, 24))
    draw = ImageDraw.Draw(sheet)
    for i, (im, p) in enumerate(zip(ims, paths)):
        x, y = (i % cols) * w, (i // cols) * h
        sheet.paste(im.convert("RGB"), (x, y))
        draw.text((x + 8, y + 8), os.path.splitext(os.path.basename(p))[0], fill=(255, 255, 0))
    sheet.save(out_path)
    print("Contact sheet:", out_path)


def main():
    args = parse_args()
    clean()
    if args.clean:
        print("Đã xoá sandbox")
        return
    coll = bpy.data.collections.get(args.collection)
    if coll is None:
        raise SystemExit(f"Không tìm thấy collection '{args.collection}'")
    os.makedirs(args.out, exist_ok=True)
    lo, hi = model_bounds(coll)
    sandbox = build(lo, hi, args.unit_height)
    # Khung camera bao cả model và người mẫu tham chiếu để so tỉ lệ
    ref_pts = [o.matrix_world @ Vector(c) for o in sandbox.objects if o.name.startswith("QA_Ref") for c in o.bound_box]
    pts = ref_pts + [lo, hi]
    flo = Vector([min(p[i] for p in pts) for i in range(3)])
    fhi = Vector([max(p[i] for p in pts) for i in range(3)])
    paths = []
    for light in args.lights.split(","):
        set_light(sandbox, light)
        for view in args.views.split(","):
            p = os.path.join(args.out, f"{view}_{light}.png")
            place_camera(sandbox, flo, fhi, view)
            render(p, args.size, args.engine)
            paths.append(p)
    contact_sheet(paths, os.path.join(args.out, "_contact_sheet.png"))
    print(f"Model size: {[round(hi[i] - lo[i], 3) for i in range(3)]}; người mẫu cao {args.unit_height}")


if __name__ == "__main__":
    main()
