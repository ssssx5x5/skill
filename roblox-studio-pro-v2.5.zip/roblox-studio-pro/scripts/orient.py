#!/usr/bin/env python3
"""Dịch cụm từ mô tả hướng / góc xoay / hành động (Việt + Anh) thành vector & CFrame.Angles theo quy ước Roblox.

    python scripts/orient.py dir "ra phía trước và hơi chếch lên"      -> vector đơn vị
    python scripts/orient.py rot "xoay 90 độ quanh trục dọc sang phải"  -> ma trận + CFrame.Angles
    python scripts/orient.py look "mũi dao chỉ xuống" --up 0,0,-1       -> khung nhìn
    python scripts/orient.py selftest

Quy ước (Roblox): trước = −Z, phải = +X, lên = +Y. CFrame.Angles(rx,ry,rz)=Rx·Ry·Rz, góc dương theo quy tắc bàn tay phải.
Ngoài ra "phải/trái/trước/sau" nói về CHÍNH VẬT (khung vật), không phải người nhìn — dùng --frame world để ép khung thế giới.
Script không đoán khi mơ hồ: trả về cảnh báo để người dùng/AI hỏi lại.
"""
import math
import re
import sys
import unicodedata

import numpy as np

AXIS = {
    "forward": (0, 0, -1), "back": (0, 0, 1), "right": (1, 0, 0), "left": (-1, 0, 0), "up": (0, 1, 0), "down": (0, -1, 0),
}
WORDS = {
    "forward": ["phia truoc", "ra truoc", "truoc", "forward", "front", "ahead", "huong ve phia truoc"],
    "back": ["phia sau", "ra sau", "lui ve sau", "sau", "backward", "back", "behind", "rear"],
    "right": ["ben phai", "sang phai", "phai", "right"],
    "left": ["ben trai", "sang trai", "trai", "left"],
    "up": ["len tren", "huong len", "len", "tren", "tro len", "up", "upward", "above", "top"],
    "down": ["xuong duoi", "huong xuong", "xuong", "duoi", "down", "downward", "below", "bottom"],
}
HEDGE = ["hoi", "chech", "nghieng", "slightly", "a bit", "somewhat", "tilted"]  # → pha 30° (có thể chỉnh)


def norm(s):
    s = unicodedata.normalize("NFD", s.lower().replace("đ", "d"))
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    return re.sub(r"\s+", " ", s).strip()


def unit(v):
    v = np.array(v, float); n = np.linalg.norm(v)
    if n < 1e-12: raise ValueError("vector 0")
    return v / n


def parse_dir(text, hedge_deg=30.0):
    """Trả (vector, warnings). Hỗ trợ: 'trước', 'lên', 'trước và hơi lên' (pha trộn), 'chéo 45 độ lên'."""
    t = " " + norm(text) + " "
    warns = []
    found = []
    used = t
    for key in ("forward", "back", "right", "left", "up", "down"):
        for w in sorted(WORDS[key], key=len, reverse=True):
            pat = r"(?<![a-z])" + re.escape(w) + r"(?![a-z])"
            m = re.search(pat, used)
            if m:
                found.append((m.start(), key)); used = used[:m.start()] + " " * (m.end() - m.start()) + used[m.end():]
                break
    if not found:
        return None, ["không nhận ra hướng nào — hỏi lại"]
    found.sort()
    keys = [k for _, k in found]
    # đối nghịch trong cùng cụm = mâu thuẫn
    for a, b in (("up", "down"), ("left", "right"), ("forward", "back")):
        if a in keys and b in keys: return None, [f"mâu thuẫn: {a} và {b} cùng xuất hiện — hỏi lại"]
    vec = np.zeros(3)
    m = re.search(r"(\d+(?:[.,]\d+)?)\s*(?:do|deg|°)", t)
    if len(keys) == 1:
        vec = np.array(AXIS[keys[0]], float)
    else:
        # hướng đầu = chính (trọng số 1); hướng sau = phụ (hedge hoặc số độ)
        main = np.array(AXIS[keys[0]], float)
        sec = np.zeros(3)
        for k in keys[1:]: sec += np.array(AXIS[k], float)
        ang = float(m.group(1).replace(",", ".")) if m else None
        is_hedge = any(h in t for h in HEDGE)
        if ang is None: ang = hedge_deg if is_hedge else 45.0
        if not m and not is_hedge: warns.append("hai hướng không nói mức — giả định chéo 45°")
        vec = math.cos(math.radians(ang)) * main + math.sin(math.radians(ang)) * unit(sec)
    return unit(vec), warns


def Rx(a): c, s = math.cos(a), math.sin(a); return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])
def Ry(a): c, s = math.cos(a), math.sin(a); return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])
def Rz(a): c, s = math.cos(a), math.sin(a); return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])


def angles(rx, ry, rz):  # = CFrame.Angles (độ → rad)
    return Rx(math.radians(rx)) @ Ry(math.radians(ry)) @ Rz(math.radians(rz))


def axis_angle(axis, deg):
    a = unit(axis); t = math.radians(deg); K = np.array([[0, -a[2], a[1]], [a[2], 0, -a[0]], [-a[1], a[0], 0]])
    return np.eye(3) + math.sin(t) * K + (1 - math.cos(t)) * (K @ K)


def euler_xyz(R):
    """Ma trận → (rx,ry,rz) độ theo CFrame.ToEulerAnglesXYZ (R = Rx·Ry·Rz)."""
    sy = R[0, 2]; ry = math.asin(max(-1, min(1, sy)))
    if abs(sy) < 0.999999:
        rx = math.atan2(-R[1, 2], R[2, 2]); rz = math.atan2(-R[0, 1], R[0, 0])
    else:
        rx = math.atan2(R[2, 1], R[1, 1]); rz = 0.0
    return tuple(math.degrees(v) for v in (rx, ry, rz))


def look_rotation(dir_vec, up_hint=(0, 1, 0), forward_axis=(0, 0, -1)):
    """Ma trận xoay đưa trục `forward_axis` của vật trùng `dir_vec`, giữ `up_hint` gần nhất."""
    f = unit(dir_vec); u = unit(up_hint)
    if abs(float(f @ u)) > 0.999: u = np.array([0, 0, 1.0]) if abs(f[2]) < 0.9 else np.array([1.0, 0, 0])
    r = unit(np.cross(f, u)); u2 = np.cross(r, f)
    # cột: right, up, back (=−forward) của khung đích
    tgt = np.column_stack([r, u2, -f])
    fa = unit(forward_axis)
    # khung vật: forward_axis → −Z (back = −forward_axis)
    src_back = -fa
    src_up = np.array([0, 1.0, 0]) if abs(fa[1]) < 0.9 else np.array([0, 0, 1.0])
    src_r = unit(np.cross(fa, src_up)); src_up = np.cross(src_r, fa)
    src = np.column_stack([src_r, src_up, src_back])
    return tgt @ src.T


def parse_rot(text):
    """'xoay 90 độ quanh trục dọc sang phải' → (R, mô tả, warnings). Trục: dọc/Y, ngang/X (nghiêng), Z (lật nghiêng sang bên)."""
    t = norm(text); warns = []
    m = re.search(r"(-?\d+(?:[.,]\d+)?)\s*(?:do|deg|°)?", t)
    if not m: return None, "", ["không có số độ — hỏi lại"]
    deg = float(m.group(1).replace(",", "."))
    sign = 1.0
    if re.search(r"\b(nguoc chieu kim dong ho|ccw|counter)", t): sign = 1.0
    if re.search(r"\b(chieu kim dong ho|cw|clockwise)\b", t) and not re.search(r"nguoc|counter|ccw", t): sign = -1.0
    if re.search(r"\b(nghieng sang phai|roll right|lat phai)\b", t): axis, sign, why = (0, 0, 1), -1.0, "nghiêng phải = roll −Z"
    elif re.search(r"\b(nghieng sang trai|roll left|lat trai)\b", t): axis, sign, why = (0, 0, 1), 1.0, "nghiêng trái = roll +Z"
    elif re.search(r"\b(ngua len|ngang len|pitch up|nhin len|ngua mat)\b", t): axis, sign, why = (1, 0, 0), 1.0, "ngửa lên = pitch +X"
    elif re.search(r"\b(cui xuong|chui xuong|pitch down|nhin xuong|gat xuong)\b", t): axis, sign, why = (1, 0, 0), -1.0, "cúi xuống = pitch −X"
    elif re.search(r"\b(sang phai|turn right|yaw right)\b", t): axis, sign, why = (0, 1, 0), -1.0, "quay phải = yaw −Y"
    elif re.search(r"\b(sang trai|turn left|yaw left)\b", t): axis, sign, why = (0, 1, 0), 1.0, "quay trái = yaw +Y"
    elif re.search(r"\b(truc doc|truc y|y axis|vertical|quanh y)\b", t): axis, why = (0, 1, 0), "trục Y"
    elif re.search(r"\b(truc x|quanh x|x axis)\b", t): axis, why = (1, 0, 0), "trục X"
    elif re.search(r"\b(truc z|quanh z|z axis|truc truoc sau)\b", t): axis, why = (0, 0, 1), "trục Z"
    else: return None, "", ["không rõ trục xoay — hỏi lại (dọc Y / ngang X / trước-sau Z)"]
    if re.search(r"\b(chieu kim dong ho|clockwise|cw)\b", t) and not re.search(r"nguoc|counter|ccw", t): sign = -1.0
    if re.search(r"(nguoc chieu kim dong ho|counter|ccw)", t): sign = 1.0
    warns.append("chiều dương = ngược chiều kim đồng hồ khi nhìn từ đỉnh trục về gốc (quy tắc bàn tay phải); kim đồng hồ = âm")
    return axis_angle(axis, sign * deg), f"{why}, {sign*deg:+g}°", warns


def fmt(v): return "(" + ", ".join(f"{x:+.4f}" for x in v) + ")"


def selftest():
    ok = True
    def chk(name, cond):
        nonlocal ok
        print(("PASS " if cond else "FAIL ") + name); ok &= bool(cond)
    def near(a, b, e=1e-6): return np.allclose(a, b, atol=e)
    v, _ = parse_dir("ra phía trước"); chk("trước = −Z", near(v, (0, 0, -1)))
    v, _ = parse_dir("hướng xuống"); chk("xuống = −Y", near(v, (0, -1, 0)))
    v, _ = parse_dir("sang phải"); chk("phải = +X", near(v, (1, 0, 0)))
    v, w = parse_dir("trước và hơi lên"); chk("trước+hơi lên: 30° trên ngang", near(v, (0, math.sin(math.radians(30)), -math.cos(math.radians(30)))))
    v, w = parse_dir("chéo 45 độ lên và ra trước"); chk("lên rồi trước 45°", near(v, (0, math.cos(math.pi/4), -math.sin(math.pi/4))))
    v, w = parse_dir("forward and down"); chk("EN forward+down có cảnh báo mức", len(w) == 1)
    v, w = parse_dir("lên và xuống"); chk("mâu thuẫn → None + báo", v is None and any("mâu thuẫn" in x for x in w))
    v, w = parse_dir("blah"); chk("vô nghĩa → None", v is None)
    R, d, _ = parse_rot("xoay 90 độ sang phải")
    chk("quay phải 90°: trước(−Z) → +X", near(R @ np.array([0, 0, -1.0]), (1, 0, 0)))
    R, d, _ = parse_rot("xoay 90 độ sang trái")
    chk("quay trái 90°: trước → −X", near(R @ np.array([0, 0, -1.0]), (-1, 0, 0)))
    R, d, _ = parse_rot("ngửa lên 90 độ")
    chk("ngửa lên 90°: trước(−Z) → +Y", near(R @ np.array([0, 0, -1.0]), (0, 1, 0)))
    R, d, _ = parse_rot("cúi xuống 90 độ")
    chk("cúi xuống 90°: trước → −Y", near(R @ np.array([0, 0, -1.0]), (0, -1, 0)))
    R, d, _ = parse_rot("nghiêng sang phải 90 độ")
    chk("nghiêng phải 90°: lên(+Y) → +X", near(R @ np.array([0, 1.0, 0]), (1, 0, 0)))
    R, d, _ = parse_rot("xoay 90 độ quanh trục y theo chiều kim đồng hồ")
    chk("CW quanh Y 90° (nhìn từ trên): trước → +X", near(R @ np.array([0, 0, -1.0]), (1, 0, 0)))
    R, d, _ = parse_rot("xoay 30 độ"); chk("thiếu trục → None", R is None)
    R = angles(20, 35, -50); e = euler_xyz(R); chk("Euler khứ hồi", near(e, (20, 35, -50), 1e-6))
    chk("Angles(0,90,0) trước→+X... = Ry(90): −Z→−X", near(angles(0, 90, 0) @ np.array([0, 0, -1.0]), (-1, 0, 0)))
    for tgt in [(0, 0, -1), (1, 0, 0), (0, -1, 0), (0.3, 0.5, -0.8), (0, 1, 0)]:
        R = look_rotation(tgt); chk(f"look_rotation → −Z trùng {tgt}", near(R @ np.array([0, 0, -1.0]), unit(tgt)))
    # vật có mũi dọc +Y (dao, tail→head), muốn mũi chỉ xuống
    R = look_rotation((0, -1, 0), forward_axis=(0, 1, 0)); chk("mũi +Y chỉ xuống", near(R @ np.array([0, 1.0, 0]), (0, -1, 0)))
    R = look_rotation((0, 0, -1), forward_axis=(0, 1, 0)); chk("mũi +Y chỉ ra trước", near(R @ np.array([0, 1.0, 0]), (0, 0, -1)))
    R = look_rotation((0.2, 0.3, -0.9), forward_axis=(0, 1, 0)); chk("R trực chuẩn, det=+1", near(R @ R.T, np.eye(3)) and abs(np.linalg.det(R) - 1) < 1e-9)
    print("ALL PASS" if ok else "CÓ LỖI")
    return 0 if ok else 1


def main(argv):
    if not argv or argv[0] == "selftest": return selftest()
    cmd, text = argv[0], argv[1] if len(argv) > 1 else ""
    if cmd == "dir":
        v, w = parse_dir(text)
        print("vector:", fmt(v) if v is not None else None, "| Vector3.new(%.4f, %.4f, %.4f)" % tuple(v) if v is not None else "")
        for x in w: print("!", x)
    elif cmd == "rot":
        R, d, w = parse_rot(text)
        if R is None: print("!", *w); return 1
        e = euler_xyz(R); print(d); print("CFrame.Angles(math.rad(%.3f), math.rad(%.3f), math.rad(%.3f))" % e)
        for x in w: print("!", x)
    elif cmd == "look":
        v, w = parse_dir(text)
        if v is None: print("!", *w); return 1
        up = (0, 1, 0)
        if "--up" in argv: up = tuple(float(x) for x in argv[argv.index("--up") + 1].split(","))
        fa = (0, 1, 0) if "--tip-y" in argv else (0, 0, -1)
        R = look_rotation(v, up, fa); e = euler_xyz(R)
        print("dir", fmt(v)); print("CFrame.Angles(math.rad(%.3f), math.rad(%.3f), math.rad(%.3f))" % e)
        for x in w: print("!", x)
    else: print(__doc__); return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
