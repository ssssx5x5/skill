#!/usr/bin/env python3
"""Sinh texture VFX trong suốt (PNG RGBA) bằng toán — để upload làm Texture cho ParticleEmitter/Beam/Decal.

    python scripts/gen_vfx_textures.py --out vfx_tex [--size 256] [--seed 7]

Tạo: glow, smoke_puff, spark, ring, slash, streak, shockwave, smoke_flipbook (4x4), fire_flipbook (4x4).
Cần numpy + Pillow. Roblox không cho upload từ script: upload thủ công qua Asset Manager (Bulk Import)
rồi dán rbxassetid vào Config / VFX.Emitter(... , { Texture = "rbxassetid://..." }).
Flipbook: ParticleEmitter.FlipbookLayout = Grid4x4, FlipbookMode = OneShot/Loop.
Màu: texture để TRẮNG/xám + alpha; tô màu bằng Color của emitter (đổi màu theo thời gian miễn phí).
"""
import argparse
import os

import numpy as np
from PIL import Image


def grid(n):
    y, x = np.mgrid[0:n, 0:n].astype(np.float32)
    return (x + 0.5) / n * 2 - 1, (y + 0.5) / n * 2 - 1  # [-1, 1]


def value_noise(n, rng, octaves=5):
    out = np.zeros((n, n), np.float32)
    amp, tot = 1.0, 0.0
    for o in range(octaves):
        c = 2 ** (o + 2)
        base = rng.random((c + 1, c + 1)).astype(np.float32)
        base[-1, :], base[:, -1] = base[0, :], base[:, 0]  # tile được
        img = Image.fromarray((base * 255).astype(np.uint8)).resize((n, n), Image.BICUBIC)
        out += np.asarray(img, np.float32) / 255 * amp
        tot += amp
        amp *= 0.5
    return out / tot


def rgba(gray, alpha):
    g = np.clip(gray, 0, 1)
    a = np.clip(alpha, 0, 1)
    arr = np.stack([g, g, g, a], -1)
    return Image.fromarray((arr * 255).astype(np.uint8), "RGBA")


def glow(n, rng):
    x, y = grid(n)
    r = np.sqrt(x * x + y * y)
    a = np.clip(1 - r, 0, 1) ** 2.2
    return rgba(np.ones_like(a), a)


def smoke_puff(n, rng, t=0.0):
    x, y = grid(n)
    r = np.sqrt(x * x + y * y)
    nz = value_noise(n, rng)
    edge = np.clip(1 - r / (0.9 - 0.25 * (nz - 0.5)), 0, 1) ** 1.5
    shade = 0.55 + 0.45 * nz
    return rgba(shade, edge * (0.9 - 0.4 * t))


def spark(n, rng):
    x, y = grid(n)
    core = np.exp(-((x / 0.08) ** 2 + (y / 0.9) ** 2)) + np.exp(-((x / 0.9) ** 2 + (y / 0.08) ** 2))
    return rgba(np.ones_like(core), core)


def ring(n, rng):
    x, y = grid(n)
    r = np.sqrt(x * x + y * y)
    a = np.exp(-((r - 0.78) / 0.06) ** 2)
    return rgba(np.ones_like(a), a)


def shockwave(n, rng):
    x, y = grid(n)
    r = np.sqrt(x * x + y * y)
    a = np.clip((r - 0.45) / 0.45, 0, 1) * np.clip((1 - r) / 0.08, 0, 1)
    a *= 0.6 + 0.4 * value_noise(n, rng)
    return rgba(np.ones_like(a), a ** 1.6)


def slash(n, rng):
    """Vệt chém cong dạng lưỡi liềm: cung tròn, dày ở giữa, thon dần hai đầu (taper theo góc, không cắt cứng)."""
    x, y = grid(n)
    cx = -0.55                       # tâm cung nằm lệch trái → cung lồi sang phải
    r = np.sqrt((x - cx) ** 2 + y ** 2)
    ang = np.arctan2(y, x - cx)      # 0 = hướng phải
    span = 0.95                      # nửa góc mở của cung (rad)
    t = np.clip(1 - np.abs(ang) / span, 0, 1)      # 1 ở giữa cung, 0 ở hai đầu
    width = 0.02 + 0.16 * t ** 0.8                 # dày ở giữa
    a = np.clip(1 - np.abs(r - 1.2) / width, 0, 1) * (t > 0)
    return rgba(np.ones_like(a), a ** 0.9)


def streak(n, rng):
    x, y = grid(n)
    a = np.exp(-((y / 0.09) ** 2)) * np.clip(1 - np.abs(x) ** 2.5, 0, 1)
    return rgba(np.ones_like(a), a)


def flipbook(n, rng, frames, fn):
    cell = n // 4
    sheet = Image.new("RGBA", (n, n), (0, 0, 0, 0))
    for i in range(frames):
        sheet.paste(fn(cell, i / (frames - 1)), ((i % 4) * cell, (i // 4) * cell))
    return sheet


def fire_frame(cell, t, seed=3):
    """Ngọn lửa: rộng ở đáy, thon lên trên, lắc theo nhiễu; y=+1 là đáy ảnh."""
    rng = np.random.default_rng(seed + int(t * 100))
    x, y = grid(cell)
    nz = value_noise(cell, rng)
    h = (1 - y) / 2                                  # 0 ở đáy → 1 ở đỉnh
    width = 0.85 * (1 - h) ** 0.7 + 0.05
    sway = (nz - 0.5) * 0.9 * h * (0.6 + t)
    d = np.abs(x - sway) / width
    body = np.clip(1 - d, 0, 1) ** 1.2
    body *= np.clip(1.05 - h * (0.85 + 0.25 * t), 0, 1) ** 0.8
    body *= np.clip(h * 12, 0, 1)                    # mép đáy mềm
    body *= 0.75 + 0.25 * nz
    heat = np.clip(body * 1.5, 0, 1)
    return rgba(heat, body)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="vfx_tex")
    ap.add_argument("--size", type=int, default=256)
    ap.add_argument("--seed", type=int, default=7)
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    rng = np.random.default_rng(a.seed)
    n = a.size
    items = {
        "glow": glow(n, rng), "smoke_puff": smoke_puff(n, rng), "spark": spark(n, rng),
        "ring": ring(n, rng), "shockwave": shockwave(n, rng), "slash": slash(n, rng), "streak": streak(n, rng),
        "smoke_flipbook": flipbook(n * 2, rng, 16, lambda c, t: smoke_puff(c, np.random.default_rng(a.seed + int(t * 50)), t)),
        "fire_flipbook": flipbook(n * 2, rng, 16, fire_frame),
    }
    for k, im in items.items():
        p = os.path.join(a.out, k + ".png")
        im.save(p)
        arr = np.asarray(im)
        print(f"[OK] {p} {im.size} alpha_max={arr[...,3].max()} alpha_mean={arr[...,3].mean():.1f}")
    print("Upload bằng Asset Manager → Bulk Import; flipbook: FlipbookLayout=Grid4x4.")


if __name__ == "__main__":
    main()
