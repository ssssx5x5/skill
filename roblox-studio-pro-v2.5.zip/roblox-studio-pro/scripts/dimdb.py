#!/usr/bin/env python3
"""Cơ sở dữ liệu kích thước thật (cm) → stud, để KHÔNG đoán tỉ lệ. Dữ liệu: references/dimensions.json (60+ họ vật thể, gần đúng).

    python scripts/dimdb.py list [--cat furniture]
    python scripts/dimdb.py plan <họ> [--style realistic] [--stud-cm 35]     # BẢNG KÍCH THƯỚC bắt buộc lập TRƯỚC khi dựng
    python scripts/dimdb.py check <họ> --h 2.6 --length 1.3 --width 1.2 [--feature seat_height=1.3 ...]   # đơn vị stud
Trong code:  import dimdb; d = dimdb.plan_studs("<họ>")  → {'features': {'<tên>': typ_stud}, 'dims': {...}}
Họ không có trong DB: dimdb báo gần đúng nhất; tự tra kích thước thật (web) và GHI nguồn trong Dimension Table.
"""
import argparse
import json
import os
import sys
import unicodedata

HERE = os.path.dirname(os.path.abspath(__file__))
PATH = os.path.join(HERE, "..", "references", "dimensions.json")


def load():
    return json.load(open(PATH, encoding="utf-8"))


def _n(s):
    s = unicodedata.normalize("NFD", s.lower().strip()); return "".join(c for c in s if unicodedata.category(c) != "Mn").replace("đ", "d").replace(" ", "_")


def find(name, db=None):
    db = db or load(); k = _n(name)
    for f, v in db["families"].items():
        if k == _n(f) or k in [_n(a) for a in v["aliases"]]: return f
    cand = [f for f, v in db["families"].items() if k in _n(f) or _n(f) in k or any(k in _n(a) or _n(a) in k for a in v["aliases"])]
    return cand[0] if cand else None


def similar(name, db=None):
    db = db or load(); k = _n(name)
    return sorted(db["families"], key=lambda f: -len(set(k) & set(_n(f))))[:5]


def plan_studs(name, stud_cm=35.0):
    db = load(); f = find(name, db)
    if not f: raise KeyError(f"'{name}' không có trong DB; gần nhất: {similar(name, db)}")
    v = db["families"][f]; s = lambda r: [round(x / stud_cm, 3) for x in r]
    return {"family": f, "dims": {k: s(r) for k, r in v["dims_cm"].items()}, "features": {k: s(r) for k, r in v["features_cm"].items()},
            "ratios": v["ratios"], "stud_cm": stud_cm}


def factor(style, db=None):
    db = db or load(); return db["styles"].get(style, 1.0)


def judge(r_cm, got_cm, k):
    lo, typ, hi = r_cm
    return lo / k <= got_cm <= hi * k


def check(name, dims=None, features=None, style="realistic", stud_cm=35.0):
    """dims={'height','length','width'} và features={tên: giá trị} đều bằng STUD. Trả [(mục, giá trị cm, khoảng cm, 'OK'|'FAIL'|'NOTE')]."""
    db = load(); f = find(name, db)
    if not f: return None, [("family", None, None, "NOTE: họ không có trong DB — tự cung cấp kích thước thật + nguồn")]
    v = db["families"][f]; k = factor(style, db); out = []
    for key, val in (dims or {}).items():
        if key in v["dims_cm"]:
            c = val * stud_cm; r = v["dims_cm"][key]; out.append((key, round(c, 1), r, "OK" if judge(r, c, k) else "FAIL"))
    for key, val in (features or {}).items():
        if key in v["features_cm"]:
            c = val * stud_cm; r = v["features_cm"][key]; out.append((key, round(c, 1), r, "OK" if judge(r, c, k) else "FAIL"))
        elif key not in v["dims_cm"]: out.append((key, round(val * stud_cm, 1), None, "NOTE: tên feature không có trong DB"))
    allv = {**{a: (b or 0) * stud_cm for a, b in (dims or {}).items()}, **{a: b * stud_cm for a, b in (features or {}).items()}}
    for rt in v["ratios"]:
        a, b = rt["a"], rt["b"]
        if a in allv and b in allv and allv[b] > 0:
            q = allv[a] / allv[b]; lo, hi = rt["range"]
            out.append((f"{a}/{b}", round(q, 2), [lo, hi], "OK" if lo / k <= q <= hi * k else "FAIL: " + rt["why"]))
    return f, out


def table(name, style="realistic", stud_cm=35.0):
    p = plan_studs(name, stud_cm); L = [f"Dimension Table — {p['family']} (1 stud = {stud_cm:g} cm, style={style}, hệ số nới ×{factor(style):g})", "| mục | cm [min–typ–max] | stud [min–typ–max] |", "|---|---|---|"]
    db = load(); v = db["families"][p["family"]]
    for grp, src in (("dims_cm", "dims"), ("features_cm", "features")):
        for k_, r in v[grp].items():
            s = p[src][k_]; L.append(f"| {k_} | {r[0]:g}–{r[1]:g}–{r[2]:g} | {s[0]:g}–{s[1]:g}–{s[2]:g} |")
    for rt in p["ratios"]: L.append(f"| tỉ lệ {rt['a']}/{rt['b']} | {rt['range'][0]}–{rt['range'][1]} | {rt['why']} |")
    return "\n".join(L)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter); sp = ap.add_subparsers(dest="c")
    l = sp.add_parser("list"); l.add_argument("--cat")
    p = sp.add_parser("plan"); p.add_argument("family"); p.add_argument("--style", default="realistic"); p.add_argument("--stud-cm", type=float, default=35)
    c = sp.add_parser("check"); c.add_argument("family"); c.add_argument("--h", type=float); c.add_argument("--length", type=float); c.add_argument("--width", type=float)
    c.add_argument("--feature", action="append", default=[]); c.add_argument("--style", default="realistic"); c.add_argument("--stud-cm", type=float, default=35)
    a = ap.parse_args()
    if a.c == "list":
        db = load()
        for f, v in db["families"].items():
            if not a.cat or v["category"] == a.cat: print(f"{f:16s} {v['category']:12s} {', '.join(v['aliases'][:3])}")
    elif a.c == "plan":
        try: print(table(a.family, a.style, a.stud_cm))
        except KeyError as e: sys.exit(str(e))
    elif a.c == "check":
        d = {k: v for k, v in (("height", a.h), ("length", a.length), ("width", a.width)) if v is not None}
        ft = {x.split("=")[0]: float(x.split("=")[1]) for x in a.feature}
        f, rows = check(a.family, d, ft, a.style, a.stud_cm)
        for r in rows: print(r)
        sys.exit(1 if any(str(r[3]).startswith("FAIL") for r in rows) else 0)
    else: ap.print_help()


if __name__ == "__main__":
    main()
