#!/usr/bin/env python3
"""
wiring_check.py - bắt lỗi "im lặng" (wiring) trong code Luau mà compiler không bắt được.

Compiler/luau-analyze chỉ biết cú pháp và kiểu. Nó KHÔNG biết:
  - key trong bảng Config/SFX được gọi ở chỗ khác nhưng không tồn tại (gõ sai, đổi tên),
  - key được định nghĩa nhưng không có handler nào dùng (config chết),
  - hai danh sách phải khớp nhau (danh sách joint vs bảng driver) nhưng lệch tên.

Cách dùng:
  python wiring_check.py <file-hoặc-thư-mục> [...] [tùy chọn]

  --table NAME          Kiểm tra mọi NAME.Key / NAME["Key"] có tồn tại trong bảng NAME;
                        và báo key định nghĩa mà không ai dùng.
  --bind NAME=FUNC[:N]  Đối số chuỗi thứ N (mặc định 1) của lời gọi FUNC("Key") là key của bảng NAME.
                        Ví dụ: --bind SFX=playSfx   hoặc   --bind SFX=Sfx.play:1
  --compare A B         Hai bảng/danh sách phải có cùng tập key. Báo phần lệch hai chiều.
  --markers             Liệt kê tên marker animation được lắng nghe (để đối chiếu với Animation Editor).

Mã thoát: 1 nếu có ERROR, 0 nếu không. Luôn in dòng tổng kết, vắng dòng đó nghĩa là script chưa chạy xong.

Giới hạn (nói thẳng): đây là phân tích văn bản, không phải trình phân tích Luau đầy đủ.
Nó bắt tốt kiểu viết thường gặp (bảng literal, NAME.Key, NAME["Key"], FUNC("Key")).
Key tạo động (NAME[variable]) không kiểm tra được; hãy dùng validator lúc chạy (references/verification.md).
"""

import argparse
import os
import re
import sys

QUOTES = "\"'`"


# ----------------------------------------------------------------------------
# Đọc và làm sạch nguồn
# ----------------------------------------------------------------------------
def read_sources(paths):
    files = []
    for p in paths:
        if os.path.isdir(p):
            for root, _, names in os.walk(p):
                for n in sorted(names):
                    if n.endswith((".lua", ".luau")):
                        files.append(os.path.join(root, n))
        elif os.path.isfile(p):
            files.append(p)
    out = {}
    for f in sorted(files):
        with open(f, encoding="utf-8", errors="replace") as fh:
            out[f] = fh.read()
    return out


def blank(text):
    """Thay mọi ký tự bằng khoảng trắng nhưng giữ xuống dòng (để số dòng không lệch)."""
    return re.sub(r"[^\n]", " ", text)


def strip_comments(src):
    """Xóa comment, giữ nguyên chuỗi và số dòng."""
    out = []
    i, n = 0, len(src)
    while i < n:
        c = src[i]
        if c == "-" and src.startswith("--", i):
            m = re.match(r"--\[(=*)\[", src[i:])
            if m:
                close = "]" + m.group(1) + "]"
                j = src.find(close, i + len(m.group(0)))
                j = n if j == -1 else j + len(close)
            else:
                j = src.find("\n", i)
                j = n if j == -1 else j
            out.append(blank(src[i:j]))
            i = j
        elif c in QUOTES:
            j = i + 1
            while j < n and src[j] != c and src[j] != "\n":
                if src[j] == "\\":
                    j += 1
                j += 1
            out.append(src[i : j + 1])
            i = j + 1
        elif c == "[":
            m = re.match(r"\[(=*)\[", src[i : i + 12])
            if m:
                close = "]" + m.group(1) + "]"
                j = src.find(close, i + len(m.group(0)))
                j = n if j == -1 else j + len(close)
                out.append(src[i:j])
                i = j
            else:
                out.append(c)
                i += 1
        else:
            out.append(c)
            i += 1
    return "".join(out)


def skip_string(src, i):
    """src[i] là dấu mở chuỗi; trả về chỉ số ngay sau dấu đóng."""
    c = src[i]
    j = i + 1
    n = len(src)
    while j < n and src[j] != c and src[j] != "\n":
        if src[j] == "\\":
            j += 1
        j += 1
    return j + 1


def match_brace(src, start):
    """src[start] == '{'. Trả về chỉ số của '}' tương ứng, hoặc -1."""
    depth = 0
    i, n = start, len(src)
    while i < n:
        c = src[i]
        if c in QUOTES:
            i = skip_string(src, i)
            continue
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                return i
        i += 1
    return -1


def split_top(src, lo, hi):
    """Tách phần giữa src[lo:hi] thành các mục cấp 1. Trả về [(offset, text)]."""
    items = []
    depth = 0
    cur_start = lo
    i = lo
    while i < hi:
        c = src[i]
        if c in QUOTES:
            i = skip_string(src, i)
            continue
        if c in "{([":
            depth += 1
        elif c in "})]":
            depth -= 1
        elif c in ",;" and depth == 0:
            items.append((cur_start, src[cur_start:i]))
            cur_start = i + 1
        i += 1
    if src[cur_start:hi].strip():
        items.append((cur_start, src[cur_start:hi]))
    return items


def line_of(src, offset):
    return src.count("\n", 0, offset) + 1


# ----------------------------------------------------------------------------
# Trích key của một bảng
# ----------------------------------------------------------------------------
def table_def_regex(name):
    return re.compile(
        r"(?<![\w.])(?:local\s+)?(?:\w+\.)*"
        + re.escape(name)
        + r"\s*(?::[^=\n]+)?=(?!=)\s*\{"
    )


ENTRY_PATTERNS = [
    re.compile(r"^\s*\[\s*[\"']([^\"']+)[\"']\s*\]\s*=(?!=)"),  # ["Key"] = v
    re.compile(r"^\s*([A-Za-z_]\w*)\s*=(?!=)"),  # Key = v
    re.compile(r"^\s*[\"']([^\"']+)[\"']\s*$"),  # "Key" (danh sách chuỗi)
]


def collect_definitions(sources, name):
    """Trả về {key: (file, line)} cho bảng `name` (gộp mọi nơi định nghĩa)."""
    defs = {}
    found_any = False
    rx = table_def_regex(name)
    for f, src in sources.items():
        for m in rx.finditer(src):
            found_any = True
            open_idx = m.end() - 1
            close_idx = match_brace(src, open_idx)
            if close_idx == -1:
                continue
            for off, text in split_top(src, open_idx + 1, close_idx):
                for pat in ENTRY_PATTERNS:
                    km = pat.match(text)
                    if km:
                        defs.setdefault(km.group(1), (f, line_of(src, off + len(text) - len(text.lstrip()))))
                        break
        # gán rời: NAME.Key = v  /  NAME["Key"] = v
        for m in re.finditer(r"(?<![\w.])" + re.escape(name) + r"\.([A-Za-z_]\w*)\s*=(?!=)", src):
            found_any = True
            defs.setdefault(m.group(1), (f, line_of(src, m.start())))
        for m in re.finditer(
            r"(?<![\w.])" + re.escape(name) + r"\[\s*[\"']([^\"']+)[\"']\s*\]\s*=(?!=)", src
        ):
            found_any = True
            defs.setdefault(m.group(1), (f, line_of(src, m.start())))
    return defs, found_any


def collect_uses(sources, name, binds):
    """Trả về {key: (file, line)} cho các nơi dùng bảng `name` (đọc + bind)."""
    uses = {}
    for f, src in sources.items():
        for m in re.finditer(
            r"(?<![\w.])" + re.escape(name) + r"\.([A-Za-z_]\w*)(?!\s*=(?!=))", src
        ):
            uses.setdefault(m.group(1), (f, line_of(src, m.start())))
        for m in re.finditer(
            r"(?<![\w.])" + re.escape(name) + r"\[\s*[\"']([^\"']+)[\"']\s*\](?!\s*=(?!=))", src
        ):
            uses.setdefault(m.group(1), (f, line_of(src, m.start())))
        for func, argn in binds:
            rx = re.compile(
                r"(?<!\w)"
                + re.escape(func)
                + r"\s*\(\s*(?:[^,()]*,){%d}\s*[\"']([^\"']+)[\"']" % (argn - 1)
            )
            for m in rx.finditer(src):
                uses.setdefault(m.group(1), (f, line_of(src, m.start())))
    return uses


def iterates_whole(sources, name):
    rx = re.compile(
        r"\b(?:pairs|ipairs|next)\s*\(\s*(?:\w+\.)*" + re.escape(name) + r"\s*\)|\bin\s+" + re.escape(name) + r"\s+do"
    )
    return any(rx.search(src) for src in sources.values())


# ----------------------------------------------------------------------------
# Báo cáo
# ----------------------------------------------------------------------------
class Report:
    def __init__(self):
        self.errors = 0
        self.warns = 0
        self.checks = 0

    def error(self, where, msg):
        self.errors += 1
        loc = "%s:%d" % where if where else "-"
        print("[ERROR] %s  %s" % (loc, msg))

    def warn(self, where, msg):
        self.warns += 1
        loc = "%s:%d" % where if where else "-"
        print("[WARN ] %s  %s" % (loc, msg))


def suggest(key, candidates):
    """Gợi ý key gần giống (bắt lỗi gõ sai)."""
    import difflib

    close = difflib.get_close_matches(key, list(candidates), n=1, cutoff=0.6)
    return " (ý bạn là '%s'?)" % close[0] if close else ""


def check_table(sources, name, binds, rep):
    defs, found = collect_definitions(sources, name)
    if not found:
        rep.error(None, "Không tìm thấy định nghĩa của bảng '%s' (sai tên hoặc nằm ngoài các file đã quét)." % name)
        return defs
    uses = collect_uses(sources, name, binds)
    rep.checks += 1
    errors_before = rep.errors
    for key, where in sorted(uses.items()):
        if key not in defs:
            rep.error(where, "'%s' được dùng nhưng bảng %s không có key này%s" % (key, name, suggest(key, defs)))
    if iterates_whole(sources, name):
        print("[INFO ] %s được duyệt toàn bộ (pairs/ipairs) nên không báo key thừa." % name)
    else:
        for key, where in sorted(defs.items()):
            if key not in uses:
                rep.warn(where, "'%s' có trong %s nhưng không có handler/chỗ nào dùng (config chết?)%s" % (key, name, suggest(key, uses)))
    label = "[ OK  ]" if rep.errors == errors_before else "[FAIL ]"
    print("%s %s: %d key định nghĩa, %d key được dùng." % (label, name, len(defs), len(uses)))
    return defs


def check_compare(sources, a, b, rep):
    da, fa = collect_definitions(sources, a)
    db, fb = collect_definitions(sources, b)
    if not fa:
        rep.error(None, "Không tìm thấy bảng/danh sách '%s'." % a)
        return
    if not fb:
        rep.error(None, "Không tìm thấy bảng/danh sách '%s'." % b)
        return
    rep.checks += 1
    errors_before = rep.errors
    for key in sorted(set(da) - set(db)):
        rep.error(da[key], "'%s' có trong %s nhưng KHÔNG có trong %s%s" % (key, a, b, suggest(key, db)))
    for key in sorted(set(db) - set(da)):
        rep.error(db[key], "'%s' có trong %s nhưng KHÔNG có trong %s%s" % (key, b, a, suggest(key, da)))
    label = "[ OK  ]" if rep.errors == errors_before else "[FAIL ]"
    print("%s so khớp %s (%d) với %s (%d)." % (label, a, len(da), b, len(db)))


def list_markers(sources):
    seen = {}
    for f, src in sources.items():
        for m in re.finditer(r"GetMarkerReachedSignal\s*\(\s*[\"']([^\"']+)[\"']", src):
            seen.setdefault(m.group(1), (f, line_of(src, m.start())))
    if not seen:
        print("[INFO ] Không thấy GetMarkerReachedSignal nào.")
        return
    print("[INFO ] Marker đang được lắng nghe (hãy đối chiếu với Animation Editor, sai chữ hoa/thường là không bắn):")
    for k, (f, ln) in sorted(seen.items()):
        print("        - %s  (%s:%d)" % (k, f, ln))


def main():
    ap = argparse.ArgumentParser(description="Kiểm tra wiring tĩnh cho code Luau.")
    ap.add_argument("paths", nargs="+", help="file .lua/.luau hoặc thư mục")
    ap.add_argument("--table", action="append", default=[], metavar="NAME")
    ap.add_argument("--bind", action="append", default=[], metavar="NAME=FUNC[:N]")
    ap.add_argument("--compare", action="append", default=[], nargs=2, metavar=("A", "B"))
    ap.add_argument("--markers", action="store_true")
    args = ap.parse_args()

    raw = read_sources(args.paths)
    if not raw:
        print("[ERROR] Không tìm thấy file .lua/.luau nào trong: %s" % ", ".join(args.paths))
        return 1
    sources = {f: strip_comments(s) for f, s in raw.items()}
    print("[INFO ] Đã quét %d file." % len(sources))

    binds_by_table = {}
    for b in args.bind:
        if "=" not in b:
            print("[ERROR] --bind cần dạng NAME=FUNC[:N], nhận được: %s" % b)
            return 1
        name, rest = b.split("=", 1)
        func, _, n = rest.partition(":")
        binds_by_table.setdefault(name, []).append((func, int(n) if n else 1))

    tables = list(dict.fromkeys(args.table + list(binds_by_table)))
    rep = Report()
    for name in tables:
        check_table(sources, name, binds_by_table.get(name, []), rep)
    for a, b in args.compare:
        check_compare(sources, a, b, rep)
    if args.markers:
        list_markers(sources)

    if not tables and not args.compare and not args.markers:
        print("[WARN ] Chưa chọn kiểm tra nào (--table / --bind / --compare / --markers).")

    print("[DONE ] %d kiểm tra, %d lỗi, %d cảnh báo." % (rep.checks, rep.errors, rep.warns))
    return 1 if rep.errors else 0


if __name__ == "__main__":
    sys.exit(main())
