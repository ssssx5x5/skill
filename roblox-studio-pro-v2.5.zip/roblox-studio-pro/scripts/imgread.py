#!/usr/bin/env python3
"""Đọc ảnh tham chiếu bằng SỐ cho AI viết code (model/VFX/UI): tách đối tượng, bảng màu, lưới pixel, bản đồ ASCII, quét đếm chi tiết, so render với ảnh mẫu.

    python scripts/imgread.py sheet  ref.png OUT_DIR            # bảng thiết kế nhiều góc → ảnh đánh số + crop từng đối tượng + OCR nhãn
    python scripts/imgread.py palette crop.png [--k 10]          # bảng màu (hex, % diện tích, tâm) + dòng Lua Color3.fromRGB
    python scripts/imgread.py measure crop.png [--cell N]        # hộp bao chủ thể, tỉ lệ, đối xứng, vị trí từng màu (0..1)
    python scripts/imgread.py grid   crop.png OUT.png            # tìm kích thước ô pixel-art, hạ về độ phân giải gốc
    python scripts/imgread.py ascii  crop.png [--k 10] [--cell N]# bản đồ chữ cái theo ô: đọc layout voxel chính xác
    python scripts/imgread.py scan   crop.png x0,y0 x1,y1 [--k 10]# quét dọc 1 đường: đoạn màu liên tiếp (ĐẾM vòng/sọc/nòng)
    python scripts/imgread.py overlay crop.png OUT.png [--n 10] [--bbox x0,y0,x1,y1] [--zoom 3]  # lưới có nhãn toạ độ để đọc vị trí
    python scripts/imgread.py compare ref.png render.png OUT.png # so render với ảnh mẫu: IoU, tỉ lệ, màu, vùng lệch
    python scripts/imgread.py selftest

Nguyên tắc: ảnh do AI vẽ (bảng thiết kế) KHÔNG nhất quán hình học giữa các góc; coi góc rõ nhất làm gốc, các góc khác là gợi ý.
Mọi số đo ở đây là ĐIỂM ẢNH hoặc tỉ lệ 0..1 trong hộp bao chủ thể — không phải studs; đổi sang studs bằng một kích thước đã biết.
"""
import argparse
import json
import math
import os
import shutil
import subprocess
import sys
import tempfile

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont


def load(path):
    return np.array(Image.open(path).convert("RGB"))


def estimate_bg(img):
    h, w = img.shape[:2]
    b = max(2, int(0.01 * min(h, w)))
    border = np.concatenate([img[:b].reshape(-1, 3), img[-b:].reshape(-1, 3), img[:, :b].reshape(-1, 3), img[:, -b:].reshape(-1, 3)])
    q = (border // 16).astype(int)
    keys, counts = np.unique(q, axis=0, return_counts=True)
    top = keys[counts.argmax()]
    sel = border[(q == top).all(1)]
    return np.median(sel, 0)


def fg_mask(img, bg=None, thr=26):
    bg = estimate_bg(img) if bg is None else np.array(bg, float)
    d = np.sqrt(((img.astype(float) - bg) ** 2).sum(2))
    return d > thr, bg


def subject_mask(img, bg=None, thr=26, keep=0.10):
    """Mặt nạ chủ thể: bỏ chữ nhãn / nét khung rời (thành phần nhỏ < keep × thành phần lớn nhất)."""
    mask, bg = fg_mask(img, bg, thr)
    h, w = mask.shape
    m8 = cv2.morphologyEx((mask * 255).astype(np.uint8), cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    k = max(3, int(0.02 * min(h, w)))
    dil = cv2.dilate(m8, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k)))
    n, lab, stats, _ = cv2.connectedComponentsWithStats(dil)
    if n <= 2:
        return mask, bg
    real = [int(((lab == i) & (m8 > 0)).sum()) for i in range(1, n)]
    big = max(real)
    keepmask = np.zeros_like(mask)
    for i, r in enumerate(real, 1):
        if r >= keep * big:
            keepmask |= (lab == i)
    return mask & keepmask, bg


def subject_bbox(mask):
    ys, xs = np.where(mask)
    if len(xs) == 0:
        return None
    return int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1


def font(sz):
    for f in ("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "DejaVuSans.ttf", "arial.ttf"):
        try:
            return ImageFont.truetype(f, sz)
        except OSError:
            pass
    return ImageFont.load_default()


def hexc(c):
    return "#%02x%02x%02x" % tuple(int(round(v)) for v in c)


def kmeans_palette(img, mask, k=10, seed=1):
    px = img[mask].reshape(-1, 3).astype(np.float32)
    if len(px) == 0:
        return [], np.zeros(len(img))
    if len(px) > 60000:
        rng = np.random.default_rng(seed)
        px_s = px[rng.choice(len(px), 60000, replace=False)]
    else:
        px_s = px
    lab = cv2.cvtColor(px_s.reshape(-1, 1, 3).astype(np.uint8), cv2.COLOR_RGB2LAB).reshape(-1, 3).astype(np.float32)
    k = min(k, len(np.unique(px_s, axis=0)))
    cv2.setRNGSeed(seed)
    _, labels, centers = cv2.kmeans(lab, k, None, (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 40, 0.5), 3, cv2.KMEANS_PP_CENTERS)
    # gộp màu gần nhau (ΔE<9) để tránh cùng màu tách đôi theo bóng
    cent = centers.copy()
    cnt = np.bincount(labels.ravel(), minlength=k).astype(float)
    order = np.argsort(-cnt)
    merged = []
    for i in order:
        for m in merged:
            if np.linalg.norm(cent[i] - m["lab"]) < 9:
                m["w"] += cnt[i]; break
        else:
            merged.append({"lab": cent[i], "w": cnt[i]})
    labs = np.array([m["lab"] for m in merged], np.float32)
    rgb = cv2.cvtColor(labs.reshape(-1, 1, 3).astype(np.uint8), cv2.COLOR_LAB2RGB).reshape(-1, 3)
    return [(rgb[i], merged[i]["w"] / cnt.sum()) for i in range(len(merged))], labs


def assign_palette(img, labs, bgmask=None):
    lab = cv2.cvtColor(img, cv2.COLOR_RGB2LAB).astype(np.float32)
    d = np.linalg.norm(lab[:, :, None, :] - labs[None, None, :, :], axis=3)
    return d.argmin(2), d.min(2)


# ---------------------------------------------------------------- sheet
def ocr_words(img):
    if not shutil.which("tesseract"):
        return []
    g = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
    g = cv2.resize(g, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)
    if g.mean() < 128:
        g = 255 - g
    with tempfile.TemporaryDirectory() as td:
        p = os.path.join(td, "o.png")
        cv2.imwrite(p, g)
        r = subprocess.run(["tesseract", p, "stdout", "--psm", "11", "tsv"], capture_output=True, text=True)
    words = []
    for line in r.stdout.splitlines()[1:]:
        c = line.split("\t")
        if len(c) >= 12 and c[11].strip() and float(c[10]) > 35 and len(c[11].strip()) >= 2:
            x, y, w, h = [int(v) / 2 for v in c[6:10]]
            words.append({"text": c[11].strip(), "box": [x, y, x + w, y + h], "conf": float(c[10])})
    return words


def cmd_sheet(a):
    img = load(a.image)
    H, W = img.shape[:2]
    mask, bg = fg_mask(img, thr=a.thr)
    m8 = (mask * 255).astype(np.uint8)
    m8 = cv2.morphologyEx(m8, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))   # bỏ nét mảnh (khung, chữ gạch chân)
    k = max(5, int(a.gap * min(H, W)))
    dil = cv2.dilate(m8, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k)))
    n, lab, stats, _ = cv2.connectedComponentsWithStats(dil)
    objs = []
    for i in range(1, n):
        x, y, w, h, area = stats[i]
        real = int(((lab == i) & (m8 > 0)).sum())
        if real < a.min_area * H * W:
            continue
        objs.append({"box": [int(x), int(y), int(x + w), int(y + h)], "px": real})
    objs.sort(key=lambda o: (round(o["box"][1] / (0.12 * H)), o["box"][0]))
    words = ocr_words(img)
    os.makedirs(a.out, exist_ok=True)
    ov = Image.fromarray(img.copy())
    d = ImageDraw.Draw(ov)
    rows = []
    for i, o in enumerate(objs):
        x0, y0, x1, y1 = o["box"]
        pad = int(0.01 * min(H, W))
        cx0, cy0, cx1, cy1 = max(0, x0 - pad), max(0, y0 - pad), min(W, x1 + pad), min(H, y1 + pad)
        crop = Image.fromarray(img[cy0:cy1, cx0:cx1])
        zoom = max(1, int(round(400 / max(crop.size))))
        if zoom > 1:
            crop = crop.resize((crop.width * zoom, crop.height * zoom), Image.NEAREST)
        fn = os.path.join(a.out, f"obj_{i:02d}.png")
        crop.save(fn)
        # nhãn gần nhất (đoán): từ có khoảng cách hộp–hộp nhỏ nhất
        best, bd = None, 1e9
        for wd in words:
            bx0, by0, bx1, by1 = wd["box"]
            dx = max(bx0 - x1, x0 - bx1, 0); dy = max(by0 - y1, y0 - by1, 0)
            dist = math.hypot(dx, dy)
            if dist < bd:
                bd, best = dist, wd["text"]
        near = best if best and bd < 0.06 * max(H, W) else ""
        o["label_guess"] = near
        rows.append((i, o["box"], o["px"], near, fn))
        d.rectangle([x0, y0, x1, y1], outline=(255, 70, 70), width=3)
        d.rectangle([x0, y0, x0 + 30, y0 + 22], fill=(255, 70, 70))
        d.text((x0 + 5, y0 + 3), str(i), fill=(255, 255, 255), font=font(16))
    ov.save(os.path.join(a.out, "overview.png"))
    json.dump({"size": [W, H], "bg": [float(v) for v in bg], "objects": objs, "ocr": words}, open(os.path.join(a.out, "sheet.json"), "w"), ensure_ascii=False, indent=1)
    print(f"Ảnh {W}×{H}, nền ≈ {hexc(bg)}, tìm thấy {len(objs)} đối tượng, {len(words)} từ OCR")
    for i, box, px, near, fn in rows:
        w, h = box[2] - box[0], box[3] - box[1]
        print(f"  #{i:02d} hộp {box} ({w}×{h}, tỉ lệ {w/max(h,1):.2f})  nhãn gần nhất (đoán): {near or '—'}  → {fn}")
    print(f"Xem {os.path.join(a.out, 'overview.png')} để biết số nào là góc nào; nhãn OCR chỉ là gợi ý.")


# ---------------------------------------------------------------- palette / measure
def cmd_palette(a):
    img = load(a.image)
    mask, bg = subject_mask(img, thr=a.thr)
    pal, labs = kmeans_palette(img, mask, a.k)
    idx, dist = assign_palette(img, labs)
    box = subject_bbox(mask)
    print(f"Nền ≈ {hexc(bg)}; chủ thể {box}; {len(pal)} màu:")
    lua = []
    for i, (rgb, share) in enumerate(pal):
        m = mask & (idx == i)
        ys, xs = np.where(m)
        if len(xs) == 0:
            continue
        bw, bh = box[2] - box[0], box[3] - box[1]
        cx, cy = (xs.mean() - box[0]) / bw, (ys.mean() - box[1]) / bh
        print(f"  {chr(65+i)}  {hexc(rgb)}  {share*100:5.1f}%  tâm=({cx:.2f},{cy:.2f})  Color3.fromRGB({int(rgb[0])}, {int(rgb[1])}, {int(rgb[2])})")
        lua.append(f"Color3.fromRGB({int(rgb[0])}, {int(rgb[1])}, {int(rgb[2])})")
    print("local PALETTE = { " + ", ".join(lua) + " }")


def symmetry(mask, box):
    x0, y0, x1, y1 = box
    m = mask[y0:y1, x0:x1]
    lr = (m & m[:, ::-1]).sum() / max((m | m[:, ::-1]).sum(), 1)
    ud = (m & m[::-1]).sum() / max((m | m[::-1]).sum(), 1)
    return float(lr), float(ud)


def cmd_measure(a):
    img = load(a.image)
    mask, bg = subject_mask(img, thr=a.thr)
    box = subject_bbox(mask)
    if not box:
        sys.exit("không thấy chủ thể (nền quá gần màu chủ thể?)")
    x0, y0, x1, y1 = box
    w, h = x1 - x0, y1 - y0
    lr, ud = symmetry(mask, box)
    print(f"Chủ thể: hộp ({x0},{y0})–({x1},{y1}), {w}×{h} điểm ảnh, tỉ lệ rộng/cao = {w/h:.3f}; chiếm {mask[y0:y1, x0:x1].mean()*100:.0f}% hộp")
    print(f"Đối xứng trái-phải {lr:.2f}, trên-dưới {ud:.2f} (1 = giống hệt; <0.7 = không đối xứng)")
    print("Trục dài:", "ngang" if w > 1.15 * h else ("dọc" if h > 1.15 * w else "gần vuông"))
    if a.cell:
        print(f"Với ô {a.cell}px: {w/a.cell:.1f} × {h/a.cell:.1f} ô")
    if a.known:
        k, v = a.known.split("=")
        axis = {"w": w, "h": h}[k]
        print(f"Quy đổi: 1 điểm ảnh = {float(v)/axis:.5f} (theo {k}={v}); chiều còn lại ≈ {float(v)/axis*(h if k=='w' else w):.3f}")
    # chiều dày theo lát cắt dọc trục dài: giúp thấy chỗ phình/thót
    long_h = w >= h
    n = 12
    print("Bề dày theo lát cắt dọc trục dài (0..1 ⇒ tỉ lệ so với dày nhất):")
    prof = []
    for i in range(n):
        if long_h:
            xs = x0 + int((i + 0.5) * w / n); col = mask[y0:y1, xs]; prof.append(int(col.sum()))
        else:
            ys = y0 + int((i + 0.5) * h / n); row = mask[ys, x0:x1]; prof.append(int(row.sum()))
    mx = max(prof) or 1
    print("  " + " ".join(f"{p/mx:.2f}" for p in prof))


# ---------------------------------------------------------------- lưới pixel-art
def detect_cell(gray):
    def period(prof):
        p = prof - prof.mean()
        ac = np.correlate(p, p, "full")[len(p) - 1:]
        ac /= ac[0] + 1e-9
        best, bl = 0, None
        lo, hi = 3, max(4, len(p) // 6)
        for lag in range(lo, hi):
            if ac[lag] > ac[lag - 1] and ac[lag] >= ac[lag + 1] and ac[lag] > best:
                best, bl = ac[lag], lag
        if bl is None:
            return None, 0.0
        # tìm chu kỳ cơ bản: nhỏ nhất có tương quan ≥ 70% đỉnh
        for lag in range(lo, bl):
            if ac[lag] > ac[lag - 1] and ac[lag] >= ac[lag + 1] and ac[lag] >= 0.7 * best:
                return lag, float(ac[lag])
        return bl, float(best)
    gx = np.abs(np.diff(gray.astype(float), axis=1)).sum(0)
    gy = np.abs(np.diff(gray.astype(float), axis=0)).sum(1)
    return period(gx), period(gy), gx, gy


def phase(prof, cell):
    best, bo = -1, 0
    for o in range(cell):
        s = prof[o::cell].sum()
        if s > best:
            best, bo = s, o
    return bo + 1  # diff lệch nửa ô


def native_pixels(img, cx, cy, ox, oy, mask=None):
    H, W = img.shape[:2]
    xs = list(range(ox % cx, W - cx + 1, cx)); ys = list(range(oy % cy, H - cy + 1, cy))
    out = np.zeros((len(ys), len(xs), 3), np.uint8)
    for j, y in enumerate(ys):
        for i, x in enumerate(xs):
            cell = img[y + cy // 4: y + cy - cy // 4 or y + cy, x + cx // 4: x + cx - cx // 4 or x + cx].reshape(-1, 3)
            out[j, i] = np.median(cell, 0)
    return out


def cmd_grid(a):
    img = load(a.image)
    gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
    (cx, sx), (cy, sy), gx, gy = detect_cell(gray)
    print(f"Ô pixel ước lượng: {cx}×{cy} điểm ảnh (độ tin cậy ngang {sx:.2f}, dọc {sy:.2f}; ≥0.5 là đáng tin)")
    if not cx or not cy or min(sx, sy) < 0.5:
        print("[CẢNH BÁO] không thấy lưới đều (độ tin cậy < 0.5) — ảnh KHÔNG phải pixel-art thật (hoặc do AI vẽ giả pixel, ô không đều/blur). Đừng ép lưới; đo bằng palette/measure/scan/ascii --cols.")
        return
    cx = cy = int(round((cx + cy) / 2)) if abs(cx - cy) <= 1 else cx
    ox, oy = phase(gx, cx), phase(gy, cy)
    nat = native_pixels(img, cx, cy, ox, oy)
    Image.fromarray(nat).resize((nat.shape[1] * 8, nat.shape[0] * 8), Image.NEAREST).save(a.out)
    print(f"Lưới gốc ≈ {nat.shape[1]} × {nat.shape[0]} ô (lệch pha {ox},{oy}); ảnh phóng 8× → {a.out}")


def cmd_ascii(a):
    img = load(a.image)
    mask, bg = subject_mask(img, thr=a.thr)
    box = subject_bbox(mask)
    img = img[box[1]:box[3], box[0]:box[2]]
    mask = mask[box[1]:box[3], box[0]:box[2]]
    gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
    if a.cell:
        cx = cy = a.cell
        ox = oy = 0
    else:
        (cx, sx), (cy, sy), gx, gy = detect_cell(gray)
        if not cx or min(sx, sy) < 0.5:
            # không có lưới: hạ mẫu theo cột cố định
            cx = cy = max(1, int(max(img.shape[:2]) / a.cols))
            print(f"(không thấy lưới pixel; hạ mẫu thô ô={cx}px, ~{a.cols} cột)")
            ox = oy = 0
        else:
            cx = cy = int(round((cx + cy) / 2))
            ox, oy = phase(gx, cx) % cx, phase(gy, cy) % cy
    nat = native_pixels(img, cx, cy, ox, oy)
    nm = np.zeros(nat.shape[:2], bool)
    H, W = mask.shape
    ys = list(range(oy % cy, H - cy + 1, cy)); xs = list(range(ox % cx, W - cx + 1, cx))
    for j, y in enumerate(ys):
        for i, x in enumerate(xs):
            nm[j, i] = mask[y:y + cy, x:x + cx].mean() > 0.5
    pal, labs = kmeans_palette(nat, nm, a.k)
    idx, _ = assign_palette(nat, labs)
    letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
    print(f"Bản đồ {nat.shape[1]} cột × {nat.shape[0]} hàng (ô {cx}px); '.' = nền. Cột 0 ở TRÁI ảnh, hàng 0 ở TRÊN.")
    for i, (rgb, share) in enumerate(pal):
        print(f"  {letters[i]} = {hexc(rgb)} ({share*100:.0f}%)")
    print("     " + "".join(str((i // 10) % 10) if i % 10 == 0 else " " for i in range(nat.shape[1])))
    for j in range(nat.shape[0]):
        print(f"{j:3d}  " + "".join(letters[idx[j, i]] if nm[j, i] else "." for i in range(nat.shape[1])))


# ---------------------------------------------------------------- scan
def cmd_scan(a):
    img = load(a.image)
    x0, y0 = [float(v) for v in a.p0.split(",")]; x1, y1 = [float(v) for v in a.p1.split(",")]
    mask, bg = subject_mask(img, thr=a.thr)
    pal, labs = kmeans_palette(img, mask, a.k)
    n = int(max(abs(x1 - x0), abs(y1 - y0))) + 1
    xs = np.linspace(x0, x1, n).round().astype(int).clip(0, img.shape[1] - 1)
    ys = np.linspace(y0, y1, n).round().astype(int).clip(0, img.shape[0] - 1)
    line = img[ys, xs]
    lab = cv2.cvtColor(line.reshape(-1, 1, 3), cv2.COLOR_RGB2LAB).reshape(-1, 3).astype(np.float32)
    d = np.linalg.norm(lab[:, None, :] - np.vstack([labs, cv2.cvtColor(np.uint8([[bg]]), cv2.COLOR_RGB2LAB).reshape(1, 3).astype(np.float32)])[None], axis=2)
    cls = d.argmin(1)
    letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    names = {i: letters[i] for i in range(len(labs))}
    names[len(labs)] = "·nền"
    runs = []
    s = 0
    for i in range(1, n + 1):
        if i == n or cls[i] != cls[s]:
            runs.append((cls[s], s, i - 1)); s = i
    # lọc nhiễu: gộp đoạn ngắn <2px vào hàng xóm
    clean = []
    for c, a0, a1 in runs:
        if clean and (a1 - a0 + 1) < 2:
            clean[-1] = (clean[-1][0], clean[-1][1], a1)
        elif clean and clean[-1][0] == c:
            clean[-1] = (c, clean[-1][1], a1)
        else:
            clean.append((c, a0, a1))
    print("Bảng màu: " + ", ".join(f"{letters[i]}={hexc(rgb)}" for i, (rgb, _) in enumerate(pal)))
    print(f"Quét {n} điểm từ ({x0:.0f},{y0:.0f}) → ({x1:.0f},{y1:.0f}); {len(clean)} đoạn:")
    for c, a0, a1 in clean:
        print(f"  [{a0:4d}–{a1:4d}] dài {a1-a0+1:4d}px  màu {names[c]}")
    seq = [names[c] for c, _, _ in clean]
    obj = [s for s in seq if s != "·nền"]
    print("Chuỗi:", " ".join(seq))
    from collections import Counter
    print("Số đoạn mỗi màu:", dict(Counter(obj)))


# ---------------------------------------------------------------- overlay
def cmd_overlay(a):
    img = Image.open(a.image).convert("RGB")
    if a.bbox:
        x0, y0, x1, y1 = [int(v) for v in a.bbox.split(",")]
        img = img.crop((x0, y0, x1, y1))
    else:
        x0 = y0 = 0
    if a.zoom != 1:
        img = img.resize((int(img.width * a.zoom), int(img.height * a.zoom)), Image.NEAREST)
    d = ImageDraw.Draw(img, "RGBA")
    f = font(max(10, int(11 * min(1.4, a.zoom))))
    for i in range(a.n + 1):
        x = int(i * (img.width - 1) / a.n)
        y = int(i * (img.height - 1) / a.n)
        d.line([(x, 0), (x, img.height)], fill=(255, 255, 0, 90), width=1)
        d.line([(0, y), (img.width, y)], fill=(255, 255, 0, 90), width=1)
        ox = x0 + x / a.zoom; oy = y0 + y / a.zoom
        d.text((x + 2, 2), f"{ox:.0f}", fill=(255, 255, 0, 255), font=f, stroke_width=1, stroke_fill=(0, 0, 0, 255))
        d.text((2, y + 2), f"{oy:.0f}", fill=(0, 255, 255, 255), font=f, stroke_width=1, stroke_fill=(0, 0, 0, 255))
    img.save(a.out)
    print(f"[OK] {a.out}: lưới {a.n}×{a.n}; nhãn vàng = x gốc, nhãn lục lam = y gốc (toạ độ trong ảnh gốc)")


# ---------------------------------------------------------------- compare
def normalize_subject(img, mask, size=256):
    box = subject_bbox(mask)
    x0, y0, x1, y1 = box
    crop = img[y0:y1, x0:x1]; m = mask[y0:y1, x0:x1]
    h, w = m.shape
    s = max(h, w)
    pad = np.zeros((s, s, 3), np.uint8); pm = np.zeros((s, s), bool)
    oy, ox = (s - h) // 2, (s - w) // 2
    pad[oy:oy + h, ox:ox + w] = crop; pm[oy:oy + h, ox:ox + w] = m
    pad = cv2.resize(pad, (size, size), interpolation=cv2.INTER_AREA)
    pm = cv2.resize(pm.astype(np.uint8), (size, size), interpolation=cv2.INTER_NEAREST).astype(bool)
    return pad, pm, (w, h)


def cmd_compare(a):
    ref = load(a.ref); ren = load(a.render)
    rm, rbg = subject_mask(ref, thr=a.thr)
    nm, nbg = subject_mask(ren, thr=a.thr)
    if rm.sum() == 0 or nm.sum() == 0:
        sys.exit("một trong hai ảnh không có chủ thể (kiểm tra nền)")
    rn, rmask, (rw, rh) = normalize_subject(ref, rm)
    nn, nmask, (nw, nh) = normalize_subject(ren, nm)
    inter = (rmask & nmask).sum(); union = (rmask | nmask).sum()
    iou = inter / max(union, 1)
    ar_ref, ar_new = rw / rh, nw / nh
    ar_err = abs(math.log(ar_new / ar_ref))
    pal, labs = kmeans_palette(ref, rm, a.k)
    ri, rd = assign_palette(rn, labs)
    ni, nd = assign_palette(nn, labs)
    letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    issues = []
    l1 = 0.0
    rows = []
    for i, (rgb, _) in enumerate(pal):
        sr = ((ri == i) & rmask & (rd < 40)).sum() / max(rmask.sum(), 1)
        sn = ((ni == i) & nmask & (nd < 40)).sum() / max(nmask.sum(), 1)
        l1 += abs(sr - sn)
        rows.append((i, rgb, sr, sn))
        if sr > 0.03 and sn < 0.4 * sr:
            issues.append(f"thiếu màu {hexc(rgb)} ({letters[i]}): mẫu {sr*100:.0f}% diện tích, render {sn*100:.0f}%")
        elif sn > 0.04 and sn > 2.2 * sr + 0.03:
            issues.append(f"dư màu {hexc(rgb)} ({letters[i]}): mẫu {sr*100:.0f}%, render {sn*100:.0f}%")
    unmatched = (nmask & (nd >= 40)).sum() / max(nmask.sum(), 1)
    if unmatched > 0.12:
        issues.append(f"{unmatched*100:.0f}% diện tích render có màu KHÔNG có trong mẫu")
    g1 = cv2.cvtColor(rn, cv2.COLOR_RGB2GRAY); g2 = cv2.cvtColor(nn, cv2.COLOR_RGB2GRAY)
    try:
        from skimage.metrics import structural_similarity as ssim
        ss = float(ssim(g1, g2))
    except Exception:
        ss = float("nan")
    # lệch theo ô 4×4
    names_r = ["trên", "giữa-trên", "giữa-dưới", "dưới"]; names_c = ["trái", "giữa-trái", "giữa-phải", "phải"]
    cells = []
    for j in range(4):
        for i in range(4):
            sl = (slice(j * 64, (j + 1) * 64), slice(i * 64, (i + 1) * 64))
            cov_r, cov_n = rmask[sl].mean(), nmask[sl].mean()
            labd = np.linalg.norm(cv2.cvtColor(rn[sl], cv2.COLOR_RGB2LAB).reshape(-1, 3).mean(0) - cv2.cvtColor(nn[sl], cv2.COLOR_RGB2LAB).reshape(-1, 3).mean(0))
            cells.append((abs(cov_r - cov_n) * 100 + labd * 0.5, j, i, cov_r, cov_n, labd))
    cells.sort(reverse=True)
    if ar_err > 0.08:
        issues.append(f"TỈ LỆ khung sai: rộng/cao mẫu {ar_ref:.2f} vs render {ar_new:.2f} (lệch {abs(ar_new/ar_ref-1)*100:.0f}%)")
    if iou < 0.8:
        issues.append(f"hình bóng chỉ khớp {iou*100:.0f}% (IoU) — hình dạng/tư thế/góc nhìn khác")
    xor = rmask ^ nmask
    diff = np.zeros((256, 256, 3), np.uint8); diff[rmask & ~nmask] = (255, 80, 80); diff[nmask & ~rmask] = (80, 160, 255); diff[rmask & nmask] = (70, 70, 70)
    panel = np.concatenate([rn, nn, diff], 1)
    Image.fromarray(panel).resize((panel.shape[1] * 2, panel.shape[0] * 2), Image.NEAREST).save(a.out)
    print(f"IoU hình bóng {iou:.2f} | tỉ lệ rộng/cao mẫu {ar_ref:.2f} vs render {ar_new:.2f} | SSIM {ss:.2f} | Σ|Δ% màu| {l1:.2f}")
    print("Ảnh: [mẫu | render | khác biệt: ĐỎ = có ở mẫu thiếu ở render, XANH = thừa ở render]  →", a.out)
    print("Phân bổ màu (theo bảng màu của MẪU):")
    for i, rgb, sr, sn in rows:
        print(f"  {letters[i]} {hexc(rgb)}  mẫu {sr*100:5.1f}%  render {sn*100:5.1f}%")
    print("Vùng lệch nhiều nhất (lưới 4×4 của chủ thể đã chuẩn hóa):")
    for sc, j, i, cr, cn, ld in cells[:3]:
        print(f"  hàng {names_r[j]} · cột {names_c[i]}: phủ mẫu {cr*100:.0f}% vs render {cn*100:.0f}%, lệch màu ΔE {ld:.0f}")
    verdict = "ĐẠT" if (iou >= 0.8 and ar_err <= 0.08 and l1 <= 0.35) else ("GẦN" if iou >= 0.65 and ar_err <= 0.2 else "LỆCH")
    print(f"Kết luận: {verdict}  (ngưỡng tham khảo: IoU≥0.8, tỉ lệ ≤8%, Σ|Δ màu|≤0.35)")
    for s in issues:
        print("  !", s)
    if not issues:
        print("  (không có vấn đề lớn theo số đo; vẫn phải NHÌN ảnh khác biệt)")
    sys.exit(0 if verdict == "ĐẠT" else 3)


# ---------------------------------------------------------------- selftest
def selftest():
    ok = True
    def chk(n, c):
        nonlocal ok
        print(("PASS " if c else "FAIL ") + n); ok &= bool(c)
    # ảnh tổng hợp: nền xám, 2 khối màu, lưới 6px
    img = np.full((120, 200, 3), (20, 22, 28), np.uint8)
    img[30:90, 20:110] = (220, 40, 40)
    img[30:90, 110:150] = (40, 80, 220)
    bg = estimate_bg(img); chk("bg ước lượng", np.abs(bg - (20, 22, 28)).max() < 3)
    m, _ = fg_mask(img); box = subject_bbox(m); chk("hộp bao", box == (20, 30, 150, 90))
    pal, labs = kmeans_palette(img, m, 4); chk("2 màu chủ đạo", len(pal) == 2)
    sh = sorted([round(s, 2) for _, s in pal]); chk("tỉ lệ màu 0.69/0.31", sh == [0.31, 0.69])
    lr, ud = symmetry(m, box); chk("hình chữ nhật đối xứng tuyệt đối", lr > 0.99 and ud > 0.99)
    L = np.zeros((60, 60), bool); L[:, :20] = True; L[40:, :] = True
    lr, ud = symmetry(L, (0, 0, 60, 60)); chk("hình chữ L: không đối xứng", lr < 0.7 and ud < 0.7)
    # pixel-art 10×8 ô, mỗi ô 8px
    rng = np.random.default_rng(3)
    nat = rng.integers(0, 4, (8, 10))
    cols = np.array([[220, 50, 50], [50, 200, 70], [60, 90, 230], [240, 220, 60]], np.uint8)
    big = np.kron(cols[nat], np.ones((8, 8, 1), np.uint8))
    (cx, sx), (cy, sy), gx, gy = detect_cell(cv2.cvtColor(big, cv2.COLOR_RGB2GRAY))
    chk(f"phát hiện ô 8px (được {cx},{cy})", cx in (8,) and cy in (8,))
    ox, oy = phase(gx, cx) % cx, phase(gy, cy) % cy
    rec = native_pixels(big, 8, 8, ox, oy)
    chk("khôi phục lưới gốc 10×8", rec.shape[:2] == (8, 10) and np.abs(rec.astype(int) - cols[nat].astype(int)).max() < 3)
    # compare: ảnh giống hệt phải ĐẠT; ảnh lệch tỉ lệ phải bị báo
    with tempfile.TemporaryDirectory() as td:
        p1 = os.path.join(td, "a.png"); p2 = os.path.join(td, "b.png"); p3 = os.path.join(td, "c.png"); o = os.path.join(td, "o.png")
        Image.fromarray(img).save(p1); Image.fromarray(img).save(p2)
        img2 = img.copy(); img2[:] = (20, 22, 28); img2[40:80, 30:80] = (220, 40, 40)
        Image.fromarray(img2).save(p3)
        class A: pass
        a = A(); a.ref, a.render, a.out, a.thr, a.k = p1, p2, o, 26, 6
        try:
            cmd_compare(a)
            code = 0
        except SystemExit as e:
            code = e.code
        chk("compare ảnh y hệt → ĐẠT (exit 0)", code == 0)
        a.render = p3
        try:
            cmd_compare(a); code = 0
        except SystemExit as e:
            code = e.code
        chk("compare ảnh khác → không ĐẠT", code == 3)
    print("ALL PASS" if ok else "CÓ LỖI")
    return 0 if ok else 1


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("sheet"); s.add_argument("image"); s.add_argument("out"); s.add_argument("--thr", type=float, default=26)
    s.add_argument("--gap", type=float, default=0.012, help="khoảng gộp (tỉ lệ cạnh ngắn)"); s.add_argument("--min-area", type=float, default=0.0015, dest="min_area")
    p = sub.add_parser("palette"); p.add_argument("image"); p.add_argument("--k", type=int, default=10); p.add_argument("--thr", type=float, default=26)
    m = sub.add_parser("measure"); m.add_argument("image"); m.add_argument("--cell", type=float); m.add_argument("--known", help="w=48 hoặc h=16: quy đổi theo kích thước đã biết"); m.add_argument("--thr", type=float, default=26)
    g = sub.add_parser("grid"); g.add_argument("image"); g.add_argument("out")
    c = sub.add_parser("ascii"); c.add_argument("image"); c.add_argument("--k", type=int, default=10); c.add_argument("--cell", type=int); c.add_argument("--cols", type=int, default=64); c.add_argument("--thr", type=float, default=26)
    sc = sub.add_parser("scan"); sc.add_argument("image"); sc.add_argument("p0"); sc.add_argument("p1"); sc.add_argument("--k", type=int, default=10); sc.add_argument("--thr", type=float, default=26)
    o = sub.add_parser("overlay"); o.add_argument("image"); o.add_argument("out"); o.add_argument("--n", type=int, default=10); o.add_argument("--bbox"); o.add_argument("--zoom", type=float, default=1)
    cp = sub.add_parser("compare"); cp.add_argument("ref"); cp.add_argument("render"); cp.add_argument("out"); cp.add_argument("--k", type=int, default=8); cp.add_argument("--thr", type=float, default=26)
    sub.add_parser("selftest")
    a = ap.parse_args()
    if a.cmd == "selftest":
        sys.exit(selftest())
    {"sheet": cmd_sheet, "palette": cmd_palette, "measure": cmd_measure, "grid": cmd_grid, "ascii": cmd_ascii, "scan": cmd_scan, "overlay": cmd_overlay, "compare": cmd_compare}[a.cmd](a)


if __name__ == "__main__":
    main()
