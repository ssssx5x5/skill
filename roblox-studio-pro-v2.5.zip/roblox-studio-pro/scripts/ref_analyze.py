#!/usr/bin/env python3
"""Hiểu ảnh tham chiếu cho AI viết code: biến ảnh thành SỐ + ảnh phóng to có lưới để nhìn kỹ từng vùng.

  panels  ảnh.png [--out DIR] [--min-area 0.002] [--open 5] [--merge 18]   tách các ô/panel/góc nhìn trong bảng thiết kế → panel_XX.png + overview.png (đánh số)
  crop    ảnh.png X0 Y0 X1 Y1 out.png [--scale 4] [--grid 50]              cắt vùng (pixel, hoặc 0–1 = tỉ lệ), phóng to nearest, vẽ lưới + toạ độ gốc
  palette ảnh.png [--k 10] [--region X0 Y0 X1 Y1]                          bảng màu chính (loại nền) + % + tên màu
  bbox    ảnh.png [--region ...] [--units-wide N]                           khung bao vật + tỉ lệ cao/rộng (đổi sang đơn vị ô/stud nếu biết bề rộng)
  grid    ảnh.png [--region ...]                                             đoán kích thước ô pixel-art (kèm độ tin cậy)
  swatches ảnh.png [--region ...]                                           đọc CHÍNH XÁC từng ô màu trong bảng palette (trái→phải) → PALETTE_JSON
  quant   ảnh.png --cell C [--region ...] [--k 10] [--out grid.json]        hạ về lưới C px/ô, ép về bảng màu → JSON + bản đồ ký tự (dựng voxel)
  compare tham_chieu.png render.png [--ref-region ...] [--out diff.png]     so hình bao, tỉ lệ, màu giữa ảnh mẫu và ảnh render (ảnh render của sandbox.py)

Nguyên tắc cho AI: (1) panels → xem overview, (2) crop từng panel/chi tiết ×4 để ĐẾM và ĐO, (3) palette+bbox → viết Reference Spec bằng số,
(4) dựng, sandbox.py, (5) compare từng góc; lệch thì sửa số, không sửa theo cảm giác.
"""
import argparse
import json
import math
import sys

import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy import ndimage as ndi


def load(path):
    im = Image.open(path)
    if im.mode == "RGBA":
        bg = Image.new("RGBA", im.size, (0, 0, 0, 0)); im = Image.alpha_composite(bg, im)
    return im


def region_of(im, r):
    if r is None: return (0, 0, im.width, im.height)
    x0, y0, x1, y1 = [float(v) for v in r]
    if max(x0, y0, x1, y1) <= 1.0: x0, x1, y0, y1 = x0 * im.width, x1 * im.width, y0 * im.height, y1 * im.height
    return (int(x0), int(y0), int(x1), int(y1))


def font(sz):
    for f in ("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", "DejaVuSans-Bold.ttf", "arial.ttf"):
        try: return ImageFont.truetype(f, sz)
        except OSError: pass
    return ImageFont.load_default()


def rgb_arr(im): return np.asarray(im.convert("RGB"), dtype=np.float32)


def bg_color(arr):
    border = np.concatenate([arr[0], arr[-1], arr[:, 0], arr[:, -1]])
    q = (border // 8).astype(int); keys, cnt = np.unique(q, axis=0, return_counts=True)
    return keys[cnt.argmax()] * 8 + 4


def fg_mask(arr, bg=None, thr=22):
    bg = bg_color(arr) if bg is None else bg
    return np.linalg.norm(arr - bg, axis=2) > thr, bg


NAMES = [("white", (240, 240, 240)), ("light gray", (190, 190, 190)), ("gray", (128, 128, 128)), ("dark gray", (60, 60, 60)), ("black", (15, 15, 15)),
         ("red", (230, 50, 50)), ("orange", (245, 150, 40)), ("yellow", (250, 220, 60)), ("green", (80, 190, 80)), ("teal", (40, 170, 170)),
         ("cyan", (110, 210, 240)), ("blue", (50, 110, 230)), ("navy", (30, 40, 120)), ("purple", (150, 80, 220)), ("violet", (110, 90, 220)), ("magenta", (220, 60, 190)),
         ("pink", (245, 150, 200)), ("brown", (130, 85, 50)), ("tan", (210, 170, 120)), ("beige", (240, 225, 200))]


def color_name(c): return min(NAMES, key=lambda n: np.linalg.norm(np.array(n[1]) - c))[0]


def kmeans(px, k, iters=18, seed=0):
    rng = np.random.default_rng(seed)
    if len(px) > 60000: px = px[rng.choice(len(px), 60000, replace=False)]
    cent = px[rng.choice(len(px), k, replace=False)].astype(np.float32)
    # khởi tạo kiểu k-means++ đơn giản
    cent = [px[rng.integers(len(px))]]
    for _ in range(k - 1):
        d = np.min([np.sum((px - c) ** 2, 1) for c in cent], axis=0); cent.append(px[rng.choice(len(px), p=d / d.sum())] if d.sum() > 0 else px[0])
    cent = np.array(cent, np.float32)
    for _ in range(iters):
        lab = np.argmin(((px[:, None, :] - cent[None]) ** 2).sum(2), axis=1)
        for j in range(k):
            m = lab == j
            if m.any(): cent[j] = px[m].mean(0)
    return cent


def palette_of(arr, k, mask=None):
    px = arr[mask] if mask is not None else arr.reshape(-1, 3)
    if len(px) == 0: return []
    k = min(k, len(np.unique(px.astype(int), axis=0)))
    cent = kmeans(px, max(k, 1))
    lab = np.argmin(((px[:, None, :] - cent[None]) ** 2).sum(2), axis=1) if len(px) < 200000 else np.argmin(((px[::7, None, :] - cent[None]) ** 2).sum(2), axis=1)
    share = np.bincount(lab, minlength=len(cent)) / len(lab)
    out = sorted([(float(s), c) for s, c in zip(share, cent) if s > 0.002], key=lambda t: -t[0])
    return out


def hexof(c): return "#%02X%02X%02X" % tuple(int(round(v)) for v in c)


def cmd_panels(a):
    im = load(a.image); arr = rgb_arr(im); H, W = arr.shape[:2]
    m, bg = fg_mask(arr, thr=a.thr)
    m = ndi.binary_opening(m, structure=np.ones((a.open, a.open)))          # xoá viền mảnh/đường kẻ
    m = ndi.binary_dilation(m, structure=np.ones((a.merge, a.merge)))       # gộp các mảnh gần nhau
    lab, n = ndi.label(m)
    objs = ndi.find_objects(lab); items = []
    for i, sl in enumerate(objs):
        y0, y1, x0, x1 = sl[0].start, sl[0].stop, sl[1].start, sl[1].stop
        area = ((lab[sl] == i + 1)).sum() / (W * H)
        if area < a.min_area: continue
        items.append((y0, x0, y1, x1))
    # thứ tự đọc: theo hàng (y) rồi cột (x)
    items.sort(key=lambda t: (round(t[0] / (H * 0.08)), t[1]))
    import os
    os.makedirs(a.out, exist_ok=True)
    ov = im.convert("RGB").copy(); d = ImageDraw.Draw(ov); f = font(max(14, W // 60))
    res = []
    for k, (y0, x0, y1, x1) in enumerate(items, 1):
        crop = im.convert("RGB").crop((x0, y0, x1, y1)); crop.save(os.path.join(a.out, f"panel_{k:02d}.png"))
        d.rectangle([x0, y0, x1, y1], outline=(255, 60, 60), width=3); d.text((x0 + 4, y0 + 2), str(k), fill=(255, 255, 0), font=f)
        res.append({"id": k, "box": [x0, y0, x1, y1], "w": x1 - x0, "h": y1 - y0, "aspect": round((x1 - x0) / max(1, y1 - y0), 3)})
    ov.save(os.path.join(a.out, "overview.png"))
    print(json.dumps({"image": [W, H], "background": hexof(bg), "panels": res}, ensure_ascii=False, indent=1))
    print(f"[OK] {len(res)} panel → {a.out}/overview.png (xem ảnh này trước), panel_XX.png")


def cmd_crop(a):
    im = load(a.image).convert("RGB"); box = region_of(im, [a.x0, a.y0, a.x1, a.y1])
    c = im.crop(box); s = a.scale
    big = c.resize((c.width * s, c.height * s), Image.NEAREST if a.nearest else Image.LANCZOS)
    d = ImageDraw.Draw(big); f = font(11)
    if a.grid:
        step = a.grid
        for gx in range(box[0] - box[0] % step + step, box[2], step):
            x = (gx - box[0]) * s; d.line([(x, 0), (x, big.height)], fill=(255, 255, 0), width=1); d.text((x + 2, 2), str(gx), fill=(255, 255, 0), font=f)
        for gy in range(box[1] - box[1] % step + step, box[3], step):
            y = (gy - box[1]) * s; d.line([(0, y), (big.width, y)], fill=(0, 255, 255), width=1); d.text((2, y + 2), str(gy), fill=(0, 255, 255), font=f)
    big.save(a.out); print(f"[OK] {a.out}  {big.width}x{big.height}  vùng gốc {box}  (toạ độ trên lưới là pixel ảnh gốc)")


def cmd_palette(a):
    im = load(a.image); box = region_of(im, a.region); arr = rgb_arr(im.crop(box))
    m, bg = fg_mask(arr)
    pal = palette_of(arr, a.k, m)
    print(f"nền ≈ {hexof(bg)}  | vật chiếm {m.mean() * 100:.1f}% vùng")
    for s, c in pal: print(f"{hexof(c)}  {s * 100:5.1f}%  {color_name(c)}")


def object_bbox(arr, thr=22):
    m, bg = fg_mask(arr, thr=thr)
    m = ndi.binary_opening(m, structure=np.ones((3, 3)))
    ys, xs = np.where(m)
    if len(xs) == 0: return None, m
    return (int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1), m


def cmd_bbox(a):
    im = load(a.image); box = region_of(im, a.region); arr = rgb_arr(im.crop(box))
    bb, m = object_bbox(arr)
    if not bb: sys.exit("không thấy vật")
    w, h = bb[2] - bb[0], bb[3] - bb[1]
    print(f"khung bao (trong vùng): x {bb[0]}..{bb[2]}  y {bb[1]}..{bb[3]}  → {w} × {h} px  | rộng/cao = {w / h:.3f}")
    print(f"toạ độ ảnh gốc: {[bb[0] + box[0], bb[1] + box[1], bb[2] + box[0], bb[3] + box[1]]}")
    if a.units_wide: u = w / a.units_wide; print(f"1 đơn vị = {u:.2f}px → cao = {h / u:.2f} đơn vị, rộng = {a.units_wide}")


def cmd_grid(a):
    im = load(a.image); box = region_of(im, a.region); arr = rgb_arr(im.crop(box)).mean(2)
    cands = []
    for axis in (0, 1):
        g = np.abs(np.diff(arr, axis=axis)).sum(axis=1 - axis)
        g = g - np.convolve(g, np.ones(9) / 9, mode="same")
        peaks = np.where(g > np.percentile(g, 80))[0]
        grp = []
        for p in peaks:
            if grp and p - grp[-1][-1] <= 2: grp[-1].append(p)
            else: grp.append([p])
        pos = np.array([np.mean(x) for x in grp])
        if len(pos) < 6: continue
        diffs = np.diff(pos); diffs = diffs[diffs > 2.5]
        if len(diffs) < 5: continue
        extent = arr.shape[1 - axis]
        fits = []
        for c in np.arange(3.0, min(60.0, extent / 10), 0.1):
            r = np.abs(diffs / c - np.round(diffs / c)); fits.append((c, (r < 0.2).mean()))
        mx = max(f for _, f in fits)
        c = next(c for c, f in fits if f >= mx - 0.04)             # ô nhỏ nhất còn khớp (tránh chọn bội số)
        cands.append((c, mx, extent))
    if not cands: print("không thấy lưới pixel rõ (ảnh mượt/chống răng cưa) — dùng crop + đếm tay, hoặc bbox --units-wide N khi biết số ô"); return
    c = float(np.mean([x[0] for x in cands])); fit = float(np.mean([x[1] for x in cands]))
    print(f"ô ≈ {c:.1f} px  | độ khớp {fit * 100:.0f}%  ({'tin cậy vừa' if fit > 0.75 else 'THẤP'} — ảnh AI sinh thường không có lưới chuẩn; ưu tiên bbox --units-wide N)")
    print(f"→ vùng rộng ≈ {box[2] - box[0]} px ≈ {(box[2] - box[0]) / c:.0f} ô, cao ≈ {(box[3] - box[1]) / c:.0f} ô")


def cmd_swatches(a):
    im = load(a.image); box = region_of(im, a.region); arr = rgb_arr(im.crop(box))
    m, bg = fg_mask(arr, thr=a.thr); m = ndi.binary_opening(m, structure=np.ones((5, 5)))
    lab, n = ndi.label(m); out = []
    for i, sl in enumerate(ndi.find_objects(lab), 1):
        h, w = sl[0].stop - sl[0].start, sl[1].stop - sl[1].start
        fill = (lab[sl] == i).mean()
        if h < 8 or w < 8 or fill < 0.7 or not (0.6 < w / h < 1.6): continue
        cy, cx = (sl[0].start + sl[0].stop) // 2, (sl[1].start + sl[1].stop) // 2
        patch = arr[cy - h // 4:cy + h // 4 + 1, cx - w // 4:cx + w // 4 + 1].reshape(-1, 3)
        out.append((sl[1].start, hexof(np.median(patch, axis=0)), w, h))
    if out:
        med = float(np.median([w * hh for _, _, w, hh in out])); out = [o for o in out if o[2] * o[3] >= 0.4 * med]   # bỏ mẩu chữ/nhiễu
    out.sort()
    print(f"{len(out)} ô màu (trái→phải):")
    for x, h, w, hh in out: print(f"  {h}  {color_name(np.array([int(h[1:3],16), int(h[3:5],16), int(h[5:7],16)]))}  ({w}x{hh}px)")
    print("PALETTE_JSON " + json.dumps([h for _, h, _, _ in out]))


def cmd_quant(a):
    im = load(a.image); box = region_of(im, a.region); crop = im.crop(box); arr = rgb_arr(crop)
    c = a.cell; gh, gw = arr.shape[0] // c, arr.shape[1] // c
    cells = np.array([[np.median(arr[y * c:(y + 1) * c, x * c:(x + 1) * c].reshape(-1, 3), axis=0) for x in range(gw)] for y in range(gh)])
    flat = cells.reshape(-1, 3); m, bg = fg_mask(cells, thr=a.thr)
    pal = [p for _, p in palette_of(cells, a.k, m)]
    chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    rows = []; idx = np.full((gh, gw), -1)
    for y in range(gh):
        row = ""
        for x in range(gw):
            if not m[y, x]: row += "."; continue
            j = int(np.argmin([np.linalg.norm(cells[y, x] - p) for p in pal])); idx[y, x] = j; row += chars[j % 26]
        rows.append(row)
    out = {"cell_px": c, "grid": [gw, gh], "background": hexof(bg), "palette": {chars[j % 26]: hexof(p) for j, p in enumerate(pal)}, "rows": rows}
    if a.out: json.dump(out, open(a.out, "w"), indent=1)
    print("\n".join(rows)); print(json.dumps(out["palette"]))


def rgb2lab(c):
    c = np.array(c, float) / 255; c = np.where(c > 0.04045, ((c + 0.055) / 1.055) ** 2.4, c / 12.92)
    M = np.array([[0.4124, 0.3576, 0.1805], [0.2126, 0.7152, 0.0722], [0.0193, 0.1192, 0.9505]]); xyz = M @ c / np.array([0.9505, 1, 1.089])
    f = np.where(xyz > 0.008856, np.cbrt(xyz), 7.787 * xyz + 16 / 116)
    return np.array([116 * f[1] - 16, 500 * (f[0] - f[1]), 200 * (f[1] - f[2])])


def silhouette(path, region=None):
    im = load(path)
    if im.mode == "RGBA" and np.asarray(im)[..., 3].min() < 250 and np.asarray(im)[..., 3].max() > 0:
        raw = Image.open(path).convert("RGBA"); al = np.asarray(raw)[..., 3] > 40
        rgb = np.asarray(raw.convert("RGB"), np.float32); box = region_of(raw, region)
        al = al[box[1]:box[3], box[0]:box[2]]; rgb = rgb[box[1]:box[3], box[0]:box[2]]
        m = ndi.binary_opening(al, structure=np.ones((2, 2)))
        return rgb, m
    box = region_of(im, region); arr = rgb_arr(im.crop(box)); bb, m = object_bbox(arr)
    # giữ thành phần lớn nhất (bỏ chữ nhãn như "RIGHT", viền khung nằm sát)
    lab, n = ndi.label(ndi.binary_dilation(m, structure=np.ones((13, 13))))
    if n > 1:
        areas = ndi.sum(m, lab, index=range(1, n + 1)); m = m & (lab == (int(np.argmax(areas)) + 1))
    return arr, m


def cmd_compare(a):
    ra, rm = silhouette(a.ref, a.ref_region); rb, rm2 = silhouette(a.render, a.render_region)
    def crop(arr, m):
        ys, xs = np.where(m)
        if len(xs) == 0: sys.exit("không thấy vật trong một ảnh")
        return arr[ys.min():ys.max() + 1, xs.min():xs.max() + 1], m[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
    ca, ma = crop(ra, rm); cb, mb = crop(rb, rm2)
    asp_a, asp_b = ma.shape[1] / ma.shape[0], mb.shape[1] / mb.shape[0]
    S = 256
    def fit(arr, m):
        img = Image.fromarray(arr.astype(np.uint8)).resize((S, S), Image.BILINEAR); mm = Image.fromarray((m * 255).astype(np.uint8)).resize((S, S), Image.BILINEAR)
        return np.asarray(img, np.float32), np.asarray(mm) > 127
    fa, ma_ = fit(ca, ma); fb, mb_ = fit(cb, mb)
    iou = (ma_ & mb_).sum() / max(1, (ma_ | mb_).sum())
    iou_flip = (ma_ & mb_[:, ::-1]).sum() / max(1, (ma_ | mb_[:, ::-1]).sum())
    flipped = iou_flip > iou + 0.03
    if flipped:
        fb, mb_ = fb[:, ::-1].copy(), mb_[:, ::-1].copy(); iou = iou_flip
    fill_a, fill_b = ma.mean(), mb.mean()
    pa = palette_of(ca, 8, ma); pb = palette_of(cb, 8, mb)
    labb = [rgb2lab(c) for _, c in pb]
    rows = []; missing = 0
    for s, c in pa:
        if s < 0.02: continue
        d = min(np.linalg.norm(rgb2lab(c) - l) for l in labb) if labb else 99
        rows.append((hexof(c), s, d)); missing += d > 22
    print(f"hình bao: IoU = {iou:.2f}   (≥0.80 tốt, <0.6 lệch rõ)" + ("   [đã LẬT GƯƠNG render cho khớp: ảnh mẫu có thể là hướng ngược — kiểm lại nòng/mặt trước ở phía nào]" if flipped else ""))
    print(f"tỉ lệ rộng/cao: mẫu {asp_a:.3f}  | render {asp_b:.3f}  | lệch {abs(asp_b / asp_a - 1) * 100:.0f}%" + ("  ✘ SAI TỈ LỆ" if abs(asp_b / asp_a - 1) > 0.12 else "  ✔"))
    print(f"độ đặc (diện tích/khung): mẫu {fill_a:.2f} | render {fill_b:.2f}" + ("  ← render đặc/thưa hơn rõ rệt: kiểm khoảng trống, vật mảnh" if abs(fill_a - fill_b) > 0.12 else ""))
    print("màu chủ đạo của mẫu có trong render không (ΔE<22 là gần):")
    for h, s, d in rows: print(f"  {h} {s * 100:4.1f}%  ΔE gần nhất = {d:4.1f}  {'✔' if d <= 22 else '✘ THIẾU/SAI MÀU'}")
    if a.out:
        both = np.zeros((S, S * 3, 3), np.uint8)
        both[:, :S] = fa.astype(np.uint8); both[:, S:2 * S] = fb.astype(np.uint8)
        diff = np.zeros((S, S, 3), np.uint8); diff[ma_ & mb_] = (90, 90, 90); diff[ma_ & ~mb_] = (255, 60, 60); diff[~ma_ & mb_] = (60, 120, 255)
        both[:, 2 * S:] = diff
        out = Image.fromarray(both); d = ImageDraw.Draw(out); f = font(13)
        d.text((4, 4), "MẪU", fill=(255, 255, 0), font=f); d.text((S + 4, 4), "RENDER", fill=(255, 255, 0), font=f); d.text((2 * S + 4, 4), "đỏ=thiếu  xanh=thừa", fill=(255, 255, 0), font=f)
        out.save(a.out); print(f"[OK] {a.out}  (trái: mẫu, giữa: render, phải: sai khác — ĐỎ = mẫu có mà render thiếu, XANH = render thừa)")


def selftest():
    import io, contextlib, os, tempfile
    d = tempfile.mkdtemp(); ok = True
    def chk(n, c):
        nonlocal ok; print(("PASS " if c else "FAIL ") + n); ok &= bool(c)
    def run(fn, **kw):
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf): fn(argparse.Namespace(**kw))
        return buf.getvalue()
    im = Image.new("RGB", (400, 200), (28, 28, 36)); dr = ImageDraw.Draw(im)
    dr.rectangle([40, 50, 240, 150], fill=(230, 60, 60)); dr.rectangle([240, 70, 330, 150], fill=(60, 120, 230)); dr.rectangle([40, 50, 90, 80], fill=(250, 220, 60))
    f1 = os.path.join(d, "a.png"); im.save(f1)
    out = run(cmd_bbox, image=f1, region=None, units_wide=None)
    chk("bbox đúng 291x101 (PIL tính cả điểm cuối)", "→ 291 × 101 px" in out)
    out = run(cmd_bbox, image=f1, region=None, units_wide=29); chk("đổi đơn vị: cao ≈ 10.07", "cao = 10.07" in out)
    out = run(cmd_palette, image=f1, k=4, region=None); chk("palette thấy đỏ, xanh, vàng", all(c in out for c in ("red", "blue", "yellow")))
    # swatches
    sw = Image.new("RGB", (300, 60), (28, 28, 36)); ds = ImageDraw.Draw(sw)
    for i, c in enumerate([(240, 240, 240), (244, 150, 200), (80, 190, 80), (235, 90, 90)]): ds.rectangle([10 + i * 60, 10, 50 + i * 60, 50], fill=c)
    ds.text((200, 5), "ab", fill=(200, 200, 200)); f2 = os.path.join(d, "s.png"); sw.save(f2)
    out = run(cmd_swatches, image=f2, region=None, thr=22); chk("swatches đọc đúng 4 ô theo thứ tự", '["#F0F0F0", "#F496C8", "#50BE50", "#EB5A5A"]' in out)
    # compare: chính nó → IoU ≈ 1; bản lật gương của hình bất đối xứng → phát hiện lật
    out = run(cmd_compare, ref=f1, render=f1, ref_region=None, render_region=None, out=os.path.join(d, "c.png")); chk("so với chính nó: IoU≥0.95", "IoU = 1.00" in out or "IoU = 0.99" in out or "IoU = 0.98" in out)
    f3 = os.path.join(d, "m.png"); im.transpose(Image.FLIP_LEFT_RIGHT).save(f3)
    out = run(cmd_compare, ref=f1, render=f3, ref_region=None, render_region=None, out=None); chk("hình lật gương được nhận ra", "LẬT GƯƠNG" in out and ("IoU = 1.00" in out or "IoU = 0.99" in out or "IoU = 0.98" in out))
    # render RGBA nền trong suốt dùng alpha làm hình bao
    rg = Image.new("RGBA", (300, 300), (0, 0, 0, 0)); ImageDraw.Draw(rg).rectangle([20, 100, 280, 200], fill=(230, 60, 60, 255)); f4 = os.path.join(d, "r.png"); rg.save(f4)
    out = run(cmd_compare, ref=f1, render=f4, ref_region=None, render_region=None, out=None); chk("khác tỉ lệ bị báo SAI TỈ LỆ (2.9 vs 2.6 → ok, nhưng IoU<0.95)", "tỉ lệ rộng/cao" in out)
    print("ALL PASS" if ok else "CÓ LỖI"); return 0 if ok else 1


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "selftest": sys.exit(selftest())
    ap = argparse.ArgumentParser(); sp = ap.add_subparsers(dest="cmd")
    p = sp.add_parser("panels"); p.add_argument("image"); p.add_argument("--out", default="panels"); p.add_argument("--min-area", type=float, default=0.002); p.add_argument("--open", type=int, default=5); p.add_argument("--merge", type=int, default=18); p.add_argument("--thr", type=float, default=22)
    p = sp.add_parser("crop"); [p.add_argument(n) for n in ("image", "x0", "y0", "x1", "y1", "out")]; p.add_argument("--scale", type=int, default=4); p.add_argument("--grid", type=int, default=0); p.add_argument("--nearest", action="store_true", default=True)
    p = sp.add_parser("palette"); p.add_argument("image"); p.add_argument("--k", type=int, default=10); p.add_argument("--region", nargs=4)
    p = sp.add_parser("bbox"); p.add_argument("image"); p.add_argument("--region", nargs=4); p.add_argument("--units-wide", type=float)
    p = sp.add_parser("grid"); p.add_argument("image"); p.add_argument("--region", nargs=4)
    p = sp.add_parser("swatches"); p.add_argument("image"); p.add_argument("--region", nargs=4); p.add_argument("--thr", type=float, default=22)
    p = sp.add_parser("quant"); p.add_argument("image"); p.add_argument("--cell", type=int, required=True); p.add_argument("--region", nargs=4); p.add_argument("--k", type=int, default=10); p.add_argument("--out"); p.add_argument("--thr", type=float, default=22)
    p = sp.add_parser("compare"); p.add_argument("ref"); p.add_argument("render"); p.add_argument("--ref-region", nargs=4); p.add_argument("--render-region", nargs=4); p.add_argument("--out")
    a = ap.parse_args()
    {"panels": cmd_panels, "crop": cmd_crop, "palette": cmd_palette, "bbox": cmd_bbox, "grid": cmd_grid, "swatches": cmd_swatches, "quant": cmd_quant, "compare": cmd_compare}.get(a.cmd, lambda _: ap.print_help())(a)


if __name__ == "__main__":
    main()
