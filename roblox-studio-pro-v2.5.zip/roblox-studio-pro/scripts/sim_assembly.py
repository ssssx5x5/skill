#!/usr/bin/env python3
"""Mô phỏng AssemblyGuard.Build + Check ngoài Studio: kiểm 'liền khối' bằng số cho một spec ổ nối.

    python scripts/sim_assembly.py <spec.json>     # xem định dạng ở docstring hàm main / examples/sniper_spec.json
Spec JSON: {"root": "receiver", "parts": {name: {"size":[x,y,z]}}, "joins": [{"a","sa","b","sb","rot_deg":[rx,ry,rz],"gap":0}]}
Quy ước giống Roblox: CFrame.Angles(rx,ry,rz) = Rz*Ry*Rx? Roblox dùng thứ tự XYZ: R = Rx*Ry*Rz (áp dụng Z trước). Ở đây dùng R = Rx @ Ry @ Rz.
Tol mặc định 0.08 stud. Mã thoát 1 nếu còn >1 cụm.
"""
import json
import math
import sys
import numpy as np


def rx(a): c, s = math.cos(a), math.sin(a); return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])
def ry(a): c, s = math.cos(a), math.sin(a); return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])
def rz(a): c, s = math.cos(a), math.sin(a); return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])


def angles(deg):
    x, y, z = [math.radians(d) for d in deg]
    return rx(x) @ ry(y) @ rz(z)


def separation(A, B):
    (ca, Ra, ha), (cb, Rb, hb) = A, B
    d = cb - ca
    best = -1e9
    axes = [Ra[:, i] for i in range(3)] + [Rb[:, i] for i in range(3)]
    axes += [np.cross(Ra[:, i], Rb[:, j]) for i in range(3) for j in range(3)]
    for L in axes:
        m = np.linalg.norm(L)
        if m < 1e-6: continue
        u = L / m
        rA = sum(ha[i] * abs(Ra[:, i] @ u) for i in range(3))
        rB = sum(hb[i] * abs(Rb[:, i] @ u) for i in range(3))
        best = max(best, abs(d @ u) - (rA + rB))
    return best


def build(spec):
    P = {}
    root = spec["root"]
    P[root] = (np.array([0.0, 10.0, 0.0]), np.eye(3))
    for j in spec["joins"]:
        pa, Ra = P[j["a"]]
        sa = np.array(j.get("sa", [0, 0, 0]), float)
        sb = np.array(j.get("sb", [0, 0, 0]), float)
        Rr = angles(j.get("rot_deg", [0, 0, 0]))
        gap = np.array([0, 0, j.get("gap", 0.0)], float)
        # B.CFrame = A * T(sa) * Rot * T(gap) * T(-sb)
        pos_socket = pa + Ra @ sa
        Rb = Ra @ Rr
        pb = pos_socket + Rb @ (gap - sb)
        P[j["b"]] = (pb, Rb)
    return P


def check(spec, tol=0.08):
    P = build(spec)
    names = list(P)
    obbs = {n: (P[n][0], P[n][1], np.array(spec["parts"][n]["size"], float) / 2) for n in names}
    parent = {n: n for n in names}
    def find(x):
        while parent[x] != x: parent[x] = parent[parent[x]]; x = parent[x]
        return x
    for i, a in enumerate(names):
        for b in names[i + 1:]:
            if separation(obbs[a], obbs[b]) <= tol:
                parent[find(a)] = find(b)
    groups = {}
    for n in names: groups.setdefault(find(n), []).append(n)
    groups = sorted(groups.values(), key=len, reverse=True)
    report = []
    for g in groups[1:]:
        best = min((separation(obbs[a], obbs[b]), a, b) for a in g for b in groups[0])
        report.append((g, *best))
    return groups, report


def main():
    spec = json.load(open(sys.argv[1], encoding="utf-8"))
    groups, rep = check(spec)
    print(f"parts={sum(len(g) for g in groups)} cum={len(groups)}")
    for g, gap, a, b in rep:
        print(f"[ROI] {g} cách thân chính {gap:.3f} stud (cặp {a} <-> {b})")
    print("OK liền khối" if len(groups) == 1 else "FAIL còn rời")
    sys.exit(0 if len(groups) == 1 else 1)


if __name__ == "__main__":
    main()
