"""Kiểm tra hình học CHUNG cho model của mb.py (không phụ thuộc loại vật thể): nối/lơ lửng, chui vào nhau, z-fight, part ẩn,
đối xứng, thế đứng, part mỏng, ngân sách, kích thước thật (dimdb), ràng buộc khai báo. Trả {'errors','warnings','md',...}."""
import importlib.util
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
TOUCH = 0.03


def _dimdb():
    spec = importlib.util.spec_from_file_location("dimdb", os.path.join(HERE, "dimdb.py"))
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m


class B:  # hộp có hướng từ dict part
    def __init__(self, p):
        cf = p["cf"]; self.c = np.array(cf[:3], float); self.R = np.array(cf[3:12], float).reshape(3, 3); self.h = np.array(p["size"], float) / 2
        self.name = p["name"]; self.id = p["id"]; self.ax = self.R.T  # hàng = trục
        self.e = np.abs(self.R) @ self.h; self.p = p


def sat(a, b):
    """(gap, trục từ a→b). gap<0: chồng lấn (độ sâu nhỏ nhất theo SAT)."""
    t = b.c - a.c; best, bax = -1e18, None
    axes = list(a.ax) + list(b.ax)
    for i in range(3):
        for j in range(3):
            x = np.cross(a.ax[i], b.ax[j]); n = np.linalg.norm(x)
            if n > 1e-9: axes.append(x / n)
    for x in axes:
        ra = float(np.abs(a.ax @ x) @ a.h); rb = float(np.abs(b.ax @ x) @ b.h); d = abs(t @ x) - ra - rb
        if d > best: best, bax = d, (x if t @ x >= 0 else -x)
    return best, bax


def sat_gap(pa, pb):
    """Dùng cho Part của mb hoặc dict part."""
    f = lambda p: B(p) if isinstance(p, dict) else B({"cf": list(p.pos) + list(p.R.reshape(-1)), "size": list(p.size), "name": p.name, "id": 0})
    return sat(f(pa), f(pb))[0]


def contained(a, b, eps=1e-3):
    """a nằm hoàn toàn trong b?"""
    sx = np.array([[x, y, z] for x in (-1, 1) for y in (-1, 1) for z in (-1, 1)]) * a.h
    w = a.c + sx @ a.R.T; loc = (w - b.c) @ b.R
    return bool(np.all(np.abs(loc) <= b.h + eps))


def zfight(a, b, tol=0.004, min_area=0.02):
    """Hai mặt ngoài song song, CÙNG hướng, cùng mặt phẳng (lệch ≤tol), phủ nhau diện tích ≥min_area → nhấp nháy khi render."""
    out = []
    for i in range(3):
        n = a.ax[i]
        for j in range(3):
            if abs(abs(n @ b.ax[j]) - 1) > 1e-4: continue
            for sa in (-1, 1):
                for sb in (-1, 1):
                    nb = sb * b.ax[j]
                    if (sa * n) @ nb <= 0: continue          # mặt đối hướng (chạm nhau) là bình thường
                    if abs((n @ a.c + sa * a.h[i]) - (n @ b.c + sb * (b.ax[j] @ n) * b.h[j])) > tol: continue
                    ov = 1.0
                    for k in range(3):
                        if k == i: continue
                        u = a.ax[k]; rb = float(np.abs(b.ax @ u) @ b.h)
                        ov *= max(0.0, a.h[k] + rb - abs((b.c - a.c) @ u))
                    if ov >= min_area: out.append((a.name, b.name, round(float(ov), 3)))
    return out


def comps(n, edges):
    par = list(range(n))
    def f(x):
        while par[x] != x: par[x] = par[par[x]]; x = par[x]
        return x
    for a, b in edges: par[f(a)] = f(b)
    g = {}
    for i in range(n): g.setdefault(f(i), []).append(i)
    return list(g.values())


def run(model, family=None):
    fr = model.scene()["frames"][0]
    fr = {"parts": [p for p in fr["parts"] if not p["name"].startswith("_REF")], "joints": []}
    return _run(fr, family or model.family, model.front, model)


def run_scene(frame, family=None, front="-z"):
    fr = {"parts": [p for p in frame["parts"] if not p["name"].startswith("_REF")], "joints": frame.get("joints", [])}
    return _run(fr, family, front, None)


def _run(fr, family, front, model):
    parts = fr["parts"]; bx = [B(p) for p in parts]; n = len(bx); E, W, I = [], [], []
    style = getattr(model, "style", "realistic"); stud_cm = getattr(model, "stud_cm", 35.0)
    if n == 0: return {"errors": ["model rỗng"], "warnings": [], "md": "model rỗng", "info": []}
    lo = np.min([b.c - b.e for b in bx], 0); hi = np.max([b.c + b.e for b in bx], 0); ext = hi - lo
    # ---- cặp gần nhau (lọc AABB trước)
    cen = np.array([b.c for b in bx]); ee = np.array([b.e for b in bx]); edges = []; pen = []; near = {}
    for i in range(n):
        d = np.abs(cen[i + 1:] - cen[i]) - (ee[i + 1:] + ee[i]); cand = np.where(np.all(d <= TOUCH * 2, 1))[0] + i + 1
        for j in cand:
            g, ax = sat(bx[i], bx[j])
            if g <= TOUCH: edges.append((i, int(j))); near[(i, int(j))] = g
            if g < 0:
                pen.append((i, int(j), -g))
    cs = comps(n, edges)
    main = max(cs, key=len); floating = []
    for c in cs:
        if c is main: continue
        best = None
        for i in c:
            for j in main:
                g, ax = sat(bx[i], bx[j])
                if best is None or g < best[0]: best = (g, i, j, ax)
        g, i, j, ax = best
        mv = ax * g  # dịch part i theo ax*g thì chạm part j (gần đúng, cận dưới)
        floating.append((bx[c[0]].name if len(c) == 1 else f"nhóm {len(c)} part ({bx[c[0]].name}…)", g, bx[j].name, mv))
    if floating:
        for nm, g, to, mv in floating[:12]:
            E.append(f"LƠ LỬNG: {nm} cách {to} {g:.2f} stud → dịch ≈ ({mv[0]:+.2f},{mv[1]:+.2f},{mv[2]:+.2f}) hoặc dùng m.on()/m.mate() để gắn")
    # ---- part ẩn / z-fight
    hid = []; zf = []
    for (i, j, d) in pen:
        a, b = bx[i], bx[j]
        if contained(a, b): hid.append(f"{a.name} nằm gọn trong {b.name}")
        elif contained(b, a): hid.append(f"{b.name} nằm gọn trong {a.name}")
        for z in zfight(a, b):
            if z not in zf: zf.append(z)
    for h in hid[:10]: W.append("PART ẨN (vô ích, tốn part): " + h)
    for a, b, ov in zf[:10]: W.append(f"Z-FIGHT: {a} và {b} có mặt trùng phẳng (phủ {ov}) → nhấp nháy; đẩy lệch ≥0.01 hoặc làm part lớn hơn 0.02")
    # ---- mỏng / to
    for b in bx:
        if (b.h * 2 < 0.06).any(): W.append(f"MỎNG: {b.name} có cạnh {2*b.h.min():.3f} stud (<0.06) — dễ vỡ hình/nhấp nháy; Roblox kẹp ≥0.05")
        if (b.h * 2 > 2048).any(): E.append(f"QUÁ TO: {b.name} vượt 2048 stud")
    # ---- thế đứng: trọng tâm trong chân đế
    ground = [b for b in bx if (b.c[1] - b.e[1]) <= lo[1] + 0.05]
    vol = np.array([np.prod(b.h * 2) for b in bx]); com = (cen * vol[:, None]).sum(0) / vol.sum()
    if ground and ext[1] > 0.3:
        gl = np.min([b.c - b.e for b in ground], 0); gh = np.max([b.c + b.e for b in ground], 0)
        if not (gl[0] - 0.05 <= com[0] <= gh[0] + 0.05 and gl[2] - 0.05 <= com[2] <= gh[2] + 0.05):
            W.append(f"THẾ ĐỨNG: trọng tâm ({com[0]:.2f},{com[2]:.2f}) nằm NGOÀI chân đế x[{gl[0]:.2f},{gh[0]:.2f}] z[{gl[2]:.2f},{gh[2]:.2f}] — sẽ đổ nếu không Anchored")
    # ---- đối xứng
    sym = getattr(model, "symmetry", None)
    if sym:
        k = "xyz".index(sym); plane = (lo[k] + hi[k]) / 2; miss = []
        for b in bx:
            m = b.c.copy(); m[k] = 2 * plane - m[k]
            ok = any(np.allclose(sorted(o.h), sorted(b.h), atol=0.02) and np.linalg.norm(o.c - m) < 0.05 for o in bx)
            if not ok: miss.append(b.name)
        if miss: E.append(f"ĐỐI XỨNG {sym}: {len(miss)} part không có cặp phản chiếu: {', '.join(miss[:8])}")
    # ---- ngân sách
    mx = getattr(model, "max_parts", 1500)
    if n > mx: W.append(f"NGÂN SÁCH: {n} part > {mx}")
    # ---- kích thước thật
    dims_rows = []
    if family:
        dd = _dimdb(); horiz = sorted([ext[0], ext[2]], reverse=True)
        feats = dict(getattr(model, "features", {}) or {})
        f, dims_rows = dd.check(family, {"height": float(ext[1]), "length": float(horiz[0]), "width": float(horiz[1])}, feats, style, stud_cm)
        for r in dims_rows:
            if str(r[3]).startswith("FAIL"): E.append(f"KÍCH THƯỚC {r[0]} = {r[1]} cm, ngoài khoảng thật {r[2]} (style {style}) {r[3][5:]}".rstrip())
            elif str(r[3]).startswith("NOTE"): I.append(f"{r[0]}: {r[3]}")
    # ---- ràng buộc khai báo
    for kind, a, b, kw in (getattr(model, "expects", []) or []):
        tag = f"{kind}({a.name if a else ''},{b.name if b else ''})"
        ba, bb = (B({"cf": list(a.pos) + list(a.R.reshape(-1)), "size": list(a.size), "name": a.name, "id": 0}) if a else None,
                  B({"cf": list(b.pos) + list(b.R.reshape(-1)), "size": list(b.size), "name": b.name, "id": 0}) if b else None)
        if kind == "touch":
            g = sat(ba, bb)[0]
            if g > TOUCH: E.append(f"RÀNG BUỘC {tag}: hở {g:.2f} stud")
        elif kind == "above":
            if not (ba.c[1] - ba.e[1] >= bb.c[1] + bb.e[1] - 0.03): E.append(f"RÀNG BUỘC {tag}: {a.name} không nằm trên {b.name}")
        elif kind == "inside":
            if not contained(ba, bb, 0.02): E.append(f"RÀNG BUỘC {tag}: {a.name} không nằm trong {b.name}")
        elif kind == "ratio":
            k = "xyz".index(kw.get("axis", "y")); q = (2 * ba.e[k]) / (2 * bb.e[k]); lo_, hi_ = kw["lo"], kw["hi"]
            if not lo_ <= q <= hi_: E.append(f"RÀNG BUỘC {tag}: tỉ lệ {q:.2f} ngoài [{lo_},{hi_}]")
        elif kind == "same_y":
            if abs(ba.c[1] - bb.c[1]) > 0.03: E.append(f"RÀNG BUỘC {tag}: lệch Y {ba.c[1]-bb.c[1]:+.2f}")
    # ---- báo cáo
    ok = not E
    L = [f"## Báo cáo mb — {'ĐẠT các kiểm tra tự động' if ok else 'CÓ LỖI'} ({n} part, {len(cs)} cụm liền, bbox {ext[0]:.2f}×{ext[1]:.2f}×{ext[2]:.2f} stud = {ext[0]*stud_cm:.0f}×{ext[1]*stud_cm:.0f}×{ext[2]*stud_cm:.0f} cm)"]
    if dims_rows:
        L += ["", "| mục | giá trị | khoảng thật (cm) | |", "|---|---|---|---|"] + [f"| {r[0]} | {r[1]} | {r[2]} | {r[3]} |" for r in dims_rows]
    for t, arr in (("ERROR", E), ("WARN", W), ("INFO", I)):
        for x in arr: L.append(f"- **{t}** {x}")
    L.append("- Số liệu ĐẠT ≠ đẹp: vẫn phải xem ảnh views.png (trước/sau/bên/trên/3-4) và đối chiếu ảnh mẫu.")
    return {"errors": E, "warnings": W, "info": I, "md": "\n".join(L), "bbox": ext.tolist(), "parts": n, "clusters": len(cs), "dims": dims_rows}
