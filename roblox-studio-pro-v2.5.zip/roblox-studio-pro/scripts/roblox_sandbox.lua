--[[ Sandbox test model trong Roblox Studio (chạy ở Command Bar hoặc plugin, edit mode).

Cách dùng: đổi MODEL_PATH rồi chạy. Script:
  1. Clone model vào Workspace._QA_Sandbox, đặt lên sàn lưới cách xa map thật (không đụng map).
  2. Đặt rig R15 tham chiếu cao ~5 studs cạnh model để so tỉ lệ.
  3. Kiểm tra: MeshPart thiếu DoubleSided, part trôi (không Anchored, không weld), mesh/texture
     chưa tải, part trong suốt hoặc nằm dưới sàn, CanCollide quá nặng, PrimaryPart, kích thước tổng.
  4. In báo cáo; gọi QA.light("day"|"sunset"|"night") và QA.view("front"|"back"|"iso"|"iso_back"|"top"|"low")
     để đổi ánh sáng/góc nhìn rồi chụp màn hình. QA.clean() xoá sandbox và khôi phục Lighting.
]]
local MODEL_PATH = "Workspace.MyModel" -- đổi thành đường dẫn model cần test
local ORIGIN = Vector3.new(5000, 0, 5000) -- vùng trống xa map thật

local Lighting = game:GetService("Lighting")
local ContentProvider = game:GetService("ContentProvider")

local function resolve(path)
	local cur = game
	for name in string.gmatch(path, "[^%.]+") do
		cur = (name == "game") and game or cur:FindFirstChild(name)
		assert(cur, "Không tìm thấy " .. path)
	end
	return cur
end

local QA = {}
_G.QA = QA

-- Lưu Lighting gốc để khôi phục
local saved = {}
for _, prop in ipairs({ "ClockTime", "Brightness", "Ambient", "OutdoorAmbient", "FogEnd" }) do
	saved[prop] = Lighting[prop]
end

local savedCamType = workspace.CurrentCamera.CameraType
local savedCamCF = workspace.CurrentCamera.CFrame

local old = workspace:FindFirstChild("_QA_Sandbox")
if old then old:Destroy() end
local sandbox = Instance.new("Folder")
sandbox.Name = "_QA_Sandbox"
sandbox.Parent = workspace

-- Sàn + lưới 4 studs
local floor = Instance.new("Part")
floor.Name = "QA_Floor"
floor.Anchored = true
floor.Size = Vector3.new(120, 1, 120)
floor.CFrame = CFrame.new(ORIGIN - Vector3.new(0, 0.5, 0))
floor.Color = Color3.fromRGB(110, 115, 125)
floor.Material = Enum.Material.SmoothPlastic
floor.Parent = sandbox
-- Lưới 4 studs bằng vạch mỏng (không cần texture ngoài)
for i = -15, 15 do
	for axis = 1, 2 do
		local line = Instance.new("Part")
		line.Name = "QA_GridLine"
		line.Anchored, line.CanCollide, line.CanQuery = true, false, false
		line.Color = (i == 0) and Color3.fromRGB(255, 200, 60) or Color3.fromRGB(80, 85, 95)
		line.Size = axis == 1 and Vector3.new(0.08, 0.02, 120) or Vector3.new(120, 0.02, 0.08)
		local offset = axis == 1 and Vector3.new(i * 4, 0.01, 0) or Vector3.new(0, 0.01, i * 4)
		line.Position = ORIGIN + offset
		line.Parent = floor
	end
end

-- Clone model, đặt đáy lên mặt sàn
local source = resolve(MODEL_PATH)
local model = source:Clone()
if model:IsA("BasePart") then -- cho phép test 1 MeshPart đơn lẻ
	local wrap = Instance.new("Model")
	wrap.Name = model.Name
	model.Parent = wrap
	wrap.PrimaryPart = model
	model = wrap
end
model.Parent = sandbox
local cf, size = model:GetBoundingBox()
model:PivotTo(model:GetPivot() + (ORIGIN + Vector3.new(0, size.Y / 2, 0) - cf.Position))
cf, size = model:GetBoundingBox()

-- Rig tham chiếu tỉ lệ (R15 mặc định); nếu không tạo được thì dùng khối cao 5 studs
local refPos = ORIGIN + Vector3.new(size.X / 2 + 4, 0, 0)
local okRig, rig = pcall(function()
	local r = game:GetService("Players"):CreateHumanoidModelFromDescription(
		Instance.new("HumanoidDescription"), Enum.HumanoidRigType.R15)
	r.Name = "QA_ScaleRef"
	r.Parent = sandbox
	local _, rs = r:GetBoundingBox()
	r:PivotTo(CFrame.new(refPos + Vector3.new(0, rs.Y / 2, 0)))
	r.PrimaryPart.Anchored = true
	return r
end)
if not okRig then
	local block = Instance.new("Part")
	block.Name = "QA_ScaleRef"
	block.Anchored = true
	block.Size = Vector3.new(2, 5, 1)
	block.Position = refPos + Vector3.new(0, 2.5, 0)
	block.Color = Color3.fromRGB(230, 140, 50)
	block.Parent = sandbox
end

-- Kiểm tra
local issues, parts, assets = {}, 0, {}
local function add(level, msg) table.insert(issues, string.format("[%s] %s", level, msg)) end

if not model.PrimaryPart then add("WARN", "Model chưa có PrimaryPart (PivotTo/SetPrimaryPartCFrame khó dùng)") end
for _, d in ipairs(model:GetDescendants()) do
	if d:IsA("BasePart") then
		parts += 1
		local name = d:GetFullName():gsub("^Workspace%._QA_Sandbox%.", "")
		if d:IsA("MeshPart") then
			if not d.DoubleSided then add("WARN", name .. ": DoubleSided = false (mặt sau có thể biến mất)") end
			if d.MeshId == "" then add("ERROR", name .. ": MeshId trống") else table.insert(assets, d.MeshId) end
			if d.TextureID ~= "" then table.insert(assets, d.TextureID) end
		end
		if not d.Anchored then
			local grounded = false
			for _, p in ipairs(d:GetConnectedParts(true)) do
				if p.Anchored then grounded = true break end
			end
			if not grounded then add("ERROR", name .. ": không Anchored và không weld vào part Anchored (sẽ rơi/rã)") end
		end
		if d.Transparency >= 1 then add("INFO", name .. ": trong suốt hoàn toàn (hitbox?)") end
		if d.Position.Y + d.Size.Y / 2 < ORIGIN.Y then add("ERROR", name .. ": nằm dưới mặt sàn") end
		if d.CanCollide and d:IsA("MeshPart") and d.CollisionFidelity == Enum.CollisionFidelity.PreciseConvexDecomposition then
			add("INFO", name .. ": collision PreciseConvexDecomposition (nặng); cân nhắc Hull/Box")
		end
	end
end

-- Asset có tải được không (asset mới upload có thể báo lỗi vài phút dù vẫn đúng: xác nhận bằng mắt)
local failed = {}
pcall(function()
	ContentProvider:PreloadAsync(assets, function(id, status)
		if status ~= Enum.AssetFetchStatus.Success then table.insert(failed, id) end
	end)
end)
for _, id in ipairs(failed) do add("WARN", "Asset chưa tải: " .. id .. " (kiểm tra lại bằng ảnh chụp)") end

print(string.format("== QA Roblox: %s | %d part | size %.2f x %.2f x %.2f studs (rig tham chiếu ~5 studs)",
	model.Name, parts, size.X, size.Y, size.Z))
if size.Y > 200 or size.Y < 0.2 then add("WARN", "Kích thước bất thường: kiểm tra scale import") end
for _, line in ipairs(issues) do print(line) end
print(#issues == 0 and "== Không phát hiện lỗi số liệu (vẫn phải chụp front/back để xem)" or "== Có vấn đề cần xem")

-- Ánh sáng thử
local PRESETS = {
	day = { ClockTime = 13, Brightness = 2.5, Ambient = Color3.fromRGB(90, 90, 100), OutdoorAmbient = Color3.fromRGB(140, 140, 150) },
	sunset = { ClockTime = 17.8, Brightness = 1.5, Ambient = Color3.fromRGB(90, 60, 50), OutdoorAmbient = Color3.fromRGB(120, 90, 80) },
	night = { ClockTime = 0, Brightness = 0.5, Ambient = Color3.fromRGB(30, 35, 55), OutdoorAmbient = Color3.fromRGB(50, 55, 80) },
}
function QA.light(name)
	for k, v in pairs(PRESETS[name] or PRESETS.day) do Lighting[k] = v end
end

-- Góc camera quanh model (front = nhìn vào LookVector của pivot)
local VIEWS = { front = { 0, 8 }, back = { 180, 8 }, left = { -90, 8 }, right = { 90, 8 },
	iso = { 35, 30 }, iso_back = { 215, 30 }, top = { 0, 85 }, low = { 30, -5 } }
function QA.view(name)
	local v = VIEWS[name] or VIEWS.iso
	local pivot = model:GetPivot()
	local bcf, bsize = model:GetBoundingBox()
	local dist = math.max(bsize.Magnitude * 1.2, 8)
	local yaw, pitch = math.rad(v[1]), math.rad(v[2])
	local look = pivot.LookVector * Vector3.new(1, 0, 1)
	if look.Magnitude < 1e-3 then look = Vector3.new(0, 0, -1) end
	local dir = (CFrame.fromAxisAngle(Vector3.yAxis, -yaw) * look.Unit) * math.cos(pitch) + Vector3.yAxis * math.sin(pitch)
	local cam = workspace.CurrentCamera
	cam.CameraType = Enum.CameraType.Scriptable
	cam.CFrame = CFrame.lookAt(bcf.Position + dir * dist, bcf.Position)
end

function QA.clean()
	for k, v in pairs(saved) do Lighting[k] = v end
	workspace.CurrentCamera.CameraType = savedCamType
	workspace.CurrentCamera.CFrame = savedCamCF
	sandbox:Destroy()
	print("Đã xoá _QA_Sandbox và khôi phục Lighting")
end

QA.light("day")
QA.view("iso")
