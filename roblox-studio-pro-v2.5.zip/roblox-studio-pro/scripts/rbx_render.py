#!/usr/bin/env python3
"""Render phần mềm (không cần GPU/Studio) cho scene.json của sandbox: nhiều góc nhìn, z-buffer, đổ bóng, viền part.

    python scripts/rbx_render.py scene.json out.png [--views front,back,left,right,top,bottom,iso,iso2,az=120:el=20]
        [--front=-z|+z|+x|-x] [--size 480] [--outline] [--ids] [--uniform] [--split DIR] [--frame N] [--persp]

Tên góc nhìn theo CHÍNH MODEL (front = mặt model quay về; --front chọn hướng đó trong thế giới, mặc định −Z như Roblox):
  front = đứng trước mặt nhìn vào        back = đứng sau lưng
  left  = đứng bên TRÁI model nhìn (mặt trước nằm bên TRÁI ảnh)   right = đứng bên phải (mặt trước nằm bên PHẢI ảnh)
  top   = nhìn từ trên xuống (mặt trước hướng LÊN ảnh)           bottom = từ dưới lên
  iso   = chéo trước-trái-trên       iso2 = chéo sau-phải-trên      az=A:el=E = tự chọn (A: 0 trước, 90 trái, 180 sau, 270 phải)
Hình dạng hỗ trợ: Block, Wedge, Ball, Cylinder (trục X). Mesh/Union/CornerWedge được xấp xỉ bằng hộp (có báo).
Đây là bản vẽ để KIỂM hình dạng/tỉ lệ/khe hở, không phải ảnh đẹp như Studio.
"""
import argparse
import json
import math
import os
import sys

import numpy as np
from PIL import Image, ImageDraw, ImageFont

BG = np.array([30, 33, 42], float)


def cf_mat(cf):
    return np.array([[cf[3], cf[4], cf[5]], [cf[6], cf[7], cf[8]], [cf[9], cf[10], cf[11]]], float), np.array(cf[:3], float)


# ---------------------------------------------------------------- hình học → tam giác (đỉnh, pháp tuyến đỉnh) trong không gian vật
def box_tris(h):
    V, N = [], []
    for ax in range(3):
        for s in (-1, 1):
            n = np.zeros(3); n[ax] = s
            o = [k for k in range(3) if k != ax]
            quad = []
            for a, b in [(-1, -1), (1, -1), (1, 1), (-1, 1)]:
                v = np.zeros(3); v[ax] = s * h[ax]; v[o[0]] = a * h[o[0]]; v[o[1]] = b * h[o[1]]; quad.append(v)
            V += [[quad[0], quad[1], quad[2]], [quad[0], quad[2], quad[3]]]
            N += [[n, n, n]] * 2
    return np.array(V), np.array(N)


def wedge_tris(h):
    hx, hy, hz = h
    A = (-hy, -hz); B = (-hy, hz); C = (hy, hz)  # (y,z)
    def P(x, yz): return np.array([x, yz[0], yz[1]])
    V, N = [], []
    def tri(a, b, c, n): V.append([a, b, c]); N.append([n, n, n])
    for x, nx in ((-hx, np.array([-1.0, 0, 0])), (hx, np.array([1.0, 0, 0]))):
        tri(P(x, A), P(x, B), P(x, C), nx)
    def quad(p, q, r, s, n): tri(p, q, r, n); tri(p, r, s, n)
    quad(P(-hx, A), P(hx, A), P(hx, B), P(-hx, B), np.array([0, -1.0, 0]))
    quad(P(-hx, B), P(hx, B), P(hx, C), P(-hx, C), np.array([0, 0, 1.0]))
    sn = np.array([0, hz, -hy], float); sn /= np.linalg.norm(sn)
    quad(P(-hx, A), P(hx, A), P(hx, C), P(-hx, C), sn)
    return np.array(V), np.array(N)


def ball_tris(h, nlat=14, nlon=26):
    def pt(i, j):
        th = math.pi * i / nlat; ph = 2 * math.pi * j / nlon
        u = np.array([math.sin(th) * math.cos(ph), math.cos(th), math.sin(th) * math.sin(ph)])
        return u * h, u / h / np.linalg.norm(u / h)
    V, N = [], []
    for i in range(nlat):
        for j in range(nlon):
            a, b, c, d = pt(i, j), pt(i + 1, j), pt(i + 1, j + 1), pt(i, j + 1)
            for t in ((a, b, c), (a, c, d)):
                V.append([t[0][0], t[1][0], t[2][0]]); N.append([t[0][1], t[1][1], t[2][1]])
    return np.array(V), np.array(N)


def cyl_tris(h, seg=28):
    hx, ry, rz = h
    V, N = [], []
    def ring(k, x):
        a = 2 * math.pi * k / seg
        return np.array([x, ry * math.cos(a), rz * math.sin(a)]), np.array([0, math.cos(a) / ry, math.sin(a) / rz]) / np.linalg.norm([math.cos(a) / ry, math.sin(a) / rz])
    for k in range(seg):
        a0, a1, b0, b1 = ring(k, -hx), ring(k + 1, -hx), ring(k, hx), ring(k + 1, hx)
        for t in ((a0, a1, b1), (a0, b1, b0)):
            V.append([t[0][0], t[1][0], t[2][0]]); N.append([t[0][1], t[1][1], t[2][1]])
        for x, nx in ((-hx, np.array([-1.0, 0, 0])), (hx, np.array([1.0, 0, 0]))):
            V.append([np.array([x, 0, 0]), ring(k, x)[0], ring(k + 1, x)[0]]); N.append([nx, nx, nx])
    return np.array(V), np.array(N)


def part_tris(p, notes):
    h = np.array(p["size"], float) / 2
    shp = p["shape"]
    if shp == "Wedge": return wedge_tris(h)
    if shp == "Ball": return ball_tris(h)
    if shp == "Cylinder": return cyl_tris(h)
    if shp in ("Mesh", "Union", "CornerWedge"):
        notes.add(f"{p['name']}: {shp} xấp xỉ bằng hộp")
    return box_tris(h)


# ---------------------------------------------------------------- camera
def view_basis(name, f):
    up = np.array([0, 1.0, 0]); r = np.cross(f, up)
    if name.startswith("az="):
        kv = dict(x.split("=") for x in name.split(":"))
        az, el = math.radians(float(kv.get("az", 0))), math.radians(float(kv.get("el", 20)))
        d_to_cam = math.cos(el) * (math.cos(az) * f - math.sin(az) * r) + math.sin(el) * up
        return -d_to_cam / np.linalg.norm(d_to_cam), up
    table = {
        "front": (-f, up), "back": (f, up), "right": (-r, up), "left": (r, up),
        "top": (np.array([0, -1.0, 0]), f), "bottom": (np.array([0, 1.0, 0]), f),
    }
    if name in table: return table[name]
    if name == "iso": d = -(0.62 * f - 0.62 * r + 0.55 * up)
    elif name == "iso2": d = -(-0.62 * f + 0.62 * r + 0.55 * up)
    else: sys.exit(f"góc nhìn không biết: {name}")
    return d / np.linalg.norm(d), up


def basis(d, up_hint):
    d = d / np.linalg.norm(d)
    right = np.cross(d, up_hint); right /= np.linalg.norm(right)
    up = np.cross(right, d)
    return right, up, d


# ---------------------------------------------------------------- rasterizer
def render_view(tris, normals, colors, meta, name, front, size, ss, outline, persp, uniform_scale=None):
    d, uph = view_basis(name, front)
    R, U, D = basis(d, uph)
    allv = tris.reshape(-1, 3)
    c0 = (allv.min(0) + allv.max(0)) / 2
    rel = allv - c0
    sx, sy, sz = rel @ R, rel @ U, rel @ D
    ext_x, ext_y = sx.max() - sx.min(), sy.max() - sy.min()
    if uniform_scale: scale = uniform_scale
    else: scale = 0.86 * size / max(ext_x, ext_y, 1e-6)
    W = H = size * ss
    cx, cy = (sx.max() + sx.min()) / 2, (sy.max() + sy.min()) / 2
    S = scale * ss
    def to_screen(P):
        q = P - c0
        x = (q @ R - cx) * S + W / 2
        y = H / 2 - (q @ U - cy) * S
        z = q @ D
        return x, y, z
    nt = len(tris)
    X, Y, Z = to_screen(tris.reshape(-1, 3))
    X, Y, Z = X.reshape(nt, 3), Y.reshape(nt, 3), Z.reshape(nt, 3)
    # ánh sáng cố định trong KHÔNG GIAN CAMERA để mọi góc nhìn có độ sáng tương đương
    Lc = np.array([-0.45, 0.65, -0.62]); Lc /= np.linalg.norm(Lc)   # (phải, lên, hướng nhìn) → ánh sáng từ trên-trái-phía camera
    Fc = np.array([0.6, -0.1, -0.5]); Fc /= np.linalg.norm(Fc)
    nflat = normals.reshape(-1, 3)
    nc = np.stack([nflat @ R, nflat @ U, nflat @ D], 1).reshape(nt, 3, 3)
    mat = meta["material"]; neon = np.array([m == "Neon" for m in mat]); metal = np.array([m in ("Metal", "DiamondPlate", "CorrodedMetal", "Foil") for m in mat])
    refl = np.array(meta["reflectance"])
    col = np.zeros((nt, 3, 3))
    key = np.clip((nc * Lc).sum(2), 0, None); fill = np.clip((nc * Fc).sum(2), 0, None)
    lum = 0.34 + 0.62 * key + 0.16 * fill
    spec = np.clip(-(nc[:, :, 2]), 0, 1) ** 24 * (0.10 + 0.5 * (metal | (refl > 0.1)))[:, None]
    for k in range(3):
        base = colors[:, k][:, None]
        col[:, :, k] = np.where(neon[:, None], np.minimum(1.0, base * 1.12 + 0.05), np.clip(base * lum + spec, 0, 1))
    zbuf = np.full((H, W), np.inf)
    img = np.tile((BG / 255.0), (H, W, 1))
    idb = np.full((H, W), -1, np.int32)
    alpha = 1 - np.array(meta["transparency"])
    pid = np.array(meta["pid"])
    def raster(i, writez, blend):
        xs, ys, zs = X[i], Y[i], Z[i]
        x0, x1 = int(max(0, math.floor(xs.min()))), int(min(W - 1, math.ceil(xs.max())))
        y0, y1 = int(max(0, math.floor(ys.min()))), int(min(H - 1, math.ceil(ys.max())))
        if x1 < x0 or y1 < y0: return
        den = (ys[1] - ys[2]) * (xs[0] - xs[2]) + (xs[2] - xs[1]) * (ys[0] - ys[2])
        if abs(den) < 1e-12: return
        gx, gy = np.meshgrid(np.arange(x0, x1 + 1) + 0.5, np.arange(y0, y1 + 1) + 0.5)
        l0 = ((ys[1] - ys[2]) * (gx - xs[2]) + (xs[2] - xs[1]) * (gy - ys[2])) / den
        l1 = ((ys[2] - ys[0]) * (gx - xs[2]) + (xs[0] - xs[2]) * (gy - ys[2])) / den
        l2 = 1 - l0 - l1
        m = (l0 >= -1e-6) & (l1 >= -1e-6) & (l2 >= -1e-6)
        if not m.any(): return
        z = l0 * zs[0] + l1 * zs[1] + l2 * zs[2]
        sub = zbuf[y0:y1 + 1, x0:x1 + 1]
        m &= z < sub - 1e-9
        if not m.any(): return
        c = l0[..., None] * col[i, 0] + l1[..., None] * col[i, 1] + l2[..., None] * col[i, 2]
        imsub = img[y0:y1 + 1, x0:x1 + 1]
        if blend:
            a = alpha[i]
            imsub[m] = imsub[m] * (1 - a) + c[m] * a
        else:
            imsub[m] = c[m]
            idb[y0:y1 + 1, x0:x1 + 1][m] = pid[i]
        if writez: sub[m] = z[m]
    opaque = [i for i in range(nt) if alpha[i] >= 0.999]
    trans = sorted([i for i in range(nt) if alpha[i] < 0.999], key=lambda i: -Z[i].mean())
    for i in opaque: raster(i, True, False)
    for i in trans: raster(i, False, True)
    if outline:
        e = np.zeros((H, W), bool)
        e[:, :-1] |= idb[:, :-1] != idb[:, 1:]
        e[:-1, :] |= idb[:-1, :] != idb[1:, :]
        e &= (idb >= 0) | np.roll(idb >= 0, 1, 1)
        img[e] = img[e] * 0.38
    out = Image.fromarray((np.clip(img, 0, 1) * 255).astype(np.uint8))
    if ss > 1: out = out.resize((size, size), Image.LANCZOS)
    return out, (ext_x, ext_y), idb, (R, U, D, c0, cx, cy, S, W, H)


def font(sz):
    for f in ("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "DejaVuSans.ttf", "arial.ttf"):
        try: return ImageFont.truetype(f, sz)
        except OSError: pass
    return ImageFont.load_default()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("scene"); ap.add_argument("out")
    ap.add_argument("--views", default="front,left,top,iso")
    ap.add_argument("--front", default="-z")
    ap.add_argument("--size", type=int, default=480)
    ap.add_argument("--ss", type=int, default=2)
    ap.add_argument("--outline", action="store_true"); ap.add_argument("--ids", action="store_true")
    ap.add_argument("--uniform", action="store_true"); ap.add_argument("--persp", action="store_true")
    ap.add_argument("--split"); ap.add_argument("--frame", type=int)
    a = ap.parse_args()
    scene = json.load(open(a.scene, encoding="utf-8"))
    fdir = {"-z": (0, 0, -1), "+z": (0, 0, 1), "+x": (1, 0, 0), "-x": (-1, 0, 0)}[a.front]
    front = np.array(fdir, float)
    views = a.views.split(",")
    frames = scene["frames"]
    if a.frame is not None: frames = [frames[a.frame]]
    elif len(frames) > 1:
        views = views[:1] if len(views) > 1 else views
    notes = set()
    panels = []
    for fi, fr in enumerate(frames):
        parts = fr["parts"]
        if not parts: sys.exit("scene rỗng")
        T, Nn, C, mats, trs, refl, pids = [], [], [], [], [], [], []
        for pi, p in enumerate(parts):
            V, N = part_tris(p, notes)
            Rm, t = cf_mat(p["cf"])
            if p.get("mesh") and p["mesh"]["type"] != "FileMesh":
                sc = np.array(p["mesh"]["scale"], float)
                if p["mesh"]["type"] == "Head": pass
            Vw = V @ Rm.T + t; Nw = N @ Rm.T
            T.append(Vw); Nn.append(Nw)
            C += [p["color"]] * len(V); mats += [p["material"]] * len(V); trs += [p["transparency"]] * len(V); refl += [p["reflectance"]] * len(V); pids += [pi] * len(V)
        for m in fr.get("meshes", []) if isinstance(fr, dict) else []:
            pass
        T = np.concatenate(T); Nn = np.concatenate(Nn); C = np.array(C, float)
        meta = {"material": mats, "transparency": trs, "reflectance": refl, "pid": pids}
        uni = None
        if a.uniform:
            d = (T.reshape(-1, 3).max(0) - T.reshape(-1, 3).min(0)); uni = 0.8 * a.size / float(np.linalg.norm(d))
        row = []
        for v in views:
            im, ext, idb, proj = render_view(T, Nn, C, meta, v, front, a.size, a.ss, a.outline, a.persp, uni)
            dr = ImageDraw.Draw(im)
            dr.text((8, 6), v + (f"  t={fr['t']:.2f}s" if len(frames) > 1 else ""), fill=(220, 224, 235), font=font(15))
            dr.text((8, a.size - 20), f"{ext[0]:.1f} × {ext[1]:.1f} studs", fill=(140, 148, 168), font=font(13))
            if a.ids:
                R, U, D, c0, cx, cy, S, W, H = proj
                for pi, p in enumerate(parts):
                    q = np.array(p["cf"][:3]) - c0
                    x = ((q @ R - cx) * S + W / 2) / (W / a.size); y = (H / 2 - (q @ U - cy) * S) / (H / a.size)
                    dr.text((x - 4, y - 6), str(pi), fill=(255, 255, 255), font=font(11), stroke_width=1, stroke_fill=(0, 0, 0))
            row.append((v, im))
            if a.split:
                os.makedirs(a.split, exist_ok=True)
                im.save(os.path.join(a.split, f"{v.replace(':', '_').replace('=', '')}{'' if len(frames) == 1 else f'_f{fi}'}.png"))
        panels.append(row)
    cols = max(len(r) for r in panels)
    flat = [im for r in panels for _, im in r]
    ncol = cols if len(frames) == 1 else min(4, len(flat))
    nrow = math.ceil(len(flat) / ncol)
    sheet = Image.new("RGB", (ncol * a.size, nrow * a.size), tuple(int(x) for x in BG))
    for i, im in enumerate(flat):
        sheet.paste(im, ((i % ncol) * a.size, (i // ncol) * a.size))
    sheet.save(a.out)
    print(f"[OK] {a.out}  ({len(flat)} ảnh, {len(parts)} part)")
    for n in sorted(notes)[:8]: print("  ~", n)
    if a.ids:
        for pi, p in enumerate(frames[-1]["parts"]): print(f"  #{pi}: {p['path']} ({p['shape']}, {p['size']})")


if __name__ == "__main__":
    main()
