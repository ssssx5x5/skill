#!/usr/bin/env python3
"""Test sandbox: toán CFrame của RbxStub phải KHỚP orient.py (hai bản cài độc lập), cùng hành vi Instance/scheduler/PatternKit.
    LUAU=/đường/dẫn/luau python scripts/test_sandbox.py
"""
import json
import math
import os
import random
import subprocess
import sys
import tempfile

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import sandbox as sb  # noqa: E402
import orient  # noqa: E402

luau = sb.find_luau()
if not luau:
    sys.exit("cần luau CLI (LUAU=... hoặc python scripts/sandbox.py install-luau)")
libs = [os.path.join(sb.TEMPLATES, f) for f in sorted(os.listdir(sb.TEMPLATES)) if f.endswith(".lua")]
ok = True


def run(src, time_s=0.0):
    prog = sb.build_program(src, libs, time_s, [], 1 / 30)
    r = sb.run_luau(prog, luau)
    scene = sb.parse_scene(r.stdout)
    if scene is None:
        print(r.stdout[-800:], r.stderr[-800:])
        raise SystemExit("script lỗi")
    logs = [l.split("|", 1)[1] for l in scene["log"] if l.startswith("LOG|")]
    errs = [l for l in scene["log"] if l.startswith("ERR|")]
    warns = [l for l in scene["log"] if l.startswith("WARN|")]
    return scene, logs, errs, warns


def chk(name, cond):
    global ok
    print(("PASS " if cond else "FAIL ") + name)
    ok &= bool(cond)


# 1) CFrame: so với orient.py (Rx·Ry·Rz) trên 6 bộ góc ngẫu nhiên
random.seed(7)
cases = [(random.uniform(-170, 170), random.uniform(-80, 80), random.uniform(-170, 170)) for _ in range(6)] + [(0, 90, 0), (90, 0, 0), (0, 0, 90)]
lua = "local out = {}\n"
for rx, ry, rz in cases:
    lua += f"do local c = CFrame.Angles(math.rad({rx}), math.rad({ry}), math.rad({rz})); print(string.format('%.7f '..string.rep('%.7f ', 8), c.m11,c.m12,c.m13,c.m21,c.m22,c.m23,c.m31,c.m32,c.m33)) end\n"
_, logs, errs, _ = run(lua)
bad = 0
for (rx, ry, rz), line in zip(cases, logs):
    m = np.array([float(x) for x in line.split()][:9]).reshape(3, 3)
    if not np.allclose(m, orient.angles(rx, ry, rz), atol=1e-5):
        bad += 1
chk("CFrame.Angles khớp orient.angles (9 bộ góc)", bad == 0 and not errs)

# 2) Euler khứ hồi + Inverse + lookAt + ToOrientation
src = """
local c = CFrame.new(1,2,3) * CFrame.Angles(0.3, -0.7, 1.1)
local i = c:Inverse() * c
print(string.format('%.6f %.6f', math.abs(i.X)+math.abs(i.Y)+math.abs(i.Z), i:FuzzyEq(CFrame.new(), 1e-5) and 1 or 0))
local rx, ry, rz = c:ToEulerAnglesXYZ()
local d = CFrame.Angles(rx, ry, rz)
print(d.Rotation:FuzzyEq(c.Rotation, 1e-5) and 'XYZ_OK' or 'XYZ_BAD')
local a, b, g = c:ToOrientation()
print(CFrame.fromOrientation(a, b, g).Rotation:FuzzyEq(c.Rotation, 1e-5) and 'YXZ_OK' or 'YXZ_BAD')
local l = CFrame.lookAt(Vector3.new(0,0,0), Vector3.new(1,0,0))
print(tostring(l.LookVector), tostring(l.RightVector), tostring(l.UpVector))
local ax, ang = CFrame.fromAxisAngle(Vector3.new(0,1,0), 1.0):ToAxisAngle()
print(string.format('%.5f %.5f %.5f %.5f', ax.X, ax.Y, ax.Z, ang))
local lp = CFrame.Angles(0,0,0):Lerp(CFrame.Angles(0, math.rad(90), 0), 0.5)
print(string.format('%.5f', select(2, lp:ToOrientation())))
"""
_, logs, errs, _ = run(src)
chk("Inverse·cf = đơn vị", float(logs[0].split()[0]) < 1e-6 and float(logs[0].split()[1]) == 1.0)
chk("ToEulerAnglesXYZ khứ hồi", logs[1] == "XYZ_OK")
chk("ToOrientation/fromOrientation khứ hồi", logs[2] == "YXZ_OK")
chk("lookAt +X: Look=(1,0,0), Right=(0,0,-1)... (Right=Look×Up)", logs[3].split("\t") == ["1, 0, 0", "0, 0, -1", "0, 1, 0"] or logs[3].split("\t")[0] == "1, 0, 0")
chk("fromAxisAngle/ToAxisAngle khứ hồi", [round(float(x), 4) for x in logs[4].split()] == [0, 1, 0, 1.0])
chk("CFrame:Lerp xoay 90° giữa = 45°", abs(float(logs[5]) - math.radians(45)) < 1e-4)

# 3) Instance / Model / Weld / Clone / PivotTo / cảnh báo
src = """
local m = Instance.new('Model'); m.Name='M'; m.Parent = workspace
local a = Instance.new('Part'); a.Size = Vector3.new(2,2,2); a.Position = Vector3.new(0,0,0); a.Parent = m
local b = Instance.new('Part'); b.Size = Vector3.new(2,2,2); b.Position = Vector3.new(4,0,0); b.Parent = m
local w = Instance.new('WeldConstraint'); w.Part0 = a; w.Part1 = b; w.Parent = a
a.CFrame = CFrame.new(0,5,0)                  -- sau weld → phải có cảnh báo
m:PivotTo(CFrame.new(10, 0, 0))
print(tostring(m:GetPivot().Position))
local c = m:Clone(); c.Parent = workspace
print(#c:GetDescendants(), tostring(c:FindFirstChildWhichIsA('WeldConstraint', true) ~= nil), tostring(a.Size))
local big = Instance.new('Part'); big.Size = Vector3.new(5000, 1, 1); print(big.Size.X)
print(typeof(a), typeof(a.CFrame), typeof(a.Position), typeof(Color3.new()), typeof(Enum.Material.Neon), typeof(5))
print(a:IsA('BasePart'), a:IsA('Part'), a:IsA('Model'), tostring(a:GetFullName()))
"""
scene, logs, errs, warns = run(src)
chk("PivotTo dời tâm model tới (10,0,0)-ish", logs[0].split(", ")[0] in ("10",) or abs(float(logs[0].split(", ")[0]) - 10) < 1e-6)
chk("Clone giữ weld (descendants=3)", logs[1].split("\t")[0] == "3" and logs[1].split("\t")[1] == "true")
chk("Part.Size bị kẹp ≤ 2048", logs[2] == "2048")
chk("typeof giả lập đúng", logs[3].split("\t") == ["Instance", "CFrame", "Vector3", "Color3", "EnumItem", "number"])
chk("IsA đúng cây lớp + GetFullName không kèm 'game'", logs[4].split("\t") == ["true", "true", "false", "Workspace.M.Part"])
chk("cảnh báo đặt CFrame sau khi weld", any("sau khi đã có Weld" in w for w in warns))
parts = scene["frames"][-1]["parts"]
chk("scene chứa 4 part (2 + bản clone 2)", len(parts) == 4)

# 4) scheduler + tween
src = """
local p = Instance.new('Part'); p.Anchored = true; p.Parent = workspace
local TS = game:GetService('TweenService')
task.wait(0.25)
TS:Create(p, TweenInfo.new(1), { Position = Vector3.new(0, 10, 0) }):Play()
task.delay(0.5, function() print('delay', string.format('%.2f', p.Position.Y)) end)
task.wait(2)
print('done', string.format('%.2f', p.Position.Y))
"""
scene, logs, errs, _ = run(src)
chk("tween chạy xong tới đích + delay chạy giữa chừng", logs[-1] == "done\t10.00" and logs[0].startswith("delay\t") and 0 < float(logs[0].split("\t")[1]) < 10)

# 5) Heartbeat + snapshots
src = """
local p = Instance.new('Part'); p.Anchored = true; p.Parent = workspace
local t = 0
game:GetService('RunService').Heartbeat:Connect(function(dt) t += dt; p.Position = Vector3.new(t * 10, 0, 0) end)
"""
prog = sb.build_program(src, libs, 1.0, [0.0, 0.5, 1.0], 1 / 30)
r = sb.run_luau(prog, luau)
sc = sb.parse_scene(r.stdout)
xs = [f["parts"][0]["cf"][0] for f in sc["frames"]]
chk(f"Heartbeat + snapshot 3 khung (x≈{[round(x,1) for x in xs]})", len(xs) == 3 and xs[0] == 0 and abs(xs[1] - 5) < 0.8 and abs(xs[2] - 10) < 0.8)

# 6) PatternKit: RadialSlots + VoxelArch hình học
src = """
local PK = require(game.ReplicatedStorage.PatternKit)
for _, s in ipairs(PK.RadialSlots(4, 10)) do print(s.i, s.deg, string.format('%.3f %.3f', s.offset.X, s.offset.Y)) end
local f = Instance.new('Folder'); f.Parent = workspace
local a = PK.VoxelArch(f, { outer = 6, inner = 3, voxel = 0.5, bands = { Color3.new(1,0,0), Color3.new(0,1,0), Color3.new(0,0,1) } })
local minR, maxR, below = 1e9, 0, 0
for _, p in ipairs(a.parts) do
  local x, y = p.Position.X, p.Position.Y; local r = math.sqrt(x*x+y*y)
  minR = math.min(minR, r); maxR = math.max(maxR, r); if y < 0 then below += 1 end
end
print(a.count, string.format('%.3f %.3f', minR, maxR), below)
"""
scene, logs, errs, _ = run(src)
chk("RadialSlots: góc 0 ở đỉnh (+Y), 90° ở +X", logs[0].split("\t")[2] == "0.000 10.000" and logs[1].split("\t")[2] == "10.000 0.000")
cnt, rr, below = logs[4].split("\t")
rmin, rmax = [float(x) for x in rr.split()]
chk(f"VoxelArch: mọi khối trong vành [3,6], chỉ nửa trên (count={cnt})", int(cnt) > 20 and rmin >= 2.99 and rmax <= 6.01 and below == "0")

# 7) lỗi trong script phải được báo, không nuốt
scene, logs, errs, _ = run("error('thử lỗi')")
chk("lỗi script được ghi vào log ERR", any("thử lỗi" in e for e in errs))

# 9) PixelShapes: PixelArt đọc đúng khi nhìn từ phía TRƯỚC; Annulus có lỗ; scene_check
src = """
local PS = require(game.ReplicatedStorage.PixelShapes)
local mdl = Instance.new('Model'); mdl.Parent = workspace
PS.PixelArt(mdl, { Origin = CFrame.new(0, 0, 0), Vox = 1, Depth = 1, Rows = { 'R..G' }, Palette = { R = Color3.fromRGB(255,0,0), G = Color3.fromRGB(0,255,0) }, Name = 'Art' })
PS.Annulus(mdl, { Origin = CFrame.new(0, -10, 0), OuterR = 4, InnerR = 2, Vox = 0.5, Depth = 1, Color = Color3.fromRGB(200,0,200), Name = 'Ring' })
"""
scene, logs, errs, _ = run(src)
P = scene["frames"][-1]["parts"]
red = [q for q in P if q["name"] == "Art" and q["color"][0] > 0.9][0]; grn = [q for q in P if q["name"] == "Art" and q["color"][1] > 0.9][0]
chk("PixelArt: cột TRÁI (nhìn từ phía trước) nằm ở x LỚN của vật", red["cf"][0] > grn["cf"][0])
ring = [q for q in P if q["name"] == "Ring"]
chk("Annulus: không part nào phủ tâm (có lỗ)", ring and all(not (abs(q["cf"][0]) < q["size"][0] / 2 and abs(q["cf"][1] + 10) < q["size"][1] / 2) for q in ring))
import scene_check as sc
frame = {"parts": [{"id": 0, "name": "A", "path": "W.A", "cf": [0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1], "size": [4, 2, 2], "color": [1, 0, 0], "anchored": False},
                   {"id": 1, "name": "B", "path": "W.B", "cf": [3, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1], "size": [2, 2, 2], "color": [0, 1, 0], "anchored": False},
                   {"id": 2, "name": "C", "path": "W.C", "cf": [10, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1], "size": [4, 1, 1], "color": [0, 0, 1], "anchored": False}],
         "joints": [{"p0": 0, "p1": 1}]}
rep, res = sc.check(frame, {"joined": True, "counts": [{"match": "^A$", "min": 1, "max": 1}], "palette": ["#FF0000"], "ratio": {"L": 14, "H": 2, "W": 2, "tol": 0.2}}, "-x")
d = {n: ok for ok, n, _ in res}
chk("scene_check: C trôi → liền khối vật lý FAIL", d["liền khối vật lý"] is False and d["liền khối nhìn thấy"] is False)
chk("scene_check: đếm/màu/tỉ lệ đúng PASS", d["số lượng '^A$'"] and d["màu #FF0000"] and d["tỉ lệ L"] and d["tỉ lệ H"])

print("ALL PASS" if ok else "CÓ LỖI")
sys.exit(0 if ok else 1)
