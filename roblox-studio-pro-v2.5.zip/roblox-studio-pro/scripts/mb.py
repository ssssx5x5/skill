#!/usr/bin/env python3
"""Model Builder (mb) — dựng model bằng QUAN HỆ (gắn/đặt lên/căn mép/đối xứng/xoay quanh pivot) thay vì tự tính toạ độ.

Lý do: AI sai chỗ/sai xoay/sai tỉ lệ vì tự cộng trừ toạ độ. Ở đây vị trí và hướng của mỗi part được TÍNH từ part khác;
một file mô tả → 3 đầu ra cùng hình học: scene.json (render + scene_check), Luau (Roblox), bpy (Blender), kèm báo cáo kiểm.

    from mb import Model
    m = Model("Ten", style="realistic")           # style: realistic|stylized|chibi|exaggerated (nới dung sai kích thước)
    a = m.box("Day", (4, 0.5, 4), at=(0, 0.25, 0))                    # at = tâm (stud), trục Roblox: +X phải, +Y lên, -Z trước
    b = m.on(m.box("Than", (1, 3, 1)), a, "top")                      # đặt Than LÊN mặt trên của Day, tự tính vị trí
    c = m.on(m.box("Bien", (0.2, 1, 3)), b, "right", align=(0, -1))   # gắn vào mặt phải, căn mép dưới
    m.save("out/")                                                    # scene.json, build.lua, blender.py, report.md, ảnh

Quy ước: đơn vị stud (1 stud = Model.stud_cm cm, mặc định 35; dùng m.cm(x) đổi cm→stud). Euler (độ) = CFrame.Angles = Rx·Ry·Rz.
Lệnh:  python scripts/mb.py selftest   |   python scripts/mb.py check scene.json [--family F]   |   python scripts/mb.py blender-map
"""
import argparse
import importlib.util
import json
import math
import os
import subprocess
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
FACES = {"right": (0, 1), "left": (0, -1), "top": (1, 1), "bottom": (1, -1), "back": (2, 1), "front": (2, -1)}
# Blender: (bx,by,bz) = (-rx, rz, ry)  — det = +1, trước Roblox (-Z) → trước Blender (-Y)
MAP = np.array([[-1, 0, 0], [0, 0, 1], [0, 1, 0]], float)
MATERIAL_PBR = {  # Enum.Material → (roughness, metallic)
    "Plastic": (0.45, 0.0), "SmoothPlastic": (0.3, 0.0), "Wood": (0.7, 0.0), "WoodPlanks": (0.7, 0.0), "Metal": (0.35, 1.0),
    "DiamondPlate": (0.35, 1.0), "CorrodedMetal": (0.6, 0.8), "Foil": (0.15, 1.0), "Neon": (0.3, 0.0), "Glass": (0.05, 0.0),
    "Concrete": (0.9, 0.0), "Brick": (0.85, 0.0), "Granite": (0.6, 0.0), "Marble": (0.2, 0.0), "Slate": (0.7, 0.0), "Fabric": (0.95, 0.0),
    "Grass": (0.95, 0.0), "Sand": (1.0, 0.0), "Ice": (0.1, 0.0), "Cobblestone": (0.85, 0.0), "Rock": (0.9, 0.0), "Pebble": (0.9, 0.0),
    "Ground": (1.0, 0.0), "Snow": (0.9, 0.0), "Asphalt": (0.9, 0.0), "Mud": (1.0, 0.0), "Leather": (0.6, 0.0), "Rubber": (0.8, 0.0),
}


def rx(a): c, s = math.cos(a), math.sin(a); return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])
def ry(a): c, s = math.cos(a), math.sin(a); return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])
def rz(a): c, s = math.cos(a), math.sin(a); return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])


def euler(d):
    """CFrame.Angles(rx,ry,rz) (độ) = Rx·Ry·Rz."""
    a, b, c = (math.radians(v) for v in d)
    return rx(a) @ ry(b) @ rz(c)


def axis_angle(axis, deg):
    k = np.array(axis, float); k /= np.linalg.norm(k); a = math.radians(deg)
    K = np.array([[0, -k[2], k[1]], [k[2], 0, -k[0]], [-k[1], k[0], 0]])
    return np.eye(3) + math.sin(a) * K + (1 - math.cos(a)) * K @ K


def look_rot(direction, local_axis=2, up=(0, 1, 0)):
    """Ma trận R sao cho trục cục bộ `local_axis` (0=X,1=Y,2=Z) của part chỉ theo `direction`; trục còn lại bám `up`."""
    d = np.array(direction, float); d /= np.linalg.norm(d)
    u = np.array(up, float)
    if abs(d @ u) > 0.999: u = np.array([1.0, 0, 0]) if abs(d[0]) < 0.9 else np.array([0, 0, 1.0])
    a = np.cross(u, d); a /= np.linalg.norm(a); b = np.cross(d, a)  # a×b = d, thuận tay phải
    cols = {2: (a, b, d), 0: (d, a, b), 1: (b, d, a)}[local_axis]
    # kiểm: cols phải thuận tay phải (X×Y=Z)
    R = np.stack(cols, 1)
    if np.linalg.det(R) < 0: R[:, 0] *= -1
    return R


def cf_list(pos, R):
    return [float(x) for x in list(pos) + list(R.reshape(-1))]


class Part:
    def __init__(self, name, shape, size, pos, R, color, material, transparency=0.0, anchored=True, group="", tex=None):
        self.name, self.shape = name, shape
        self.size = np.array(size, float); self.pos = np.array(pos, float); self.R = np.array(R, float)
        self.color, self.material, self.transparency, self.anchored = color, material, transparency, anchored
        self.group, self.tex = group, tex
        self.parent = None          # part cha (weld)
        self.tags = set(); self.ref = False; self.anchors = {}
        self.notes = []; self.cyl_axis = "x"

    def eff(self):
        """(size, R) theo quy ước Roblox cho backend: trụ có trục tròn gốc là X. Khung người dùng giữ size THEO TRỤC THẾ GIỚI (cyl y → (d, dài, d))."""
        if self.shape == "Cylinder" and self.cyl_axis != "x":
            L = self.size["xyz".index(self.cyl_axis)]; d = self.size[{"y": 0, "z": 0}[self.cyl_axis]]
            Rm = rz(math.pi / 2) if self.cyl_axis == "y" else ry(math.pi / 2)
            return np.array([L, d, d]), self.R @ Rm
        return self.size, self.R

    @property
    def half(self): return self.size / 2

    def extent(self):
        """Nửa kích thước bao AABB thế giới."""
        return np.abs(self.R) @ self.half

    def local_extent_in(self, R_frame):
        """Nửa kích thước part dọc các trục của khung R_frame (cột = trục)."""
        return np.abs(R_frame.T @ self.R) @ self.half

    def world(self, local): return self.pos + self.R @ np.array(local, float)

    def anchor(self, name):
        if name in self.anchors: lp, ln = self.anchors[name]
        elif name == "center": lp, ln = np.zeros(3), np.zeros(3)
        elif name in FACES:
            i, s = FACES[name]; ln = np.zeros(3); ln[i] = s; lp = ln * self.half[i]
        else: raise KeyError(f"{self.name}: anchor '{name}' không có (có: {list(FACES)+['center']+list(self.anchors)})")
        return self.world(lp), self.R @ np.array(ln, float)


class Model:
    def __init__(self, name="Model", style="realistic", stud_cm=35.0, front="-z"):
        self.name, self.style, self.stud_cm, self.front = name, style, float(stud_cm), front
        self.parts = []; self._grp = []; self.family = None; self.features = {}; self.expects = []
        self.symmetry = None; self.max_parts = 1500; self._names = {}
        self.textures = {}

    # ------------------------------------------------------------------ đơn vị
    def cm(self, v): return v / self.stud_cm
    def to_cm(self, v): return v * self.stud_cm

    # ------------------------------------------------------------------ tạo part
    def _unique(self, name):
        full = ".".join(self._grp + [name]) if self._grp else name
        n = self._names.get(full, 0); self._names[full] = n + 1
        return (name if n == 0 else f"{name}{n + 1}")

    def add(self, name, shape, size, at=None, rot=(0, 0, 0), color="#A3A2A5", material="Plastic", transparency=0.0, anchored=True, tex=None):
        size = np.maximum(np.array(size, float), 0.05)
        col = color if isinstance(color, str) else "#%02X%02X%02X" % tuple(int(round(x * 255)) for x in color)
        p = Part(self._unique(name), shape, size, at if at is not None else (0, 0, 0), euler(rot), col, material, transparency, anchored, ".".join(self._grp), tex)
        self.parts.append(p)
        for g in self._gstack_parts: g.append(p)
        return p

    _gstack_parts = ()
    def box(self, name, size, **k): return self.add(name, "Block", size, **k)
    def ball(self, name, d, **k): return self.add(name, "Ball", (d, d, d), **k)
    def cyl(self, name, length, d, axis="y", **k):
        """Trụ đường kính d, dài length, trục theo `axis` (x|y|z) của khung part. size lưu theo trục thế giới nên on()/mặt top/bottom đúng như hộp."""
        sz = {"x": (length, d, d), "y": (d, length, d), "z": (d, d, length)}[axis]
        p = self.add(name, "Cylinder", sz, **k); p.cyl_axis = axis
        return p
    def wedge(self, name, size, **k): return self.add(name, "Wedge", size, **k)

    def group(self, name):
        m = self
        class G:
            def __enter__(s):
                m._grp.append(name); s.parts = []
                m._gstack_parts = tuple(m._gstack_parts) + (s.parts,); return s.parts
            def __exit__(s, *a):
                m._grp.pop(); m._gstack_parts = tuple(m._gstack_parts)[:-1]
        return G()

    def custom_anchor(self, part, name, local_pos, local_normal=(0, 1, 0)):
        part.anchors[name] = (np.array(local_pos, float), np.array(local_normal, float)); return part

    # ------------------------------------------------------------------ đặt theo quan hệ
    def on(self, child, parent, face="top", align=(0, 0), off=(0, 0), gap=0.0, rot=(0, 0, 0), weld=True):
        """Đặt `child` NGOÀI mặt `face` của `parent` (top/bottom/left/right/front/back), hướng = hướng parent·rot.
        align=(u,v): căn 2 trục tiếp tuyến theo thứ tự trục cục bộ còn lại của parent; -1 = mép nhỏ, 0 = giữa, +1 = mép lớn.
        off=(du,dv): dịch thêm (stud) theo 2 trục đó. gap>0 hở, gap<0 chìm vào (nối chắc, tránh khe)."""
        i, s = FACES[face]
        Rp = parent.R; Rc = Rp @ euler(rot); child.R = Rc
        hp = parent.half; hc = child.local_extent_in(Rp)
        tang = [k for k in range(3) if k != i]
        loc = np.zeros(3)
        loc[i] = s * (hp[i] + hc[i] + gap)
        for n, k in enumerate(tang):
            loc[k] = align[n] * (hp[k] - hc[k]) + off[n]
        child.pos = parent.pos + Rp @ loc
        if weld: child.parent = parent
        return child

    def inside(self, child, parent, align=(0, 0, 0), off=(0, 0, 0), rot=(0, 0, 0), weld=True):
        """Đặt child BÊN TRONG parent (3 trục), align -1/0/+1 theo trục cục bộ parent."""
        Rp = parent.R; child.R = Rp @ euler(rot)
        hp = parent.half; hc = child.local_extent_in(Rp)
        loc = np.array([align[k] * (hp[k] - hc[k]) + off[k] for k in range(3)])
        child.pos = parent.pos + Rp @ loc
        if weld: child.parent = parent
        return child

    def mate(self, child, canchor, parent, panchor, off=(0, 0, 0), rot=None, weld=True):
        """Trùng điểm neo `canchor` của child với `panchor` của parent. rot=None: giữ hướng đã có; rot=(độ) hướng = parent·rot."""
        if rot is not None: child.R = parent.R @ euler(rot)
        cp, _ = child.anchor(canchor); pp, _ = parent.anchor(panchor)
        child.pos = child.pos + (pp - cp) + parent.R @ np.array(off, float)
        if weld: child.parent = parent
        return child

    def beside(self, child, ref, axis="x", sign=1, gap=0.0, align=0.0):
        """Đặt child cạnh ref theo trục THẾ GIỚI (x|y|z) về phía sign; các trục còn lại giữ nguyên tâm (+align·sai lệch mép trên trục Y/…)."""
        k = "xyz".index(axis)
        child.pos = child.pos.copy()
        child.pos[k] = ref.pos[k] + sign * (ref.extent()[k] + child.extent()[k] + gap)
        return child

    def rod(self, name, p0, p1, thick=0.2, shape="box", thick2=None, overlap=0.0, **k):
        """Thanh/chi giữa hai điểm p0→p1 (bất kỳ hướng): dài đúng |p1−p0| (+2·overlap)."""
        p0 = np.array(p0, float); p1 = np.array(p1, float); d = p1 - p0; L = float(np.linalg.norm(d)) + 2 * overlap
        if shape == "cyl":
            part = self.add(name, "Cylinder", (L, thick, thick), **k); part.R = look_rot(d, 0)  # trục X cục bộ = hướng thanh
        else:
            part = self.add(name, "Block", (thick, thick2 or thick, L), **k); part.R = look_rot(d, 2)
        part.pos = (p0 + p1) / 2
        return part

    def path(self, name, points, thick=0.2, joints=True, **k):
        """Chuỗi thanh nối các điểm; joints=True thêm bi tại mỗi khúc để không hở."""
        out = []
        for i in range(len(points) - 1):
            out.append(self.rod(f"{name}_{i}", points[i], points[i + 1], thick, overlap=thick * 0.25 if joints else 0, **k))
        if joints:
            for i in range(1, len(points) - 1):
                out.append(self.ball(f"{name}_j{i}", thick, at=points[i], **{kk: v for kk, v in k.items() if kk in ("color", "material")}))
        return out

    def arc(self, name, center, axis, radius, a0, a1, segs=12, thick=0.2, depth=None, plane_up=(0, 1, 0), **k):
        """Cung tròn quanh `axis` đi qua góc a0→a1 (độ), dựng bằng `segs` thanh; điểm đầu tại +hướng u (vuông góc axis)."""
        ax = np.array(axis, float); ax /= np.linalg.norm(ax)
        u = np.cross(ax, plane_up); u = u / np.linalg.norm(u) if np.linalg.norm(u) > 1e-6 else np.array([1.0, 0, 0])
        pts = [np.array(center, float) + axis_angle(ax, a0 + (a1 - a0) * i / segs) @ u * radius for i in range(segs + 1)]
        out = []
        for i in range(segs):
            r = self.rod(f"{name}_{i}", pts[i], pts[i + 1], thick, thick2=depth, overlap=thick * 0.2, **k)
            out.append(r)
        return out

    def bezier(self, name, p0, p1, p2, p3, segs=12, thick=0.2, **k):
        P = [np.array(p, float) for p in (p0, p1, p2, p3)]
        pts = [((1 - t) ** 3) * P[0] + 3 * (1 - t) ** 2 * t * P[1] + 3 * (1 - t) * t * t * P[2] + t ** 3 * P[3] for t in (i / segs for i in range(segs + 1))]
        return self.path(name, pts, thick, **k)

    # ------------------------------------------------------------------ biến đổi / nhân bản
    def clone(self, part, name=None, pos=None, R=None):
        q = Part(self._unique(name or part.name), part.shape, part.size.copy(), part.pos.copy() if pos is None else pos, part.R.copy() if R is None else R,
                 part.color, part.material, part.transparency, part.anchored, ".".join(self._grp), part.tex)
        q.cyl_axis = part.cyl_axis; q.parent = part.parent; q.tags = set(part.tags); q.anchors = dict(part.anchors)
        self.parts.append(q)
        for g in self._gstack_parts: g.append(q)
        return q

    def rotate_about(self, parts, pivot, axis, deg):
        """Xoay part/nhóm quanh điểm thế giới `pivot` (bản lề, cửa, nắp...). Giữ nguyên quan hệ tương đối giữa các part."""
        ps = parts if isinstance(parts, (list, tuple)) else [parts]
        Rm = axis_angle(axis, deg); pv = np.array(pivot, float)
        for p in ps: p.pos = pv + Rm @ (p.pos - pv); p.R = Rm @ p.R
        return parts

    def move(self, parts, d):
        for p in (parts if isinstance(parts, (list, tuple)) else [parts]): p.pos = p.pos + np.array(d, float)
        return parts

    def mirror(self, parts, axis="x", plane=0.0, suffix="_R"):
        """Phản chiếu qua mặt phẳng vuông góc trục thế giới `axis` tại `plane`; R' = M·R·M giữ phép quay đúng (không lật part)."""
        k = "xyz".index(axis); M = np.eye(3); M[k, k] = -1
        out = []
        for p in (parts if isinstance(parts, (list, tuple)) else [parts]):
            pos = p.pos.copy(); pos[k] = 2 * plane - pos[k]
            q = self.clone(p, p.name + suffix, pos, M @ p.R @ M)
            if p.parent is not None and p.parent not in out: q.parent = p.parent
            out.append(q)
        # parent của bản sao: nếu parent cũng được mirror thì trỏ sang bản sao tương ứng
        mp = {id(a): b for a, b in zip(parts if isinstance(parts, (list, tuple)) else [parts], out)}
        for q, p in zip(out, parts if isinstance(parts, (list, tuple)) else [parts]):
            if p.parent is not None and id(p.parent) in mp: q.parent = mp[id(p.parent)]
        return out if isinstance(parts, (list, tuple)) else out[0]

    def array_linear(self, part, n, step, name=None):
        step = np.array(step, float)
        return [self.clone(part, f"{name or part.name}_{i}", part.pos + step * i) for i in range(1, n)]

    def array_radial(self, parts, n, axis=(0, 1, 0), center=(0, 0, 0), name=None):
        """n-1 bản sao xoay quanh trục đi qua `center` (bản gốc là bản 0, chia đều 360°)."""
        ps = parts if isinstance(parts, (list, tuple)) else [parts]; out = []
        for i in range(1, n):
            Rm = axis_angle(axis, 360.0 * i / n); c = np.array(center, float)
            for p in ps: out.append(self.clone(p, f"{name or p.name}_{i}", c + Rm @ (p.pos - c), Rm @ p.R))
        return out

    def ground(self, y=0.0):
        """Hạ cả model để đáy thấp nhất chạm y."""
        lo = min((p.pos[1] - p.extent()[1]) for p in self.parts if not p.ref)
        for p in self.parts: p.pos[1] += y - lo

    # ------------------------------------------------------------------ gắn nhãn kích thước / ràng buộc
    def declare(self, family, symmetry=None):
        self.family = family; self.symmetry = symmetry or self.symmetry; return self

    def feature(self, name, value_studs):
        """Ghi một kích thước ngữ nghĩa (vd 'seat_height') để đối chiếu với DB cỡ thật. Dùng measure helpers bên dưới để lấy giá trị."""
        self.features[name] = float(value_studs)

    def top_y(self, *ps): return max(p.pos[1] + p.extent()[1] for p in ps)
    def bottom_y(self, *ps): return min(p.pos[1] - p.extent()[1] for p in ps)
    def span(self, axis, *ps):
        k = "xyz".index(axis)
        return max(p.pos[k] + p.extent()[k] for p in ps) - min(p.pos[k] - p.extent()[k] for p in ps)

    def expect(self, kind, a=None, b=None, **kw):
        """Ràng buộc kiểm sau khi dựng: touch(a,b) | above(a,b) | inside(a,b) | ratio(a,b,lo,hi theo trục y/x/z) | same_y(a,b)."""
        self.expects.append((kind, a, b, kw))

    # ------------------------------------------------------------------ ra scene
    def real_parts(self): return [p for p in self.parts if not p.ref]

    def mannequin(self, height=5.0, at=None):
        """Người mẫu tham chiếu 5 stud (đầu 1, thân 2, chân 2) đặt cạnh model, cùng sàn; đánh dấu ref (không tính vào kiểm tra)."""
        real = self.real_parts()
        lo = min(p.pos[1] - p.extent()[1] for p in real)
        xs = max(p.pos[0] + p.extent()[0] for p in real)
        x, z = (xs + 1.5, real[0].pos[2]) if at is None else at[:2]
        h = height / 5.0
        spec = [("leg", (0.8 * h, 2.0 * h, 0.8 * h), 1.0 * h), ("torso", (1.6 * h, 2.0 * h, 0.8 * h), 3.0 * h), ("head", (1.0 * h, 1.0 * h, 1.0 * h), 4.5 * h)]
        save, self._gstack_parts = self._gstack_parts, ()
        for n, sz, cy in spec:
            p = self.add("_REF_" + n, "Block", sz, at=(x, lo + cy, z), color="#DD7733"); p.ref = True
        self._gstack_parts = save

    def scene(self):
        parts, idx = [], {id(p): i for i, p in enumerate(self.parts)}
        for i, p in enumerate(self.parts):
            sz, Re = p.eff()
            path = "Workspace." + self.name + "." + ((p.group + ".") if p.group else "") + p.name
            h = p.color.lstrip("#"); col = [int(h[j:j + 2], 16) / 255 for j in (0, 2, 4)]
            parts.append({"id": i, "path": path, "name": p.name, "class": "WedgePart" if p.shape == "Wedge" else "Part", "shape": p.shape,
                          "size": [float(x) for x in sz], "cf": cf_list(p.pos, Re), "color": col, "material": p.material,
                          "transparency": p.transparency, "reflectance": 0, "anchored": p.anchored, "canCollide": True})
        joints = [{"kind": "WeldConstraint", "path": "Weld", "p0": idx[id(p.parent)], "p1": idx[id(p)]} for p in self.parts if p.parent is not None and not p.ref]
        return {"frames": [{"t": 0, "parts": parts, "nodes": [], "joints": joints, "extras": []}], "log": [], "time": 0}

    # ------------------------------------------------------------------ backend Luau
    def luau(self, textures_note=True):
        L = ["-- Sinh bởi mb.py — hình học đã kiểm. Đơn vị stud, trước = -Z.", "local model = Instance.new(\"Model\")", f"model.Name = {json.dumps(self.name)}",
             "local function P(name, shape, size, cf, hex, mat, parent, tr)", "\tlocal p = (shape == \"Wedge\") and Instance.new(\"WedgePart\") or Instance.new(\"Part\")",
             "\tp.Name = name; p.Size = size; p.CFrame = cf; p.Color = Color3.fromHex(hex); p.Material = Enum.Material[mat]; p.Transparency = tr or 0",
             "\tp.Anchored = true; p.TopSurface = Enum.SurfaceType.Smooth; p.BottomSurface = Enum.SurfaceType.Smooth",
             "\tif shape == \"Ball\" then p.Shape = Enum.PartType.Ball elseif shape == \"Cylinder\" then p.Shape = Enum.PartType.Cylinder end",
             "\tp.Parent = parent; return p", "end", "local groups = {}",
             "local function G(path) if path == \"\" then return model end; if groups[path] then return groups[path] end",
             "\tlocal parentPath, nm = path:match(\"^(.*)%.([^.]+)$\"); local par = parentPath and G(parentPath) or model",
             "\tif not parentPath then par = model; nm = path end",
             "\tlocal f = Instance.new(\"Model\"); f.Name = nm; f.Parent = par; groups[path] = f; return f end",
             "local byName = {}"]
        real = [p for p in self.parts if not p.ref]
        for i, p in enumerate(real):
            sz, Re = p.eff(); cf = ", ".join(f"{x:.5f}" for x in cf_list(p.pos, Re))
            L.append(f"byName[{i}] = P({json.dumps(p.name)}, {json.dumps(p.shape)}, Vector3.new({sz[0]:.4f}, {sz[1]:.4f}, {sz[2]:.4f}), CFrame.new({cf}), {json.dumps(p.color.lstrip('#'))}, {json.dumps(p.material)}, G({json.dumps(p.group)}), {p.transparency})")
        idx = {id(p): i for i, p in enumerate(real)}
        L.append("-- Weld theo quan hệ đã khai báo (child↔parent); toàn bộ Anchored=true để không rã. Bỏ Anchored nếu cần vật lý.")
        for p in real:
            if p.parent is not None and id(p.parent) in idx:
                L.append(f"do local w = Instance.new(\"WeldConstraint\"); w.Part0 = byName[{idx[id(p.parent)]}]; w.Part1 = byName[{idx[id(p)]}]; w.Parent = byName[{idx[id(p)]}] end")
        if real: L.append("model.PrimaryPart = byName[0]")
        L += ["model.Parent = workspace", "return model"]
        return "\n".join(L) + "\n"

    # ------------------------------------------------------------------ backend Blender
    def blender_matrix(self, p):
        T = np.eye(4); T[:3, :3] = MAP @ p.R; T[:3, 3] = MAP @ p.pos
        return T

    def blender(self, tex_dir=None):
        rows = []
        for p in self.real_parts():
            sz, Re = p.eff(); T = np.eye(4); T[:3, :3] = MAP @ Re; T[:3, 3] = MAP @ p.pos; r, mt = MATERIAL_PBR.get(p.material, (0.6, 0.0))
            rows.append({"name": (p.group + "." if p.group else "") + p.name, "shape": p.shape, "size": [float(x) for x in sz], "m": [[float(x) for x in rw] for rw in T],
                         "color": p.color.lstrip("#"), "rough": r, "metal": mt, "alpha": 1 - p.transparency, "tex": p.tex, "emit": p.material == "Neon"})
        data = repr(rows)
        return BLENDER_TEMPLATE.replace("__DATA__", data).replace("__NAME__", repr(self.name)).replace("__TEXDIR__", repr(tex_dir or ""))

    # ------------------------------------------------------------------ kiểm tra + lưu
    def check(self, family=None, strict=False):
        mc = _load("mbcheck")
        return mc.run(self, family or self.family)

    def save(self, out, render=True, views="front,back,left,top,iso,iso2", size=420, mannequin=True, family=None, tex_dir=None):
        os.makedirs(out, exist_ok=True)
        if mannequin and not any(p.ref for p in self.parts) and self.real_parts(): self.mannequin()
        sc = self.scene()
        json.dump(sc, open(os.path.join(out, "scene.json"), "w"))
        open(os.path.join(out, "build.lua"), "w", encoding="utf-8").write(self.luau())
        open(os.path.join(out, "blender.py"), "w", encoding="utf-8").write(self.blender(tex_dir))
        rep = self.check(family)
        open(os.path.join(out, "report.md"), "w", encoding="utf-8").write(rep["md"])
        json.dump({k: v for k, v in rep.items() if k != "md"}, open(os.path.join(out, "report.json"), "w"), default=str, indent=1)
        if render:
            cmd = [sys.executable, "-I", os.path.join(HERE, "rbx_render.py"), os.path.join(out, "scene.json"), os.path.join(out, "views.png"),
                   "--views", views, "--front=" + self.front, "--size", str(size), "--outline"]
            r = subprocess.run(cmd, capture_output=True, text=True)
            if r.returncode: rep["render_error"] = r.stderr[-300:]
        print(rep["md"])
        return rep


def _load(name):
    spec = importlib.util.spec_from_file_location(name, os.path.join(HERE, name + ".py"))
    m = importlib.util.module_from_spec(spec); sys.modules[name] = m; spec.loader.exec_module(m); return m


BLENDER_TEMPLATE = r'''# Sinh bởi mb.py — chạy: blender -b --python blender.py   (hoặc dán vào Scripting). CHƯA được chạy thử trên Blender thật.
# Hệ trục: Blender (x,y,z) = Roblox (-x, z, y); 1 đơn vị = 1 stud. Mesh dựng bằng from_pydata (không dùng bpy.ops) nên chạy được headless.
import bpy, math, os
from mathutils import Matrix
DATA = __DATA__
NAME = __NAME__
TEXDIR = __TEXDIR__

def unit_mesh(shape):
    if shape == "Ball":
        seg, rng, v, f = 16, 10, [], []
        v.append((0, 0, 0.5)); 
        for j in range(1, rng):
            th = math.pi * j / rng
            for i in range(seg):
                ph = 2 * math.pi * i / seg
                v.append((0.5 * math.sin(th) * math.cos(ph), 0.5 * math.sin(th) * math.sin(ph), 0.5 * math.cos(th)))
        v.append((0, 0, -0.5)); last = len(v) - 1
        for i in range(seg): f.append((0, 1 + i, 1 + (i + 1) % seg))
        for j in range(rng - 2):
            for i in range(seg):
                a = 1 + j * seg + i; b = 1 + j * seg + (i + 1) % seg
                f.append((a, a + seg, b + seg, b))
        base = 1 + (rng - 2) * seg
        for i in range(seg): f.append((last, base + (i + 1) % seg, base + i))
        return v, f
    if shape == "Cylinder":   # trục X (như Roblox), bán kính 0.5 theo Y/Z
        seg = 24; v = []; f = []
        for i in range(seg):
            a = 2 * math.pi * i / seg
            v.append((-0.5, 0.5 * math.cos(a), 0.5 * math.sin(a))); v.append((0.5, 0.5 * math.cos(a), 0.5 * math.sin(a)))
        for i in range(seg):
            j = (i + 1) % seg
            f.append((2 * i, 2 * j, 2 * j + 1, 2 * i + 1))
        f.append(tuple(2 * i for i in reversed(range(seg)))); f.append(tuple(2 * i + 1 for i in range(seg)))
        return v, f
    if shape == "Wedge":      # đáy y=-0.5, mặt đứng z=+0.5, dốc từ (y-0.5,z-0.5) lên (y+0.5,z+0.5) — khớp renderer
        pts = [(-0.5, -0.5, -0.5), (0.5, -0.5, -0.5), (-0.5, -0.5, 0.5), (0.5, -0.5, 0.5), (-0.5, 0.5, 0.5), (0.5, 0.5, 0.5)]
        f = [(0, 1, 3, 2), (2, 3, 5, 4), (0, 4, 5, 1), (0, 2, 4), (1, 5, 3)]
        return pts, f
    v = [(x, y, z) for x in (-0.5, 0.5) for y in (-0.5, 0.5) for z in (-0.5, 0.5)]
    f = [(0, 1, 3, 2), (4, 6, 7, 5), (0, 4, 5, 1), (2, 3, 7, 6), (0, 2, 6, 4), (1, 5, 7, 3)]
    return v, f

def material(row):
    name = "mb_%s_%s_%s_%s" % (row["color"], row["tex"] or "flat", row["rough"], row["metal"])
    m = bpy.data.materials.get(name)
    if m: return m
    m = bpy.data.materials.new(name); m.use_nodes = True
    b = m.node_tree.nodes.get("Principled BSDF")
    c = tuple(int(row["color"][i:i + 2], 16) / 255 for i in (0, 2, 4))
    b.inputs["Base Color"].default_value = (*c, 1); b.inputs["Roughness"].default_value = row["rough"]; b.inputs["Metallic"].default_value = row["metal"]
    if row["alpha"] < 1: b.inputs["Alpha"].default_value = row["alpha"]
    if row["emit"]:
        for k in ("Emission Color", "Emission"):
            if k in b.inputs: b.inputs[k].default_value = (*c, 1); break
        if "Emission Strength" in b.inputs: b.inputs["Emission Strength"].default_value = 2.0
    if row["tex"] and TEXDIR:
        nt = m.node_tree
        for sock, suffix, cs in (("Base Color", "albedo", "sRGB"), ("Roughness", "roughness", "Non-Color"), ("Metallic", "metalness", "Non-Color")):
            fp = os.path.join(TEXDIR, "%s_%s.png" % (row["tex"], suffix))
            if os.path.exists(fp):
                t = nt.nodes.new("ShaderNodeTexImage"); t.image = bpy.data.images.load(fp); t.image.colorspace_settings.name = cs
                nt.links.new(t.outputs["Color"], b.inputs[sock])
        fp = os.path.join(TEXDIR, "%s_normal.png" % row["tex"])
        if os.path.exists(fp):
            t = nt.nodes.new("ShaderNodeTexImage"); t.image = bpy.data.images.load(fp); t.image.colorspace_settings.name = "Non-Color"
            nm = nt.nodes.new("ShaderNodeNormalMap"); nt.links.new(t.outputs["Color"], nm.inputs["Color"]); nt.links.new(nm.outputs["Normal"], b.inputs["Normal"])
    return m

coll = bpy.data.collections.new(NAME); bpy.context.scene.collection.children.link(coll)
for row in DATA:
    v, f = unit_mesh(row["shape"])
    me = bpy.data.meshes.new(row["name"]); me.from_pydata(v, [], f); me.update()   # mỗi object 1 mesh riêng để có vật liệu riêng
    ob = bpy.data.objects.new(row["name"], me)
    S = Matrix.Diagonal((row["size"][0], row["size"][1], row["size"][2], 1.0))      # kích thước nằm trong ma trận (Roblox local, rồi MAP)
    ob.matrix_world = Matrix(row["m"]) @ S
    me.materials.append(material(row))
    coll.objects.link(ob)
print("mb: tạo %d object trong collection %s" % (len(DATA), NAME))
'''

# --------------------------------------------------------------------------------------------- selftest
def selftest():
    rng = np.random.default_rng(7); ok = 0; bad = 0
    def chk(c, msg):
        nonlocal ok, bad
        if c: ok += 1
        else: bad += 1; print("FAIL", msg)
    for _ in range(200):
        rot = rng.uniform(-180, 180, 3); R = euler(rot)
        chk(abs(np.linalg.det(R) - 1) < 1e-9 and np.allclose(R @ R.T, np.eye(3)), "euler orthonormal")
        d = rng.normal(size=3)
        for ax in (0, 1, 2):
            Rl = look_rot(d, ax); e = np.zeros(3); e[ax] = 1
            chk(np.allclose(Rl @ e, d / np.linalg.norm(d), atol=1e-9) and abs(np.linalg.det(Rl) - 1) < 1e-9, f"look_rot axis{ax}")
        # on(): child nằm ngoài mặt, chạm đúng
        m = Model("t"); par = m.box("p", rng.uniform(0.5, 4, 3), rot=tuple(rot)); par.pos = rng.normal(size=3)
        ch = m.box("c", rng.uniform(0.3, 3, 3))
        face = list(FACES)[int(rng.integers(6))]
        m.on(ch, par, face, align=(rng.choice([-1, 0, 1]), rng.choice([-1, 0, 1])), rot=tuple(rng.choice([0, 90, 180, 270], 3)))
        sep = _load("mbcheck").sat_gap(par, ch)
        chk(abs(sep) < 1e-6, f"on(): chạm mặt gap={sep:.2e} face={face}")
        # mirror giữ det=+1 và là phép đối xứng
        mm = m.mirror(ch, "x"); chk(abs(np.linalg.det(mm.R) - 1) < 1e-9 and abs(mm.pos[0] + ch.pos[0]) < 1e-9, "mirror")
    # rotate_about bảo toàn khoảng cách
    m = Model("t"); a = m.box("a", (1, 1, 1), at=(2, 0, 0)); b = m.box("b", (1, 1, 1), at=(3, 1, 0)); d0 = np.linalg.norm(a.pos - b.pos)
    m.rotate_about([a, b], (0, 0, 0), (0, 1, 0), 37); chk(abs(np.linalg.norm(a.pos - b.pos) - d0) < 1e-9, "rotate_about")
    # radial
    m = Model("t"); a = m.box("a", (0.5, 0.5, 0.5), at=(2, 0, 0)); cl = m.array_radial(a, 6, (0, 1, 0)); chk(len(cl) == 5 and all(abs(np.linalg.norm(c.pos) - 2) < 1e-9 for c in cl), "radial")
    # Blender map
    chk(abs(np.linalg.det(MAP) - 1) < 1e-12, "MAP det"); chk(np.allclose(MAP @ np.array([0, 0, -1]), [0, -1, 0]), "front→-Y"); chk(np.allclose(MAP @ np.array([0, 1, 0]), [0, 0, 1]), "up→+Z")
    print(f"mb selftest: {ok} PASS, {bad} FAIL"); return bad


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sp = ap.add_subparsers(dest="cmd")
    sp.add_parser("selftest")
    c = sp.add_parser("check"); c.add_argument("scene"); c.add_argument("--family"); c.add_argument("--front", default="-z")
    a = ap.parse_args()
    if a.cmd == "selftest": sys.exit(1 if selftest() else 0)
    if a.cmd == "check":
        sc = json.load(open(a.scene)); mc = _load("mbcheck"); rep = mc.run_scene(sc["frames"][-1], a.family, a.front); print(rep["md"]); sys.exit(1 if rep["errors"] else 0)
    ap.print_help()


if __name__ == "__main__":
    main()
