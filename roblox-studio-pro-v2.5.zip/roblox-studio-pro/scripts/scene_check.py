#!/usr/bin/env python3
"""Kiểm model của sandbox theo KỲ VỌNG bằng số (rút từ ảnh mẫu) — cổng chặn trước khi giao.

    python scripts/scene_check.py scene.json --expect expect.json [--front -z] [--tol 0.05]
    python scripts/sandbox.py run build.lua --render out.png --expect expect.json     # cùng kiểm, một lệnh

expect.json (mọi khoá đều tuỳ chọn):
  {"ratio": {"L": 48, "H": 21.4, "W": 16, "tol": 0.15},     # Dài (theo --front) : Cao (Y) : Rộng; khớp theo trung bình nhân nên sai số chia đều
   "counts": [{"match": "^Barrel", "min": 6, "max": 6}],   # regex trên tên part hoặc đường dẫn
   "palette": ["#EB5A5A"], "palette_tol": 20,                # mỗi màu phải có part gần (khoảng cách RGB 0–255)
   "joined": true,                                          # 1 cụm nhìn thấy (SAT) VÀ 1 assembly vật lý (weld + Anchored gom vào "mặt đất")
   "min_parts": 100, "max_parts": 700,
   "bbox_studs": {"L": [20, 30], "H": [8, 12]}}
Mã thoát 1 nếu có FAIL.
"""
import argparse
import importlib.util
import json
import math
import os
import re
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
FRONT = {"-z": (0, 0, -1), "+z": (0, 0, 1), "+x": (1, 0, 0), "-x": (-1, 0, 0)}


def _sandbox():
    spec = importlib.util.spec_from_file_location("sandbox", os.path.join(HERE, "sandbox.py"))
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m


def components(n, edges):
    par = list(range(n))
    def f(x):
        while par[x] != x: par[x] = par[par[x]]; x = par[x]
        return x
    for a, b in edges: par[f(a)] = f(b)
    g = {}
    for i in range(n): g.setdefault(f(i), []).append(i)
    return list(g.values())


def analyze(frame, front="-z", tol=0.05):
    parts, joints = frame["parts"], frame["joints"]
    n = len(parts); rep = {"parts": n}
    mn = np.full(3, 1e18); mx = np.full(3, -1e18)
    for p in parts:
        cf = p["cf"]; c = np.array(cf[:3]); R = np.array(cf[3:12]).reshape(3, 3); h = np.abs(R) @ (np.array(p["size"]) / 2)
        mn = np.minimum(mn, c - h); mx = np.maximum(mx, c + h)
    ext = mx - mn; f = np.abs(np.array(FRONT[front], float)); up = np.array([0, 1.0, 0]); right = np.abs(np.cross(np.array(FRONT[front], float), up))
    rep.update(L=float(f @ ext), H=float(ext[1]), W=float(right @ ext), extent=ext.round(3).tolist())
    idx = {p["id"]: i for i, p in enumerate(parts)}
    jedges = [(idx[j["p0"]], idx[j["p1"]]) for j in joints if j.get("p0") in idx and j.get("p1") in idx]
    anch = [i for i, p in enumerate(parts) if p.get("anchored")]
    comps = components(n, jedges + [(anch[0], a) for a in anch[1:]])
    rep["assemblies"] = len(comps)
    rep["loose"] = [parts[c[0]]["name"] + "#" + str(parts[c[0]]["id"]) for c in comps if len(c) == 1 and not parts[c[0]].get("anchored")][:12]
    sb = _sandbox(); cedges = []
    order = sorted(range(n), key=lambda i: parts[i]["cf"][0])
    for ii, a in enumerate(order):
        ha = max(parts[a]["size"]) / 2
        for b in order[ii + 1:]:
            if parts[b]["cf"][0] - parts[a]["cf"][0] > (ha + max(parts[b]["size"]) / 2) * 1.8 + 1: break
            if sb.separation(parts[a], parts[b]) <= tol: cedges.append((a, b))
    cc = sorted(components(n, cedges), key=len, reverse=True)
    rep["clusters"] = len(cc); rep["floating"] = [parts[i]["name"] + "#" + str(parts[i]["id"]) for c in cc[1:] for i in c][:12]
    return rep


def check(frame, exp, front="-z", tol=0.05):
    rep = analyze(frame, front, tol); parts = frame["parts"]; res = []
    add = lambda name, ok, d: res.append((bool(ok), name, d))
    if "ratio" in exp:
        r = exp["ratio"]; t = r.get("tol", 0.15); ks = [k for k in "LHW" if r.get(k)]
        sc = math.exp(sum(math.log(max(rep[k], 1e-6) / r[k]) for k in ks) / len(ks))
        for k in ks:
            want = r[k] * sc; add(f"tỉ lệ {k}", abs(rep[k] - want) <= t * want, f"có {rep[k]:.2f}, mong {want:.2f} (±{int(t * 100)}%; 1 đơn vị mẫu = {sc:.3f} studs)")
    for c in exp.get("counts", []):
        pat = re.compile(c["match"], re.I); n = sum(1 for p in parts if pat.search(p["name"]) or pat.search(p["path"]))
        lo, hi = c.get("min", 0), c.get("max", 10 ** 9); add(f"số lượng '{c['match']}'", lo <= n <= hi, f"có {n}, mong {lo}..{hi if hi < 10**9 else '∞'}")
    if "min_parts" in exp: add("min_parts", rep["parts"] >= exp["min_parts"], f"{rep['parts']} ≥ {exp['min_parts']}")
    if "max_parts" in exp: add("max_parts", rep["parts"] <= exp["max_parts"], f"{rep['parts']} ≤ {exp['max_parts']}")
    if "palette" in exp:
        tl = exp.get("palette_tol", 45); cols = [np.array(p["color"]) * 255 for p in parts]
        for h in exp["palette"]:
            h2 = h.lstrip("#"); want = np.array([int(h2[i:i + 2], 16) for i in (0, 2, 4)], float)
            best = min((np.linalg.norm(c - want) for c in cols), default=1e9); add(f"màu {h}", best <= tl, f"gần nhất cách {best:.0f}/255")
    if exp.get("joined"):
        add("liền khối nhìn thấy", rep["clusters"] == 1, f"{rep['clusters']} cụm" + (f"; rời: {rep['floating'][:6]}" if rep["floating"] else ""))
        add("liền khối vật lý", rep["assemblies"] == 1 and not rep["loose"], f"{rep['assemblies']} assembly" + (f"; part trôi: {rep['loose'][:6]}" if rep["loose"] else ""))
    for k, (lo, hi) in exp.get("bbox_studs", {}).items(): add(f"kích thước {k} (studs)", lo <= rep[k] <= hi, f"{rep[k]:.2f} ∈ [{lo},{hi}]")
    return rep, res


def run_check(scene, exp_path, front="-z", tol=0.05):
    exp = json.load(open(exp_path, encoding="utf-8")); frame = scene["frames"][-1]
    rep, res = check(frame, exp, front, tol)
    print(f"-- So với kỳ vọng ({exp_path}) --  Parts {rep['parts']} | L={rep['L']:.2f} H={rep['H']:.2f} W={rep['W']:.2f} studs | {rep['clusters']} cụm nhìn thấy | {rep['assemblies']} assembly")
    for ok, name, d in res: print(("PASS " if ok else "FAIL ") + f"{name}: {d}")
    return sum(1 for ok, *_ in res if not ok)


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("scene"); ap.add_argument("--expect", required=True); ap.add_argument("--front", default="-z"); ap.add_argument("--tol", type=float, default=0.05)
    a = ap.parse_args()
    sys.exit(1 if run_check(json.load(open(a.scene, encoding="utf-8")), a.expect, a.front, a.tol) else 0)


if __name__ == "__main__":
    main()
