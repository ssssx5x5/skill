#!/usr/bin/env python3
"""DevForum search helper for the roblox-studio-devforum skill.

Discourse exposes a public JSON API, so we never need to scrape HTML.

    python df.py search "pathfinding npc" --limit 8
    python df.py read 3623472 --posts 3
    python df.py read 4600251 --code-only
    python df.py multi "datastore save" "datastore throttling"

Exit codes: 0 ok, 1 nothing found, 2 network/parse error.
"""

import argparse
import html
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

BASE = "https://devforum.roblox.com"
UA = "Mozilla/5.0 (compatible; roblox-skill/1.0; +https://devforum.roblox.com)"
HERE = os.path.dirname(os.path.abspath(__file__))
CACHE_DIR = os.path.join(HERE, "..", ".cache")
CATEGORY_CACHE = os.path.join(CACHE_DIR, "categories.json")
RATE_SLEEP = 0.45          # be a polite client
TIMEOUT = 30
MAX_RETRIES = 3


def _get(path, params=None):
    url = BASE + path
    if params:
        url += "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json"})
    last = None
    for attempt in range(MAX_RETRIES):
        try:
            with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
                return json.loads(r.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            last = e
            if e.code == 429:                       # rate limited: back off
                time.sleep(2 ** attempt)
                continue
            if e.code == 404:
                return None
            raise
        except (urllib.error.URLError, TimeoutError) as e:
            last = e
            time.sleep(1 + attempt)
    raise SystemExit(f"ERROR: request failed after {MAX_RETRIES} tries: {last}")


def categories():
    """category_id -> readable name, cached on disk."""
    if os.path.exists(CATEGORY_CACHE):
        try:
            with open(CATEGORY_CACHE, encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    data = _get("/categories.json", {"include_subcategories": "true"})
    out = {}
    if data:
        for c in data.get("category_list", {}).get("categories", []):
            out[str(c["id"])] = c["name"]
            for s in c.get("subcategory_list", []) or []:
                out[str(s["id"])] = f"{c['name']}/{s['name']}"
    os.makedirs(CACHE_DIR, exist_ok=True)
    with open(CATEGORY_CACHE, "w", encoding="utf-8") as f:
        json.dump(out, f)
    return out


def url_for(topic):
    return f"{BASE}/t/{topic.get('slug', 'topic')}/{topic['id']}"


def search(query, limit=10):
    data = _get("/search.json", {"q": query})
    if not data:
        return []
    # Discourse already returns relevance order -- do not re-sort, replies lie.
    return (data.get("topics", []) or [])[:limit]


def _short(s, n=110):
    s = re.sub(r"\s+", " ", s or "").strip()
    return s[:n] + ("…" if len(s) > n else "")


def print_search(query, topics, cats):
    print(f'### QUERY: "{query}"  -> {len(topics)} topic')
    if not topics:
        print("  (không có kết quả)\n")
        return
    for t in topics:
        cat = cats.get(str(t.get("category_id")), "?")
        flags = []
        if t.get("has_accepted_answer"):
            flags.append("SOLVED")
        if t.get("closed"):
            flags.append("closed")
        flag = (" [" + ",".join(flags) + "]") if flags else ""
        date = (t.get("last_posted_at") or t.get("created_at") or "")[:10]
        print(f"  - {t['title']}{flag}")
        print(f"    id={t['id']}  replies={t.get('posts_count', 0)}  last={date}  cat={cat}")
        ex = _short(t.get("excerpt"))
        if ex:
            print(f"    \"{ex}\"")
        print(f"    {url_for(t)}")
    print()


PRE_RE = re.compile(r"<pre[^>]*>\s*<code[^>]*class=\"[^\"]*lang-([\w+-]+)[^\"]*\"[^>]*>(.*?)</code>\s*</pre>", re.S)
PRE_NOLANG_RE = re.compile(r"<pre[^>]*>\s*<code[^>]*>(.*?)</code>\s*</pre>", re.S)
TAG_RE = re.compile(r"<[^>]+>")


def _unescape(s):
    return html.unescape(s).replace("\r\n", "\n")


def extract(cooked, code_only=False):
    """Return post text with fenced code blocks preserved."""
    blocks = []

    def stash(m):
        lang = m.group(1).lower()
        if lang in ("", "none"):
            lang = "lua"          # DevForum default for Roblox snippets
        blocks.append((lang, _unescape(m.group(2))))
        return f"\x00CODE{len(blocks) - 1}\x00"

    text = PRE_RE.sub(stash, cooked)
    text = PRE_NOLANG_RE.sub(stash, text)

    if code_only:
        return blocks

    text = TAG_RE.sub(" ", text)
    text = _unescape(text)
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text).strip()

    def restore(m):
        lang, body = blocks[int(m.group(1))]
        return f"\n```{lang}\n{body}\n```\n"

    return re.sub(r"\x00CODE(\d+)\x00", restore, text)


def read(topic_id, n_posts=3, code_only=False):
    data = _get(f"/t/{topic_id}.json")
    if not data:
        return None
    return data


def print_read(data, n_posts, code_only):
    print("=" * 78)
    print(f"TOPIC: {data['title']}  (id {data['id']}, {data['posts_count']} posts)")
    print(url_for(data))
    print("-" * 78)
    posts = data.get("post_stream", {}).get("posts", [])[:n_posts]
    if code_only:
        found = False
        for p in posts:
            for lang, body in extract(p["cooked"], code_only=True):
                found = True
                print(f"\n--- @{p['username']} ({lang}) ---")
                print(body.strip())
        if not found:
            print("(không có code block trong các post đầu)")
        return
    for p in posts:
        body = extract(p["cooked"])
        if p.get("accepted_answer"):
            print("[ACCEPTED ANSWER]")
        print(f"\n--- @{p['username']} ---")
        print(body[:1800] + ("…" if len(body) > 1800 else ""))
    print()


def main():
    ap = argparse.ArgumentParser(description="Search and read devforum.roblox.com")
    sub = ap.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("search", help="search topics")
    s.add_argument("query")
    s.add_argument("--limit", type=int, default=10)
    s.add_argument("--json", action="store_true")

    m = sub.add_parser("multi", help="run several queries at once")
    m.add_argument("queries", nargs="+")
    m.add_argument("--limit", type=int, default=6)

    r = sub.add_parser("read", help="read a topic")
    r.add_argument("topic_id", type=int)
    r.add_argument("--posts", type=int, default=3)
    r.add_argument("--code-only", action="store_true")
    r.add_argument("--json", action="store_true")

    a = ap.parse_args()
    cats = {}

    if a.cmd == "search":
        cats = categories()
        topics = search(a.query, a.limit)
        if a.json:
            print(json.dumps([{**t, "url": url_for(t)} for t in topics], indent=2, ensure_ascii=False))
        else:
            print_search(a.query, topics, cats)
        return 0 if topics else 1

    if a.cmd == "multi":
        cats = categories()
        total = 0
        for i, q in enumerate(a.queries):
            if i:
                time.sleep(RATE_SLEEP)
            topics = search(q, a.limit)
            total += len(topics)
            print_search(q, topics, cats)
        return 0 if total else 1

    if a.cmd == "read":
        data = read(a.topic_id)
        if not data:
            print(f"ERROR: topic {a.topic_id} not found", file=sys.stderr)
            return 2
        if a.json:
            print(json.dumps({"title": data["title"], "url": url_for(data),
                              "posts": data["post_stream"]["posts"]}, ensure_ascii=False))
        else:
            print_read(data, a.posts, a.code_only)
        return 0

    return 2


if __name__ == "__main__":
    sys.exit(main())
