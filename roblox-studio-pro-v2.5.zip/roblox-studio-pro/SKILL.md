---
name: roblox-studio-pro
description: Làm mọi thứ trong Roblox Studio ở mức production — MODEL BUILDER (mb.py: dựng theo quan hệ, đúng chỗ/xoay/tỉ lệ cỡ thật, sinh Roblox + Blender, texture PBR), sandbox xem ảnh + hiểu ảnh mẫu bằng số, model dựng bằng code KHÔNG RỜI (AssemblyGuard/GeoKit/ModelKit/KnifeKit vật cong), hiểu hướng/góc xoay (Spatial Brief), animation khó R6/R15/Part (AnimKit), VFX (VFXKit), UI (UIKit), âm thanh (SoundKit), script Luau, UI, NPC AI, DataStore, remote/anti-exploit, terrain/lighting, tối ưu lag, review code. Có template chạy được, linter, vòng chấm chất lượng. Trigger: bất kỳ yêu cầu nhắc Roblox, Luau, Studio, part, Humanoid, DataStore, RemoteEvent, "làm hiệu ứng/model/NPC/UI trong Roblox".
---

# Roblox Studio Pro (v2.4) — skill tổng

Một skill thay cho 30 skill rời. Nó không nhồi mọi thứ vào một chỗ, mà **điều phối**: đọc đúng
reference cho đúng việc, rồi làm theo một quy trình cố định.

## 0. Ba quy tắc gốc

**1. Tra trước khi nghĩ.** Roblox đổi API liên tục; trí nhớ của bạn chứa hàm đã deprecated.
Với mọi yêu cầu, tra `devforum.roblox.com` (mục 3) trước khi viết dòng code đầu tiên.
Không tự phát minh lại thứ đã có người giải xong và được duyệt SOLVED.

**2. Ví dụ là ví dụ, không phải chủ đề.** Failure phổ biến nhất: user xin "cái cây" mà agent
dựng ra "vụ nổ quái vật" vì đó là mẫu nó vừa thấy. Mọi chủ đề mới phải chạy lại
`references/subject-breakdown.md` từ đầu. Nếu bạn sắp dùng lại chữ `Roar`, `Monster`, `Jumpscare`
cho một thứ không phải vậy — dừng, làm lại breakdown.

**3. Kiểm chứng bằng số, không bằng cảm giác.** Không viết "đã kiểm tra" nếu chưa chạy gì.
`pcall` trả `true` không có nghĩa là việc đã xảy ra — đọc lại giá trị sau khi gán.
Hình học tính bằng math và so bằng số, không đặt bằng mắt.

**4. Dùng công cụ có sẵn, đừng viết lại.** `templates/` có `VFXKit`, `GeoKit`, `ModelKit`, `PoseKit` và dự án mẫu (đọc `references/templates-guide.md`). Hiệu ứng → `require(VFXKit)`; model có đường cong → `GeoKit`; chấm model → `ModelKit.Audit`. Mỗi lần tự viết lại `tween/ringWave/lightFlash` là một lần chất lượng trôi đi.

**5. Dựng xong phải NHÌN trước khi giao.** Với model/VFX từ ảnh mẫu hoặc mô tả phức tạp: chạy `scripts/sandbox.py run ... --render --expect` (sandbox kiểu Studio), mở ảnh render bằng công cụ xem ảnh, đối chiếu với ảnh mẫu bằng `imgread.py compare`, sửa lỗi lớn nhất trước, lặp ≥ 2 vòng. Ảnh mẫu thì phải **đo bằng số** (`imgread.py`, `ref_analyze.py`), không dựng theo cảm giác. Xem `references/sandbox-loop.md`, `references/image-understanding.md`.

**6. Model nhiều part: dựng bằng `scripts/mb.py`, không gõ toạ độ tay.** Lập **Dimension Table** trước (`dimdb.py plan <họ>`), dựng khung bằng quan hệ (`on/inside/mate/rod/rotate_about/mirror`), đo đặc trưng từ part (`top_y/span`), `save()` để chạy kiểm tự động (lơ lửng, ẩn, z-fight, thế đứng, đối xứng, kích thước thật) **trước khi render**. Dùng cho cả Roblox và Blender. Xem `references/model-builder.md` (cách dùng) và `references/model-pipeline.md` (9 cổng nghiệm thu, chấm điểm, vòng sửa tối đa 5).

**Việc nhỏ (sửa 1 dòng, hỏi API) thì bỏ qua DevForum và breakdown dài**; quy trình 7 bước giữ tỷ lệ với độ lớn của việc.

## 1. Quy trình 7 bước (giữ tỷ lệ với độ lớn của việc)

| # | Bước | Việc phải làm |
|---|---|---|
| 1 | **Hiểu yêu cầu** | Viết lại 1 dòng: muốn gì, đã có gì (script/ảnh/log đính kèm), ràng buộc cứng ("một script", "Command Bar"), ngôn ngữ trả lời. Yêu cầu "sửa/nâng cấp" = **thay đổi cái đang có**: đọc nó trước, giữ phần chạy được. User liệt kê vài lỗi → đó là ví dụ của một *họ* lỗi, sửa cả họ |
| 2 | **Chia nhỏ chủ đề** | `references/subject-breakdown.md`: giải phẫu, pha theo thời gian, chuyển động, màu/ánh sáng, tỷ lệ studs, lớp, ngân sách. 5–15 dòng. Có hướng/góc/hành động trong mô tả → thêm **Spatial Brief** (`spatial-language.md`) |
| 3 | **Quyết định chỗ ở** | Server / client / shared, loại script, thư mục, cái gì trigger (bảng ở mục 4) |
| 4 | **Viết name contract** | Mọi tên đi qua ranh giới (key Config, key SFX, tên remote, tên joint, marker, tag) gom một chỗ. **Bug im lặng sống ở đây** |
| 5 | **Dựng** | Skeleton chạy được trước, rồi thêm lớp chi tiết. Asset là placeholder cho tới khi user đưa id thật |
| 6 | **Kiểm chứng** | `references/verification.md` + `scripts/wiring_check.py` + self-test runtime. So hình học bằng số. Model/VFX tĩnh: **sandbox + xem ảnh + compare với mẫu** (`sandbox-loop.md`) |
| 7 | **Báo cáo** | Đã làm gì, đã kiểm gì, **chưa** kiểm được gì, user phải làm gì (thay id, bấm Play, xem gì ở Output) |

### Bốn câu hỏi trước dòng code đầu

Bỏ qua câu nào là hỏng đúng phần đó:

| Câu hỏi | Vì sao quan trọng |
|---|---|
| **Tỷ lệ và thể loại?** Đánh tay đôi / prop môi trường / khổng lồ? Anime, thực tế, horror? | Quyết định số lớp, thời lượng, có cần `cataclysm.md` không |
| **Ở đâu trong không gian?** CFrame gốc, pivot, hướng mặt, parent | Quyết định `PivotTo` hay `CFrame`, có phải bám terrain không |
| **Nhịp?** Chuẩn bị → va chạm → dư chấn, mỗi pha bao lâu? | Quyết định bảng `t =` của timeline; sai nhịp là mất lực |
| **Kênh cảm giác?** Hình / sóng / mảnh vụn / ánh sáng / âm thanh / màn hình — thiếu lớp nào? | Quyết định danh sách việc; thiếu lớp = hiệu ứng "rẻ tiền" |

## 2. Định tuyến: đọc reference nào

Chỉ đọc file liên quan — đừng đọc hết các file. Việc lớn thường cần 3–5 file.

| User muốn | Đọc |
|---|---|
| **Thao tác trực tiếp trong Studio đang mở**: chạy Luau, sửa script, inspect DataModel, playtest, benchmark, sinh terrain | `references/studio-mcp-index.md` (tra dòng) → đọc đúng khoảng của `studio-mcp.md` |
| Bất kỳ hiệu ứng / "làm cho nó ngầu" (nổ, lửa, phép, sét, portal, aura, slash) | `subject-breakdown.md` → `vfx-animation.md` |
| Phá huỷ quy mô lớn: bom, thiên thạch, sập map, cột sáng, đất cháy lan | `cataclysm.md` |
| Cutscene, intro, camera, "đặt cái này ở đâu" | `vfx-animation.md` (+ `ui-overlays.md`) |
| Animation: chạy track, marker, procedural joint, swing vũ khí | `vfx-animation.md` |
| Model dựng bằng code: creature, prop, rig, Command Bar builder | `assets.md` |
| Cây cối, đá, tinh thể, nấm, rải trên terrain | `assets.md` |
| Map, terrain, trời, mây, thời tiết, ngày/đêm, kích thước thực tế | `world.md` → `environment.md` |
| Part, material, Lighting, Atmosphere, post-processing, CSG, EditableMesh | `world.md` |
| GUI, HUD, shop, inventory UI, "vỡ trên mobile" | `ui.md` |
| Overlay màn hình: vignette, letterbox, VHS, HUD cinematic | `ui-overlays.md` |
| Ngôn ngữ: `--!strict`, type solver, generic, OOP, module, task library | `luau.md` |
| Cấu trúc project, replication, RunContext, streaming, bootstrap | `architecture.md` |
| Lag, FPS, memory, "tối ưu", nhiều NPC, network cost | `security-perf.md` → `luau-optimization.md` |
| Vật lý: raycast, hitbox, va chạm, xe, đạn, constraint | `simulation.md` |
| Nhân vật: Humanoid, máu, spawn, Tool, animation mặc định | `simulation.md` |
| NPC, quái, pet, đi theo, pathfinding, state machine | `simulation.md` |
| Remote, đồng bộ state, "client không nhận được" | `networking-data.md` |
| Lưu dữ liệu, leaderboard, session lock, migration, MessagingService | `networking-data.md` |
| Lobby, matchmaking, teleport nhiều place | `networking-data.md` |
| Chống exploit, validate remote, dupe, Ban API | `security-perf.md` |
| Tiền tệ, level, round, combat, inventory, shop, pet | `gameplay.md` |
| Robux, gamepass, subscription, ad, loot box policy | `gameplay.md` |
| Analytics, funnel, A/B test, season pass, live event | `gameplay.md` |
| Input, keybind, mobile button, camera, VR | `input-audio-chat.md` |
| Âm thanh, nhạc, 3D audio, mixing, TTS | `input-audio-chat.md` |
| Chat, command, bubble, filter text | `input-audio-chat.md` |
| Rojo, Wally, luau-lsp, StyLua, selene, CI, publish | `pipeline.md` |
| Test, Jest Lua, TestEZ, CI runner | `pipeline.md` |
| Open Cloud API, webhook, bot, dashboard ngoài game | `pipeline.md` |
| Tạo asset: mesh, texture, PBR, outfit, voxel từ ảnh pixel | `assets.md` |
| "Không có gì xảy ra" / nhiều mảnh phải khớp nhau | `verification.md` + `scripts/wiring_check.py` |
| **Chấm chất lượng / "đẹp chưa"**: vòng chụp → đo → sửa, rubric, ngân sách | `references/quality-loop.md` |
| **Model có đường cong**, creature, tàu, bình, cành; rig; pose procedural; LOD | `references/geometry-rigging.md` (+ `templates/GeoKit.lua`, `ModelKit.lua`, `PoseKit.lua`) |
| **Dự án mới**: Rojo, Remotes + Validate, DataService, lint/format | `templates/project/` + `references/templates-guide.md` |
| **Texture VFX** (khói, lửa flipbook, vết chém, glow) và **cutscene timeline** | `references/vfx-textures-cutscene.md` (+ `scripts/gen_vfx_textures.py`, `templates/CutsceneKit.lua`) |
| Dùng VFXKit (nổ, chém, sét, ring, rung camera...) | `references/templates-guide.md` + `templates/VFXKit.lua` |
| **Có ảnh mẫu / bảng thiết kế** (concept art, sprite sheet, nhiều góc nhìn) | `references/image-understanding.md` (+ `scripts/imgread.py`, `scripts/ref_analyze.py`) → viết Reference Spec bằng số |
| **Dựng model nhiều part / đúng tỉ lệ / đúng chỗ-xoay / cả Roblox lẫn Blender / texture** | `references/model-builder.md` (+ `scripts/mb.py`, `dimdb.py`, `mbcheck.py`, `texgen.py`, `references/dimensions.json`) → nghiệm thu bằng `references/model-pipeline.md` (+ `model-acceptance.md`, `model-defects.md`, `templates/model-report.md`) |
| **Dựng xong cần xem/kiểm**: ảnh nhiều góc, tỉ lệ, số lượng, liền khối, so với ảnh mẫu | `references/sandbox-loop.md` (+ `scripts/sandbox.py`, `rbx_render.py`, `scene_check.py`, `templates/sandbox/`) |
| **Hình tròn/cong dạng pixel-voxel**: vòm cầu vồng, vòng nòng, khối mây, mặt cười, N vật quanh trục | `templates/PatternKit.lua` (VoxelArch, RadialSlots, VoxelBlob) + `PixelShapes.lua` (Annulus, PixelArt) — mẫu: `examples/MinigunRainbow.lua` |
| **Model không được rời** (sniper, súng, xe, robot nhiều part) | `references/assembly-integrity.md` (+ `templates/AssemblyGuard.lua`, `scripts/sim_assembly.py`) |
| **Vật cong** (karambit, hawkbill, sickle, cung, móc) | `references/curved-objects.md` (+ `templates/KnifeKit.lua`, `scripts/render_geom.py`) |
| **Mô tả hướng/góc xoay/hành động** ("mũi chỉ xuống", "xoay 90°", "cầm ngược") — LUÔN làm Spatial Brief | `references/spatial-language.md` (+ `scripts/orient.py`, `templates/Orient.lua`) |
| **Animation khó** (R6/R15/Humanoid/Part): combo, lộn, IK, layer, mirror | `references/animation-advanced.md` (+ `templates/AnimKit.lua`, `AnimClips.lua`) |
| **VFX mạnh nhất** (Part + hiệu ứng Roblox + texture + Toolbox + GUI) | `references/vfx-advanced.md` |
| **UI/HUD**: thanh máu, crosshair, scope, toast, damage number | `references/ui-kit.md` (+ `templates/UIKit.lua`) |
| **Âm thanh** laser/nổ/súng: tổng hợp hoặc Toolbox, nhiều lớp 3D | `references/audio-sfx.md` (+ `templates/SoundKit.lua`, `scripts/synth_sfx.py`) |
| Review code, audit trước launch, API deprecated | `security-perf.md` |

## 3. Tra DevForum trước khi code

Nguyên tắc: **không tự nghĩ ra từ đầu khi đã có người làm rồi.** Nhưng tra không phải copy —
đọc → thẩm định → áp dụng → trích nguồn.

### 3.1 Rút từ khóa (bước quyết định chất lượng)

Gạch ra 3 thứ: **đối tượng** (Part, Humanoid, Camera, DataStore), **hành vi** (xoay, phát sáng,
lưu, nổ), **triệu chứng** (nếu là bug). Rồi dịch sang thuật ngữ Roblox:

| User nói | Từ khóa forum |
|---|---|
| "làm nó phát sáng" | `Neon material`, `PointLight`, `SurfaceLight`, `Bloom` |
| "làm nó rung" | `camera shake`, `screen shake`, `CFrame jitter` |
| "nó cứ bay lên trời" | `character flying`, `BodyVelocity`, `AlignPosition` |
| "lưu tiến trình" | `DataStoreService`, `ProfileStore`, `session locking` |
| "làm mượt" | `TweenService`, `Lerp`, `RenderStepped` |
| "nhiều người thấy" | `RemoteEvent`, `server authority`, `replication` |
| "NPC đi theo" | `PathfindingService`, `MoveTo`, `Humanoid` |

Dùng tên API chính xác, không dùng câu dài. `"pathfinding npc follow player"` thắng
`"làm sao để npc đi theo người chơi"`.

### 3.2 Cú pháp Discourse — dùng ngay

| Cú pháp | Tác dụng |
|---|---|
| `in:title` | Chỉ tìm trong tiêu đề — **dùng nhiều nhất**, lọc nhiễu cực tốt |
| `#help-and-feedback:scripting-support` | Giới hạn category |
| `after:2025-01-01` | Chỉ thread mới (tránh API cũ) |
| `order:latest` | Ưu tiên mới nhất |
| `status:solved` | Chỉ thread đã có đáp án |

`"screen shake in:title"` cho kết quả đúng gấp nhiều lần `"screen shake effect"`.

### 3.3 Chạy search

```bash
SKILL_DIR="<thư mục chứa SKILL.md>"   # vd ~/.claude/skills/roblox-studio-pro
DF="$SKILL_DIR/scripts/df.py"

python "$DF" search "pathfinding npc follow in:title" --limit 8
python "$DF" multi "tween part rotation" "TweenService CFrame" "rotate smoothly in:title" --limit 5
python "$DF" read <id> --posts 3          # đọc 3 post đầu
python "$DF" read <id> --code-only        # chỉ bóc code block, giữ indent
```

Luôn chạy **3–5 query khác góc nhìn**: (1) tên API chính xác, (2) mục tiêu bằng từ thường,
(3) triệu chứng nếu là bug, (4) biến thể `in:title`, (5) lọc category nếu tìm module có sẵn.

### 3.4 Chọn và đọc

Ưu tiên: `[SOLVED]` → `scripting-support` → `community-resources`/`community-tutorials`.
Bỏ qua `#collaboration`, `#bulletin-board`, portfolio. **Đọc tối đa 2–3 thread** — quá 3 là lãng phí;
nếu 3 thread không giải quyết được thì vấn đề nằm ở query, quay lại 3.1.

### 3.5 Thẩm định — không được bỏ qua

Code forum có thể cũ. Kiểm: hàm deprecated (`wait` → `task.wait`, `BodyVelocity` → `LinearVelocity`,
`Mouse` → `UserInputService`); ngày tháng (thread trước 2023 phải soi kỹ); bug đã fix chưa;
code có thiếu ngữ cảnh không (Script hay LocalScript, đặt ở đâu); replies nhiều **không** có nghĩa là đúng.

Nếu code mâu thuẫn với hiểu biết của bạn về API hiện tại → **nói rõ cho user**, đừng lặng lẽ chọn một bên.

### 3.6 Không tìm thấy thì sao

Nói thẳng: đã tra N query, không có thread khớp. Đừng bịa "đã tìm thấy". Rồi: thử lại bằng API
chính xác hơn hoặc bỏ `in:title` → tra Creator Docs (`create.roblox.com/docs`) → tự làm nhưng
ghi rõ **đây là cách tự nghĩ, chưa có nguồn cộng đồng**.

Cuối câu trả lời luôn kèm:

```
Nguồn đã đọc:
- <tên thread> — https://devforum.roblox.com/t/.../id (SOLVED)
```

## 4. Script đặt ở đâu (sai chỗ = im lặng không chạy)

| Loại | Chạy khi ở |
|---|---|
| `Script` (RunContext mặc định) | `Workspace`, `ServerScriptService` (server) |
| `Script` với `RunContext = Client` | chạy trên client ở bất kỳ đâu LocalScript chạy được |
| `LocalScript` | `StarterPlayerScripts`, `StarterGui`, `StarterPack`, `StarterCharacterScripts`, `ReplicatedFirst` |
| `ModuleScript` | không bao giờ tự chạy; chỉ khi có script `require` |

Chia chuẩn: **Logic** ở server (sự thật, damage, state), **Presentation** ở client (VFX, SFX, camera, UI),
**Config** là bảng ở đầu script. Server nói "chuyện gì đã xảy ra", client quyết "trông thế nào".
Module dùng chung ở `ReplicatedStorage`; bí mật server-only ở `ServerStorage`.

## 5. Luật cứng (kèm lý do)

- `task.wait/spawn/delay/defer`, **không** `wait()/spawn()/delay()` — bị throttle, không đồng bộ scheduler.
- Dùng `dt` từ `Heartbeat`/`RenderStepped`; **không** giả định 60 FPS. Làm mượt bằng `1 - exp(-k*dt)`.
- Server là nguồn sự thật. Validate **mọi** tham số RemoteEvent (kiểu, khoảng, cooldown, khoảng cách).
  Client gửi **ý định**, không gửi **kết quả**.
- Dọn mọi thứ mình tạo: `Debris:AddItem`, `:Destroy()`, `:Disconnect()`. Rò rỉ gây lag sau 10–20 phút.
- **Không bịa asset id.** Id âm thanh/animation/mesh/texture là placeholder trong Config cho tới khi
  user đưa id thật — và phải nói rõ. Id bịa fail im lặng.
- Không fail im lặng: `FindFirstChild` trả nil phải `warn`; không `pcall` nuốt lỗi mà không log.
- Tránh API deprecated: `Animator:LoadAnimation` (không phải `Humanoid:`), `Model:PivotTo`
  (không `SetPrimaryPartCFrame`), `LinearVelocity/AlignOrientation/AlignPosition`
  (không `BodyVelocity/BodyGyro/BodyPosition`).
- Set `Parent` **cuối cùng** khi tạo Instance. Build hàng loạt: parent từng chunk nhỏ + `task.wait()`
  giữa các chunk — một lần ghi `.Parent` lớn là thao tác không nhường, treo Studio hoặc rớt kết nối.
- `WaitForChild` (có timeout khi hợp lý) cho thứ load trễ; `FindFirstChild` + nil check cho thứ tùy chọn.
- Animation phải thuộc owner của experience (hoặc group), nếu không sẽ không load.
- Tỷ lệ theo studs: nhân vật cao ~5 studs. Hiệu ứng "to" là hàng chục đến hàng trăm studs.
- Hiệu ứng dùng nhiều lớp (hình, sáng, âm, camera/màn hình). Chỉ particle trông rẻ tiền.
- Ưu tiên building block không cần asset (Part, Neon, Beam, emitter texture có sẵn) để kết quả
  vẫn chạy trước khi user đưa asset.

## 6. Bẫy đắt giá nhất (bug im lặng — học từ thực chiến)

- **Không bao giờ che tên hàm global**: `warn`, `print`, `error`, `type`, `next`, `select`, `tick`.
  `local warn = Instance.new("Frame")` giết mọi `warn(...)` sau đó với
  `attempt to call a Instance value` — và chỉ trên nhánh chạy tới nó.
- **Không `Tween.Completed:Wait()` để chờ camera/CFrame.** Tween có thể không bao giờ fire `Completed`
  (bị script khác ghi đè, instance đổi, `CameraType` reset) → cả chuỗi treo, Output trống.
  Dùng vòng `RenderStepped` + `Lerp`.
- **`pcall` trả `true` không có nghĩa là đã xảy ra.** `Part.Size` bị clamp ở 2048, `Camera.CFrame`
  bị ghi đè frame sau, property có thể read-only: sau khi gán, **đọc lại và so**.
- **`WaitForChild` không timeout là bẫy chết** khi chờ thứ có thể không tồn tại (`PlayerModule` trong
  place tự dựng, `Humanoid`, `Animator`). Treo vĩnh viễn và **không in gì**; triệu chứng duy nhất là
  hiệu ứng bắt đầu trễ vài giây.
- **KeyframeSequence đăng ký lúc runtime im lặng không di chuyển rig.** Phải publish animation,
  hoặc dùng `AnimationConstraint.Transform` trong `PreSimulation`.
- **`math.noise` có granularity 1.0** — tham số nguyên trả về 0. Nhân tọa độ với hệ số lẻ trước khi gọi.
- **`humanoid.Jump = true` xoá sạch vận tốc ngang.**
- **Sửa code trong playtest bị revert khi stop** — đừng ngồi sửa giữa lúc test.
- **`Enum.Material.Grass` cực kỳ đắt** — không dùng cho terrain/part diện tích lớn.
- **Streaming giấu geometry khỏi client** — kiểm trước khi đổ lỗi cho pathfinding.
- **`humanoid:MoveTo` không làm gì khi đích cách ~1 stud.**
- **`local x: { T } = []` không hợp lệ** — `[]` không phải literal trong Luau.
- **`string.find` không có `|`** — Lua pattern không phải regex.
- **Không fake được một `Player`** — đã chứng minh, đừng thử lại.
- **GUI phải set `.Parent` khi tạo**, nếu không layout không tính.
- **Model rời ra**: Part neo `Anchored=false` mà không có Weld/khớp thì rơi từng mảnh. Dựng bằng `AssemblyGuard.Build` (socket + weld), rồi `Check` (0 khe hở, 1 assembly). Xem `assembly-integrity.md`.
- **Hiểu sai hướng**: "phải/trái" theo vật, trước = −Z, góc dương = ngược chiều kim đồng hồ; Cylinder tròn quanh trục X; `CFrame.Angles` là Rx·Ry·Rz. Làm Spatial Brief (`spatial-language.md`) rồi kiểm bằng số.
- **Vật cong bằng hộp thẳng**: không ra đường cong. Dùng `KnifeKit`/`GeoKit` phân đoạn hoặc mesh, kiểm phủ/tràn bằng số và render ảnh.

Bẫy theo từng lĩnh vực nằm ở mục `## Bẫy` cuối mỗi reference. Đó là phần giá trị nhất — đọc nó
trước khi debug.

## 7. Khi kết quả yếu — chẩn đoán nhanh

| Phàn nàn | Nguyên nhân thường gặp | Sửa |
|---|---|---|
| "hiệu ứng trông rẻ tiền" | sai tỷ lệ, chỉ 1 lớp, không có pha, màu phẳng | làm lại breakdown: tỷ lệ studs, 4+ lớp, chuẩn bị-chính-dư chấn, màu theo thời gian |
| "chỉ đẹp trên ví dụ" | copy cấu trúc ví dụ | breakdown chủ đề mới; đổi tên mọi thứ theo chủ đề mới |
| "camera/cutscene sai chỗ" | đoán tọa độ thế giới | đặt part camera trong Studio hoặc tính từ chủ thể |
| "không có gì xảy ra" | lỗi wiring im lặng | `verification.md`: name contract, `wiring_check.py`, self-test, bảng vị trí script |
| "lag" | đoán mò không đo | `security-perf.md`: đo, đổi một thứ, đo lại |
| "model trông như hộp" | primitive đối xứng, màu phẳng, không chi tiết | `assets.md`: bất đối xứng, gradient, ánh sáng; hoặc import mesh và dùng code cho rig/VFX |
| "UI vỡ trên mobile" | dùng Offset thay Scale | `ui.md`: Scale, `ScreenInsets`, `UIAspectRatioConstraint` |

## 8. Định dạng trả lời khi giao code

1. Một câu: tính năng gồm gì và chạy ở đâu.
2. Với mỗi script: **tên + loại (Script/LocalScript/ModuleScript) + vị trí**, rồi code block.
3. **Để chỉnh**: id placeholder và các giá trị Config quan trọng (scale, duration, quality).
4. **Kiểm chứng**: đã chạy tool gì, kết quả; dòng log cần thấy khi Play (ví dụ `[Wiring] OK (...)`);
   cái gì chưa kiểm được.
5. **Cách test**: Play / Play Solo, nhìn gì nghe gì, xem ở đâu trong Output.
6. **Nguồn** (nếu có tra forum).

Giải thích ngắn. User cần code chạy được và biết chỗ nào để tinh chỉnh.

## 9. Checklist tự soát trước khi giao

- [ ] Đã chạy breakdown cho **chủ đề này** (không copy từ ví dụ); default đã nêu rõ.
- [ ] Mỗi script đúng chỗ, đúng loại, có lý do.
- [ ] Không `wait()`, không API deprecated, không asset id bịa.
- [ ] Mọi tên đi qua ranh giới nằm trong contract; `wiring_check.py` đã chạy, ERROR/WARN đã xử.
- [ ] Self-test runtime in ra xác nhận; không có `nil` bị bỏ qua im lặng.
- [ ] Mọi connection và instance tạm đã dọn.
- [ ] Remote đã validate; client không quyết định kết quả quan trọng.
- [ ] Đã xử lý nil (nhân vật chết, player rời, instance bị destroy giữa chừng, respawn).
- [ ] Config ở đầu; không magic number.
- [ ] Hiệu ứng đủ lớp và đúng cấu trúc thời gian; overlay không chặn input.
- [ ] Hình học tính và so bằng số (khe hở, đối xứng, kích thước studs).
- [ ] Ngân sách hiệu năng đã nêu (parts, particle, update rate) và có quality scaling.
- [ ] Cutscene khôi phục camera và control ở **mọi** đường thoát.
- [ ] `python scripts/lint_luau.py` không ERROR; `luau-compile` sạch (nếu có).
- [ ] Đã dùng `VFXKit/GeoKit/ModelKit` thay vì viết lại helper; model đã qua `ModelKit.Audit`.
- [ ] Đã chạy vòng chất lượng (`quality-loop.md`) và báo đủ 4 dòng: Đã chạy / Đạt / Trượt-chưa kiểm / Bạn cần làm.
- [ ] Model nhiều part: `AssemblyGuard.Check` = 1 assembly, 0 khe hở; (ngoài Studio) `sim_assembly.py` exit 0.
- [ ] Có Spatial Brief: mọi hướng/góc đã thành vector/số, `orient.py selftest` đạt; vật cong đã render ảnh xem.
- [ ] Có ảnh mẫu: đã `imgread.py sheet/scan/overlay` + `ref_analyze.py swatches`, viết Reference Spec (kích thước, **số lượng đếm trên crop**, vị trí %, bảng màu).
- [ ] Đã chạy `sandbox.py run --render --expect` và **mở ảnh render xem**; hết FAIL; `imgread.py compare` từng góc IoU ≥ 0.75 (hoặc nêu rõ vì sao chưa).
- [ ] Model nhiều part: có Dimension Table (`dimdb.py plan`), dựng bằng `mb.py` (quan hệ, không toạ độ tay), `report.md` 0 ERROR trước khi render, `m.feature` đo từ part; texture theo `model-builder.md` §5; điểm ≥12/14 (`model-pipeline.md`).
- [ ] Báo cáo nói rõ cái gì **chưa** kiểm chứng (Blender thật, Studio thật nếu chưa chạy).

## 10. Script có sẵn (chạy được, không cần cài gì)

| Script | Dùng để | Lệnh |
|---|---|---|
| `scripts/df.py` | Search + đọc DevForum qua Discourse JSON API | `python scripts/df.py search "..." --limit 8` |
| `scripts/wiring_check.py` | Bắt lỗi **wiring im lặng** mà compiler không thấy: key Config gõ sai, handler chết, 2 danh sách lệch tên | `python scripts/wiring_check.py <path> --table Config` |
| `scripts/check_docs.py` | Biên dịch mọi block ` ```lua ` trong tài liệu (mảnh minh hoạ được tách riêng) | `LUAU_COMPILE=<luau-compile> python scripts/check_docs.py` |
| `scripts/lint_luau.py` | Bắt luật cứng: `wait()`, che global, deprecated, `Completed:Wait()`, `WaitForChild` không timeout | `python scripts/lint_luau.py <file-hoặc-thư-mục>` |
| `scripts/gen_vfx_textures.py` | Sinh PNG VFX trắng+alpha (glow, khói, tia, vòng, vết chém, flipbook lửa/khói) | `python scripts/gen_vfx_textures.py --out vfx_tex` |
| `scripts/mb.py` | **Model builder**: khai báo quan hệ → `scene.json` + `build.lua` (Roblox) + `blender.py` + `report.md` + `views.png` (6 góc + người mẫu 5 stud) | `python scripts/mb.py selftest`; dùng `from mb import Model` |
| `scripts/dimdb.py` | Kích thước thật 60+ họ vật thể (cm→stud, khoảng min–typ–max, tỉ lệ giữa đặc trưng) | `python scripts/dimdb.py plan <họ>` |
| `scripts/mbcheck.py` | Kiểm hình học chung (do `mb.save` gọi; cũng chạy trên scene.json) | `python scripts/mb.py check scene.json --family <họ>` |
| `scripts/texgen.py` | 16 kiểu texture PBR tileable + xem trước + kiểm seam | `python scripts/texgen.py make <kiểu> --out tex/` |
| `scripts/qa_check.py`, `sandbox_blender.py`, `roblox_sandbox.lua` | (từ MQP) kiểm/chụp **trong Blender / Studio** — chưa chạy thử ở đây | xem `references/model-pipeline.md` |
| `scripts/sandbox.py` | **Sandbox kiểu Studio**: chạy code Luau dựng model → ảnh nhiều góc, `inspect` (cây, kích thước, cụm rời, weld), `--expect` kiểm tỉ lệ/số lượng/màu/liền khối, `--time/--snaps` | `python scripts/sandbox.py run build.lua --autolib --render out.png --expect e.json` |
| `scripts/imgread.py` | **Hiểu ảnh mẫu bằng số**: sheet (tách + OCR nhãn), palette, measure, grid/ascii, scan (đếm), overlay (lưới toạ độ), compare | `python scripts/imgread.py sheet bang.png out/` |
| `scripts/ref_analyze.py` | Bổ sung cho imgread: swatches (đọc ô màu chính xác), crop có lưới, compare tự nhận lật gương, bbox đổi đơn vị | `python scripts/ref_analyze.py swatches panel.png` |
| `scripts/scene_check.py` | Kiểm `scene.json` theo `expect.json` (cổng chặn, mã thoát 1 nếu FAIL) | `python scripts/scene_check.py scene.json --expect e.json` |
| `scripts/sim_assembly.py` | Mô phỏng model từ spec JSON: đếm cụm rời (SAT), exit 1 nếu >1 | `python scripts/sim_assembly.py spec.json` |
| `scripts/render_geom.py` | Vẽ ảnh side/front/top/iso từ JSON hình học để NHÌN trước khi giao | `python scripts/render_geom.py in.json out.png` |
| `scripts/orient.py` | Lời → vector/CFrame.Angles (Việt+Anh), có `selftest` | `python scripts/orient.py dir "trước và hơi lên"` |
| `scripts/synth_sfx.py` | Tổng hợp SFX laser/nổ/súng/UI + phân tích phổ | `python scripts/synth_sfx.py --out sfx --analyze` |
| `scripts/extract_sprite.py` | Tách sprite pixel-art thành lưới ô để dựng voxel | `python scripts/extract_sprite.py --image a.png --grid 16` |

**`wiring_check.py` bắt buộc có flag, không flag thì chỉ quét mà không kiểm gì:**

| Flag | Kiểm gì |
|---|---|
| `--table NAME` | Key trong bảng Config có được dùng, và key dùng có tồn tại (gợi ý key gần nhất khi gõ sai) |
| `--bind NAME=FUNC[:N]` | Tên trong danh sách phải khớp hàm handler, đúng số tham số |
| `--compare A B` | Hai danh sách phải khớp nhau (ví dụ danh sách joint vs bảng driver) |
| `--markers` | Marker animation có handler tương ứng |

Ví dụ thật: file có `Config = { Speed = 5, Jump = 10 }` rồi gọi `Config.Speedd` →
`[ERROR] 'Speedd' được dùng nhưng bảng Config không có key này (ý bạn là 'Speed'?)`.
Đây chính là loại bug mà compiler **không** bắt được và Output **không** báo.

`extract_sprite.py` cần `numpy` (`python -m pip install numpy`).

## 11. Giới hạn cần biết

- `df.py` chỉ **đọc** forum, không đăng bài (cần đăng nhập). Vài category giới hạn cho member
  (Regular/Plus) có thể trả 404. Script tự giãn nhịp 0.45s và retry khi 429 — đừng chạy hàng trăm query.
- Sandbox (`sandbox.py`) kiểm hình dạng/tỉ lệ/số lượng/kết nối, **không** thay Studio: không vật lý, ánh sáng, CSG, mesh thật; Wedge/Cylinder cần VERIFY.
- Không có Studio đang mở thì **không quan sát được runtime** — phải nói rõ điều đó trong báo cáo,
  và dùng `verification.md` để kiểm bằng số thay vì bằng mắt.
- `studio-mcp.md` chỉ dùng được khi Studio MCP đã kết nối; nếu `list_roblox_studios` trả `[]`
  thì bridge chưa listen — file đó có mục chẩn đoán riêng.
