# Evals

`evals.json` có 13 prompt phủ model / VFX / code / perf / không-có-Studio. Cách dùng:

1. Chạy từng prompt trong một phiên sạch **có** skill và một phiên **không** skill (đường cơ sở).
2. Với mỗi bản trả lời, đánh dấu `must` (đạt/không) và `avoid` (vi phạm/không), rồi tra mã rubric trong `references/quality-loop.md`.
3. Điểm = (số `must` đạt − số `avoid` vi phạm) / số `must`. Ghi bảng điểm vào `evals/results/<ngày>.md`.
4. Sửa skill → chạy lại toàn bộ; chỉ giữ thay đổi nếu điểm trung bình tăng và không case nào tụt.

Bộ này là điểm khởi đầu: thêm case mỗi khi gặp một lỗi thật ngoài đời (mỗi bug im lặng gặp một lần = một case mới).
