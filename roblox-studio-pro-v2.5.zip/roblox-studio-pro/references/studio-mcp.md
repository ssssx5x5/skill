# Studio MCP — điều khiển Roblox Studio bằng agent

> Nguồn: ghi chép thực chiến 2.633 dòng, giữ nguyên toàn bộ (không chưng cất, không lược bỏ).
> Đọc file này khi cần THAO TÁC vào Studio đang mở: chạy Luau, sửa script, inspect DataModel,
> playtest, benchmark, sinh terrain. Không đọc nếu chỉ cần viết code offline.

# Roblox Studio MCP

Drive an open Roblox Studio session from an MCP client: read/edit scripts, execute Luau,
inspect the DataModel, run playtests, capture the viewport, generate assets.

## Setup (Windows)

Roblox Studio ships a **built-in** MCP server. The standalone repo
`Roblox/studio-rust-mcp-server` is **discontinued** — do not install it.

### Do NOT use `%LOCALAPPDATA%\Roblox\mcp.bat`

That file has a **syntax error** (missing closing paren on the `else` branch). Running it
spews garbage to stderr:

```
'else' is not recognized as an internal or external command
'"%B/..\StudioMCP.exe"' is not recognized as an internal or external command
'))' is not recognized as an internal or external command
```

MCP clients that read stderr strictly treat the server as broken and **never load the tools**.
Symptom: the config looks correct, Studio is running, but no `mcp__Roblox_Studio__*` tools exist.

### Point directly at the exe instead

`<file cấu hình MCP của client bạn dùng>`:

```json
{
  "mcpServers": {
    "Roblox_Studio": {
      "command": "C:\\Users\\<user>\\AppData\\Local\\Roblox\\Versions\\version-<hash>\\StudioMCP.exe",
      "args": []
    }
  }
}
```

Resolve the current version directory (Studio updates change it):

```bash
ls -t "$LOCALAPPDATA/Roblox/Versions" | head -1
ls "$LOCALAPPDATA/Roblox/Versions"/version-*/StudioMCP.exe
```

### Verify the server without Studio running

The exe responds to a real MCP handshake on stdio. This isolates server problems from
Studio/trust problems:

```bash
printf '%s\n' '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"probe","version":"1.0"}}}' \
  | "$LOCALAPPDATA/Roblox/Versions"/version-*/StudioMCP.exe
```

Expect (and empty stderr, exit 0):

```json
{"jsonrpc":"2.0","id":1,"result":{"protocolVersion":"2024-11-05","capabilities":{"tools":{"listChanged":true}},"serverInfo":{"name":"RobloxStudio","version":"1.0.0"},"instructions":"Studio MCP Proxy - bridges MCP clients with Roblox Studio"}}
```

List the tools with a follow-up `tools/list` after `initialized`. Expect **29 tools** as of
Studio 0.741: `upload_image, search_game_tree, script_search, skill, subagent, multi_edit,
generate_mesh, get_console_output, user_mouse_input, store_image, http_get, character_navigation,
script_read, get_studio_state, screen_capture, insert_asset, script_grep, wait_job_finished,
generate_procedural_model, generate_texture, segment_mesh, search_asset, generate_material,
user_keyboard_input, execute_luau, inspect_instance, start_stop_play, list_roblox_studios`.
The count drifts between Studio releases — what matters is that `tools/list` *returns*, which
proves the bridge binary is healthy.

### `{"studios":[]}` when Studio IS open — the bridge is not listening

A healthy handshake plus `list_roblox_studios -> {"studios":[]}` does **not** mean the in-Studio
toggle is off. It means nothing is bound to the bridge's port, so Studio's registration attempt
never lands. Diagnose from the outside in; do not start toggling GUI checkboxes.

1. **Confirm Studio is actually running.** Git Bash has no `tasklist` on PATH — call it fully
   qualified:

   ```bash
   "/c/Windows/System32/tasklist.exe" //FO CSV | grep -i -E "roblox|studio"
   ```

2. **Find the port and look for the listener.** The bridge binds a loopback port
   (observed: **13469**). The failure signature is a Studio PID with `SYN_SENT` and *no*
   `LISTENING` row:

   ```bash
   "/c/Windows/System32/netstat.exe" -ano | grep -E ":134[0-9][0-9]"
   ```

   ```
   TCP  127.0.0.1:13469  127.0.0.1:61021  TIME_WAIT  0          <- a previous, working session
   TCP  127.0.0.1:61075  127.0.0.1:13469  SYN_SENT   3736       <- Studio retrying, nobody home
   ```

   `SYN_SENT` with no `LISTENING` on the same port is conclusive: Studio is reaching out, no
   bridge accepts. PID 3736 was `RobloxStudioBeta.exe`.

3. **Confirm in Studio's own log.** Studio states it plainly:

   ```
   %LOCALAPPDATA%\Roblox\logs\<ver>_<timestamp>_Studio_<hash>_last.log
   HttpError: ConnectFail  url:{ "http://localhost:13469/studio" }
   ```

   That same log is the place to verify the in-Studio MCP host is up — grep `startMcpHost`:

   ```bash
   grep -c -i "startMcpHost" "$LOCALAPPDATA/Roblox/logs/"*_Studio_*_last.log
   ```

   Real tool-handler errors show up here too (`Missing required argument: file_path`,
   `Missing required argument: is_start`), which the client-side error messages often mangle.

**Root cause and fix.** The bridge process is launched by the *client*, not by Studio — Studio only
registers into it. So restarting Studio silently breaks the link until the client reconnects.
Check whether the MCP tools are registered in the current session:

```
ToolSearch tool_names:["mcp__Roblox_Studio__list_roblox_studios"]
```

If that returns nothing, the client link is down and no amount of work from a spawned helper
process will fix it — a direct `StudioMCP.exe` subprocess starts its *own* bridge on a *different*
port, which Studio never registers with. The user must re-activate the `Roblox_Studio` MCP server
in the client. Config (`<file cấu hình MCP của client bạn dùng>`) and approvals being present is not sufficient
evidence that it is active.

### User-side steps (cannot be automated)

1. Roblox Studio open on a place → Assistant → `…` → **Manage MCP Servers** →
   **Enable Studio as MCP server**.
2. Client's connector page → custom connector (top right) → **Trust** the server.
   Evidence: entry appears in `<file approvals MCP của client>`.
3. **Restart the MCP client fully.** MCP config is read once at startup.

This client is not in Roblox's Quick connect list (Antigravity, Codex CLI, Claude Code,
Claude Desktop, Cursor, Gemini CLI, VS Code) → JSON config is the only route.

## Every tool call needs `studio_id`

```lua
-- always resolve first, never hardcode: the id changes per Studio launch
list_roblox_studios()  --> {"studios":[{"id":"...","name":"Place1"}]}
```

Pass that `id` as `studio_id` on every subsequent call. Multiple Studio windows are supported —
each call targets its instance explicitly.

## `multi_edit` with a non-empty `old_string` replaces; with `""` it APPENDS

Two different behaviours live in this one tool, and the tool reports success for both.

**Normal use — `old_string` non-empty.** `multi_edit` takes `[{old_string, new_string}, ...]`,
applies them **in sequence** on the result of the previous edit, and is **atomic** — if any edit
fails, **nothing** is applied. A non-matching `old_string` is a clean no-op that names the failure:

```
Edit 3 - old_string 'local DEFAULT_LINES = { ... }' not found in current content
```

Verified: a 4-edit call whose 3rd edit failed left the script completely unchanged. Safe to batch.

**The trap — `old_string: ""`.** An empty `old_string` matches at position 1 and **appends
`new_string` to the end of the existing source**. It does not clear, does not replace, and does not
error. Push a script N times this way and it holds N concatenated copies; the parse then fails with
`Expected <eof>, got '<keyword>'` at the first duplicated line. This is deterministic and was
reproduced precisely:

```
send "a\nb\nc"        -> "a\nb\nc"                          (exact round-trip)
then multi_edit ""    -> "a\nb\nca\nb\nca\\n\\n\\nb\\n\\n\\nca\nb\nca\nb\nc"
```

Note the earlier claim in this skill that the append "was not reproducible" — it is reproducible,
and `old_string: ""` is the trigger. The reason it *looked* erratic is that the growth factor
depends on the prior content, so it is not a constant multiple.

**How to deploy safely.** Use `""`-append only for the case it is actually right for — creating a
missing script object — and never for content:

```python
# create only if absent (append is what we want here)
if not exists(path):
    multi_edit(file_path=path, className="ModuleScript",
               edits=[{"old_string": "", "new_string": "-- pending"}])

# rewrite: ONE assignment, structurally incapable of appending
execute_luau(f'{target}.Source = [==[{source}]==]')
```

A single `.Source` assignment cannot append, cannot partially apply, and needs no diff. Raise the
long-string level (`[===[`) if the content contains `]==]`. Then **read `.Source` back** and compare
— `ok` / `ok~` (whitespace-only drift) / `FAIL` (with expected vs actual line count). Never trust the
write's own success report.

Symptom to recognise instantly: **two top-level `return`s in one module** — the file was duplicated.

### Non-ASCII in `old_string` can fail to match even when the text is visibly there

A script containing Vietnamese/Chinese strings may reject an `old_string` copied straight out of
`script_read`, with the text plainly present in the file. The source stores **precomposed** Unicode
characters, and the transport can normalise them into decomposed form (base letter + combining
diacritic), which is a different byte sequence.

Workarounds, in order of preference:

1. **Keep `old_string` ASCII-only.** Anchor on the surrounding code, not the string literal.
2. **Do the replacement Lua-side** when the match must include the non-ASCII text:

```lua
local src = script.Source
local i, j = src:find(old, 1, true)              -- plain find, no pattern
if not i then return "KHONG TIM THAY" end
if src:find(old, j + 1, true) then return "KHONG DUY NHAT" end
script.Source = src:sub(1, i - 1) .. new .. src:sub(j + 1)
```

`string.find(..., true)` is a plain substring search, and building the result with `sub` +
concatenation sidesteps `gsub`'s `%` escaping in the replacement string entirely. Always check the
match is **unique** before replacing.

Non-ASCII in `new_string` is fine — only matching is affected.

### Still write whole scripts with `execute_luau` when creating them

```lua
local RS = game:GetService("ReplicatedStorage")
local s = Instance.new("ModuleScript")
s.Name = "ChunkManager"
s.Source = [==[
--!strict
local M = {}
return M
]==]
s.Parent = RS.SomeFolder
```

The `[==[ ... ]==]` long string avoids escaping quotes inside the Luau source. Use this for new
scripts; use `multi_edit` for edits to existing ones.

**To overwrite an existing script, just assign `.Source`** — do not destroy and recreate. Destroying
loses the instance's identity (any script still `require`-ing it keeps a stale reference, and
`WaitForChild` callers can break):

```lua
local target = game.ReplicatedStorage.Folder:FindFirstChild("Name")
if target then
	target.Source = [==[
	--!strict
	-- full new body
	]==]
end
```

Use `Instance.new` only when the script does not exist yet.

### `local x: { T } = []` is invalid — and `[]` is never a Luau literal

Luau has **no** array-literal syntax. `{ T }` is a valid *type annotation* (array of `T`), which
makes the mistake easy to write and confusing to read:

```lua
local layers: { Part } = []      -- SAI: Expected <eof>, got 'local' further down
local layers: { Part } = {}      -- DUNG
```

The error surfaces at the *next* `local`, not on the offending line, so it looks like a corruption
or a missing `end` rather than a bad literal. Same trap in every form:
`{ [string]: Bed } = []`, `{ RBXScriptConnection } = []`, `{ number } = []` — all must be `{}`.

Fast check across a whole tree:

```bash
grep -rn -- '= \[\]' *.lua     # any hit is a bug
```

**Always verify the write** — line count and byte count:

```lua
local src = script.Source
local n = 0
for _ in (src .. "\n"):gmatch("(.-)\n") do n = n + 1 end
return string.format("%d dong, %d byte", n, #src)
```

Do **not** validate with `loadstring` on source that carries `--!strict` or type annotations.
`loadstring` compiles at runtime, outside the type-checker's prelude, and rejects annotations that
Studio itself accepts happily:

```
loadstring(src)  -->  nil, "Expected <eof>, got 'local'"
```

That error is identical to the append-corruption error, so it manufactures a false positive for a
perfectly good file. Use `require` on the module instead — it exercises the real compiler and is the
only check that matches what Studio does.

One module = exactly one top-level `return`. Two `return`s means the file was duplicated.

## `string.find` has no `|` — a Lua pattern is not a regex

`"|"` is **not** alternation in Lua patterns. It is an ordinary literal character. This is a silent
bug: the code compiles, runs, and never matches anything.

```lua
-- SAI: khong bao gio khop, ke ca voi "KillBlock"
string.find(name, "kill|hp|lava|spike")
```

Verified: a hazard classifier written this way returned `false` for `KillBlock`, `Lava`, `Spike` and
`DamagePart` — every case it was written to catch. Nothing errored; it just never fired.

Fix by listing the words and matching each with a **plain** find:

```lua
local WORDS = { "kill", "damage", "spike", "lava" }
local function nameMatches(nm)
	for _, w in ipairs(WORDS) do
		if string.find(nm, w, 1, true) then return true end
	end
	return false
end
```

Lua patterns also lack `+?`, `{n,m}`, `\b`, `\d`, `\w`, `(?i)` and lookarounds. The word-boundary
idiom is `%f`:

```lua
string.find(nm, "%f[%w]hp%f[%W]")   -- "hp" as a whole word; skips "Shape"/"Graph"/"Photo"
```

Use it when a short keyword is a substring of common innocuous names.

**When adding any keyword matcher, run the classifier against a table of realistic names** and print
the verdicts — that is what catches this class of bug. Include both the hazards it must catch and
lookalikes it must not (`Shape`, `Graph`, `Photo`, `Platform`).

## A jumpable rise and a jumpable distance are two different limits

`MAX_HOP` (max horizontal) and `JUMP_UP` (max rise) are usually stored as two independent
constants, and then compared independently:

```lua
if rise <= JUMP_UP and edgeHop <= MAX_HOP then   -- SAI: cho phep goc bat kha thi
```

They are not independent — the horizontal reach **shrinks as the rise grows**, and the corner of
that rectangle is unreachable. For a player character (`JumpHeight = 7.2`, `Gravity = 196.2`,
`WalkSpeed = 16`, `jumpVel = sqrt(2*g*h) = 53.15`):

```
t(r)      = (jv + sqrt(jv^2 - 2*g*r)) / g      -- thoi gian bay toi khi roi ve do cao r
D_max(r)  = WalkSpeed * t(r)
```

| rise r | D_max | rise r | D_max |
|---|---|---|---|
| 0 | 8.67 | 4 | 7.22 |
| 1 | 8.36 | 5 | 6.73 |
| 2 | 8.02 | 6 | 6.10 |
| 3 | 7.65 | 7 | 5.05 |

So with `MAX_HOP = 7`, `JUMP_UP = 6`, the pair **(rise 6, distance 7) is impossible** — 12 distinct
`(rise, distance)` pairs in that rectangle are. The old code accepted all of them, computed
`v = math.clamp(D / T, 0, WALK_SPEED)`, silently clamped to 16, and the bot fell short into the
void every time.

The fix is one condition, using the real envelope with a safety margin:

```lua
local REACH_SAFE = 0.85
local function jumpTime(rise)
	local g = workspace.Gravity
	local jv = humanoid.UseJumpPower and humanoid.JumpPower or math.sqrt(2 * g * humanoid.JumpHeight)
	local disc = jv * jv - 2 * g * rise
	if disc <= 0 then return nil end            -- cao hon dinh nhay
	return (jv + math.sqrt(disc)) / g
end
local function maxHop(rise)
	local t = jumpTime(rise)
	return t and (WALK_SPEED * t * REACH_SAFE) or nil
end
-- ...
if edgeHop <= math.min(MAX_HOP, maxHop(rise) or 0) then   -- nhan
```

`math.clamp` on the launch speed is what hid the bug: clamping an impossible request produces a
plausible-looking number instead of an error. **Never clamp a value that represents "can I reach
this" — reject the candidate instead.**

**Corollary: never jump without a confirmed landing spot.** A heuristic like

```lua
local ahead = groundHit(root.Position + dir * 3)
needJump = ahead == nil        -- "khong co dat phia truoc -> nhay" = nhay mu
```

jumps across any gap regardless of width, and is a top cause of "the bot falls into the void
constantly". Only jump to a target that the reach test already accepted.

## `humanoid.Jump = true` WIPES horizontal velocity

This is the single most expensive bug in scripted jumping, and it is invisible unless you measure.
Setting the launch velocity around the jump does not do what it looks like:

| order | velocity 0.05 s later |
|---|---|
| set velocity, **then** `humanoid.Jump = true` | `(0.0, 43.3, -0.0)` — horizontal **gone** |
| `humanoid.Jump = true`, **then** set velocity | `(0.0, 53.2, -12.9)` — kept |

Worse: even the second order is unreliable. Setting the velocity in the *same tick* right after
`humanoid.Jump = true` still gets overwritten, because the humanoid applies its own jump on the next
physics step. A bot built this way jumps straight up and falls back — which reads as "the bot can't
jump gaps" when the real cause is a wiped velocity.

**The robust fix is to hold the horizontal velocity every tick while airborne**, writing only X/Z so
gravity and the jump keep owning Y:

```lua
local flightHoriz = nil    -- Vector3, chi X/Z co y nghia

-- khi nhay:
humanoid.WalkSpeed = v
humanoid.Jump = true
flightHoriz = flat.Unit * v
root.AssemblyLinearVelocity = Vector3.new(flat.Unit.X * v, jv, flat.Unit.Z * v)

-- moi tick trong luc bay:
if now < flightUntil or state == Freefall or state == Jumping then
	if flightTarget then humanoid:MoveTo(flightTarget) end
	if flightHoriz then
		local vel = root.AssemblyLinearVelocity
		root.AssemblyLinearVelocity = Vector3.new(flightHoriz.X, vel.Y, flightHoriz.Z)
	end
	continue
end
```

Clear `flightHoriz` on landing. **Also brake on landing** — the bot arrives with the full horizontal
speed and slides straight off the far side of a small platform:

```lua
if flightTarget then                                  -- chi dung mot lan, ngay tick vua ha
	root.AssemblyLinearVelocity = Vector3.new(0, root.AssemblyLinearVelocity.Y, 0)
end
flightTarget, flightHoriz, flightUntil = nil, nil, 0
```

## Measuring a character's real jump — and how a bad measurement poisons the model

You cannot derive a bot's jump reach from `JumpHeight` alone, and **you cannot trust a measurement
taken while the bot's own control loop is running.** That mistake cost a full debugging cycle here.

**The wrong measurement.** Jumping in place with the bot's loop still active gave an apex of
**6.57** studs, and `6.57 / 7.2 = 0.91` was baked in as `JUMP_APEX_FACTOR`. The bot then
under-estimated its own reach by ~9% and **refused jumps it could easily make** — which reads as
"the bot is stupid", not "a constant is wrong".

**The right measurement.** Disable the bot's control loop first (e.g. move its goal marker far away
so the loop idles), then jump on a large flat surface with no platform edges to interfere:

| WalkSpeed | distance covered | apex | flight time |
|---|---|---|---|
| 8 | 3.44 | 7.30 | 0.567 s |
| 13 | 5.98 | 7.31 | 0.553 s |
| 14 | 6.66 | 7.31 | 0.549 s |
| 16 | **7.79** | **7.31** | 0.566 s |

So the real apex is **7.30–7.31 studs** — it matches `JumpHeight = 7.2` after all, and the 6.57 was
contaminated.

**Two separate corrections fall out of this table:**

1. **Apex** — trust `JumpHeight` (factor ≈ 1.0). `T(0) = 2 * sqrt(2*g*7.2) / g = 0.542 s`.
2. **Horizontal loss** — the bot is *given* 16 studs/s but only achieves **~13.8**, a ~14% loss.
   That is a physical property of the flight, not a safety margin, so it belongs in its own constant:

```lua
local JUMP_APEX_FACTOR = 1.0    -- do lai: dinh nhay that 7.30, khop JumpHeight
local HOP_EFF = 0.90            -- mat mat toc do ngang khi bay — DO DUOC, khong phai bien an toan
local REACH_SAFE = 0.95         -- bien an toan THAT SU (sai so + do tre mang)

local function jumpApex()
	if humanoid.UseJumpPower then
		return humanoid.JumpPower * humanoid.JumpPower / (2 * workspace.Gravity)
	end
	return humanoid.JumpHeight * JUMP_APEX_FACTOR
end

local function jumpVel()  return math.sqrt(2 * workspace.Gravity * jumpApex()) end
local function jumpTime(rise)
	local g, jv = workspace.Gravity, jumpVel()
	local disc = jv * jv - 2 * g * rise
	if disc <= 0 then return nil end
	return (jv + math.sqrt(disc)) / g
end
local function maxHop(rise, relax)
	local t = jumpTime(rise)
	if not t then return nil end
	return WALK_SPEED * t * HOP_EFF * math.min(1, relax or REACH_SAFE)
end
```

**Check the model against the table before trusting it:** `16 * 0.542 * 0.90 = 7.80` vs the measured
`7.79`. If your formula does not reproduce the measurement to within ~0.1 stud, it is wrong.

Re-calibrate if the avatar, `JumpHeight`, `WalkSpeed`, or gravity changes.

**The resulting hard limit is worth stating plainly:** at `WalkSpeed = 16` the maximum horizontal
distance a character can clear is **~7.8 studs**. Any gap wider than that is genuinely impossible
with an ordinary jump, and a bot refusing it is correct, not broken. If a human clears more, they are
using something the bot lacks — landing exactly on the lip, a running start, or a wall-hop.

**A separate waste worth checking:** how early does the jump fire? A gap probe that runs out
`2.5` studs ahead of the ledge means the bot launches 2.5 studs *before* the edge and throws away
2.5 studs of its reach. Probe just far enough to be safe — one tick of travel
(`WalkSpeed * STEP` ≈ 0.8 studs at 16/0.05) plus a small margin:

```lua
local mid = groundNear(root.Position + flat.Unit * math.min(flat.Magnitude * 0.5, 1.0), myTop)
```

## A long raycast finds the floor BELOW the void

`workspace:Raycast(pos, Vector3.new(0, -60, 0))` will happily hit a baseplate 20 studs below a gap
and report "there is ground here". Every edge guard built on it therefore says *safe* at the exact
moment the bot should stop — and the bot walks off the platform.

Measured symptom: a bot that stops safely on a platform one run, and walks into the void the next,
with the same code and the same geometry.

**Always check the height of the hit, not just its existence:**

```lua
-- groundHit ban toi 60 studs nen no "thay" ca baseplate duoi vuc. Chi tinh la dat khi mat cham
-- NGANG TAM CHAN (lech toi da 2 studs).
local function groundNear(pos, refTop)
	local hit = groundHit(pos)
	if hit and hit.Position.Y >= refTop - 2 then
		return hit
	end
	return nil
end
```

Use `groundNear` for **both** the edge guard and the "is there a gap ahead" test. They are the same
question and must use the same answer.

## `humanoid:MoveTo` does nothing when the target is ~1 stud away

Walking a bot in small steps looks safe and is silently fatal:

```lua
humanoid:MoveTo(root.Position + dir * 1)     -- bot dung im vinh vien
humanoid:MoveTo(root.Position + dir * 2)     -- bot di
```

The humanoid treats a target within roughly a stud as already reached and never starts moving. A
fallback that advances 1 stud per tick therefore freezes the bot at a spot 2+ studs from the ledge —
and since jump reachability is measured from where the bot stands, the jump it needs never becomes
"close enough" and the bot refuses forever.

**Fix: aim far and gate the movement with the edge probe**, rather than aiming short:

```lua
local ahead = groundNear(root.Position + toGoal.Unit * 1.5, myTop)
if ahead == nil or looksDangerous(ahead.Instance) then
	humanoid:MoveTo(root.Position)          -- dung ngay
	continue
end
humanoid:MoveTo(root.Position + toGoal.Unit * 8)   -- dich xa -> humanoid di lien tuc
```

The probe distance must exceed one tick of travel (`WalkSpeed * STEP` ≈ 0.8 studs at 16/0.05) so the
bot cannot overshoot the edge between checks, while staying small enough that the bot gets close
enough to the ledge for its jump to be feasible.

## Small gaps are walkable — do not jump them

A character's collision hull bridges a gap narrower than its own footprint, so a "gap" below a
certain width costs nothing and **jumping it is worse than walking it**: it burns `JUMP_COOLDOWN`,
overshoots, and can land badly. Measured on a default character (root part 2×2, `WalkSpeed = 16`),
walking straight across gaps of increasing width:

| gap | result | dip below the platform |
|---|---|---|
| 2.5 | crosses | 0.7 studs |
| 3.5 | crosses | 1.7 studs |
| **4.5** | **crosses** | 2.3 studs |
| 5.0 | **falls** | — |
| 6.0 | **falls** | — |

So gaps up to **~4.5 studs** are crossable on foot, and the character merely sags into the gap. Use a
value with margin below the measured limit:

```lua
local BRIDGE = 4.2   -- DO DUOC: khe <= 4.5 studs thi nhan vat di qua duoc, khong roi
```

Gate the jump on it — only jump when the far side is further than the character can bridge:

```lua
local needJump = rise > 1.5
if not needJump then
	local mid = groundNear(root.Position + flat.Unit * math.min(flat.Magnitude * 0.5, 1.0), myTop)
	if mid == nil then
		-- Khong co dat ngay truoc mat. NHUNG khe nho hon be ngang nhan vat thi khong the roi.
		local far = groundNear(root.Position + flat.Unit * math.min(flat.Magnitude, BRIDGE), myTop)
		needJump = (far == nil)
	end
end
```

Probe at `min(flat.Magnitude, BRIDGE)` so a gap just under the limit still finds the far platform,
while a wider one does not.

**Measure the limit for your own character** — it depends on the avatar's collision size. Build
strips with gaps of 0.5 / 1 / 1.5 / 2 / 2.5 / 3.5 / 4.5 / 5 / 6 studs high above a floor, walk the
character straight across each, and record where it drops.

## Choosing the ground the bot is standing on: overlap, not contact

A "which part am I standing on" helper is easy to write wrong, and the failure mode is a permanent
freeze that looks like broken pathing.

```lua
-- SAI: bat ky part nao cham hop do cung duoc
for _, part in ipairs(region) do
	if top <= ceiling and top > bestY then best, bestY = part, top end
end
```

The probe box is typically larger than the character (4×4 is common), so a platform the character is
merely *touching* at the lip gets selected over the one it is actually standing on. If the pathing
then excludes the current ground from candidate steps (`skip = myGround`), the bot will **never
target the platform it actually needs** and stands still forever. Measured:

```
bot z=-151.0 | ground=D_Bar1.5     -- thuc te dang dung tren D_Bar2
```

Two passes fix it: find the **highest** surface (so a huge baseplate far below cannot win on area),
then among parts within ~2 studs of that height pick the one with the **largest XZ overlap with the
character's foot box**:

```lua
local FOOT = Vector3.new(2, 6, 2)

local function supportGround()
	if not root then return nil, nil end
	local region = workspace:GetPartBoundsInBox(
		CFrame.new(root.Position - Vector3.new(0, 3.5, 0)), SUPPORT_BOX, searchParams)
	local ceiling = root.Position.Y - 1.2
	local px, pz = root.Position.X, root.Position.Z

	local highest = -math.huge
	for _, part in ipairs(region) do
		if part:IsA("BasePart") then
			local top = part.Position.Y + part.Size.Y * 0.5
			if top <= ceiling and top > highest then highest = top end
		end
	end
	if highest == -math.huge then return nil, nil end

	local best, bestY, bestArea = nil, -math.huge, -1
	for _, part in ipairs(region) do
		if part:IsA("BasePart") then
			local top = part.Position.Y + part.Size.Y * 0.5
			if top <= ceiling and top >= highest - 2 then
				local ox = math.min(px + FOOT.X * 0.5, part.Position.X + part.Size.X * 0.5)
					- math.max(px - FOOT.X * 0.5, part.Position.X - part.Size.X * 0.5)
				local oz = math.min(pz + FOOT.Z * 0.5, part.Position.Z + part.Size.Z * 0.5)
					- math.max(pz - FOOT.Z * 0.5, part.Position.Z - part.Size.Z * 0.5)
				local area = math.max(0, ox) * math.max(0, oz)
				if area > bestArea or (area == bestArea and top > bestY) then
					best, bestY, bestArea = part, top, area
				end
			end
		end
	end
	return best, bestY
end
```

**Any time a bot "refuses to move" for no visible reason, print what it thinks it is standing on
first.** This one bug accounted for several rounds of misdiagnosis.

### The ground probe's ceiling must be generous — a character sags into gaps

Standing normally, the root sits ~3 studs above the platform top, so a ceiling of `root.Y - 1.2`
looks safe. But when the character **walks across a gap it can bridge, it sags into it** and the root
drops to ~1.1 studs above the top — and the ceiling then rejects the very platform it is standing on:

```
bot y=-452.9 | ground=nil top=-inf   ->  MOI ung vien "qua cao"
```

`supportGround` returns nil → the loop's "no ground" branch calls `humanoid:MoveTo(root.Position)` →
the bot **stops every tick** and looks permanently stuck. Measured root sag while bridging:
2.5-stud gap → 0.7 studs; 4.5-stud gap → 2.3 studs.

Make the probe box taller and the ceiling looser:

```lua
local SUPPORT_BOX = Vector3.new(4, 8, 4)
-- ...
local region = workspace:GetPartBoundsInBox(
	CFrame.new(root.Position - Vector3.new(0, 4, 0)), SUPPORT_BOX, searchParams)
local ceiling = root.Position.Y - 0.5
```

### `HumanoidStateType.Climbing` happens with no truss in sight

A climb branch written as "if the state is Climbing, steer along the truss" silently freezes the bot
whenever the state appears for another reason — which it does:

```
vi tri: y=-452.9 z=-142.8 | state=Enum.HumanoidStateType.Climbing     -- khong co truss nao
```

The character was wedged in a gap between two platforms. `climbDir` was `nil` (the truss probe had
not hit anything), so the branch did nothing and `continue`d — **standing still forever**.

**Gate the branch on the truss actually being detected, not on the state alone:**

```lua
if state == Enum.HumanoidStateType.Climbing and climbDir then
	humanoid:MoveTo(root.Position + climbDir * 3 + Vector3.new(0, 8, 0))
	...
	continue
end
```

And clear `climbDir` when the truss probe misses, so a stale direction cannot steer a later spurious
climb.

### Do not "wait then retry" when waiting yields no new information

A bot that relaxes its safety margin only after standing still for N seconds spends those N seconds
looking broken. Measured with a per-movement trace (not a fixed sampling rate):

```
z=-140.0  dung im 2.7 s
z=-150.4  dung im 2.9 s
z=-160.5  dung im 5.2 s      <- roi moi chiu thu
```

Nothing changes while it waits, so the wait buys nothing. **Try the safe pass, and if it yields
nothing, retry immediately with the relaxed pass:**

```lua
local usedRelax = false
local spot, _, _, why = nextStep(goal, myTop, myGround, REACH_SAFE)
if not spot then
	usedRelax = true
	spot, _, _, why = nextStep(goal, myTop, myGround, 1.0)
end
```

Max stall went from **5.2 s to 0.22 s** with no loss of caution — the safe candidate is still
preferred whenever one exists.

**To measure stalling, log on movement, not on a timer.** Record a sample each time the position
changes by ≥ 0.5 studs, then diff the timestamps. A fixed 0.4 s sampler hides the stall entirely
because it keeps emitting rows while the bot stands still.

## Landing inset must be computed per axis

When aiming at a point safely inside a target platform, compute the inset for X and Z separately.
Taking `min(Size.X, Size.Z)` and applying it to both axes pulls the landing point to the lip along
the *long* axis for no reason — and that is where the bot falls:

```lua
-- SAI: thanh mong 1.5 x 8 studs -> inset 0.375 ap cho ca truc Z dai 8 studs
local inset = math.min(insetBase, math.min(part.Size.X, part.Size.Z) * 0.25)

-- DUNG
local insetX = math.min(insetBase, part.Size.X * 0.25)
local insetZ = math.min(insetBase, part.Size.Z * 0.25)
```

A long thin bar approached along its length needs a *tight* X inset (the bar is narrow) and a
*generous* Z inset (there are 8 studs of platform to land on).

## A Lua closure does not see a `local` declared after it

```lua
local function refreshFilter()          -- dinh nghia TRUOC
	landParams.FilterDescendantsInstances = list   -- landParams la NIL o day
end

local landParams = RaycastParams.new()  -- khai bao SAU -> qua muon
```

Closures capture upvalues **by name at definition time**. A `local` declared later in the same scope
is not visible to an earlier function; it resolves to a global, which is `nil`, and the error appears
at the call site:

```
BotClient:333: attempt to index nil with 'FilterDescendantsInstances'
```

It compiles cleanly and only fails at runtime. When inserting a new `local` that a function uses,
**check the declaration order** — a cheap scripted check:

```lua
local function pos(s) return src:find(s, 1, true) or math.huge end
-- assert pos("local landParams") < pos("local function refreshFilter")
```

## Testing a bot in Studio with one client: use a marker part

A bot that follows a master cannot be tested with a single client — and `Instance.new("Player")` is
blocked (`lacking capability WritePlayer`), so a fake master is impossible. A **marker part** solves
it and unblocks the whole test loop:

```lua
-- trong vong lap, thay cho "lay vi tri master":
local testTarget = botTargetRef          -- cache, lam moi 2 giay/lan
if testTarget and testTarget:IsA("BasePart") then
	goal = testTarget.Position
end
```

Then place/move a part named `BotTarget` in Studio and watch the bot navigate to it. Also gate a
stuck-diagnostic print on the same flag so the bot reports *why* it stopped:

```lua
print(string.format("[Bot] TEST ket: why=%s | minh y=%.1f z=%.1f | dich y=%.1f z=%.1f", ...))
```

Three traps that cost real time:

- **`FindFirstChild` is not recursive.** A part inside a folder is invisible to
  `workspace:FindFirstChild("BotTarget")`. Use `FindFirstChild("BotTarget", true)` — but cache it
  (~2 s) rather than scanning every tick.
- **Make the marker non-collidable.** A solid marker gets climbed, the bot stands on it, the goal
  becomes "right here", and it never moves. `CanCollide = false`.
- **Disable the give-up teleport in test mode.** Otherwise the bot teleports to the goal and the test
  proves nothing about its pathing.

## Edits made during a playtest are reverted when you stop it

Moving parts, changing properties, or creating instances from the **Server** datamodel during a
playtest is discarded the moment `start_stop_play {is_start: false}` runs. A test target you placed
during the run silently snaps back to its saved position on the next run — which looks like the bot
ignoring the target.

Make every setup change in **Edit** mode. Client-side changes to a part only affect that client's
view and vanish with the playtest too.

## Making a bot avoid hazards it was never told about

When the bot must work in a game you cannot inspect (a live obby, someone else's place), do not try
to enumerate the hazards. Give it two tiers:

**Tier 1 — name/tag guess.** A word list plus `CollectionService:HasTag(part, "Kill")`. Cheap, but
only a guess; get the matching right (see the `|` section above) and bias toward **precision**, not
recall: a false negative self-corrects on the next death, while a false positive permanently
blacklists a good platform.

**Tier 2 — learn from damage.** This is the part that actually works, and it needs no knowledge of
the game:

```lua
-- trong bindCharacter(char): gan Touched cho MOI BasePart cua nhan vat (khong chi HumanoidRootPart —
-- vat hazard o mat dat thi ban chan cham truoc)
local lastTouch, lastTouchAt = nil, 0
for _, d in ipairs(char:GetDescendants()) do
	if d:IsA("BasePart") then
		d.Touched:Connect(function(hit)
			if hit ~= currentGround and not hit:IsDescendantOf(char) then
				lastTouch, lastTouchAt = hit, os.clock()
			end
		end)
	end
end

local lastHealth = hum.Health
hum.HealthChanged:Connect(function(h)
	if h < lastHealth - 0.5 and lastTouch and os.clock() - lastTouchAt < 1.5 then
		dangerous[lastTouch] = os.clock()
		print("[Bot] HOC: " .. lastTouch:GetFullName() .. " la nguy hiem")
		lastTouch = nil
	end
	lastHealth = h
end)
```

Verified end to end: a test part whose `Touched` did `Health -= 20` produced
`[BotClient] HOC: Workspace.KillTestPart la nguy hiem (hp 100 -> 0)` in the console.

Details that matter:

- **Exclude the part the bot is standing on** (`currentGround`, refreshed each tick), or every step
  marks the floor as lethal.
- **Exclude the bot's own parts** (`hit:IsDescendantOf(char)`) — limbs touch each other constantly.
- **Keep the `dangerous` table outside `bindCharacter`** so the knowledge survives death and
  respawn. Clearing it on respawn throws away everything learned.
- **The `HealthChanged` guard runs even on a fatal hit** (hp → 0 fires before the character is
  removed), so instant-kill blocks are learned too.
- **Guard with `not dangerous[lastTouch]`** so a bot respawning next to the same hazard does not
  re-log it forever.

Then filter every pathing candidate through the classifier, and also check the raycast hit before
walking into it:

```lua
if looksDangerous(part) then ... end                       -- trong nextStep
if ahead == nil or looksDangerous(ahead.Instance) then     -- truoc khi buoc toi
	humanoid:MoveTo(root.Position)                          -- dung yen, khong di
end
```

**Expose the classifier as a chat command** (`scan`) that prints a per-part verdict table
(`nhay duoc` / `NGUY HIEM` / `qua xa` / `qua cao` / `xuyen qua`). It turns an invisible decision into
something the user can read in the Output window, and it is the fastest way to find out that the
classifier is broken.

## Streaming hides geometry from the client — check it before blaming the pathing

If a bot's pathing works in Studio but collapses in the published game, check
`workspace.StreamingEnabled` **first**:

```lua
return workspace.StreamingEnabled    -- true = client khong thay part o xa
```

With streaming on, `workspace:GetPartBoundsInRadius`, `GetPartBoundsInBox` and `Raycast` on the
**client** only see streamed-in parts. A bot probing its surroundings for a platform will find
nothing where a platform exists, decide "no ground ahead", and walk into the void. Nothing errors —
the queries just return less.

`workspace.StreamingMinRadius` / `StreamingTargetRadius` / `StreamingIntegrityMode` may not exist in
the current engine version — read them defensively or skip them.

Two ways out: turn streaming off if the place can afford it, or move the geometry probing to the
server and replicate the decision down. Do not "fix" the pathing logic before checking this flag.

## Benchmarking render performance

Use `Stats.RenderBreakdown` (triangles per material) and `Stats.PerformanceStats` (CPU/GPU
ms). Read them from the **Client** datamodel during a playtest.

```lua
local Stats = game:GetService("Stats")
local out = {}
for _, item in Stats.RenderBreakdown:GetChildren() do
  if item:IsA("StatsItem") then
    local ok, v = pcall(function() return item:GetValue() end)
    if ok and v > 0 then out[item.Name] = math.floor(v) end
  end
end
return out
```

`RenderBreakdown` is a **rolling average** — after changing the scene, wait several seconds
before reading it, or the old values persist.

### Do NOT judge performance by Studio Editor FPS

Measuring FPS in the Editor with `RenderStepped` reports ~15 FPS **even on an empty scene**
(baseline verified: 15 FPS with all geometry deleted). The Editor caps it. Always use
`RenderBreakdown` / `PerformanceStats` instead.

### `Enum.Material.Grass` is extremely expensive

Measured on 25 chunks (5×5, 256 stud each):

| | Grass | Ground |
|---|---|---|
| Terrain triangles | 32,902 | **20,600** |
| Grass triangles | **124,745** | **0** |

Switching `Enum.Material.Grass` → `Enum.Material.Ground` removes 124k grass triangles and
cuts total terrain triangles by **37%**. Check the material of every large terrain surface
before optimizing anything else — it is the cheapest and largest win.

## Roblox engine hard limits

| Limit | Value | Consequence |
|---|---|---|
| Terrain voxel size | **4 stud** | fixed; chunk sizes must be multiples of 4 |
| Terrain world extent | **1792×1792 stud** | **cannot be infinite**; max 448 voxels/side |
| `ReadVoxels`/`WriteVoxels` | **1024 cells per call** | a 256-stud chunk (64³) needs 256 calls — do not use at runtime |
| Practical part count | ~20–30k | beyond this the engine stalls |

To exceed 1792 stud, shift the world origin (`PivotTo` everything) as the player travels —
that is a separate project, not a configuration flag.

## Terrain vs Part-based chunks — choose by the void requirement

Roblox `Terrain` renders **only outer faces**, giving meshing, backface culling, and
occlusion for free. Filling a chunk with `FillBlock` is far cheaper than building the same
volume from `Part`s:

| | Terrain `FillBlock` | Part blocks (3D voxels) |
|---|---|---|
| 25 chunks | **0.072 s** | — |
| 9 chunks × 1 layer | — | 0.933 s (9,216 parts) |
| Extrapolated 25 chunks × 32 layers | | **~819,000 parts** |

**But Terrain cannot do "chunk outside radius = void".** Terrain is a single engine-wide
volume: either voxels exist or they are `Air`. Clearing the outside requires repeated
`FillBlock(Air)` calls as the player moves, and refilling on return — very expensive.

Part-based chunks make the void **free**: create parts only for chunks inside the radius;
chunks outside simply do not exist, so nothing renders and the player sees empty space.
No clearing, no fog fakery needed.

**The affordable middle ground is columns, not voxels.** One `Part` per 32-stud column
(8×8 = 64 parts per 256-stud chunk):

| Approach | Total parts | Build time | Terrain detail |
|---|---|---|---|
| 3D voxels (8 stud) | 819,000 | ~83 s | high |
| **Columns (32 stud)** | **1,600** | **170 ms** | rolling hills |
| One part per chunk | 25 | 1 ms | flat |

Columns give real elevation variation at 1,600 parts — measured 0 terrain triangles,
~7,700 opaque draw calls, 1,756 MB for 25 chunks. Clone parts from a pre-configured
template (`self._template:Clone()`) rather than calling `Instance.new` per part.

Prefer Terrain when the world is bounded and you want maximum detail per part. Prefer
column parts when you need an unbounded, streamable world with a visible void boundary.

## Streaming

`StreamingEnabled` (on by default) is Roblox's built-in streaming layer — it loads and
unloads around the player with zero application code. Use it **or** a hand-rolled chunk
system, not both; they fight each other.

For hand-rolled systems: keep chunk folders separate from terrain, throttle generation with
a per-frame budget (e.g. 1–2 chunks/frame) to avoid frame spikes, and queue chunks sorted by
distance so the nearest appear first.

## Luau pitfalls encountered

- `..` binds **tighter** than `and`. `"str" .. tbl and "ok"` concatenates a string with a
  table and crashes. Parenthesize: `"str" .. (tbl and "ok" or "?")`.
- `export type X = typeof(X.new())` must appear **before** the function definition, and the
  metatable form must be `typeof(setmetatable({} :: { field: T }, X))`.
- Iterating a dict needs `pairs()`; `for k, v in dict do` silently fails.
- `Stats.FrameRateManager` and `Stats.Render` **do exist** as `StatsItem` instances (confirmed
  in the DataModel tree), but reading them in the Editor returns the Editor's capped frame
  rate, not real performance. Use `Stats.RenderBreakdown` and `Stats.PerformanceStats`.
- `TextButton` has no `:Activate()` method. To test a button programmatically, extract the
  handler out of the `MouseButton1Click` connection, or test the underlying API directly.
- **`MeshId` is on `SpecialMesh`, not `Part`.** `part.MeshId = ""` throws
  `MeshId is not a valid member of Part`. To make a plain block, simply never add a mesh;
  to clear one, destroy the `SpecialMesh` child. Easy to write by accident when a helper
  like `createSegment()` clears a mesh but not every caller adds one.
- **`ShapeInOut` takes `ParticleEmitterShapeInOut`, not `ParticleOrientation`.** Mixing them
  throws `Unable to assign property ShapeInOut. EnumItem of type ParticleEmitterShapeInOut
  expected, got an EnumItem of type ParticleOrientation`. The two are neighbours in the
  autocomplete list and the intent ("face the camera") belongs to `Orientation`, so the
  mistake reads as correct. Correct pair:
  ```lua
  emitter.ShapeInOut  = Enum.ParticleEmitterShapeInOut.InAndOut
  emitter.Orientation = Enum.ParticleOrientation.FacingCamera
  ```
- **A module-level table field read before it is ever assigned is `nil`, not 0.**
  `Module.lastOffset` initialised only inside `stop()` throws
  `attempt to perform arithmetic (sub) on number and nil` on the *first* `update()` —
  every frame, until the error log is thousands of lines deep. Initialise accumulator
  fields at declaration. Also guard engine properties that can legitimately be `nil` on a
  bare place (`Lighting.ExposureCompensation` is one).
- **Storing a script correctly is not the same as it running.** All three bugs above
  compiled cleanly *and* required cleanly; only `RenderStepped` exposed them. A require
  sweep passes modules that throw on their first frame — read the console during an actual
  playtest before calling anything verified.

## `math.noise` has granularity 1.0 — integer arguments return 0

This is the single most deceptive bug in procedural terrain. `math.noise` snaps to integer
lattice nodes, so **any argument that is a whole number returns exactly 0**.

Three failure modes seen in practice:

1. `math.noise(wx * 0.01 + seed, wz * 0.01)` with a large `seed` (e.g. `20260927`) — the seed
   **swallows** `wx * 0.01` (~0.16) into its integer part, so every `wx` yields the same
   value. Terrain varies along one axis only. Detect it by comparing `(16,16)` vs `(48,16)` —
   if both return the same number, this is the bug.
2. `math.noise(x, z, seed * 0.001)` — `seed = 1 → 0.001`, `500 → 0.5`, `1000 → 1.0` are all
   integers → returns 0 for every small seed.
3. `FREQ = 0.5` or `1` — integer coordinates land exactly on lattice nodes → 0.

**Correct approach** — hash the seed into an *odd* offset in (0,1) using two irrationals:

```lua
local PHI   = 0.618033988749895  -- 1/phi
local SQ2M1 = 0.414213562373095  -- sqrt(2) - 1

local o1 = (seed * PHI) % 1
local o2 = (seed * SQ2M1) % 1
local n = math.noise(wx * FREQ + o1, wz * FREQ + o2)
```

Verified: `seed=1 → (16,16)=-0.4171`, `seed=2 → +0.0738`, `seed=20260927 → -0.2231`. Every
seed differs and both X and Z vary. Always assert a seed invariant in a `demo()`.

## Reading live state from `execute_luau`

Each `execute_luau` call runs in a **fresh sandbox**. `require()` returns a **new module
instance** whose state is not shared with the module already running inside a Script or
LocalScript. Consequences:

- `require(Controller).getStats()` from a command returns zeros, not the running state.
- Unload/reload cycles reset `require` caches unpredictably.

**Read live state through `workspace` or through the GUI instance**, not through `require`.
When a playtest may be interrupted between calls (character respawn recreates `PlayerGui`),
**gather every reading in ONE command** rather than several sequential ones.

## GUI construction: set `.Parent` when creating

A helper that takes children as an argument is easy to call backwards. This pattern silently
produced an empty ScreenGui (created but with zero children):

```lua
-- WRONG: parents toggleBtn INTO the UICorner, and never sets ScreenGui.Parent
local function make(cls, props, children)
  local inst = Instance.new(cls)
  for k, v in pairs(props) do inst[k] = v end
  for _, c in ipairs(children or {}) do c.Parent = inst end
  return inst        -- .Parent never set!
end
make("UICorner", { CornerRadius = UDim.new(0, 8) }, { toggleBtn })
```

Use a helper that parents immediately, and nest explicitly:

```lua
local function new(cls, parent, props)
  local inst = Instance.new(cls)
  for k, v in pairs(props) do inst[k] = v end
  inst.Parent = parent
  return inst
end
local btn = new("TextButton", gui, { Name = "Toggle", Text = "OPEN" })
new("UICorner", btn, { CornerRadius = UDim.new(0, 8) })
```

Verify the built tree by dumping `#gui:GetChildren()` — 0 children means the parenting step
was missed, not that the GUI failed to appear.

## You cannot fake a `Player` — proven

`Instance.new("Player")` fails on a script thread:

```
The current thread cannot create 'Player' (lacking capability WritePlayer)
```

`WritePlayer` is a RobloxScriptSecurity capability, so neither the command bar nor a plugin can
grant it. Consequences no workaround fixes:

- `game.Players` can never contain a fabricated player.
- `Players:GetPlayerFromCharacter(model)` returns `nil` for a clone.
- Leaderboards, `PlayerAdded`, and anything iterating `Players:GetPlayers()` will not see it.

If the goal is "test my game with 2 players", the correct answer is Studio's **Local Server**
test (Test → Clients and Servers → N Players), which produces *real* Player instances. The MCP
cannot start it — `start_stop_play` takes only `is_start`, with no player count.

### Cloning an avatar as an NPC (the achievable part)

Visually and physically identical to a player, but it is a `Model`:

```lua
local Players = game:GetService("Players")
local desc = Players:GetHumanoidDescriptionFromUserId(USER_ID)
local model = Players:CreateHumanoidModelFromDescription(desc, Enum.HumanoidRigType.R15)
model.Name = USERNAME
model.Parent = workspace

local hum = model:FindFirstChildOfClass("Humanoid")
hum.DisplayName = USERNAME                    -- nametag like a player
hum.NameDisplayDistance = 100
hum.HealthDisplayDistance = 100
hum.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.Viewer

-- REQUIRED: the generated `Animate` is a LocalScript and will NOT run in workspace.
-- Copy its Source into a Script and destroy the LocalScript, or the clone T-poses/slides.
local animate = model:FindFirstChild("Animate")
if animate and animate:IsA("LocalScript") then
    local src = animate.Source
    animate:Destroy()
    local s = Instance.new("Script"); s.Name = "Animate"; s.Source = src; s.Parent = model
end
```

`CreateHumanoidModelFromDescription` returns a full R15 rig (16 MeshParts + `HumanoidRootPart`)
plus `Shirt`, `Pants`, `BodyColors` and accessories. It does **not** include the `Health` regen
script that real player characters have.

Grounded placement — measure the Y offset, do not guess it:

```lua
local lowest = math.huge
for _, d in ipairs(model:GetDescendants()) do
    if d:IsA("BasePart") then lowest = math.min(lowest, d.Position.Y - d.Size.Y / 2) end
end
local p = model:GetPivot()
model:PivotTo(CFrame.new(x, p.Position.Y - lowest, z))   -- feet now at y = 0
```

Scripts do not run in Edit mode, so `Animate` and physics only come alive during a playtest.

### Three traps when the clone becomes an NPC

**Do not name the clone after the player.** `workspace:WaitForChild("username")` becomes ambiguous
the moment that player spawns — characters are parented to Workspace under the player's own name,
so you get the character instead of the NPC. Rename the model (e.g. `Bot`).

**The `Animate` conversion has two traps, and the second one silently kills all animation.**
Converting LocalScript → Script stops the T-pose, but if you build the replacement with
`Instance.new("Script")` and copy only `.Source`, you **lose the 22 children** the stock `Animate`
carries — the `PlayEmote` BindableFunction and every animation id (`idle`, `walk`, `run`, `jump`,
… as StringValues). Two consequences:

1. The stock script ends with `script:WaitForChild("PlayEmote").OnInvoke = ...`. With no child it
   yields **forever**, so nothing after it ever runs:
   ```
   Infinite yield possible on 'Workspace.Bot.Animate:WaitForChild("PlayEmote")'
   ```
2. Those lines *are* the animation loop — `playAnimation("idle", ...)` and
   `while Character.Parent ~= nil do stepAnimate(...) end`. So the NPC slides around as a static
   mannequin with **no idle, walk, run or jump animation**, and nothing reports an error. Only the
   `Infinite yield` warning hints at it.

The script also ends with an emote chat hook that dereferences
`game:GetService("Players").LocalPlayer` — nil on the server:

```
Workspace.Bot.Animate:924: attempt to index nil with 'Chatted'
```

Fix both at once by rebuilding `Animate` from a fresh stock model instead of hand-converting:

```lua
local Players = game:GetService("Players")
local desc = Players:GetHumanoidDescriptionFromUserId(USER_ID)
local tmp = Players:CreateHumanoidModelFromDescription(desc, Enum.HumanoidRigType.R15)
local fresh = tmp:FindFirstChild("Animate")          -- 22 children

local new = Instance.new("Script")
new.Name = "Animate"
for _, c in ipairs(fresh:GetChildren()) do c:Clone().Parent = new end
new.Source = fresh.Source:gsub(
    "if not FFlagUserAnimateRemoveEmoteChatHook then", "if false then")
new.Parent = bot
bot.Animate:Destroy()
tmp:Destroy()
```

Verify with `#bot.Animate:GetChildren() == 22`, `animator:GetPlayingAnimationTracks()` returning
1, and a console free of the `Infinite yield` line.

**Edits made during a playtest are discarded when you stop.** Anything patched while `Game
Started` — including that Animate fix — is thrown away with the play session. Reapply in Edit mode
before trusting it.

### Testing chat commands from MCP — `TextChannel:SendAsync` works

`Player.Chatted` is the natural hook for chat commands. Two obvious routes are dead, but a third
one works:

- ❌ `user_keyboard_input` refuses to type into the chat —
  `VirtualInput::SendKey: CoreGUI has keyboard focus. VirtualInput cannot process this key.`
- ❌ `game:GetService("Chat"):Chat(character, "text")` returns without error but **does not fire
  `Player.Chatted`** — verified by attaching a listener, which never fired.
- ✅ **Send through the real chat pipeline, from the Client datamodel:**

```lua
-- execute_luau, datamodel_type = "Client"
local ch = game:GetService("TextChatService")
    :FindFirstChild("TextChannels"):FindFirstChild("RBXGeneral")
ch:SendAsync("follow me")          -- fires Player.Chatted on the server
```

`SendAsync` returns successfully and the server-side `Player.Chatted` **does** fire, so chat-driven
behaviour is fully testable over MCP. The legacy `Chat` service route stays dead; it is
`TextChatService` that carries the real pipeline (`TCS.ChatVersion` was
`Enum.ChatVersion.TextChatService` in the test place). Find the channel by name rather than
assuming — `TextChannels` may hold `RBXGeneral` plus custom channels.

**Prove it end to end, don't trust the return value.** `send=true err=nil` is not evidence a
message went anywhere. Hook `Player.Chatted` on the **server**, stash into a `StringValue` in
`ServerStorage`, then send from the **client**, then read the `StringValue` back:

```lua
-- Server: install the listener first
for _, p in ipairs(game:GetService("Players"):GetPlayers()) do
	p.Chatted:Connect(function(msg)
		sv.Value = sv.Value .. p.Name .. ": " .. msg .. "\n"   -- sv = ServerStorage.ChatProbe
	end)
end
-- Client: send.  -- Server: task.wait(1.5) then read sv.Value
```

Measured result: `[9.93] nioikokfaafaafd: test chat tu bot` — the round trip is real.

### Reading chat from a client: `TextChatService.MessageReceived` fires

`MessageReceived` **does fire on the client**, and — usefully — it also fires for messages the
local client sent itself. `message.TextSource.UserId` resolves the speaker:

```lua
TextChatService.MessageReceived:Connect(function(message)
	local src = message.TextSource
	if not src then return end                                   -- system messages have no TextSource
	local sender = Players:GetPlayerByUserId(src.UserId)
	if not sender or sender == player then return end             -- ignore self / unknown
	handleCommand(sender, message.Text)
end)
```

Verified with one client: `send=true err=nil | bat duoc 1 tin: text=probe msg | userId=11234515308`.

**Consequence worth knowing before promising a test:** because any sane handler carries a
`sender == player` guard (otherwise the bot obeys its own chat), **a chat-driven client script
cannot be tested for command routing with a single client.** The only player present is the one
whose messages are filtered out. A second real client is mandatory — there is no way around it
from MCP.

### `StudioTestService.AddPlayers` exists but is not usable from an MCP playtest

The service is real and so are the methods (`AddPlayers`, `EndTest` are both functions):

```
StudioTestService: ok=true svc=StudioTestService
  svc.AddPlayers -> function: 0x65c9e383c3bc35ae
  svc.EndTest    -> function: 0xe7c2e8b856a678d6
  svc.AddPlayer / svc.StartTest / svc.DisconnectClient  -> not a valid member
```

But calling it from a playtest started by `start_stop_play` fails:

```
AddPlayers: can only be called from the server DataModel of a running Studio test session
```

So the documented "programmatic multi-client simulation" is **not** reachable this way. Revisit it
only if the test is launched as a real Studio test session (CLI / `TestService`), not via the MCP
play toggle. `Instance.new("Player")` remains blocked as well (`lacking capability WritePlayer`),
so a fake master cannot be manufactured either.

### An NPC cannot speak into the chat window from the server — split brain/mouth

Measured on the client and the server, in that order:

| Call | Where it is legal | What it actually does |
|---|---|---|
| `TextChannel:SendAsync(text)` | **client only** | sends *as the local player* — wrong speaker for an NPC |
| `TextChannel:DisplaySystemMessage(text)` | **client only** | appends a line to the chat window ✅ |
| `TextChatService:DisplayBubble(root, text)` | server *and* client | returns success, **renders nothing** |
| `TextChatService.DisplaySystemMessage` | — | **does not exist** (`false/string`) |

Errors are explicit: `TextChannel:SendAsync can only be called on the client.` So there is **no**
server-side path into the chat window, and `SendAsync` is the wrong call anyway (it would show the
player talking to themselves). The working design is a split:

- **Server = brain.** Owns movement, command parsing and the master gate. When the NPC should
  speak it fires **one** `RemoteEvent` with the *semantic* kind, not the sentence:
  `botSay:FireAllClients(action, message)` where `action ∈ {"CHAT","STOP","TP","FOLLOW","FALL"}`.
- **Client = mouth.** A `LocalScript` owns every string the NPC says, picks the line, and calls
  `channel:DisplaySystemMessage("[Bot] " .. text)`.

Why send the *kind* and not the text: the command words (`STOP_WORDS`/`FOLLOW_WORDS`/`TP_WORDS`)
have to live on the server anyway for movement, and the chat tables belong on the client. Sending
the kind means **neither list is duplicated** — the server never learns the jokes, the client never
learns the command words.

Two more things this buys you: the client-side bubble is a plain `BillboardGui` under
`Workspace.Bot.Head`, readable from the Client datamodel (unlike `DisplayBubble`, which produced no
inspectable instance); and every client can render its own bubble without the server owning a GUI.

### Making an NPC's line look like a normal chat message, not a system notice

`DisplaySystemMessage` produces a `TextChatMessage` with **no `TextSource`**, so it renders as bare
text — no name, no colour, reads like a system notice. `SendAsync` is not the fix: it sends *as the
local player* (wrong speaker), gets text-filtered (which kills profanity), and fires
`Player.Chatted`, so a server that replies to chat will answer the NPC's own line forever.

The fix is `TextChatService.OnIncomingMessage` plus a metadata tag — the chat renders the bot's line
exactly like a player's:

```lua
channel:DisplaySystemMessage(text, "BOT")

TextChatService.OnIncomingMessage = function(message)
	if message.Metadata ~= "BOT" then return nil end   -- leave real chat alone
	local props = Instance.new("TextChatMessageProperties")
	props.PrefixText = '<font color="#00b0ff">Bot:</font>'   -- rich text works here
	return props
end
```

Measured result: the label renders as `<font color="#00b0ff">Bot:</font> Alo cái đầu m, đi tiếp đi.`
— same wrapper as a real message, so it looks like a normal chat line from a speaker named "Bot".
`OnIncomingMessage` fires for `DisplaySystemMessage` **and** for the local player's own
`SendAsync`, so it is also the cheapest way to observe chat from a client.

### Verifying the chat window from MCP — read `CoreGui.ExperienceChat`

The chat window is a real instance tree, so its contents are **readable** — this is the only way to
prove an NPC's line actually reached the player:

```lua
-- execute_luau, datamodel_type = "Client"
local chat = game:GetService("CoreGui"):FindFirstChild("ExperienceChat")
for _, d in ipairs(chat:GetDescendants()) do
	if d:IsA("TextLabel") and string.find(d.Text, "%[Bot%]", 1) then
		print(d.Text)   -- [Bot] Mới nói gì đấy? Nói lại xem.
	end
end
```

`game:GetService("CoreGui")` is readable from the Client datamodel, and `ExperienceChat` is the
chat ScreenGui. A `print` in the LocalScript proves the call *ran*; only reading
`ExperienceChat` proves the line *rendered*.

**Do not try to read the message history off the `TextChannel`.** Its children are `TextSource`
(one per speaker, named by `UserId`), not `TextChatMessage` — `channel.X.Text` errors with
`Text is not a valid member of TextSource`. And `DisplaySystemMessage` fires neither
`MessageReceived` nor `OnIncomingMessage`… it *does* fire `OnIncomingMessage` (use that), but it
never fires `MessageReceived`.

**The chat window only renders labels while it is OPEN.** Collapsed, `CoreGui.ExperienceChat` holds
nothing but chrome (`stop-small`, `microphone`) with `chatInputRow.Visible = false` — and that is
true for the player's *own* messages too, so a scan that finds zero labels means "window is closed",
not "the feature is broken". Either get the user to open the chat, or verify the pipeline with
`OnIncomingMessage` (which fires regardless of window state) and read the rendered label separately
while the window is open.

### Sampling a moving object: fire the trigger and the sampler in parallel

Tool calls are seconds apart, so "send chat, then measure" misses the start of the run and you
cannot tell a clean traversal from a fluke. Issue the Client `SendAsync` call and the Server
sampling call **in the same message** so they run concurrently and the sampler captures from t=0.

Sample at 0.2 s, not 1 s. A 1-second interval cannot distinguish "walked to the edge" from
"jumped and fell", and the mid-air samples are exactly the interesting ones.

### Verify a black-box NPC by replicating its raycasts

When a script's decision function is a local, don't add debug prints and burn a restart. Re-run the
same `workspace:Raycast` calls from an `execute_luau` snippet using the bot's live position and
print what each probe angle would decide. That puts perception and behaviour side by side with no
restart, and it is what proved the ray was too short to see the lava.

Also note the playtest can stop on its own between calls; `Server datamodel is not available in
Edit mode` means it ended. Re-read `get_studio_state` before assuming a running session — and
re-check it after `start_stop_play`, which can report "Game Stopped" while Studio is still in Play.

### Driving one specific player

`user_keyboard_input`, `user_mouse_input` and `character_navigation` all take
`datamodel_type: "Client"` with **no client index and no player selector** — the only selector
anywhere is `studio_id` (which Studio window). With two clients open there is no way to say which
one receives input.

Server-side Luau is the workaround: `execute_luau` with `datamodel_type="Server"` can target a
player by name — `Humanoid:MoveTo` (walks), `PivotTo`, `Jump`, `WalkSpeed`,
`Humanoid:EquipTool`. It cannot touch the camera or mouse-look, which are client-side.

`VirtualInputManager` exists in current Studio builds (visible in the DataModel tree), but
whether `SendKeyEvent` works from `execute_luau` is **unverified** — test before relying on it.

## NPC follower bot: the bugs that actually bite

Written from a bot that follows a player across a platform obby with lava kill blocks. Each of
these cost a playtest cycle.

### Raycast length must reach the bottom of the map

A downward ray from `pos + (0, 4, 0)` of 12 studs only reaches `pos - 8`. On a low platform it hits
the lava and everything works. Two platforms up (pivot y=10.5) it ends at y=2.5 — *above* lava at
y=1 — so it returns **nil**. The bot reads "no ground" as "open gap, safe to jump" and leaps into
lava it never saw.

The failure is height-dependent, which is what makes it nasty: correct at the start of the obby,
wrong later, so it looks like a flaky bot rather than a blind one. Size the ray for the tallest
thing the bot can stand on, not the gap it usually crosses (`GAP_DEPTH = 40` for a 13-platform
obby rising 2 studs per step).

### Never re-decide while airborne

Mid-jump the downward ray hits the lava in the gap below, so the "am I standing on a kill block"
test returns true, `decide()` returns `escape`, and the bot steers *backward* mid-air and drops in.
Guard the whole decision block on `humanoid.FloorMaterial ~= Enum.Material.Air` and let the frozen
`MoveTo` target carry the arc.

### …but the stuck detector must NOT be behind that guard

A bot wedged against a platform's side wall reports `FloorMaterial == Air` indefinitely. If the
"stuck → teleport to the player" check sits after the airborne guard it is skipped, and the bot is
frozen forever with no error. Put the stuck check **first**, and measure progress by horizontal
displacement rather than by whether the bot is on safe ground:

```lua
local moved = Vector3.new(root.Position.X - lastPos.X, 0, root.Position.Z - lastPos.Z).Magnitude
if moved > 0.15 then            -- NOT > 1, see below
    lastPos = root.Position
    lastMovedAt = now
elseif now - lastMovedAt > 5 then
    bot:PivotTo(targetRoot.CFrame * CFrame.new(0, 2, 4))
    lastPos = root.Position
    lastMovedAt = now
    continue
end
```

A movement-based give-up is also map-agnostic — it works on a flat baseplate and on an obby,
whereas "time since last safe ground" only covers the lava case.

**The threshold must be smaller than one tick of walking.** `moved` is measured between
`task.wait(0.05)` ticks, and a humanoid at the default `WalkSpeed = 16` covers `16 * 0.05 = 0.8`
studs per tick. A `moved > 1` threshold therefore **never fires for a walking bot**, so it decides
it is stuck and teleports to its owner every 5 seconds, forever. The symptom reads as "the bot
cannot walk", not as a threshold bug. Use something well under one tick's travel (`0.15`).

`CFrame.new(0, 2, 4)` lands 4 studs *behind* the target — local **+Z** is the back of a CFrame
(`LookVector` is −Z) — which is what you want when the owner asked to be followed from behind.

### Never clear `followTarget` when the player dies

`if targetHum.Health <= 0 then followTarget = nil end` means **one death permanently ends the
follow**. The bot then stands motionless forever, and the symptom reads as "the bot is frozen",
not "the player died" — so you chase the wrong bug. Distinguish *left the game*
(`not target.Parent`) from *respawning* (`targetRoot == nil or health <= 0` →
`humanoid:MoveTo(root.Position)` and wait).

### A `continue` silently disables everything after it

Two separate bugs came from this. The stuck-teleport was unreachable because `escape` and
`blocked` both `continue`d first. And the walk-unstick jump reset `lastProgress`, so the
"stuck too long" branch could never trigger at all. When you add a `continue`, walk the rest of
the loop body and ask what just stopped running.

### Measure "arrived" in 3D, not 2D

`flatDistance <= 4` is satisfied by a bot standing in lava directly *beneath* the player — it
declares victory 12 studs below its owner. Require `math.abs(delta.Y) <= STOP_DISTANCE` as well.

### Tune probe distances against the real geometry

`LANDING_PROBE` must reach at least the corner-to-corner gap or the bot correctly refuses every
jump and parks at the platform edge forever. Mind the step threshold too: platforms rising exactly
2.0 studs are missed by `diff > 2` — use `> 1.5`.

### An edge guard must probe at least as far as it steps

The classic "am I about to walk off?" guard is `raycast(pos + dir * 2)`; the classic step is
`MoveTo(pos + dir * 4)`. When the target point lies *off* the platform (a follow point 7 studs
behind a player standing near the edge), the guard passes — it saw floor 2 studs out — and the
4-stud step carries the NPC straight off. Measured: the bot walked off the goal at z=12.22 on a
platform ending at z=11, then fell 11 studs.

The guard only fires on the branch where `nextStep` found no candidate, so it silently never runs
on the normal path. Either probe `>=` the step length, or clamp the step to the probed distance.

This is exactly what happens when you *test* follow behaviour by teleporting the player with
`CFrame.new(vector)` — that resets rotation to identity, so "behind the player" can point off the
platform and you end up measuring the edge guard instead of the follow logic. Set the look
direction deliberately when you move the player in a test.

### A client can aim a server-owned NPC, but it cannot control its physics

Measured, with the server's controller switched off first (`stop`, then confirm 0.00 studs over 2 s)
so nothing else could move the bot:

| Called from the Client datamodel on a server-owned NPC | Server's view |
|---|---|
| `humanoid:MoveTo(target)` | ✅ moved the full 8.00 studs, server read `107.25` |
| `hrp.AssemblyLinearVelocity = Vector3.new(0, 50, 0)` | ❌ client saw `y=279`, server still `y=15.59` |
| server does `SetNetworkOwner(player)`, then the client sets velocity | ❌ still `y=15.59` |

So `MoveTo` is a replicated **walk request** the server honours, while velocity writes are a purely
local illusion. Any NPC whose skill depends on `WalkSpeed` / `Jump = true` /
`AssemblyLinearVelocity` — a precise jump arc, for instance — **must stay server-side**; moving it to
a LocalScript silently removes the skill instead of erroring.

Corollary: "make it all client-side" is not a valid fix for "the server can't do X". Split by what
the datamodel actually permits (chat → client, physics → server) and say so with the numbers.

### Kill blocks must exclude the NPC

A tag-armed kill part kills anything with a Humanoid, including your own bot — and `Health = 0`
does not revive cleanly because death breaks the joints. Tag the bot (`CollectionService:AddTag(bot,
"Bot")`) and skip tagged characters in the kill handler. Also set
`humanoid.BreakJointsOnDeath = false` so any death is recoverable by re-setting `Health`.

### The player's own body is not terrain

`RaycastParams`/`OverlapParams` built with `FilterDescendantsInstances = { bot }` exclude only the
bot, so **every player character is a valid "platform"**. The owner is usually the nearest and
highest-scoring one, so `nextStep` picks `Workspace.<player>.HumanoidRootPart` as the next step:
the bot walks into its owner, gets blocked by their body, and oscillates. The same bad filter also
lets the downward probe land on the owner's leg and report it as the floor. In the owner's words:
*"it walks up in front of me"*. Exclude **all** characters, and refresh once a second so respawns
are picked up:

```lua
local function refreshFilter()
    local list = { bot }
    for _, p in ipairs(Players:GetPlayers()) do
        if p.Character then table.insert(list, p.Character) end
    end
    rayParams.FilterDescendantsInstances = list
    searchParams.FilterDescendantsInstances = list
end
refreshFilter()
```

Confirm it with a probe, not a playtest: re-run the candidate loop from `execute_luau` at the
bot's live position and print what `nextStep` would choose. `chosen = Workspace.<player>.HumanoidRootPart`
is the smoking gun.

### Chasing "behind me" — and how to test it without lying to yourself

Aim at `targetRoot.Position + targetRoot.CFrame.LookVector * -FOLLOW_BACK`, and test arrival
against **that point**, not against the player: otherwise, once the player walks into the bot the
distance is 0, the bot never re-establishes a trailing spot, and it stands inside its owner.

The harness matters more than the code here. Two ways to produce a fake bug:

- **Do not anchor the player's `HumanoidRootPart`.** An anchored character is an immovable wall:
  when the owner turns 180° the bot must cross to the far side, cannot push past, and parks *in
  front*. Same bot, same code — anchored player gave `behindPct=66 / inFrontPct=33`; the same run
  with a real, pushable player walking under `Humanoid:MoveTo` gave `behindPct=100 / avgDot=-1.00 /
  inFrontPct=0`.
- **Client-side `hrp.CFrame = ...` stops replicating once the character is dead.** The client
  happily reports "player done at 175,22,0" while the server keeps the corpse at the spawn point,
  so the bot follows a player that never moved and you debug a phantom. Check
  `Humanoid:GetState()` before trusting any player-driven test.

Drive the test player from the **server** with `character.Humanoid:MoveTo(target)`: real physics,
pushable, auto-rotates to face travel. Or drop the moving target entirely — pin the owner at the
goal and let the bot traverse the whole map unaided, which is a *harder* test than a moving one.

Measured on a random 16-platform obby: 175 studs in ~13 s, `bigTeleports=0`, 13 jumps for 16 gaps,
`behindDot=-0.98`, health 100. Forced into lava: motionless for the whole wait with `MoveDirection`
all zeros (no self-rescue), then teleported to the owner.

### A startup `print` of a count is not a status check

`KillBlocks` printed `da arm 0 kill block` because it ran before `ObbyGenerator` created the lava —
yet the lava *was* armed, via `CollectionService:GetInstanceAddedSignal("Kill")`. The count was
true and the conclusion ("kill block broken") was false. Log inside the arming function
(`print("[KillBlocks] arm " .. part:GetFullName())`), not a snapshot count at startup.

### `FloorMaterial` is NOT an airborne test

The obvious "am I in the air" check is `humanoid.FloorMaterial == Enum.Material.Air`. It is wrong.
`FloorMaterial` keeps reporting the platform you just jumped off for a while after take-off,
because the humanoid's floor probe still reaches it. Caught red-handed by logging take-off heights:
the bot "took off" at **y = 13.0** from a platform whose top is 5.2 (its HRP stands at ~7.9) — 13.0
is the *apex* of the previous jump. So the guard never engaged until half way through the arc, and
the bot re-decided mid-air — precisely the bug the guard exists to prevent.

Use the state machine:

```lua
local s = humanoid:GetState()
local airborne = s == Enum.HumanoidStateType.Freefall or s == Enum.HumanoidStateType.Jumping
```

### Narrow platforms: thin bars ARE solvable — it was two bugs, not the geometry

Asked to turn the platforms into thin bars. The first attempts fell into the lava every run. Two
separate root causes, found in this order. The earlier conclusion in this file ("an obby has to be
built around the jumper's arc") was **wrong** — it was these bugs, not the geometry.

**Cause 1 — `Freefall` clears the `MoveTo` target, and the humanoid brakes itself to a stop.**

Prove it with an A/B on a throwaway clone instead of guessing (rig at the end of this section). A
humanoid in `Freefall` with `AssemblyLinearVelocity = (10, 30, 0)`:

| | vx through the arc |
|---|---|
| no `MoveTo` | `10 → 0.5 → 0.0 → 0.0 …` — killed instantly |
| `humanoid:MoveTo(target)` re-issued every tick | `16.0 → 16.0 → 16.0 → 16.0 …` — held all the way |

The humanoid transitions `Jumping` → `Freefall` at the apex, and `Freefall` **clears the walk
target**, so the controller brakes horizontal velocity to zero mid-flight. Measured collapse:
`vx 13.5 → 11.2 → 1.9 → 0.0` exactly as `vy` crossed 0. Re-issue the target every tick while
airborne and the arc becomes exact.

```lua
-- guard first: airborne = self-remembered deadline OR humanoid state
local state = humanoid:GetState()
if now < flightUntil
    or state == Enum.HumanoidStateType.Freefall
    or state == Enum.HumanoidStateType.Jumping then
    -- Freefall XOA diem MoveTo -> phai nhet lai moi tick
    if flightTarget then humanoid:MoveTo(flightTarget) end
    continue
end
flightTarget = nil                 -- cleared once grounded
...
flightUntil = now + T + 0.25
flightTarget = spot
```

`flightUntil` must be self-remembered: neither `FloorMaterial` nor `GetState()` alone is a reliable
airborne test, and the deadline also stops the bot re-deciding mid-flight. `T` is the **larger**
quadratic root — the moment you come back down to the target height (the smaller root is when you
pass that height going *up*, and the arc comes out short):

```lua
local g = workspace.Gravity
local jumpVel = humanoid.UseJumpPower and humanoid.JumpPower or math.sqrt(2 * g * humanoid.JumpHeight)
local rise = spot.Y - myTop
local disc = jumpVel * jumpVel - 2 * g * rise
local T = disc > 0 and (jumpVel + math.sqrt(disc)) / g or 2 * jumpVel / g
local D = (Vector3.new(spot.X, 0, spot.Z) - Vector3.new(root.Position.X, 0, root.Position.Z)).Magnitude
humanoid.WalkSpeed = math.clamp(D / T, 0, WALK_SPEED)
humanoid.Jump = true
flightUntil = now + T + 0.25
flightTarget = spot
```

Restore `humanoid.WalkSpeed = WALK_SPEED` once grounded.

**The humanoid overrides your horizontal velocity.** In the `MoveTo` trial the humanoid pinned vx to
exactly `WalkSpeed` (16.0), ignoring the `(10, …)` assigned a line earlier. So **`WalkSpeed` is the
knob that sets jump distance**, not `AssemblyLinearVelocity` — `D / T` goes into `WalkSpeed` and the
horizontal velocity takes care of itself. Measured landing error after this fix: **+0.05 and +0.03
studs** on successive bars.

**Cause 2 — sparse downward ray probes miss a thin platform, so the bot freezes on its own bar.**

The support probe cast 5 rays at offsets `0, ±2` and took the highest hit. With bars 1.0–1.6 studs
wide, a bot standing **0.9 studs off centre** (perfectly supported — its capsule is far wider than
the bar) has *every* probe miss the bar and hit the lava underneath. It then believes it is standing
on a kill block and freezes in place. The trace is unmistakable:

```
t2.43 x30.28 y11.64 Running v=( 5.8,-28.5)
t2.61 x30.47 y 6.90 Running ground=Lava*      <- standing on Platform4 (top 3.98 + body 2.9)
t2.73 ... t7.38  x30.47 y6.97  khong doi trong 5 giay  -> rescue teleport
```

A ray from the HRP centre is fine for a 7–9 stud platform and hopeless for a 1-stud bar. Query a box
that covers the capsule instead:

```lua
local SUPPORT_BOX = Vector3.new(4, 6, 4)

local function supportGround()
    local region = workspace:GetPartBoundsInBox(
        CFrame.new(root.Position - Vector3.new(0, 3.5, 0)), SUPPORT_BOX, searchParams)
    local best, bestY = nil, -math.huge
    local ceiling = root.Position.Y - 1.2   -- bo qua part ngang tam HRP
    for _, part in ipairs(region) do
        if part:IsA("BasePart") then
            local top = part.Position.Y + part.Size.Y * 0.5
            if top <= ceiling and top > bestY then best, bestY = part, top end
        end
    end
    return best, bestY     -- return the TOP, not the part's centre
end
```

Return the top, not `part.Position.Y`: the old caller used the raycast hit point, which *was* the top
surface. Caveat — a neighbouring platform up to 2 studs higher and inside the box can win, so `myTop`
may be a couple of studs optimistic. It self-corrects (`nextStep` rejects platforms behind the bot),
but do not treat `myTop` as exact.

**Result after both fixes** — same bot, bars **0.64–0.99 studs** wide and 14–18 across with 4.5–5.5
stud gaps, `SEED` pinned: **9 consecutive clean laps, 0 rescue teleports, 0 falls, 11–13 s per lap.**

**The A/B rig for humanoid internals.** Never reason about `Freefall`/`AirController` behaviour from
memory; measure it. Clone the rig, strip its scripts, drive it in the air:

```lua
local m = workspace.Bot:Clone()
m.Name = "ProbeBot"
for _, d in ipairs(m:GetDescendants()) do if d:IsA("BaseScript") then d:Destroy() end end
m.Parent = workspace
local hum, hrp = m:WaitForChild("Humanoid"), m:WaitForChild("HumanoidRootPart")
m:PivotTo(CFrame.new(0, 300, 0))
hrp.AssemblyLinearVelocity = Vector3.zero
task.wait(0.4)
hrp.AssemblyLinearVelocity = Vector3.new(10, 30, 0)
-- then sample hrp.AssemblyLinearVelocity every 0.05 s, with and without hum:MoveTo(...)
```

Note: `AirController` is **not** a child of the Humanoid in current Studio
(`hum:GetChildren()` = Animator, NumberValue ×7, HumanoidDescription, Status), so
`MaintainLinearMomentum` is not reachable that way — re-issuing `MoveTo` is the practical fix.

### Instrument lightly, and do not trust one failed lap

A 0.05 s sampling loop that also raycasts every tick was enough to produce a **0.4 s server hitch**
under MCP: position and velocity frozen mid-air (`v=(10.8, -5.0)` identical across three samples,
gravity not applied). That hitch cut a jump short and cost a lap. Signature of a hitch rather than a
bot bug: position *and* velocity unchanged across samples, then a resume. Sample at 0.2 s with
position only when timing laps; keep the fine trace for single-shot diagnosis.

Corollary: one failed lap out of two is not evidence of a regression — re-run before rewriting code.
If two laps fail at the *same* x, that is a systematic cause worth a trace, not noise.

### Each playtest generates a new random map — fix the seed before comparing

Comparing "3 falls" against "6 falls" across two runs proves nothing when the map is regenerated
from `os.time()` every playtest. Pin `SEED` to a constant while iterating on bot behaviour, or the
noise will read as signal. This cost a wrong conclusion ("the fix made it worse") in this very
session.

## Syntax-check a script in Edit mode without a playtest

`loadstring(script.Source)` inside `execute_luau {datamodel_type:"Edit"}` compiles the source and
returns `(nil, err)` on a syntax error. It is the cheapest possible check, works in Edit mode, and
needs no restart:

```lua
local src = game.ServerScriptService.BotController.Source
local fn, err = loadstring(src)
print(fn and "OK" or ("LOI: " .. tostring(err)))
```

Use it every time you hand-edit a script through `multi_edit` or paste one in from disk.

**The place is the source of truth, not your copy on disk.** A "fixed" file sitting in `D:\` proves
nothing about what is running — the live place can still hold the old version. Read `Source` out of
Studio and diff it before concluding a fix landed. In this session the user reported "the script
doesn't work" while the fix lived only in a text file; the live `BotController` still had
`MASTER_NAME = "roblox"`, so every message was rejected by the master gate.

**Counting lines: `src:gmatch("[^\n]*")` over-counts** (it also matches the empty string at every
position, roughly doubling the count). For real line numbers use:

```lua
for l in (src .. "\n"):gmatch("(.-)\n") do table.insert(lines, l) end
```

**`get_studio_state` → `Place is not open`** right after Studio launches means the MCP server is up
but the place has not finished loading. Re-call `list_roblox_studios` before concluding anything; a
few seconds later it usually connects normally. An empty tool result is not evidence.

## Verifying a server→client port statically, before trusting it

Moving a working script between datamodels (`ServerScriptService` → `StarterPlayerScripts`, or the
reverse) is where silent damage happens: the port looks fine, compiles fine, and quietly lost a
tuned constant or a whole branch. `loadstring` will not catch that — it only proves syntax.

Two checks cost one `execute_luau` call each and catch nearly all of it. **Diff the constants:**

```lua
local function consts(src)
	local t = {}
	for line in (src .. "\n"):gmatch("(.-)\n") do
		-- loose on purpose: a trailing `-- comment` is common and must not hide the line
		local name, val = line:match("^local%s+([A-Z_]+)%s*=%s*([%d%.]+)")
		if name then t[name] = val end
	end
	return t
end
-- then print name / server value / client value, flagging nil and mismatches
```

Anchoring the pattern with `$` (i.e. `([%d%.%-]+)%s*$`) **silently skips every line that has a
trailing comment** — it reported 11 of 13 constants as "missing from the server" when they were all
present. Loosen it and only capture the leading number.

**Then check that each logic marker survived**, by substring presence in both sources:

```lua
local checks = { "GetPartBoundsInBox", "GetPartBoundsInRadius", "humanoid:MoveTo",
	"AssemblyLinearVelocity", "Enum.HumanoidStateType.Climbing", "UseJumpPower",
	"trailTarget", "recordTrail", "nextStep", "supportGround" }
-- flag anything present on one side and absent on the other
```

Measured result on a real port: **14/14 constants identical, 11/11 logic markers present**. That is
the difference between "I copied it" and "I know I copied it". It also surfaced one orphan of my own
making — a `CLIMB_SPEED` constant declared during the port and never referenced. Delete your own
orphans when you find them.

## A hard-coded rescue threshold must be checked against the map's floor level

A bot controller commonly carries a "fell out of the world" rescue:

```lua
if root.Position.Y < -60 then
	bot:PivotTo(CFrame.new(HOME))   -- HOME = (6, 4, 0)
end
```

That constant is an assumption about where the map sits. Move the play area and the rule silently
becomes a **teleport-home-every-tick trap**: the bot stands on the new geometry, is yanked back to
`HOME` on the next tick, falls, is yanked back again — an infinite loop that looks like "the bot is
broken" rather than "the threshold is stale".

Before touching movement logic, measure the Y range of every model and compare it to the threshold:

```lua
for _, m in ipairs(workspace:GetChildren()) do
	if m:IsA("Model") then print(m.Name, m:GetBoundingBox()) end
end
```

Also probe downward under `HOME` and under `SpawnLocation` with a long raycast. A `SpawnLocation`
left floating hundreds of studs above the real floor is easy to miss and makes both the player and
the bot fall on join.

## Measuring whether a rig can traverse a structure: jump apex, then height gaps

The jump height is **not** `Humanoid.JumpHeight` when `UseJumpPower` is true — `JumpHeight` is then
ignored entirely. The real apex is:

```
apex = JumpPower^2 / (2 * Gravity)      -- 50^2 / (2*196.2) = 6.37 studs
```

**A rig's jump and the player's jump live in different places — and the player's is usually bigger.**
`StarterPlayer.CharacterUseJumpPower = false` with `CharacterJumpHeight = 7.2` (the default) means
**players jump 7.2 studs**; the sibling `CharacterJumpPower = 50` is ignored precisely because
`UseJumpPower` is false. A `Humanoid` sitting inside the workspace carries its own pair — measured
here as `UseJumpPower = true`, `JumpPower = 50` → **6.37 studs**. So a challenge the owner can clear
may be one the bot cannot, and quoting only the rig's number understates what the *player* can do
(and vice versa). Read both before telling anyone a jump is impossible:

```lua
local sp = game.StarterPlayer
print(sp.CharacterUseJumpPower, sp.CharacterJumpPower, sp.CharacterJumpHeight)  -- player
local h = workspace.Bot:FindFirstChildOfClass("Humanoid")
print(h.UseJumpPower, h.JumpPower, h.JumpHeight)                                 -- the rig
```

**Measure the rig's height over ALL descendants, not just the visible limbs.** An extra part in the
model (a stray `Handle` left over from an avatar clone) sits above the head and inflates the
feet-to-top number: 5.19 studs from `LeftFoot`/`Head` alone, **5.50** over every `BasePart`. The
larger number is the one that decides whether the character fits under a ceiling — use it.

Then collect every part's top surface, sort by height, and report only the gaps larger than `apex`:

```lua
local rows = {}
for _, d in ipairs(model:GetDescendants()) do
	if d:IsA("BasePart") then
		table.insert(rows, { top = d.Position.Y + d.Size.Y * 0.5, name = d.Name, pos = d.Position })
	end
end
table.sort(rows, function(a, b) return a.top < b.top end)
```

Each reported gap is a place the rig physically cannot climb — a fact, not an opinion. Report the
pair of parts on both sides so the reader can see whether something bridges it.

**A gap bridged by a `TrussPart` is not a gap for a human — it is a ladder.** Trusses are climbable,
so a tower with 12-stud "gaps" is a climbable tower. But a bot that decides its next step with a
height-band filter (`top <= myTop + JUMP_UP`) excludes the truss top and therefore **never aims at
it**. Check for `TrussPart` before calling a structure impassable, and say explicitly that the bot
needs climb behaviour rather than that the tower is broken.

**`TrussPart` is locked to a 2×2 cross-section — you cannot build a wall out of one.** Assigning
`Size = (9, 16.58, 0.70)` reads back as `(2.00, 16.58, 2.00)`: the engine clamps X and Z to 2 and
keeps only the length. So converting a wall into a truss silently deletes the barrier. To make a
climbable barrier across a 9-stud corridor you need a **row** of trusses 2 studs apart (5 of them,
each touching the next), and then verify from both sides that the row spans the corridor — otherwise
the bot just walks around the end onto the baseplate and past the obstacle.

**`Humanoid:MoveTo` is not enough to climb a truss.** Measured against a 16.58-stud truss wall: the
bot entered `Climbing` on contact, rose **1.22 studs** (`y -489.00 → -487.78`, `vy 11.20`), then fell
straight back (`vy -10.84`) and milled about near the wall. Two suspects, neither confirmed: the
`MoveTo` target sat 3 studs horizontally into a truss only 2 studs thick, so the point was *past* the
wall and the humanoid walked through rather than up; and the `Climbing` controller may read player
input rather than `WalkToPoint`. Treat "the bot climbs trusses" as unproven. If it must climb, hoist
it deterministically — set `AssemblyLinearVelocity` upward every tick, the same trick the jump code
already uses — instead of leaning on the state machine.

**A raycast hit does not prove collision.** `workspace:Raycast` hits parts whose `CanCollide` is
`false`, so "the truss row blocks the corridor" is not established by raycasting. Use a physics test
(small unanchored part with a velocity through it) or a character test.

**Tall walls make greedy navigation useless.** A maze whose walls are 16 studs high (vs a 6.37-stud
apex) can only be solved by walking corridors. A "pick the part nearest the goal" heuristic sees no
candidate step at all — walls fall outside its height band, leaving only the floor — so it degenerates
to "walk straight at the goal", hits a wall, and either freezes or teleports to the player. Verify by
re-running the candidate filter from a point inside the maze and printing how many steps it finds;
"2 candidates, both at floor level" is a decisive answer.

**A jumpable rise is not the same as a standable step — check the headroom.** Two identical slabs
stacked with the **same XZ centre** are unusable however low the rise is, because the lower slab's
standing surface lies entirely *under* the upper one. The number that decides it is the free gap
`upperBottom - lowerTop` versus the rig's own height (feet to top of head) — **not** `HipHeight`,
which only describes the root's offset.

Measured on the R15 rig in this place: `LeftFoot` bottom to `Head` top = **5.19 studs**. A reported
"5.69-stud step" made of two 1-stud slabs leaves only `5.69 - 1.0 = 4.69` studs of headroom, so the
character cannot stand on the lower slab at all and can never take off. Report the rise *and* the
headroom side by side — the fix is then obvious (offset the upper slab sideways, or thin the lower
one), and no amount of bot code can work around it.

```lua
local lo, hi = math.huge, -math.huge
for _, d in ipairs(bot:GetDescendants()) do
	if d:IsA("BasePart") then
		lo = math.min(lo, d.Position.Y - d.Size.Y * 0.5)
		hi = math.max(hi, d.Position.Y + d.Size.Y * 0.5)
	end
end
print(string.format("rig height = %.2f studs", hi - lo))
```

**Always print `Anchored` when measuring challenge geometry.** Unanchored test pieces silently
self-destruct: two unanchored slabs stacked 5.69 apart float above the floor, fall on the first
playtest, and settle resting on each other as a **1-stud** step — below the usual `> 1.5` step
threshold, so the challenge the user believes they built does not exist in play. A floating
unanchored part is also a red flag that the geometry is still being dragged around.

**Before promising "the bot can jump over a wall", check that a jumpable wall exists.** Every wall in
the place measured 16–16.58 studs against a 6.37-stud apex — there was nothing to test against. Say
so with the numbers and the maximum jumpable height, rather than shipping untested jump logic against
a hypothetical obstacle.

## Never compute a part's footprint as `Position ± Size/2`

That formula is only correct for axis-aligned parts. A wall with `Orientation.Y = ±90` and
`Size = (16, 16, 4)` occupies **4 studs along X and 16 along Z** — the exact opposite of what the
naive formula predicts. A whole maze can be built from rotated walls and every footprint you quote
will be wrong.

**The tell:** a horizontal raycast reports a hit at a coordinate *outside* the part's
`Position ± Size/2` range. That is only possible for a rotated part — stop and re-measure instead of
trusting the numbers.

Compute the true world AABB from the CFrame:

```lua
local cf, sz = part.CFrame, part.Size
local rx, ry, rz = cf.RightVector*sz.X/2, cf.UpVector*sz.Y/2, cf.LookVector*sz.Z/2
local ex = math.abs(rx.X) + math.abs(ry.X) + math.abs(rz.X)
local ey = math.abs(rx.Y) + math.abs(ry.Y) + math.abs(rz.Y)
local ez = math.abs(rx.Z) + math.abs(ry.Z) + math.abs(rz.Z)
-- footprint: X [cf.Position.X-ex .. cf.Position.X+ex], etc.
```

Print `Orientation` alongside every part when auditing a structure; a count of parts whose
`Orientation.Y % 180 ~= 0` tells you immediately whether the naive formula is safe. Heights are
unaffected by a Y rotation, so vertical-gap analysis (jump reachability) stays valid either way.

**Corollary for building a test path:** never hand-pick waypoints by eye in a rotated structure.
The player is usually teleported into position during a test, and teleporting ignores collisions — so
a hand-picked path can run straight through a wall, and the bot will faithfully follow the trail into
that wall and stall. That stall is *correct* behaviour, not a bug. Build the test path with a grid
BFS over the true AABBs so the route is guaranteed walkable.

## Making a follower bot navigate a maze without writing a pathfinder

A bot whose step chooser filters candidates by a height band (`top <= myTop + JUMP_UP`) sees **zero**
candidates in a maze: the walls are far too tall to be a "step", leaving only the floor. It degenerates
to "walk straight at the goal", hits a wall, and freezes or teleports. Measured: 2 candidates, both at
floor level.

You usually do **not** need BFS. If the bot follows a player, record the player's **breadcrumb trail**
and have the bot walk it — the player already solved the maze, so the trail is the solution:

- Record every `TRAIL_STEP` studs (4 is fine); cap the length; clear the trail when a new point jumps
  more than ~30 studs (teleport / respawn).
- **Record on every tick, even before the follow command arrives.** If you only record while following,
  the trail starts at the moment "come" is typed and the whole approach march is lost — which is
  exactly the part that crosses the maze.
- Target the **nearest** trail point, drop everything before it (this self-cleans the stale prefix after
  a give-up teleport), drop points already passed, then walk to the next remaining point.
- Deliberately keep the look-ahead **short** (one or two breadcrumbs). Aiming 12 studs ahead makes the
  bot cut corners and drive into the wall at every right angle.
- Feed that point into the existing `goalFlat` and leave the rest of the movement code untouched.

Verified: a bot that previously beelined into a 40-stud wall instead walked east along it, turned south
through the 8-stud gap at its end, and came back west — and on a 198-stud BFS route closed from 27.2
studs away to 1.5 studs with a smooth, monotonic distance curve (no teleport).

## Input state in a playtest: listen to events, never poll

`UserInputService:IsMouseButtonPressed(Enum.UserInputType.MouseButton1)` reported **`true`
continuously** during a playtest while nothing was pressed, and `mouse.Button1Down` agreed with it.
A "hold the button to repeat an action" feature built on that poll fired ~33 items/second forever.
The symptom looks like a logic bug — a 200-item pool drained to 76 in 2.5 s — but the items were
being *consumed*, not recreated.

Use the events, which are driven by real input and cannot latch:

```lua
local holding = false
UIS.InputBegan:Connect(function(i, gp)
	if gp then return end
	if i.UserInputType == Enum.UserInputType.MouseButton1 then holding = true end
end)
UIS.InputEnded:Connect(function(i)
	if i.UserInputType == Enum.UserInputType.MouseButton1 then holding = false end
end)
-- focus can be lost mid-hold, so the Up event never arrives
UIS.WindowFocusReleased:Connect(function() holding = false end)
```

To make a quick click and a hold share one rate, act on `InputBegan` immediately and set
`nextFire = os.clock() + INTERVAL`; the Heartbeat then only reads the flag.

**Design consequence to raise with the user:** in Roblox, holding LMB (and RMB) **rotates the
camera**. Binding "hold LMB = repeat action" means the action fires every time the player looks
around. Say so before implementing it.

**Diagnosing a phantom input.** Sample the item count *and* the Instance identity of their container
over a few seconds:

- Count falling, container unchanged → something is consuming them (they fly off and self-destruct).
- Count resetting to full under a **new** container → the spawn function is being re-entered, i.e. a
  latched key is firing `InputBegan` on OS auto-repeat.

Never conclude "logic bug" from a bare number; measure identity too.

## Editing a script when `multi_edit` will not cooperate

`multi_edit` intermittently fails parameter validation (`must have required property 'file_path'`)
on long payloads, and cannot match an `old_string` containing non-ASCII text (Vietnamese, accents).
Neither is a dead end — **`Script.Source` is writable** from `execute_luau` in Edit mode:

```lua
local s = game:GetService("StarterPlayer").StarterPlayerScripts.MyScript
local src = s.Source
local i, j = src:find("exact old text", 1, true)   -- plain find: no pattern escaping
src = src:sub(1, i - 1) .. "new text" .. src:sub(j + 1)
s.Source = src
```

Splitting on `"\n"` and replacing `lines[n]` by index sidesteps Unicode normalisation entirely.
Return a read-back in the same call to verify. Do all of this in Edit mode.

## Other things that cost time here

- **`_G` is not shared** between a running `LocalScript` and `execute_luau`. Expose state through an
  Instance (`SetAttribute` / `StringValue`) if you need to read it from outside.
- **`screen_capture` only captures the edit-time viewport.** You cannot screenshot a playtest —
  verify gameplay numerically (positions, `LookVector`, counts) instead of visually.
- **`VirtualInputManager:SendKeyEvent` is blocked** (`lacking capability RobloxScript`). The MCP
  keyboard/mouse tools inject through a stateful layer that can get stuck: after a failed call it
  reported `VirtualInput::SendMouseButton: duplicate button state` for every later press, and no
  sequence of Up/Down cleared it. Budget for losing mouse injection for the rest of the session.
- **The `studio_id` changes** whenever Studio restarts *or* the place is saved under a new name
  (`Place1` → `van kiem quy (placeId: 107870753337796)`). Re-run `list_roblox_studios` on any
  "instance is not connected" error; never reuse the previous id.
- **Edits made while a playtest is running are reverted when it stops** — `Source` edits included,
  not just DataModel changes. Stop the playtest first. The user may also start/stop it themselves,
  which invalidates a client-side `execute_luau` mid-sequence; re-check `get_studio_state` instead of
  assuming Play mode persists.

## Fly mode: do not anchor the root, and do not reuse the toggle key

Three mistakes that together produce a character that looks **petrified** (frozen body, cannot turn):

1. **`HumanoidRootPart.Anchored = true`** to cancel gravity freezes the character completely.
2. **Writing `AssemblyLinearVelocity = Vector3.zero` every frame does not cancel gravity** — gravity
   is applied *after* your write within the same physics step. Measured: a character left drifting
   down at **7 studs/s** with the velocity zeroed each frame.
3. **Reusing `Space` as both "fly up" and the double-tap toggle** makes the two fight.

What actually works:

```lua
-- turn on
humanoid.PlatformStand = true
bv = Instance.new("BodyVelocity")
bv.MaxForce = Vector3.new(math.huge, math.huge, math.huge)   -- huge force => gravity overridden
bv.Velocity = Vector3.zero
bv.Parent = root

-- every RenderStepped
bv.Velocity = dir.Unit * SPEED          -- dir from camera-relative WASD
```

`BodyVelocity` writes the velocity *inside* the physics step, so it genuinely cancels gravity —
unlike a Lua-side velocity write. Verified: stationary to **0.0 studs / 0.5 s** with no input.

Two details that decide whether it *feels* like flying:

- **Drive WASD off the full camera look vector** (look up + W = ascend). Then no up/down key is
  needed at all and the double-tap toggle key stays free.
- **Rotate the character with a `BodyGyro`, not by writing `CFrame`.** Writing `root.CFrame` every
  frame both fights the velocity constraint and locks the character's facing, which reads to the
  player as "petrified — I can't turn":

```lua
bg = Instance.new("BodyGyro")
bg.maxTorque = Vector3.new(9e9, 9e9, 9e9)
bg.CFrame = camera.CFrame        -- refresh every RenderStepped
bg.Parent = root
```

  Verified: `BodyGyro.CFrame.LookVector` matched `camera.LookVector` to **0.0°** of deviation.
  Use `9e9` rather than `math.huge` for `MaxForce` / `MaxTorque` — it is the conventional
  "effectively infinite" value and avoids edge cases in the solver.

Re-assert `PlatformStand = true` in `RunService.Stepped` (it runs *before* physics) and disable
`Ragdoll` / `FallingDown` while flying, or the body goes limp in mid-air. Re-enable them when fly is
turned off so the change does not outlive the feature.

**Behaviour to warn the user about:** the default third-person camera looks slightly downward
(measured `LookVector.Y = -0.40`, ~23°), so holding W pushes the character *into the floor* when it is
on the ground. To take off, look up first. This is inherent to camera-relative movement, not a bug —
but it looks like "W does nothing" if you do not expect it.

Guard the toggle against key auto-repeat: `InputBegan` repeats while a key is held, so track a
`spaceDown` flag and treat only the first `InputBegan` as a tap.

**Scope trap:** the fly state (`flying`, `bv`, `spaceDown`) must be declared **above** every function
that assigns it (e.g. `bindCharacter`, which runs on respawn) — otherwise that function writes a
*global* and the local never changes.

## Obby bot navigation: replace a greedy step-picker with PathfindingService

A hand-rolled `nextStep()` that scores candidates by straight-line distance to the goal **cannot go
around a wall**, and no amount of constant tuning fixes it. Two failure modes to recognise:

1. **The scoring rejects every detour.** `if score < myScore - 1 then` requires each step to get
   *closer to the goal* — going around something means first moving away or sideways, so it is
   filtered out. This is a *mathematical* impossibility, not a tuning problem.
2. **Hard-coded flank manoeuvres** (`farZ = wall.Position.Z - wall.Size.Z * 0.5`, `sign` on X) only
   work for one axis-aligned wall approached from one side.

Use `PathfindingService` as the backbone instead:

```lua
local pathObj = PathfindingService:CreatePath({
	AgentRadius = 0.8, AgentHeight = 5,
	AgentCanJump = true, AgentCanClimb = true, WaypointSpacing = 4,
})
-- wp.Action == Enum.PathWaypointAction.Jump -> do your own jump physics
```

Measured facts worth keeping:

- `AgentRadius` **2.5 will not fit on a 1-stud-wide bar**. Drop to ~0.8 for obby geometry.
- Pathfinding **fails (`NoPath`) on long goals** whenever the navmesh is cut by gaps or thin bars.
  Measured on a test obby: spawn→A_Step8 OK (8 wp), A_Step8→B_Gap6 OK, A_Step8→C_Rise2 **NoPath**.
- Fix with a **rolling window**: if `ComputeAsync(goal)` fails, path to
  `root.Position + (goal - root.Position).Unit * 20`. It must be the **3D** direction — a horizontal
  window just walks along the floor *underneath* the goal and never climbs.
- Pathfinding does not know which parts kill. Raycast down at each waypoint and reject the whole path
  if any of them is dangerous.

Keep a manual `findHop()` for when the navmesh is cut: fan out several directions around the goal
direction (`0, ±15, ±30, ±45, ±65`), probe 3..14 studs, and accept a landing only if it is within
`maxHop(rise)`. Fewer angles than that and the bot cannot jump *diagonally* around a kill block.

**Throttle it.** A 9-direction × 12-distance fan is ~108 raycasts; called every 0.05 s tick that is
>2000 raycasts/s. Cache the result and recompute at most every 0.15 s.

### `groundAt` vs `groundNear` — the bug that stops every jump

A "is there a gap ahead?" probe must use the **level-aware** helper, not the raw one:

```lua
local near = groundNear(root.Position + dir * 1.5, myTop)   -- DUNG
local near = groundAt(root.Position + dir * 1.5)            -- SAI
```

`groundAt` casts 40 studs down, so over a gap it hits the **baseplate 24 studs below** and reports
"there is ground ahead" → the bot concludes there is no gap → **it never jumps, ever**. Symptom: the
bot stands still at a ledge with `state = Running` for tens of seconds while every diagnostic says
the path lookup failed. Always require `hit.Position.Y >= refTop - 2`.

### Hazard learning produces permanent false positives

Learning "this part damaged me" from `HealthChanged` + last `Touched` will mark whatever the bot
touched last — including the safe platform it *fell off of*. It is never unlearnt, so the bot refuses
to ever stand there again and jams permanently.

Guard it by requiring the bot to still be at that part's level:

```lua
and math.abs(root.Position.Y - (lastTouch.Position.Y + lastTouch.Size.Y * 0.5)) < 4
```

### Do not "rescue" a stuck bot by teleporting it

A `GIVE_UP` timer that teleports the bot to the master hides the fact that it cannot path, and
produces exactly the symptom users report: **freeze, delay, then teleport**. Replace with a real
unstuck ladder that cycles every couple of seconds — jump, strafe left, strafe right, back off — and
only step to a point that has ground under it.

### Reparenting is blocked by capabilities

`:Clone()` then setting `.Parent` — even into a plain `Folder` in `Workspace` — fails with
*"cannot reparent … since … has additional values for the Capabilities property"*. Neither
`ServerStorage` nor a new `ModuleScript` works. There is no in-place backup: rely on Studio's undo
stack, and keep the source text you read so you can rewrite it.

## "My place is gone" — prove it first, and find who owns it

A user reporting a lost place is almost always *looking at the wrong account*, not a deleted
place. Two API calls settle it, no login required:

```
# does it still exist? (the ONLY unauthenticated endpoint that returns place data)
https://economy.roblox.com/v2/assets/{placeId}/details
-> {"Name":"...","Creator":{"Id":...,"Name":"..."},"Created":"...","Updated":"..."}

# game page (renders even for private places)
https://www.roblox.com/games/{placeId}
-> "This experience is not accessible because it is unrated"  == place EXISTS, just unrated
```

**Do not trust `thumbnails.roblox.com/v1/places/gameicons` as an existence check.** It returns
`"state":"Completed"` with an icon even for bogus IDs — control-tested with `placeId=1` and
`placeId=999999999999999`, both 200 OK.

Endpoints that **do not work** unauthenticated (don't waste turns): `apis.roblox.com/universal-api/v1/places/{id}`
(404 in every variant), `develop.roblox.com/v1/places/{id}` (404), `www.roblox.com/places/api-getplace`
(404), `games.roblox.com/v1/games/multiget-place-details` (401 — needs cookie). The game page
body fetch times out (heavy JS); `HEAD` times out too. `universeId` is **not derivable** from a
placeId publicly — read it out of the Studio launch log instead (below).

**Mapping a `universeId` back to its places — this one works unauthenticated:**
```
https://develop.roblox.com/v1/universes/{universeId}/places
-> {"data":[{"id":<placeId>,"universeId":<universeId>,"name":"...","description":"..."}]}
```
(`apis.roblox.com/universal-api/v1/universes/{id}/places` 404s — use the `develop.` host.)
This is the reliable way to settle "which account owns this place": pair it with the
`userId` / `Player <id> added` lines in the Studio log for the session that opened it.
`games.roblox.com/v1/games?universeIds=` returns `[TITLE UNAVAILABLE]` / `[UNKNOWN]` for
unrated/private universes, so it is useless as an ownership check here.

## `Resolving timed out` in a Studio log — separate noise from a real resolver fault

Symptom people report: the account picker won't switch accounts, or Studio hangs on sign-in.

**Step 1 — check which URLs are timing out.** Roblox deliberately probes several regional nodes
and discards the slow ones, so these are expected and harmless:

```
tracing.roblox.com/v1/traces                      <- telemetry
contentdelivery.roblox.com/test-50kb              <- speed test
silver.roblox.com/_/_/1px.gif                     <- latency probe
nrt2-128-116-120-3.roblox.com/_/_/1px.gif         <- latency probe
```

**Step 2 — if real auth endpoints are involved, measure the resolver properly.** The decisive
test separates the network path from the OS resolver: send a raw UDP DNS query straight to
`1.1.1.1` as the process's *first* network operation, then time `socket.gethostbyname()` for a
hostname that is definitely uncached.

Measured on one affected machine:

```
UDP direct -> 1.1.1.1                    62 ms   <- network path is FINE
UDP direct -> 8.8.8.8                    90 ms
gethostbyname(<fresh roblox cdn name>) 11343 ms  <- OS RESOLVER is the problem
gethostbyname(<cached / other names>)   60-78 ms
```

**The signature to look for: the FIRST system-resolver lookup in each fresh process takes ~11 s,
everything afterwards is 3–80 ms.** ~11 s ≈ 2 × 5 s, which matches Windows trying dead DNS
servers before falling back — and Studio only budgets 5 s (`Resolving timed out after 5000
milliseconds`).

**Do not conclude from a single sample — and beware the cache confound.** The same measurement
read 11.4 s once, then 52–108 ms on three re-runs, then 11.3 s again. Two traps:

1. The delay only shows on an **uncached** lookup; a warm system cache hides it for the TTL.
2. A "fast" re-run is not evidence the problem is gone — it is evidence the name is cached.

An A/B that looks decisive can still be worthless. This sequence looked like proof the sandbox
was at fault:

```
inside sandbox  : auth.roblox.com  11312 ms
outside sandbox : auth.roblox.com     82 ms      <- looked conclusive
```

…but the inside run had just cached `auth.roblox.com`. Redone with **freshly generated names**
(`*.sslip.io`, random label, one fresh process per measurement, run both sides):

```
inside sandbox  : first lookup 11228 ms
outside sandbox : first lookup 11219 ms          <- identical, not a sandbox artifact
```

And split by address family (fresh name + fresh process per mode):

```
unspec (IPv4+IPv6)  11224 ms
AF_INET  (IPv4)     11199 ms
AF_INET6 (IPv6)     11212 ms
```

All three slow ⇒ not an IPv6-only problem. **Rule: to measure a resolver, every probe needs a
name that has never been resolved before, in its own fresh process. Random labels under a
wildcard-DNS domain (`*.sslip.io`, `*.nip.io`) give you those on demand.**

**The actual culprit in the case above was `InterfaceMetric`, not the IPv6 DNS.** A VPN adapter
(`Radmin VPN`) had **metric 1** while Wi-Fi had **metric 10**, so it won routing and the DNS
Client sent its queries down a dead VPN tunnel first, waited out the timeout, then fell back.
Measured before and after:

```
Radmin VPN metric = 1     -> first lookup 11,199-11,343 ms
Radmin VPN metric = 9999  -> first lookup    113-361 ms     (98x faster)
```

The fix that worked, all in one admin `.bat`:

```
netsh interface ipv4 set interface "Radmin VPN" metric=9999
netsh interface ipv6 set interface "Radmin VPN" metric=9999
netsh interface teredo set state disabled
ipconfig /flushdns
```

**The dead IPv6 entries turned out to be a red herring.** `netsh interface ipv6 set dnsservers
"..." source=static address=none` ran with admin and **did not remove them** — `fec0:0:0:ffff::1/2/3`
are Windows built-in site-local defaults (they appear on `Loopback` too) and are not user-removable
config. They also never caused the delay. Do not chase them.

Diagnose the metric first with `netsh interface ipv4 show interfaces` (or `Get-NetIPInterface`) —
look for any non-Wi-Fi adapter with a **lower** metric than the real uplink.

## Reading account state off the local machine (Windows)

When the user has forgotten a password or can't tell accounts apart, these files answer it:

| Path | What it gives you |
|---|---|
| `%LOCALAPPDATA%\Roblox\logs\*_Studio_*.log` | launch command line: `userId:<id>`, `placeId:`, **`universeId:`**; and `Player <id> added` = the account Studio was logged in as during that playtest |
| `%LOCALAPPDATA%\Roblox\LocalStorage\appStorage.json` | **`PreviousAccountsList`** — every account in Studio's account picker (`username`, `userId`, `showInAccountPicker`); `UserId` = current account; `AccountBlob` = DPAPI credential blob |
| `%LOCALAPPDATA%\Roblox\LocalStorage\RobloxCookies.dat` | Studio cookie, DPAPI-encrypted (`AQAAANCMnd8BFdERjHoAwE/Cl+sBAAAA…`) |
| `%LOCALAPPDATA%\Roblox\<userId>\` | per-account dir (CustomRibbonTabs, InstalledPlugins) — its existence proves that account was used on this machine |
| `Chrome/Edge User Data\<Profile>\Login Data` | sqlite `logins(origin_url, username_value)` — **usernames readable**, passwords encrypted |
| `Chrome/Edge User Data\<Profile>\Network\Cookies` | sqlite `cookies(name, host_key, expires_utc)` — whether a live `.ROBLOSECURITY` exists (value stays encrypted) |
| `Chrome User Data\<Profile>\History` | sqlite `urls` — search `/users/<id>/profile` to learn which Chrome profile manages which account |

Copy the sqlite file to a temp path before opening it — Chrome locks the live DB.

**Recovery path to hand the user, in order:**
1. **Studio's account picker** — avatar top-right → pick the account. If the session is still
   valid it switches with no password at all. This is the fastest fix and is why
   `showInAccountPicker: true` matters.
2. Open the browser profile that holds a live `.ROBLOSECURITY` for that account.
3. Only if asked for a password: `https://www.roblox.com/login/forgot-password`.

**Line to hold:** report *where* a credential lives and let the user click it. Do **not** decrypt
`.ROBLOSECURITY` cookies, `AccountBlob`, or browser passwords. If the machine shows signs of
account trading (many saved Roblox logins, shops like `*roblox.vn`), stay on the official paths.

### Correlating Studio sessions with machine reboots

When a user claims "Studio switched accounts by itself after a restart", the Windows System event
log settles it. Two gotchas:

- **Timezone.** Roblox logs are UTC (`...Z`). Windows event log timestamps are **local time**.
  Convert before lining them up, or the correlation is nonsense.
- **`Get-WinEvent` needs no admin** to read the System log, but the PowerShell tool here returns
  empty stdout. Write to a file and read the file instead — that works:

```powershell
Get-WinEvent -FilterHashtable @{LogName='System'; StartTime=[datetime]'2026-10-01T00:00:00'} |
  Where-Object { $_.Id -eq 12 -or $_.Id -eq 13 -or $_.Id -eq 6005 -or $_.Id -eq 6006 -or $_.Id -eq 1074 } |
  Select-Object TimeCreated, Id | Sort-Object TimeCreated | Format-Table -AutoSize |
  Out-File -FilePath "<path>" -Encoding utf8
```

| ID | Meaning |
|---|---|
| 12 | OS started |
| 13 | OS shutting down |
| 6005 / 6006 | Event Log service started / stopped (boot / clean shutdown) |
| 1074 | a process requested shutdown or restart |
| 41 | unexpected shutdown (power loss, hard reset) |

Pair each `launchtime:<unixms>` (or the filename timestamp) in the Studio logs with these events.
A real case: Studio ran as account A until a shutdown at 13:00, the machine rebooted at 16:39, and
the next Studio launch at 16:40 came up as account B — with **no `requestLogOut` in any log in
between**. That is a genuine anomaly worth reporting, and the raw timeline is the evidence.

**Two gaps to watch for:** a boot with no preceding shutdown ID 13 means either an unclean
shutdown or a resume from hibernation/Fast Startup — you cannot tell which from these events, so
say so rather than implying a clean restart. And `reg.exe` is on the sandbox program blacklist,
so `HKCU\Software\Roblox\RobloxStudioBrowser` (where Studio historically kept cookies) is
unreadable from here.

### Is a Studio log tampered?

Append-only text from many threads looks "out of order" by design. Count timestamps that go
backwards and measure how far:

```
38,391-line log -> 43 backwards steps, min 1.0 ms, median 1.0 ms, max 1145 ms, 0 gaps > 120 s
```

Sub-second reversals are normal thread interleaving. Look instead for **large** reversals, long
gaps with no lines, or a header/footer that does not match the filename timestamp — those are
truncation or rewriting. State the numbers; do not just assert "the log looks fine".

### The persisted account state can contradict the logs

`appStorage.json` → `PreviousAccountsList` records per-account `signInTimestamp` /
`signOutTimestamp`. In one case it claimed an account had `signOutTimestamp = 2026-09-01` and
**no** `signInTimestamp` — while the logs proved that same account hit `Authenticated : YES` and
played on 29/09, 30/09, 01/10 and 02/10. The file disagreed with reality. Also check mtimes:
`RobloxCookies.dat` had not been written since 30/09 even though logins happened on 02/10, which
means the live session had moved to `appStorage.json` / `rbx-storage.db`.

### Reading the registry without admin — `winreg`, not `reg.exe`

`reg.exe` is on the sandbox **Program Blacklist** and `regedit.exe` fails with *"Access is
denied"* even for HKCU. But `winreg` is a direct API call, not a program launch, so it is **not
blocked** — and HKCU needs no elevation. Use it instead of giving up or asking the user.

```python
import winreg
base = r'SOFTWARE\Roblox\RobloxStudio\LoggedInUsersStore'
k1 = winreg.OpenKey(winreg.HKEY_CURRENT_USER, base, 0, winreg.KEY_READ)
s1 = winreg.EnumKey(k1, 0); winreg.CloseKey(k1)
k2 = winreg.OpenKey(winreg.HKEY_CURRENT_USER, base + '\\' + s1, 0, winreg.KEY_READ)
s2 = winreg.EnumKey(k2, 0); winreg.CloseKey(k2)
k3 = winreg.OpenKey(winreg.HKEY_CURRENT_USER, base + '\\' + s1 + '\\' + s2, 0, winreg.KEY_READ)
print(winreg.EnumValue(k3, 0))
```

**Trap: `OpenKey` with the full path fails with `FileNotFoundError`.** The store is really a
subkey named `https:` containing a subkey named `www.roblox.com`, so the path Regedit shows
(`...\LoggedInUsersStore\https:\www.roblox.com`) is not openable as one string. Enumerate level by
level with `EnumKey` as above.

The `users` value there is a `REG_SZ` holding **two JSON objects concatenated with `;`** — not one
valid JSON document, so a single `json.loads` raises `Extra data`. Split on `;` first. Real
example, 361 chars, listing both accounts still present in the store:

```
{"11617111303":{"username":"sadadafafaafel","profilePicUrl":"..."}};
{"11234515308":{"username":"nioikokfaafaafd","profilePicUrl":"..."}};
```

**Do not drive Regedit by synthetic input to read a value.** Click, double-click, right-click and
Enter all failed to open the Modify dialog, and the Data column truncates the string anyway.
Read the raw value with `winreg` and, if a visual is wanted, screenshot the window afterwards —
the exact string is better evidence than a screenshot.

## Pushing a script when the MCP client is down (raw JSON-RPC)

If `StudioMCP.exe` is not running (the MCP client dropped, so the `mcp__Roblox_Studio__*`
tools vanish from the tool index), you can still drive Studio: **`StudioMCP.exe` is a plain MCP
server over stdio**, so spawn it yourself and speak JSON-RPC.

```python
import subprocess, json, threading, time
EXE = r'C:\Users\User\AppData\Local\Roblox\Versions\version-76e1a02649ad4f35\StudioMCP.exe'
p = subprocess.Popen([EXE], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                     text=True, encoding='utf-8', errors='replace', bufsize=1)

def send(o):
    p.stdin.write(json.dumps(o, ensure_ascii=False) + '\n'); p.stdin.flush()

def call(method, params, timeout=40):          # read until the matching id arrives
    ...                                        # skip notifications; guard with a deadline
# handshake
call("initialize", {"protocolVersion":"2024-11-05","capabilities":{},
                    "clientInfo":{"name":"pusher","version":"1.0"}})
send({"jsonrpc":"2.0","method":"notifications/initialized","params":{}})
# then any tool
call("tools/call", {"name":"multi_edit", "arguments":{
     "file_path":"game.StarterPlayer.StarterPlayerScripts.MyScript",
     "className":"LocalScript", "datamodel_type":"Edit", "studio_id": sid,
     "edits":[{"old_string":"", "new_string": open(SRC, encoding='utf-8').read()}]}})
```

Reading the `.lua` off disk in Python and passing it as `new_string` avoids transcribing a
600-line script by hand. `push_script.py` / `check_state.py` in the workspace do exactly this —
reuse them.

**`list_roblox_studios` is FLAKY.** It returns `{"studios":[]}` intermittently even while Studio
has a place open — observed twice in one session, then working on the next call seconds later.
**Never conclude "no place is open" from a single call.** Retry with a ~2 s delay (a 12-attempt
loop is enough) before reporting a problem or asking the user to change anything.

**Studio is only listed once a place is open** — the Start Page does not count. And note that
`StudioMCP.exe` exists in more than one `Versions\version-*` folder; a version mismatch is NOT the
cause of an empty list (both were probed and both saw the running Studio). Studio's own
`%LOCALAPPDATA%\Roblox\mcp.bat` names the right exe for the current version.

### Three traps that make tests lie to you

**`get_console_output` returns PLAIN TEXT, not JSON.** If your helper does
`json.loads(result["result"]["content"][0]["text"])` for every tool, this one silently yields `{}`
and you will conclude the console is empty while it is actually full of the log you need. Read that
tool's text raw.

**`user_mouse_input`: never put a `wait` between `moveTo` and `mouseButtonDown`.** With
`moveTo → wait → mouseButtonDown` the click is simply not delivered and the feature looks broken.
Put them back-to-back in the same `actions` array:
```json
[{"action":"moveTo","x":430,"y":330},
 {"action":"mouseButtonDown","mouse_button":"left"},
 {"action":"wait","wait_time_ms":600},
 {"action":"mouseButtonUp","mouse_button":"left"}]
```
Splitting `moveTo` and the button press into **separate tool calls** also loses the position — keep
them in one call.

**The synthetic mouse can stay stuck "down"** between tests, and the next press fails with
`VirtualInput::SendMouseButton: duplicate button state.` Send a `mouseButtonUp` first to clear it.

**A "disappearing" object is usually a measurement taken too late.** A projectile that sticks for
3 s and then fades was reported as "17 swords destroyed within 0.5 s" — it was measured ~3.5 s after
the click, past the whole lifecycle. Measure immediately (0.2–0.5 s after the action), or better,
add a temporary `print` with the reason at the destroy site and read the log. Instrumenting beats
inferring: one print in the removal path answered in a single run what several timed measurements
had got wrong.

## Related Roblox MCP skills

The server exposes its own knowledge via the `skill` tool — call it **before** writing code
for these areas: `rbx-debug`, `rbx-perf-profiling`, `rbx-scene-analysis`, `rbx-unit-test`,
`rbx-device-simulator-lua`, `rbx-docs-search`, `rbx-create-skill`.

## Safety

A connected client can read and **modify** the open place. Work on a copy or a
source-controlled project before authorizing bulk edits. Ask before modifying someone's game.
