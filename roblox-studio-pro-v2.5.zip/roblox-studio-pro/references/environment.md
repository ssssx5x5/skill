# Môi trường: map, terrain, bầu trời, mây, ánh sáng, thời tiết

## Mục lục
1. Quy trình dựng một map
2. Số đo thật của nhân vật (để kiểm bằng số)
3. Terrain bằng code
4. Lighting, Atmosphere, Sky
5. Mây: chọn kỹ thuật theo nhu cầu
6. Mây volumetric giả bằng sprite/puff: tự tính sáng tối
7. Thời tiết và ngày đêm
8. Vùng (zone) đổi không khí theo vị trí
9. Hiệu năng

## 1. Quy trình dựng một map

Làm theo lớp, từ thô đến tinh. Mỗi lớp phải chơi được trước khi sang lớp sau, vì sửa bố cục ở giai đoạn chi tiết rất tốn.

1. **Blockout**: khối xám đúng kích thước. Chốt đường đi, tầm nhìn, điểm nhấn (landmark), chỗ ẩn nấp. Chưa màu, chưa vật liệu.
2. **Ánh sáng thô**: `Lighting` + `Atmosphere` + `Sky` để chốt tâm trạng. Ánh sáng quyết định cảm giác nhiều hơn model.
3. **Vật liệu + màu**: bảng 4-6 màu chủ đạo, 3-5 `Material`. Lặp lại để thống nhất.
4. **Chi tiết** (props, cây, vết bẩn, decal) theo nguyên tắc: dày ở nơi người chơi nhìn lâu, thưa ở xa.
5. **Hiệu ứng khí quyển**: sương, hạt bụi, mây, tiếng môi trường (ambient loop, tiếng gió).
6. **Tối ưu + test** (mục 9).

Kỹ thuật dựng bằng code: dùng **kit** (tập module lặp: tường, cột, cửa) có kích thước theo lưới (ví dụ 4 studs, khớp lưới voxel terrain), ráp bằng hàm `place(kitName, cframe)`. Dễ sửa hàng loạt và dễ builder một script.

## 2. Số đo thật của nhân vật

Thiết kế bằng số, không bằng cảm giác. Với nhân vật mặc định (R15, `WalkSpeed` 16, `JumpHeight` 7.2, trọng lực 196.2 studs/s²):

| Thứ | Giá trị tham khảo |
|---|---|
| Chiều cao nhân vật | ~5 studs |
| Cửa đi tối thiểu | rộng 4, cao 7+ (thoải mái: 6 x 9) |
| Hành lang | rộng 8+ (căng thẳng/horror: 5-6) |
| Trần nhà | 12-14 (thấp hơn tạo cảm giác ngột ngạt) |
| Nhảy cao tối đa | 7.2 studs |
| Khoảng nhảy xa tối đa | ~8-9 studs (bay ~0.54s ở tốc độ 16) |
| Khe nhảy qua thoải mái | <= 6 studs |
| Bậc leo tự nhiên | <= 2 studs (cao hơn phải nhảy) |

Muốn kiểm: nếu bạn thay `WalkSpeed`/`JumpHeight`, tính lại `airTime = 2 * sqrt(2 * jumpHeight / 196.2)` và `maxGap = walkSpeed * airTime`. Với AI dùng `PathfindingService`, `AgentRadius`/`AgentHeight` phải khớp thực thể, nếu không quái không lọt cửa mà bạn tưởng lọt.

## 3. Terrain bằng code

Terrain voxel có độ phân giải 4 studs. Dựng cột theo hàm chiều cao, chia việc qua `task.wait()` để không treo Studio.

```lua
local terrain = workspace.Terrain
local SEED = 123.456 -- số lẻ để tránh math.noise = 0 ở các điểm nguyên
local HALF, STEP, BASE = 256, 4, 20

local function heightAt(x: number, z: number): number
	local broad = math.noise(x * 0.008, z * 0.008, SEED) * 45    -- đồi lớn
	local detail = math.noise(x * 0.04, z * 0.04, SEED + 7.7) * 7 -- nhấp nhô nhỏ
	return math.max(BASE + broad + detail, 4)
end

local function materialAt(h: number): Enum.Material
	if h > 55 then return Enum.Material.Snow
	elseif h > 40 then return Enum.Material.Rock
	elseif h < 12 then return Enum.Material.Sand
	end
	return Enum.Material.Grass
end

for x = -HALF, HALF, STEP do
	for z = -HALF, HALF, STEP do
		local h = heightAt(x, z)
		terrain:FillBlock(CFrame.new(x, h / 2, z), Vector3.new(STEP, h, STEP), materialAt(h))
	end
	if (x // STEP) % 8 == 0 then task.wait() end
end
```

Gợi ý: dùng `Terrain:FillBall`/`FillCylinder` cho hố, hang, hồ; `FillBlock` với `Enum.Material.Water` cho nước (đổ nước thấp hơn bờ). Muốn tinh hơn (sườn dốc mượt, đa vật liệu theo độ dốc) hãy đọc/ghi voxel hàng loạt bằng `ReadVoxels`/`WriteVoxels`. Phần này phức tạp, nên kiểm tra tài liệu hiện hành trước khi dùng.

## 4. Lighting, Atmosphere, Sky

Các thuộc tính chính (đều chỉnh được bằng script trừ khi ghi chú):

- `Lighting`: `ClockTime`/`TimeOfDay`, `Brightness`, `Ambient`, `OutdoorAmbient`, `ColorShift_Top/Bottom`, `EnvironmentDiffuseScale`, `EnvironmentSpecularScale`, `ExposureCompensation`, `GlobalShadows`, `ShadowSoftness`, `GeographicLatitude`.
- `Lighting.Technology` (ShadowMap/Future...): **đặt trong Studio**, không đổi được lúc chạy. Hãy nói người dùng đặt nó.
- `Atmosphere` (con của Lighting): `Density` (độ dày sương), `Offset`, `Color`, `Decay` (màu chân trời), `Glare`, `Haze`. Thay cho `FogStart/FogEnd` cũ ở hầu hết trường hợp.
- `Sky`: `SkyboxBk/Dn/Ft/Lf/Rt/Up` (asset id), `SunTextureId`, `MoonTextureId`, `StarCount`, `CelestialBodiesShown`. Không có asset hợp lệ thì để placeholder và báo.
- Hậu kỳ: `ColorCorrectionEffect`, `BloomEffect`, `DepthOfFieldEffect`, `SunRaysEffect`, `BlurEffect`.

Công thức tâm trạng nhanh (đây là điểm xuất phát, hãy tinh chỉnh bằng mắt):

| Tâm trạng | Gợi ý |
|---|---|
| Horror đêm | `ClockTime` 0-2, `Brightness` 0.1-0.4, `Atmosphere.Density` 0.4-0.6 màu xám lam, `Ambient` tối nhưng không đen hẳn |
| Hoàng hôn ấm | `ClockTime` ~17.5-18.5, `Atmosphere.Decay` cam, `Glare`/`Haze` vừa, bloom nhẹ |
| Giữa trưa khô | `ClockTime` 13, `Atmosphere.Density` thấp 0.2-0.3, `Decay` xanh nhạt |
| Sương dày | `Atmosphere.Density` 0.5-0.7, `Haze` cao, `Offset` 0.2-0.4 |

Nguyên tắc: **tối không có nghĩa là đen**. Giữ `Ambient`/`OutdoorAmbient` đủ để người chơi đọc được hình khối; để sáng/tối nằm ở tương phản cục bộ (đèn, ánh trăng).

## 5. Mây: chọn kỹ thuật theo nhu cầu

Roblox không cho viết shader tùy chỉnh. Mọi mây "volumetric" đều là mẹo. Chọn theo ngân sách:

| Kỹ thuật | Ưu | Nhược | Dùng khi |
|---|---|---|---|
| `Clouds` của Terrain (`Instance.new("Clouds", workspace.Terrain)`, chỉnh `Cover`, `Density`, `Color`) | Rẻ nhất, ổn định | Một lớp phẳng ở độ cao cố định, ít kiểm soát hình dạng | Nền trời nhẹ, game mobile |
| Sprite/billboard dán texture mây | Đẹp, rẻ nếu ít đối tượng, hình dạng đa dạng | Cần texture (upload hoặc bake bằng code), nhìn từ trên xuống kém | Trời có nhiều loại mây, camera ở mặt đất |
| Cụm "puff" bằng Part cầu mờ | Có chiều sâu thật, đi xuyên được | Sáng tối do engine quyết định, dễ ra **đốm xám**; nhiều part thì nặng | Mây gần, cảnh quan sát được |
| Bake bằng CPU ray march rồi dán lên sprite | Mây đẹp, có sáng tối vật lý | Tốn công, cần `EditableImage` hoặc texture dựng sẵn (kiểm tra API còn khả dụng) | Mây là trọng tâm hình ảnh |

**Tham chiếu hình dạng thật** (để có "nhiều loại mây", không chỉ 1-3 kiểu). Mỗi loại là một bộ tham số, không phải một model riêng:

| Loại | Đặc điểm | Gợi ý tham số |
|---|---|---|
| Cumulus humilis/mediocris | Đáy phẳng, đỉnh bông, rời rạc | chiều rộng:cao ~ 2:1, đáy phẳng rõ |
| Cumulus congestus | Cao, đỉnh hình súp lơ | cao hơn rộng, nhiều tầng puff |
| Cumulonimbus | Rất cao, đỉnh nở như đe | đáy tối, đỉnh sáng, đỉnh dẹt rộng |
| Stratocumulus | Lớp dày thành mảng, có khe | dẹt, nhiều mảng nối nhau |
| Altocumulus | Đàn ô nhỏ xếp hàng ở tầng giữa | nhiều cụm nhỏ đều đặn, mỏng |
| Stratus | Phủ kín, xám phẳng | rất rộng, mỏng, ít chi tiết |
| Cirrus | Sợi mảnh, rất cao | kéo dài một hướng, trong suốt cao |

Tạo đa dạng bằng cách trộn: loại, kích thước (ngẫu nhiên có phân phối, không đồng đều), độ cao đáy, độ dẹt, độ trong suốt, hướng gió. Nếu người dùng chỉ muốn mây trung bình đến lớn, đặt `MIN_SIZE` trong Config rồi loại bỏ mẫu nhỏ ngay khi sinh.

## 6. Mây volumetric giả bằng sprite/puff: tự tính sáng tối

**Nguyên nhân gốc của "đốm xám" (polka dot)**: mỗi puff là một Part bị engine chiếu sáng/đổ bóng độc lập. Khi ánh sáng yếu hoặc nghiêng, mỗi cầu có một nửa tối và nhiều cầu chồng nhau tạo thành chấm xám. Mây thật không thế: ánh sáng đi xuyên qua khối và tán xạ nhiều lần.

**Hướng sửa**: không để engine quyết định sáng tối của mây. Tính màu từng puff/pixel theo mô hình đơn giản rồi gán cố định, dùng vật liệu không bị đổ bóng (`Neon`, hoặc sprite) và `CastShadow = false`.

Mô hình vật lý rút gọn cho một điểm trong mây:
- **Hấp thụ** theo độ dày mật độ phía trên nó dọc tia sáng mặt trời: `T = exp(-sigma * depth)` (Beer-Lambert). Càng sâu trong khối, càng tối.
- **Tán xạ nhiều lần** làm sáng lại: cộng một sàn sáng (`MIN_LIGHT`) để vùng tối không bao giờ thành xám đen.
- **Viền sáng** (silver lining): mép mỏng khi nhìn ngược về phía mặt trời sáng hơn (tán xạ tiến).
- **Ánh trời** từ trên xuống làm đỉnh sáng hơn đáy; đáy mây tích thường phẳng và tối hơn, hơi xanh xám.

```lua
local CLOUD = {
	SunColor    = Color3.fromRGB(255, 252, 245),
	ShadowColor = Color3.fromRGB(150, 162, 182), -- vùng tối: xám xanh, KHÔNG phải đen
	MIN_LIGHT   = 0.35,   -- sàn sáng do tán xạ nhiều lần
	ABSORB      = 1.6,    -- hệ số hấp thụ (sigma)
	SKY_TOP     = 0.25,   -- cộng thêm cho đỉnh mây
	EDGE_BOOST  = 0.35,   -- viền sáng khi nhìn ngược nắng
}

-- heightFrac: 0 (đáy) .. 1 (đỉnh) trong khối mây
-- sunDepth: độ dày mật độ giữa điểm này và mặt trời (0 = lộ ra nắng)
-- thinness: 1 ở mép mỏng, 0 ở lõi dày
-- backlit: 0..1, 1 khi camera nhìn ngược về phía mặt trời
local function cloudShade(heightFrac: number, sunDepth: number, thinness: number, backlit: number): Color3
	local transmit = math.exp(-CLOUD.ABSORB * sunDepth)
	local light = CLOUD.MIN_LIGHT + (1 - CLOUD.MIN_LIGHT) * transmit
	light += CLOUD.SKY_TOP * heightFrac * 0.5
	light += CLOUD.EDGE_BOOST * thinness * backlit
	return CLOUD.ShadowColor:Lerp(CLOUD.SunColor, math.clamp(light, 0, 1))
end
```

Quy trình bake (nếu làm sprite):
1. Sinh trường mật độ (noise nhiều octave nhân với "hình khối" gồm vài cầu/ellipsoid cộng nhau để có đáy phẳng, đỉnh bông).
2. Với mỗi pixel sprite: ray march xuyên khối tích lũy mật độ (alpha) và, ở mỗi bước, march ngắn về phía mặt trời để lấy `sunDepth`. Gom màu theo `cloudShade`.
3. Chia việc qua nhiều frame (`task.wait()` mỗi N dòng). Bake **một lần** khi vào game.
4. Dùng lại từng sprite cho nhiều đám mây với xoay/co giãn/tint khác nhau.

Hiệu năng cho nhiều mây:
- Số sprite trên trời: giữ vài chục đến ~150; sắp theo khoảng cách, bỏ cái ngoài tầm nhìn.
- Cập nhật vị trí/hướng ở 5-10 Hz, không phải mỗi frame; trôi theo gió bằng tween dài hoặc một "bục" duy nhất.
- Mờ dần ở xa bằng `distanceAlpha` (xem `ui-overlays.md` mục 6) để mây không hiện/biến mất đột ngột.
- Dùng pool: mây ra khỏi vùng thì tái sử dụng ở phía ngược lại thay vì hủy/tạo.

Hãy nói thẳng với người dùng rằng đây là xấp xỉ, và vài tham số (`ABSORB`, `MIN_LIGHT`, màu bóng) cần chỉnh bằng mắt trong Studio dưới ánh sáng thật của map.

## 7. Thời tiết và ngày đêm

```lua
-- Chu kỳ ngày đêm: 1 giờ game = secondsPerHour giây thực
local RunService = game:GetService("RunService")
local Lighting = game:GetService("Lighting")
local SECONDS_PER_HOUR = 20

RunService.Heartbeat:Connect(function(dt)
	Lighting.ClockTime = (Lighting.ClockTime + dt / SECONDS_PER_HOUR) % 24
end)
```

Muốn đổi màu theo giờ: lưu bảng keyframe `{ hour, ambient, atmosphereColor, density }` và nội suy giữa hai keyframe kề nhau bằng `Color3:Lerp`/`math.lerp`.

**Mưa** (ở client): một part mỏng nằm trên đầu camera mang `ParticleEmitter` (hạt dài, rơi thẳng, `Rate` cao, `Lifetime` ngắn) và cập nhật vị trí theo camera ở 10-20 Hz. Tweening `Atmosphere.Density` tăng, `Lighting.Brightness` giảm, thêm tiếng mưa 2D (loop) và tiếng mưa 3D trên mái.

**Sét**: một cú chớp (`Lighting.Brightness`/`ColorCorrection` tăng vọt rồi tắt trong ~0.1-0.3s, có thể nháy đôi) **rồi sau đó** mới nghe sấm. Độ trễ thật: `delay = dist / 1200` giây (âm thanh ~343 m/s, 1 stud ~ 0.28 m nên ~1200 studs/s). Sấm xa thì trầm hơn: giảm `EqualizerSoundEffect` cao tần và tăng `ReverbSoundEffect`.

**Gió**: `workspace.GlobalWind` (Vector3) ảnh hưởng cỏ/cây của terrain; hãy kiểm tra hành vi hiện tại của nó với hạt và foliage trong phiên bản Studio bạn dùng.

Nếu hệ thống thời tiết có lệnh chat (`/storm`, `/rain`), đăng ký bằng `Player.Chatted` hoặc `TextChatService` (`TextChatCommand`), gom tên lệnh vào một bảng và **đối chiếu mọi key cấu hình với handler** (xem `verification.md`: đây đúng là loại lỗi im lặng hay gặp).

## 8. Vùng (zone) đổi không khí theo vị trí

Thay vì `Touched` (hay hụt, tốn), dùng volume part (CanCollide/CanTouch/CanQuery = false, `Transparency = 1`) gắn tag `Zone` và attribute (`Ambient`, `Density`, `MusicId`...). Client kiểm tra vị trí camera ở 4 Hz bằng `workspace:GetPartBoundsInBox(...)` hoặc so sánh tọa độ với AABB, rồi tween Lighting/Atmosphere/nhạc tới giá trị của vùng. Có vùng chuyển tiếp (nội suy theo khoảng cách tới biên) thì không bị giật.

## 9. Hiệu năng

- `StreamingEnabled`: bật cho map lớn; với model quan trọng đặt `ModelStreamingMode`; code client dùng `WaitForChild` có timeout cho thứ có thể chưa được stream.
- Part tĩnh: `Anchored = true`; chi tiết trang trí: `CanCollide/CanQuery/CanTouch = false`, `CastShadow = false` cho vật nhỏ.
- `MeshPart.CollisionFidelity` đặt `Box`/`Hull` cho vật trang trí; chỉ cần `Default/Precise` ở chỗ va chạm thật.
- Ít lớp trong suốt chồng nhau (mây, kính, sương) vì tốn fill-rate; hạt giới hạn `Rate` và `Lifetime`.
- Gộp những gì có thể: nhiều part giống nhau lặp lại trên map lớn nên là một nhóm có thể tắt cả cụm khi xa.
- Đo bằng thanh MicroProfiler (Ctrl+F6) và Developer Console thay vì đoán.
