# UI responsive đa nền tảng: safe area, layout, style và input

> Khi nào dùng: khi dựng HUD/menu/shop hoặc khi một bộ UI chạy đúng trên desktop nhưng lệch, che, hoặc bấm không được trên phone, tablet và console.

## ScreenGui và safe area

UI luôn là chuyện của client: `ScreenGui` trong `StarterGui` được copy sang `PlayerGui` của từng player, hoặc tạo thẳng trong một controller client. Server không đụng `PlayerGui` trong thiết kế bình thường.

| `ScreenGui.ScreenInsets` | Vùng an toàn | Dùng cho |
| --- | --- | --- |
| `Enum.ScreenInsets.None` | không né gì | nền full-bleed, ảnh tràn viền |
| `Enum.ScreenInsets.DeviceSafeInsets` | né tai thỏ/notch và cạnh cong, **không** né topbar | nền lớn có nội dung sát mép |
| `Enum.ScreenInsets.CoreUISafeInsets` | né cả device inset và topbar Roblox | mặc định cho UI bấm được |
| `Enum.ScreenInsets.TopbarSafeInsets` | né topbar, giữ nguyên device inset | UI thiết kế muốn tràn xuống dưới tai thỏ |

```luau
--!strict
local Players = game:GetService("Players")
local playerGui = Players.LocalPlayer:WaitForChild("PlayerGui")

local gui = Instance.new("ScreenGui")
gui.Name = "Hud"
gui.ResetOnSpawn = false                                  -- mặc định là true: UI mất sau khi chết
gui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
gui.ScreenInsets = Enum.ScreenInsets.CoreUISafeInsets     -- né tai thỏ + topbar
gui.IgnoreGuiInset = false
gui.ClipToDeviceSafeArea = true                           -- cắt phần tràn ra ngoài vùng an toàn

local root = Instance.new("Frame")
root.Name = "Root"
root.Size = UDim2.fromScale(1, 1)
root.BackgroundTransparency = 1
root.Parent = gui

gui.Parent = playerGui -- parent cuối: một layout pass, không flicker
```

- `ScreenInsets` chỉ mở rộng vùng gốc của `ScreenGui`; con bên trong vẫn phải dùng `Scale` để co giãn theo vùng đó.
- `SafeAreaCompatibility` (`None`, `FullscreenExtension`) là đường migration cho `ScreenGui` cũ dựa vào `IgnoreGuiInset`; UI mới không cần.
- Test bằng **Device Emulator**: phone portrait + landscape, tablet, console (10-foot), màn 4K. Mỗi tổ hợp là một layout khác nhau, không phải một.

## Scale và Offset

| Dùng `Scale` (`UDim2.fromScale`, `UDim.new(scale, 0)`) | Dùng `Offset` (`UDim2.fromOffset`, `UDim.new(0, px)`) |
| --- | --- |
| kích thước và vị trí khung, panel, vùng chứa | padding, `UIStroke.Thickness`, icon, viền, bán kính `UICorner` |
| khoảng cách tương đối giữa các khối | kích thước cố định của một nút đã được duyệt thiết kế |
| mọi thứ phải sống sót qua phone ↔ 4K | chi tiết mà tỉ lệ sẽ làm méo (icon 24×24, stroke 1px) |

- `AnchorPoint = Vector2.new(0.5, 0.5)` + `Position = UDim2.fromScale(0.5, 0.5)` là tâm phần tử. Đặt `AnchorPoint` sai là nguyên nhân số một của "UI lệch trên mobile" khi mọi thứ khác đúng.
- Kích thước lai hợp lệ: `UDim2.new(1, -32, 0, 56)` = rộng full trừ 32px lề, cao cố định 56px. Đây là mẫu chuẩn cho thanh công cụ.
- `GuiObject.AbsoluteSize` chỉ đúng **sau** một layout pass. Đọc ngay sau khi `Parent` sẽ ra 0 — đợi `RunService.Heartbeat` hoặc `AbsoluteSize` changed.
- Toàn bộ một nhóm cần phóng to/thu nhỏ (popup, tutorial): `UIScale.Scale`, không nhân từng `UDim2`.

## Layout: UIListLayout, flex, grid

| Nhu cầu | Dùng |
| --- | --- |
| hàng/cột tự co giãn | `UIListLayout` (`FillDirection`, `Padding`, `HorizontalFlex`/`VerticalFlex`, `Wraps`, `SortOrder`) |
| một item chiếm hết chỗ trống | `UIFlexItem` con với `FlexMode = Grow` (hoặc `Fill`, `Shrink`, `Custom`, `None`) |
| grid kiểu inventory | `UIGridLayout` trong `ScrollingFrame` có `AutomaticCanvasSize` |
| carousel/trang | `UIPageLayout` |
| bo góc, viền, đệm | `UICorner`, `UIStroke`, `UIPadding` |
| gradient, đổ bóng | `UIGradient`, `UIShadow` |

```luau
--!strict
-- Hàng toolbar: các nút giữ kích thước, một spacer giãn hết phần còn lại.
local list = Instance.new("UIListLayout")
list.FillDirection = Enum.FillDirection.Horizontal
list.HorizontalFlex = Enum.UIFlexAlignment.Fill -- chia đều phần trống cho item Grow/Fill
list.Padding = UDim.new(0, 8)
list.SortOrder = Enum.SortOrder.LayoutOrder
list.Parent = bar

local spacer = Instance.new("Frame")
spacer.Name = "Spacer"
spacer.LayoutOrder = 2
spacer.Size = UDim2.fromScale(0, 1) -- bị flex ghi đè theo trục ngang
spacer.BackgroundTransparency = 1
spacer.Parent = bar

local flex = Instance.new("UIFlexItem")
flex.FlexMode = Enum.UIFlexMode.Grow
flex.GrowRatio = 1
flex.Parent = spacer
```

- `HorizontalFlex`/`VerticalFlex` nhận `Enum.UIFlexAlignment`: `None`, `Fill`, `SpaceAround`, `SpaceBetween`, `SpaceEvenly`. Khi khác `None`, `Size` của con **theo trục đó bị bỏ qua** — đặt `Size` rồi thắc mắc sao không ăn là hiểu nhầm phổ biến nhất của flex.
- `UIListLayout` ghi lại `Position`/`Size` của con mỗi layout pass. Mọi tween vào hai property này trên con của layout sẽ bị reset ngay frame sau.
- `ScrollingFrame` + `UIListLayout`: set `AutomaticCanvasSize = Enum.AutomaticSize.Y`, `CanvasSize = UDim2.new()`, `ScrollingDirection = Enum.ScrollingDirection.Y`. Để `CanvasSize` cũ là scroll sai và cuối danh sách bị cắt.
- Danh sách dài: dựng lazy hoặc virtualize (chỉ tạo item trong viewport), đừng tạo 500 item rồi ẩn.

## Constraint

| Constraint | Chốt điều gì | Lưu ý |
| --- | --- | --- |
| `UIAspectRatioConstraint` | tỉ lệ rộng/cao | `AspectRatio` mặc định `1`; `DominantAxis` quyết định trục nào bị bó |
| `UISizeConstraint` | `MinSize`/`MaxSize` tuyệt đối | chặn panel phình trên 4K và bẹp trên phone |
| `UITextSizeConstraint` | `MinTextSize`/`MaxTextSize` | chỉ có tác dụng khi `TextScaled = true` |
| `UIPadding` | đệm trong, không đổi kích thước ngoài | đệm ăn vào vùng của layout con |
| `UIScale` | phóng to cả nhánh | dùng cho hiệu ứng pop, không dùng để "sửa DPI" |

- `TextScaled = true` cho ra cỡ chữ khác nhau giữa các nút cùng cấp vì nó khớp theo chiều cao khả dụng. Ưu tiên `TextSize` cố định + `AutomaticSize` + `UITextSizeConstraint` cho trường hợp cần co theo khung.
- `AutomaticSize` cho frame tự lớn theo nội dung (tooltip, chat bubble, list). Kết hợp `AutomaticSize` với `UISizeConstraint.MaxSize` để không tràn màn hình.

## StyleSheet, token và theme

Styling mức engine thay cho việc copy-paste giá trị property khắp nơi. Một `StyleSheet` gắn vào một nhánh qua `StyleLink`.

| Selector | Khớp với | Ví dụ |
| --- | --- | --- |
| `Class` | class của `GuiObject`/`UIComponent` | `"TextButton"`, `"UICorner"` |
| `.Tag` | `CollectionService` tag | `".Primary"` |
| `#Name` | `Instance.Name` | `"#CloseButton"` |
| `:State` | `Enum.GuiState` (`Hover`, `Press`, `NonInteractable`, `Idle`) | `"TextButton:Hover"` |
| `@Query` | `StyleQuery` đang bật, hoặc built-in: `@PreferredInput{Gamepad,KeyboardAndMouse,Touch}`, `@ViewportDisplaySize{Small,Medium,Large}`, `@PreferredTextSize{Medium,Large,Larger,Largest}`, `@ReducedMotionEnabled{True,False}` | `"@ViewportDisplaySizeSmall"` |
| `::Class` | pseudo-instance (thêm modifier mà không cần chèn instance) | `"TextButton::UICorner"` |
| `A > B`, `A B` | con trực tiếp / hậu duệ | `".Container > ImageLabel"` |

```luau
--!strict
local tokens = Instance.new("StyleSheet")   -- token = attribute trên sheet
tokens.Name = "Tokens"
tokens:SetAttribute("Primary", Color3.fromHex("3B82F6"))
tokens:SetAttribute("Radius", UDim.new(0, 8))

local sheet = Instance.new("StyleSheet")
sheet.Name = "AppStyle"
local derive = Instance.new("StyleDerive")
derive.StyleSheet = tokens                  -- đổi dòng này là đổi theme
derive.Parent = sheet

local rule = Instance.new("StyleRule")
rule.Selector = ".Primary"
rule:SetProperties({ BackgroundColor3 = "$Primary", AutoButtonColor = false })
rule.Parent = sheet

local hover = Instance.new("StyleRule")
hover.Selector = ".Primary:Hover"
hover:SetProperty("BackgroundColor3", "$PrimaryHover")
hover.Parent = sheet

local link = Instance.new("StyleLink")
link.StyleSheet = sheet
link.Parent = screenGui

buy:AddTag("Primary")                       -- TextButton mang tag .Primary
```

- Theme: tạo `LightTheme`/`DarkTheme` định nghĩa **cùng tên token**, rồi trỏ `StyleDerive.StyleSheet` sang theme đang bật. Không cần set lại property của từng nút.
- `@ViewportDisplaySize` cho phép một bộ UI tự đổi layout theo màn hình mà không cần một `Script` đọc `ViewportSize` — đây là lý do chính nên dùng style sheet thay vì set property bằng code.
- Chỉnh trực quan bằng **Style Editor** trong Studio; giá trị trong code và trong editor là một.

## RichText và text

- `RichText = true` bật `<b>`, `<i>`, `<u>`, `<s>`, `<font color="#FF0" size="24" face="...">`, `<stroke color="" thickness="">`, `<br>`, `<mark>`.
- **Luôn escape** `<`, `>`, `&` trong text do người chơi nhập trước khi chèn vào chuỗi RichText. Không escape là tag do người chơi viết được thực thi (đổi màu, chèn `<font size>` khổng lồ, phá layout).
- Text của player này hiển thị cho player khác **phải** filter bằng `TextService:FilterStringAsync` trên server, kể cả tên pet, biển hiệu, tên guild, ghi chú trade.
- `FontFace = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Bold)` cho weight/style; `Enum.Font` là API cũ, không có weight.
- `TextTruncate = Enum.TextTruncate.AtEnd` cho khung cố định; `TextWrapped = true` phải đi kèm chiều cao đủ hoặc `AutomaticSize.Y`.
- Localize bằng `LocalizationTable` + auto-translation; đừng nướng chữ vào ảnh.

## Gamepad và touch

- Đọc `UserInputService.PreferredInput` (`KeyboardAndMouse`, `Touch`, `Gamepad`) và nghe `GetPropertyChangedSignal("PreferredInput")` để đổi prompt/layout. **Không** suy ra nền tảng từ `TouchEnabled`/`KeyboardEnabled`: máy hybrid và console có thể bật nhiều cờ cùng lúc.
- Dùng `GuiButton.Activated` (chuột, touch, gamepad đều phát) thay `MouseButton1Click` (gamepad không phát).
- Console: mọi phần tử tương tác phải `Selectable = true`; đặt `GuiService.SelectedObject` khi menu mở (nếu không, cần analog stick để bắt đầu điều hướng); nhóm bằng `SelectionGroup` và `NextSelectionUp/Down/Left/Right` để D-pad đi đúng thứ tự; bind `Enum.KeyCode.ButtonB` để đóng.
- Touch target tối thiểu ≈ **44×44 px**; chữ đọc được ≥ **14 px** trên phone.
- `Input Action System`: `InputBinding.UIButton` cho phép một nút on-screen kích hoạt action, dùng chung binding với phím và tay cầm thay vì viết hai nhánh code.

## UIDragDetector

- `UIDragDetector` thay `GuiObject.Draggable` (đã deprecated, không dùng cho việc mới).
- `DragStyle`: `TranslatePlane` (kéo tự do trong mặt phẳng), `TranslateLine` (chỉ theo `DragAxis`), `Rotate`, `Scriptable` (tự áp kết quả). `DragSpace` quyết định hệ quy chiếu; event: `DragStart`, `DragContinue`, `DragEnd`.
- Phải là **hậu duệ** của `GuiObject` được kéo, không phải con của một object khác trong cây.
- Kéo trong `ScrollingFrame`: scroll sẽ cướp input. Tắt `ScrollingEnabled` trong `DragStart`, bật lại trong `DragEnd`.
- Kéo một item nằm trong `UIListLayout`/`UIGridLayout`: layout ghi lại `Position` mỗi pass nên item bật về chỗ cũ. Kéo trong container không có layout, hoặc `DragStyle = Scriptable` rồi tự ghi vị trí.

## CanvasGroup và tween

- `CanvasGroup` render cả subtree vào một texture: fade bằng `GroupTransparency`, đổi màu bằng `GroupColor3`. Dùng cho panel mờ dần, chuyển cảnh — **không** dùng cho UI lớn luôn hiển thị (tốn texture memory, chữ nhoè khi scale).
- `CanvasGroup` làm phẳng cây con: `ZIndex` giữa các nhánh khác nhau không còn so sánh được, và nội dung bên trong không `ClipsDescendants` ra ngoài nhóm.
- Tween trên client: `TweenService:Create(frame, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), { BackgroundTransparency = 0 }):Play()`. Giữ handle nếu cần `:Cancel()` khi mở/đóng nhanh, tránh hai tween chồng nhau giật.
- Pop/nhấn: tween `UIScale.Scale` (1 → 1.08 → 1) thay vì `Size` — layout không nhảy, không đẩy các item khác.

## BillboardGui và SurfaceGui

| | `BillboardGui` | `SurfaceGui` |
| --- | --- | --- |
| Hướng | luôn quay về camera | dán lên một mặt của part |
| Dùng cho | tên nhân vật, thanh máu, marker | màn hình, biển hiệu, bảng điều khiển |
| Kích thước | `Size` dùng `Scale` để tự nhỏ lại theo khoảng cách | `SizingMode = FixedSize` + `CanvasSize`, hoặc `PixelsPerStud` |
| Thuộc tính then chốt | `MaxDistance`, `AlwaysOnTop`, `LightInfluence`, `Adornee` | `Face`, `LightInfluence`, `AlwaysOnTop`, `Adornee` |
| Không render khi | part adornee bị stream ra ngoài | part adornee bị stream ra ngoài |

- Nội dung riêng từng player (tên, máu): giữ `BillboardGui` trong `PlayerGui` và trỏ `Adornee` vào part — không nhân bản GUI vào world.
- `AlwaysOnTop` chỉ bật cho thứ thật sự cần xuyên vật thể (marker nhiệm vụ); bật tràn lan làm UI dính lên tường và mất cảm giác chiều sâu.
- `SurfaceGui` đặt trong `StarterGui` mà không set `Adornee` thì không hiện ở đâu cả — nó cần một part đích.
- `ProximityPrompt` cho tương tác cross-platform miễn phí (tự đổi prompt theo input); vẫn phải validate ở server.

## Framework khai báo: React-lua, Fusion, Vide

| | Package | Mô hình | Hợp khi |
| --- | --- | --- | --- |
| React | `jsdotlua/react` + `react-roblox` | component + hooks, `ReactRoblox.createRoot` | nhiều màn hình, state phức tạp, team quen web |
| Fusion | `Fusion` (0.3: `Fusion.scoped`, `scope:Value`, `scope:Computed`, `scope:New`, `Fusion.OnEvent`, `Fusion.peek`) | state reactive + dựng instance khai báo | UI gắn chặt với state game, cần dọn dẹp theo scope |
| Vide | `Vide` | reactive nhỏ, nhẹ | UI ít màn hình, muốn ít abstraction |

- Chọn theo cái dự án đang dùng; đổi framework giữa đường đắt hơn mọi lợi ích.
- Giữ state game trong controller/store, UI chỉ render và phát intent lên. Nhét logic vào component là lý do phổ biến khiến UI không test được.
- `React.useEffect` cleanup phải disconnect signal của Roblox, nếu không mỗi lần mount lại rò một connection.
- API khác nhau giữa các major version của cả ba thư viện — đọc docs đúng version đã cài, đừng copy snippet từ blog.

## Hiệu năng

- Đừng set text/property mỗi frame khi giá trị không đổi; so sánh trước khi ghi.
- Ẩn menu đã đóng bằng `Visible = false` (hoặc `Enabled = false` trên `ScreenGui`) thay vì destroy/tạo lại liên tục.
- Nhiều `UIGradient`/`CanvasGroup`/`UIStroke` trên UI động đều tốn frame time — kiểm bằng MicroProfiler trước khi tối ưu chỗ khác.
- `TextScaled` buộc tính lại layout chữ mỗi khi khung đổi; UI nhiều text động nên dùng `TextSize` cố định.

## Bẫy

- **UI biến mất sau khi nhân vật chết** — `ScreenGui.ResetOnSpawn` mặc định là `true` — đặt `false` cho HUD.
- **UI bị topbar/tai thỏ che, nhất là trên iPhone** — `ScreenInsets` đang là `None` (template cũ) hoặc `IgnoreGuiInset` bị bật — đặt `ScreenInsets = Enum.ScreenInsets.CoreUISafeInsets` và `IgnoreGuiInset = false`.
- **Nút bấm trên mobile không ăn dù trên PC chạy tốt** — handler gắn vào `MouseButton1Click` — chuyển sang `Activated`.
- **Mở menu bằng tay cầm thì D-pad không điều hướng được** — chưa set `GuiService.SelectedObject` và các item thiếu `Selectable` — set selected khi mở, khai báo `SelectionGroup` + `NextSelection*`.
- **Layout đúng trên PC, vỡ trên phone** — kích thước và vị trí viết bằng `Offset` tuyệt đối — chuyển sang `Scale`, giữ `Offset` cho padding/icon.
- **Set `Size` cho item mà không có tác dụng** — `UIListLayout.HorizontalFlex`/`VerticalFlex` khác `None` đang ghi đè trục đó — bỏ flex, hoặc chấp nhận và điều khiển bằng `UIFlexItem`/`GrowRatio`.
- **Tween `Position` chạy được một frame rồi bật về** — phần tử nằm trong `UIListLayout`/`UIGridLayout`, layout ghi lại mỗi pass — tween `UIScale`/`CanvasGroup`, hoặc bọc trong frame không do layout quản lý.
- **`ScrollingFrame` không scroll tới cuối danh sách** — `CanvasSize` cũ còn set trong khi `AutomaticCanvasSize` đang bật — set `CanvasSize = UDim2.new()` và `AutomaticCanvasSize = Enum.AutomaticSize.Y`.
- **Đọc `AbsoluteSize` ngay sau `Parent` ra 0** — layout chưa chạy — đợi `Heartbeat` hoặc `AbsoluteSize` changed.
- **Chữ trong RichText hiển thị sai, có chỗ mất chữ** — text người chơi chứa `<` chưa escape — escape `<`, `>`, `&` trước khi ghép chuỗi.
- **Panel mờ dần xong thì chữ nhoè và FPS giảm** — `CanvasGroup` render subtree ra texture, scale càng lớn càng nhoè và tốn memory — chỉ dùng cho panel tạm, gỡ `CanvasGroup` sau khi hiệu ứng kết thúc.
- **Kéo item trong danh sách thì nó giật về chỗ cũ** — `UIDragDetector` nằm trong vùng do layout quản lý — kéo ở container không layout, hoặc `DragStyle = Scriptable`.
- **`SurfaceGui` không hiện** — thiếu `Adornee` hoặc đặt sai `Face` — trỏ `Adornee` vào part và kiểm tra `Face`.
- **Billboard biến mất khi player đi xa** — `MaxDistance` chặn, hoặc part adornee bị stream ra ngoài — tăng `MaxDistance`/tắt streaming cho part đó, hoặc chuyển sang UI màn hình khi ở xa.
- **Đổi theme không có tác dụng** — `StyleRule` đang set giá trị cứng thay vì `$Token`, hoặc `StyleLink` không nằm trong nhánh chứa UI — dùng token và đặt `StyleLink` ở gốc `ScreenGui`.
- **Style theo `@ViewportDisplaySize` không đổi khi resize** — selector viết sai tên query (`@ViewportDisplaySizeSmall` là đúng, `@Small` thì không) — dùng đúng tên built-in.
