# Vật cong (karambit, hawkbill, sickle, cung, móc câu…)

Khối hộp thẳng không làm được đường cong; cần **dải phân đoạn** (Part) hoặc **lưới tam giác** (MeshPart). Dùng `templates/KnifeKit.lua` (dao cong) và `GeoKit.lua` (hình học thô).

## Chọn đường nào
| | Parts (phân đoạn) | MeshPart (EditableMesh/lưới) |
|---|---|---|
| Bề mặt | thấy bậc nhẹ, dung sai 0.012 stud | mượt |
| Rủi ro | gần như không | vị trí đặt MeshPart cần xác nhận trong Studio (VERIFY) |
| Chọn khi | mặc định, cần chắc chắn | cần đẹp và đã thử được trong Studio |

## Hình học karambit (đã kiểm bằng số + ảnh)
- Lưỡi = cung tròn tâm `C=(HandleLen, −hw+Rs)`; sống ở cung ngoài, mép sắc ở cung trong (phía lõm). Quét `Sweep°` (mặc định 100°) → mũi chỉ gần ngang rồi hơi xuống. Rộng giảm dần theo `w(φ)=BladeW(1−(φ/θ)^Taper)`.
- Khung vật: Y = đuôi→đầu cán, −Z = hướng lưỡi cong ra, X = bề dày. Vòng ring nằm mặt phẳng YZ ở đuôi.
- Kiểm tra tự động (`tests/run_knife_test.sh`): phủ 98%+ vùng lưỡi giải tích, tràn ra ngoài < 14% → giảm bằng chia mịn, mũi đúng `(0,cosθ,−sinθ)`, mép lõm, lưới kín/manifold/thể tích dương.
- `scripts/render_geom.py` dựng ảnh side/front/top/iso để NHÌN trước khi giao.

## Quy trình cho vật cong mới
1. Viết hình dạng 2D (mặt cắt cạnh) bằng cung/đường bậc hai, ghi vector mũi và phía lõm trong Spatial Brief.
2. Chia đoạn đến khi lệch ≤ dung sai (`segmentsFor`).
3. Ghép bằng `AssemblyGuard.Build` (socket có chủ đích) — không rời.
4. Chạy test số + `sim_assembly.py` + render ảnh. Không giao khi chưa xem ảnh.

## Hình cong/tròn kiểu pixel-voxel (không phải dao)
Vòm cầu vồng, vòng kẹp, đĩa, khối mây, N vật quanh trục: dùng `templates/PatternKit.lua` (`VoxelArch`, `RadialSlots`, `VoxelBlob`) và `templates/PixelShapes.lua` (`Annulus`, `Disc`, `PixelArt`). Không bao giờ thay vòm bằng hộp phẳng hay xếp "vòng tròn" thành một hàng. Kiểm bằng `sandbox.py run --render` rồi xem ảnh (xem `sandbox-loop.md`).
