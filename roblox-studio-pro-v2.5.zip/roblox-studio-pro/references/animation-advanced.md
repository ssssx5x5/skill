# Animation nâng cao: Humanoid R15/R6, rig Part, nhiều lớp, IK

> Dùng `templates/AnimKit.lua` (engine), `AnimClips.lua` (20 clip có test), `PoseKit.lua` (cũ, đơn giản). Không cần publish animation; không dùng `KeyframeSequence` runtime (không chạy — xem vfx-animation.md).

## 1. Một clip chạy trên mọi rig

Pose viết bằng độ, **trong khung part cha** (X phải, Y lên, Z lùi). Ghi vào khớp bằng `Transform = C0⁻¹ · Δ · C0`:
- R15 (`Motor6D` hoặc `AnimationConstraint`): `C0` ≈ identity → Δ ghi thẳng.
- R6: `C0` đã xoay 90° → công thức tự bù; **cùng clip** chạy đúng.
- Rig Part tuỳ ý (súng, robot, rồng): khớp là `Motor6D` bất kỳ; dùng tên khớp thật.

`AnimKit.Rig(model)` tự nhận `R15 / R6 / Generic`. `AnimKit.Player(rig)` bind `PreSimulation` (Transform chỉ ghi được ở đây).

## 2. Humanoid, R6, R15, Part — khác nhau ở đâu

| Rig | Khớp có sẵn | Lưu ý |
|---|---|---|
| R15 | 15 khớp (Root, Waist, Neck, vai/khuỷu/cổ tay, hông/gối/cổ chân) | Đủ cho mọi clip. Humanoid `Animate` mặc định vẫn chạy: lớp của bạn ghi sau nên đè; nếu đánh nhau → `track:AdjustWeight(0)` các track mặc định |
| R6 | 6 khớp (RootJoint, Neck, 2 vai, 2 hông) | Không khuỷu/gối/Waist. AnimKit **gấp** tương đương (gối→hông 0.35, khuỷu→vai 0.25, Waist→Root). Chuyển động R6 luôn kém mượt hơn R15 — nói rõ với người dùng |
| Humanoid bất kỳ | Đọc khớp thật | Humanoid vẫn điều khiển di chuyển/trạng thái; AnimKit chỉ ghi Transform |
| Part rig (không Humanoid) | Tạo Motor6D | `AnimKit.Rigify(model)` đổi weld → Motor6D (pose hiện tại = pose nghỉ). Sau đó clip dùng tên khớp = tên part con. Ví dụ súng: `Rigify` rồi animate `bolt`, `magazine`, `boltKnob` |

## 3. Chiều trục (đã kiểm bằng toán, chưa bằng mắt trong Studio)

Vai/hông `x+` = ra trước · `z+` = tay phải dang · Khuỷu `x+` = gập · Gối `x−` = gập · Waist/Neck `x−` = cúi · `y+` = quay trái · Root `x` giảm tới −360 = lộn tới. Nếu lần đầu thấy một chi chuyển ngược → đảo dấu **trục đó trong clip**, báo lại để cập nhật bảng này.

## 4. Nhiều lớp, mask, additive, mirror

```lua
local rig = AnimKit.Rig(character)
local pl = AnimKit.Player(rig)
pl:Play(Clips.Run, { Layer = 1 })                                        -- chân/thân chạy
pl:Play(Clips.RifleHold, { Layer = 2, Mask = AnimKit.Masks.Upper })      -- thân trên giữ súng (đè lên Run)
pl:Play(Clips.RifleRecoil, { Layer = 3, Additive = true })               -- giật súng cộng thêm
pl:Play(Clips.SniperBolt, { Layer = 4, Mask = AnimKit.Masks.RightArm, OnEvent = function(n) Snd.Play("bolt") end })
pl:Play(Clips.SwordCombo1, { Mirror = true })                            -- đánh tay trái (đổi L/R, đảo yaw/roll)
```
Sự kiện clip (`Hit`, `Impact`, `Land`, `BoltUp`...) gọi `OnEvent` → nối với VFX/Sound đúng nhịp, không `task.wait`.
`AnimKit.HitStop(pl, 0.08)` đóng băng; `pl.TimeScale = 0.3` slow-mo.

## 5. IK tay/chân (R15)

`AnimKit.AimLimb(rig, "R", "Arm", worldTarget, worldPole)` đặt cổ tay tới `worldTarget` (khuỷu hướng về `worldPole`). Gọi mỗi `PreSimulation` **sau** Player. Dùng cho: tay trái bám ốp súng/ống ngắm, tay chạm tường/tay nắm, chân bám bậc thang. Giải 2 xương = định lý cos (`SolveTwoBone`, có test: độ dài xương giữ nguyên, tới đích khi với tới được). R6 không có khuỷu/gối → không IK, dùng clip.
Suy dẫn đưa Δ khuỷu về khung xương 1: `Δ = Q0⁻¹ · dS⁻¹ · dE_parent · dS · Q0` với `Q0` là khung nghỉ của part xương 1.

## 6. Làm animation "cực khó"

1. **Breakdown theo pha** (chuẩn bị → hành động → dư chấn) và **ghi bảng thời gian** trước khi viết key (xem `subject-breakdown.md`).
2. **Nguyên tắc 12**: anticipation (lùi trước khi chém), overshoot (`e="back"`), snap (`e="snap"` cho va chạm), follow-through (`AnimKit.Spring` cho tóc/áo/anten/đuôi), arcs (không đi đường thẳng), weight (Root `p[2]` hạ khi đáp).
3. **Root**: lộn/xoay quanh `Root`; nâng/hạ bằng `p[2]` (stud) — Root cho phép lớn, chi ≤ 0.8 stud.
4. **Loop** phải khép kín (pose cuối = đầu) — `ValidateClip` bắt.
5. **Kiểm bằng số**: `bash tests/run_anim_test.sh` (mọi clip hợp lệ). Trong Studio: sample `Transform` 90 lần → số giá trị phân biệt ≫ 1 (đã có công thức ở assets.md).
6. **Kết hợp VFX/âm**: chèn `Events` rồi `OnEvent` gọi `VFX.Impact`, `VFX.Shake`, `Snd.Play`.

## 7. Giới hạn thật

- Nội suy Euler từng trục (như đường cong Blender): tốt cho clip tác giả viết; xoay lớn nhiều trục cùng lúc có thể "xoắn" — chia thành nhiều key.
- Chưa có foot-planting/ground IK tự động, ragdoll blend, hay retarget animation published. Animation published của Roblox vẫn dùng được song song (AnimationTrack) — AnimKit ghi sau nên đè khớp được chọn.
- Chưa chạy trong Studio: các clip/IK đúng toán nhưng **chiều trục cần xác nhận bằng mắt một lần**.
