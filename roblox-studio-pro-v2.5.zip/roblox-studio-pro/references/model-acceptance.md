# Checklist nghiệm thu model

## Brief & thiết kế
- [ ] Mục đích, phong cách, tỉ lệ và hướng trước được xác định.
- [ ] Giả định và chi tiết chưa rõ được ghi lại.
- [ ] Silhouette nhận diện được từ góc chính và ở kích thước nhỏ.

## Hình học
- [ ] Kích thước tổng thể và tỷ lệ phù hợp brief.
- [ ] Không có phần rời/lơ lửng ngoài ý muốn.
- [ ] Các phần cần tiếp xúc không có khe hở nhìn thấy.
- [ ] Không có mặt hở/pháp tuyến sai ảnh hưởng kết quả.
- [ ] Chi tiết mỏng có độ dày phù hợp.
- [ ] Pivot và phần chuyển động được bố trí đúng.
- [ ] Độ phức tạp phù hợp ngân sách hiệu năng.

## Hình ảnh & vật liệu
- [ ] Đã xem trước 3/4.
- [ ] Đã xem sau 3/4.
- [ ] Đã kiểm tra các mặt bên và vùng nối cần thiết.
- [ ] Texture/UV không kéo giãn, vỡ hoặc lệch.
- [ ] Vật liệu hiển thị đúng dưới ánh sáng dự kiến.
- [ ] Lỗi phát hiện đã được sửa và ảnh chụp lại.

## Tích hợp
- [ ] Đúng hướng, scale và pivot sau import.
- [ ] Không clipping, biến mất mặt hoặc lỗi vật liệu trong ứng dụng đích.
- [ ] Nếu chưa kiểm tra được, ghi “chưa kiểm chứng”.

## Bàn giao
- [ ] File và vị trí được ghi rõ.
- [ ] Báo cáo liệt kê kiểm tra đã làm và lỗi còn lại.
- [ ] Không tuyên bố đạt/hoàn hảo khi thiếu bằng chứng.
