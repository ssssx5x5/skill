# Kiểm chứng wiring: bắt lỗi "im lặng"

## Mục lục
1. Vì sao compiler không đủ
2. Các họ lỗi im lặng (và cách bắt từng họ)
3. Quy trình bắt buộc: Hợp đồng -> Viết -> Quét tĩnh -> Tự kiểm lúc chạy
4. Module `Wiring` dùng lúc chạy
5. Dùng `scripts/wiring_check.py`
6. Kiểm tra theo từng domain
7. Cách báo cáo kết quả kiểm chứng

## 1. Vì sao compiler không đủ

`luau-compile` và `luau-analyze` chỉ chứng minh code **hợp lệ về cú pháp và kiểu**. Chúng không biết ý định của bạn. Những lỗi dưới đây đều biên dịch sạch và chạy không báo lỗi, nhưng tính năng không hoạt động:

- `Config.HaloSped` (gõ sai) đọc ra `nil`, code rơi vào giá trị mặc định mà không ai biết.
- Một key trong Config có tên đúng nhưng **không có handler nào đọc**: người dùng chỉnh số, không có gì thay đổi.
- Tên joint trong danh sách khác tên trong bảng driver (`WingR` vs `Wing_R`): đoạn `if motor then` bỏ qua trong im lặng.
- Bảng SFX thiếu key hoặc id còn là placeholder: `Sound:Play()` không phát gì và không lỗi.

Nguyên nhân chung: **thông tin chạy qua tên dạng chuỗi** (key, tên Instance, tên remote, tên marker), nơi mà ngôn ngữ không kiểm tra. Nên kiểm chứng phải nhắm vào các tên đó.

## 2. Các họ lỗi im lặng

| # | Họ lỗi | Triệu chứng | Cách bắt |
|---|---|---|---|
| 1 | Key được dùng nhưng không tồn tại (gõ sai, đổi tên) | Giá trị `nil`, dùng mặc định, hoặc bỏ qua | `wiring_check.py --table`, bảng `strict` lúc chạy |
| 2 | Key định nghĩa nhưng không ai dùng (config chết) | Chỉnh không có tác dụng | `wiring_check.py` báo WARN; theo dõi "key đã đọc" lúc chạy |
| 3 | Hai danh sách phải khớp nhưng lệch (joint vs driver, state vs handler) | Một phần cơ thể/hành vi không chạy | `wiring_check.py --compare`, `Wiring.sameSets` |
| 4 | Bảng SFX/asset thiếu key hoặc còn placeholder | Im lặng, không hình, không tiếng | `Wiring.checkAssets` lúc khởi động; `safePlay` cảnh báo |
| 5 | Tên Remote lệch giữa server và client | Sự kiện không bao giờ tới; chỉ có "Infinite yield" khó thấy | Gom tên Remote vào một bảng dùng chung; tạo Remote bằng code từ bảng đó |
| 6 | Tên marker animation lệch | Đòn đánh không gây sát thương/hiệu ứng | `--markers`, watchdog lúc chạy (mục 4) |
| 7 | Tag/Attribute gõ sai | `GetTagged` trả bảng rỗng | `Wiring.checkTagged` |
| 8 | Script đặt sai nơi hoặc sai loại (LocalScript trong Workspace) | Script không chạy, không báo gì | In dòng khởi động; xem checklist vị trí ở `SKILL.md` |
| 9 | Thứ tự khởi tạo (client chạy trước khi server tạo xong) | `nil` lúc đầu, rồi ổn | `WaitForChild` có timeout + cảnh báo |
| 10 | `pcall` nuốt lỗi | Tính năng chết, Output trống | Không `pcall` trừ khi ghi log kết quả `false` |
| 11 | Instance bị thay (respawn, clone) mà vẫn giữ tham chiếu cũ | Hiệu ứng áp lên đối tượng đã hủy | Kiểm tra `instance.Parent` hoặc kết nối lại khi `CharacterAdded` |
| 12 | Giá trị placeholder còn nguyên (`rbxassetid://0`, id rỗng) | Không phát/không hiện | `Wiring.checkAssets` |

## 3. Quy trình bắt buộc

1. **Hợp đồng trước.** Trước khi viết code, liệt kê *mọi tên* đi qua ranh giới giữa các phần: key Config, tên SFX, tên joint, tên Remote, tên marker, tên state, tag, attribute. Đặt chúng ở một nơi (một bảng `Names`/`Contract` hoặc phần đầu file) và code chỉ tham chiếu qua bảng đó. Hợp đồng càng nhỏ và tập trung, lỗi lệch tên càng ít.
2. **Viết code** dùng hợp đồng thay vì chuỗi rải rác (`Names.Remote.Jumpscare`, không phải `"Jumpscare"` ở ba nơi).
3. **Quét tĩnh**: chạy `scripts/wiring_check.py` trên mọi file với các bảng liên quan. Sửa mọi ERROR, đọc từng WARN và quyết định (xóa key thừa hoặc nối handler còn thiếu).
4. **Tự kiểm lúc chạy**: thêm `Wiring` self-test chạy khi khởi động (ít nhất trong Studio). Cuối self-test in **một dòng xác nhận** (`[Wiring] OK: N checks`). Dòng đó vắng mặt hoặc có `warn` là dấu hiệu rõ ràng, thay vì im lặng.
5. **Báo cáo**: nói với người dùng đã quét/kiểm gì, kết quả ra sao, và dòng log nào nên thấy khi bấm Play.

Không được tuyên bố "đã kiểm tra" nếu chưa chạy công cụ. Nếu sandbox không có `luau-analyze`, nói rõ "chưa biên dịch"; quét wiring chạy được bằng Python nên vẫn nên chạy.

## 4. Module `Wiring` dùng lúc chạy

Đặt ở `ReplicatedStorage` (dùng được cả server và client).

```lua
--!strict
local RunService = game:GetService("RunService")
local CollectionService = game:GetService("CollectionService")

local Wiring = {}
local problems: { string } = {}
local checks = 0
local warnedOnce: { [string]: boolean } = {}

local function fail(msg: string)
	table.insert(problems, msg)
end

-- Bảng "nghiêm ngặt": đọc key không tồn tại thì báo lỗi ngay thay vì trả nil.
-- Dùng rawget(tbl, key) khi muốn kiểm tra key tùy chọn.
function Wiring.strict(name: string, tbl: any): any
	return setmetatable(tbl, {
		__index = function(_, key)
			error(("[Wiring] %s.%s không tồn tại (gõ sai hoặc thiếu định nghĩa?)"):format(name, tostring(key)), 2)
		end,
	})
end

-- Bảng bắt buộc phải có đủ các key này và giá trị hợp lệ.
function Wiring.requireKeys(name: string, tbl: { [any]: any }, keys: { string })
	checks += 1
	for _, k in keys do
		if rawget(tbl, k) == nil then
			fail(("%s thiếu key '%s'"):format(name, k))
		end
	end
end

-- Hai tập tên phải trùng nhau (joint vs driver, state vs handler).
function Wiring.sameSets(nameA: string, a: { [any]: any }, nameB: string, b: { [any]: any })
	checks += 1
	local function keysOf(t: { [any]: any }): { [string]: boolean }
		local out = {}
		for k, v in t do
			out[typeof(k) == "string" and k or tostring(v)] = true -- hỗ trợ cả map lẫn list chuỗi
		end
		return out
	end
	local ka, kb = keysOf(a), keysOf(b)
	for k in ka do
		if not kb[k] then fail(("'%s' có trong %s nhưng không có trong %s"):format(k, nameA, nameB)) end
	end
	for k in kb do
		if not ka[k] then fail(("'%s' có trong %s nhưng không có trong %s"):format(k, nameB, nameA)) end
	end
end

-- Bảng asset (SFX/animation/texture): mọi id phải có và không phải placeholder.
function Wiring.checkAssets(name: string, assets: { [string]: string }, requiredKeys: { string }?)
	checks += 1
	for _, k in requiredKeys or {} do
		if assets[k] == nil then fail(("%s thiếu key bắt buộc '%s'"):format(name, k)) end
	end
	for k, id in assets do
		if id == "" or id == "rbxassetid://0" or id == "rbxassetid://" then
			fail(("%s.%s còn là placeholder (%q): sẽ im lặng khi chạy"):format(name, k, id))
		end
	end
end

-- Cây con phải có đúng các Instance (ví dụ rig phải có đủ Motor6D mà driver cần).
function Wiring.requireChildren(root: Instance, names: { string }, recursive: boolean?)
	checks += 1
	for _, n in names do
		if not root:FindFirstChild(n, recursive ~= false) then
			fail(("%s không có con tên '%s'"):format(root:GetFullName(), n))
		end
	end
end

function Wiring.checkTagged(tag: string, minCount: number?)
	checks += 1
	if #CollectionService:GetTagged(tag) < (minCount or 1) then
		fail(("Tag '%s' chưa gắn cho Instance nào (gõ sai tag?)"):format(tag))
	end
end

-- Phát âm thanh qua bảng SFX, cảnh báo một lần nếu thiếu key hoặc placeholder.
function Wiring.safeSfx(sfx: { [string]: string }, key: string): string?
	local id = sfx[key]
	if not id or id == "rbxassetid://0" or id == "" then
		local tag = "sfx:" .. key
		if not warnedOnce[tag] then
			warnedOnce[tag] = true
			warn(("[Wiring] SFX '%s' thiếu hoặc là placeholder"):format(key), debug.traceback())
		end
		return nil
	end
	return id
end

-- Watchdog marker: nếu animation kết thúc mà marker mong đợi chưa bắn thì cảnh báo.
function Wiring.expectMarker(track: AnimationTrack, markerName: string, onReached: (string?) -> ())
	local fired = false
	local c = track:GetMarkerReachedSignal(markerName):Connect(function(param)
		fired = true
		onReached(param)
	end)
	track.Stopped:Once(function()
		c:Disconnect()
		if not fired then
			warn(("[Wiring] animation '%s' kết thúc mà marker '%s' chưa bắn (sai tên? chưa thêm vào animation?)"):format(
				track.Name, markerName))
		end
	end)
end

-- Gọi một lần ở cuối self-test. Trong Studio thì dừng bằng error để không bỏ sót.
function Wiring.report(scope: string)
	if #problems == 0 then
		print(("[Wiring] OK (%s): %d kiểm tra"):format(scope, checks))
		return true
	end
	local msg = ("[Wiring] %s: %d vấn đề:\n - %s"):format(scope, #problems, table.concat(problems, "\n - "))
	if RunService:IsStudio() then error(msg, 0) else warn(msg) end
	return false
end

return Wiring
```

Cách dùng ở đầu script khởi động:

```lua
local Wiring = require(game.ReplicatedStorage.Wiring)

local Config = Wiring.strict("Config", { EyeCount = 7, HaloSpeed = 2 })
Wiring.checkAssets("SFX", SFX, { "Roar", "Footstep", "Snap" })
Wiring.sameSets("JOINTS", JOINTS, "DRIVERS", DRIVERS)
Wiring.requireChildren(monsterModel, JOINTS)
Wiring.report("Angel") -- in "[Wiring] OK (Angel): 4 kiểm tra" hoặc dừng với danh sách lỗi
```

Lưu ý khi dùng bảng `strict`: đọc key không có sẽ **ném lỗi**, đây là mục đích. Muốn kiểm tra tùy chọn thì dùng `rawget(tbl, "Key")`. `Wiring.sameSets` coi cả map (key = tên) lẫn list chuỗi (giá trị = tên). Placeholder có chủ đích trong quá trình phát triển sẽ làm `checkAssets` báo: hãy ghi rõ cho người dùng để họ thay id thật, hoặc cho tạm `warn` thay vì `error` bằng cách chạy ngoài Studio.

## 5. Dùng `scripts/wiring_check.py`

Chạy từ sandbox hoặc máy người dùng, không cần Roblox:

```bash
python scripts/wiring_check.py src/ \
  --table Config \
  --bind SFX=playSfx --bind SFX=Sfx.play:2 \
  --compare JOINTS DRIVERS \
  --markers
```

- `--table NAME`: mọi `NAME.Key` và `NAME["Key"]` phải có trong bảng; key không ai dùng bị báo WARN.
- `--bind NAME=FUNC[:N]`: đối số chuỗi thứ N của `FUNC("Key")` coi như key của `NAME`. Dùng cho `playSfx("Roar")`, `Sfx.play(self, "Roar")` (N = 2).
- `--compare A B`: hai bảng hoặc danh sách phải có cùng tập tên. Mỗi bên có phần thừa đều bị báo ERROR kèm gợi ý "ý bạn là ...".
- `--markers`: liệt kê marker đang được lắng nghe để đối chiếu với Animation Editor.

Mã thoát 1 nếu có ERROR. Luôn in dòng `[DONE ]` ở cuối. Script bỏ qua comment và hiểu chuỗi nhiều dòng. Giới hạn: nó đọc văn bản, không hiểu key động (`Config[name]`). Với trường hợp đó, dùng bảng `strict` lúc chạy.

## 6. Kiểm tra theo từng domain

- **Quái/AI**: mỗi state có handler; mỗi animation có marker mong đợi; mỗi âm thanh có key; mỗi joint driver có Motor6D tương ứng trong rig vừa dựng.
- **VFX/SFX**: bảng id có đủ key và không còn placeholder; emitter có `Texture` hợp lệ; Remote báo "chơi hiệu ứng" có người nhận ở client.
- **UI/Overlay**: ScreenGui đã vào `PlayerGui`; ZIndex/DisplayOrder không bị lớp khác che; mỗi hàm `setStrength` được nối với nguồn dữ liệu (khoảng cách quái, sát thương); nếu không, overlay dựng đúng nhưng không bao giờ bật.
- **Map/Terrain**: số đo theo `environment.md` mục 2; tag `Zone` có Instance; số part/MeshPart trong ngân sách.
- **Mây/Thời tiết**: mọi lệnh (`/storm`, `/rain`...) có handler; mọi preset thời tiết có đủ trường mà hệ thống đọc; mọi loại mây khai báo đều được sinh ra ít nhất một lần (đếm trong self-test).
- **Model bằng code**: kích thước và vị trí theo `procedural-modeling.md` mục 8; mọi Part có tên khớp tên script tìm.

## 7. Cách báo cáo kết quả kiểm chứng

Một đoạn ngắn, cụ thể, gồm: (1) đã chạy công cụ nào và kết quả (ví dụ "wiring_check: 3 bảng, 0 lỗi, 1 cảnh báo đã xử lý"), (2) self-test nào đã thêm và dòng log cần thấy, (3) phần nào chưa kiểm chứng được và vì sao (không có Studio để chạy, không nghe/nhìn được kết quả), (4) việc cần người dùng làm (thay id placeholder, bấm Play và xem Output).

Không dùng cụm "đã kiểm tra kỹ" khi thực tế chỉ đọc lại bằng mắt. Báo đúng mức độ đã làm.

## 8. Wiring for VFX recipes, cutscenes and generalization (added in v2)

New feature types add new names that cross boundaries. Put each in a shared table and check it:

| Names | Shared table | Check |
|---|---|---|
| VFX recipe names (server trigger -> client `Kit.play`) | `VfxNames` | `wiring_check.py src/ --table VfxNames` |
| Cutscene names (server remote -> `CutsceneLibrary`) | `CutsceneNames` | `wiring_check.py src/ --table CutsceneNames` |
| SFX keys | `SFX` | `--table SFX --bind SFX=playSfx` (or `Kit.sfx`) |
| Camera Parts (`Shot01`...) and their attributes | list in Config | runtime: `warn` when a Part or attribute is missing |
| Joint names for code-authored clips | `JOINTS` | `--compare JOINTS DRIVERS`, `Wiring.requireChildren` |

Generalization check (ask before delivering): is every name in this code about the subject the user asked
for? A leftover `Roar`, `Monster` or `Jumpscare` in a plant or explosion request means the example was
copied instead of the subject being analyzed (see `subject-breakdown.md` section 6).

Things the tools cannot see, so say so in the report: whether it looks good, whether the sound is right,
frame rate on a phone, whether built-in particle textures render. Give the user the exact thing to look at.

