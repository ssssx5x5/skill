# VFX mạnh nhất: ghép Part + hiệu ứng Roblox + texture + asset Toolbox + GUI

Hiệu ứng "rẻ tiền" thường chỉ có một lớp. Mạnh = **đủ 6 lớp, đúng nhịp**. Dùng `templates/VFXKit.lua`.

## Sáu lớp (thiếu lớp nào thì thêm lớp đó)
| Lớp | Công cụ | Hàm VFXKit |
|---|---|---|
| 1. Hình khối (Part Neon, sóng, mảnh vỡ) | Part, Neon, tween Size/Transparency | `Ball`, `Ring`, `Shards`, `Slash`, `Lightning` |
| 2. Hạt & chùm (ParticleEmitter, Beam, Trail) | Emitter có texture alpha | `Emitter`, `Burst`, `Beam`, `Tracer`, `LaserBeam` |
| 3. Ánh sáng | PointLight/SpotLight, Bloom | `LightFlash`, `BloomPulse` |
| 4. Màn hình (GUI/hậu kỳ) | ScreenGui, ColorCorrection, DepthOfField | `ScreenFlash`, `ColorGrade`, `DepthFocus`, `Shake` |
| 5. Cảm giác va chạm | hit-stop, rung camera | `HitStop`, `Shake` |
| 6. Âm thanh | SoundKit nhiều lớp | xem `audio-sfx.md` |

Combo sẵn: `Explosion`, `Impact`, `MuzzleFlash`, `BulletImpact`, `Charge`, `Teleport`, `Outline`.

## Texture
Sinh bằng `scripts/gen_vfx_textures.py` (glow, khói, tia, vòng, vết chém, flipbook), **upload thủ công** lên Creator Hub để có id thật, rồi `VFX.SetTextures({...})` / `VFX.UseFlipbook(...)`. Chưa có id → VFXKit rơi về texture mặc định, không crash. Nguyên tắc: texture trắng+alpha, màu đặt bằng `ColorSequence` (tint được, tái dùng được).

## Asset từ Toolbox / Creator Store
`VFX.PlayAsset(template, pos, scale, life)`: **xoá mọi Script/LocalScript/ModuleScript** trong asset ngoài (nguy cơ backdoor), neo, phát emitter (attribute `EmitCount`), tự dọn. Thẩm định trước khi dùng:
1. Tìm bằng công cụ `search_asset` (Studio MCP) hoặc Creator Store; xem số lượt dùng/đánh giá, tác giả.
2. Chèn thử vào workspace trống, liệt kê descendants: bất kỳ `Script` lạ, `require(<số>)`, `HttpService` → loại.
3. Đo: số emitter, `Rate`, `Lifetime` → ngân sách hạt.
4. Hiệu ứng nhập về lưu trong ReplicatedStorage làm template, **không** để chạy tại chỗ.
Không có id thật thì dùng lớp tự dựng; không bịa id.

## GUI ghép hiệu ứng
Nháy trắng/đỏ (`ScreenFlash`), vignette, speed lines, crosshair khi bắn (`UIKit`): xem `ui-kit.md`. Mọi lớp GUI `Active=false` để không chặn input.

## Ngân sách & chất lượng
`VFX.Quality` (0.3–1) nhân số hạt/mảnh; `VFX.AutoQuality()` tự hạ theo FPS. Trần tham khảo: ≤ 300 hạt sống/hiệu ứng, ≤ 40 Part tạm, dọn bằng Debris.

## Nhịp (mẫu)
Chuẩn bị (0.2–0.6s: `Charge`, ánh sáng hút vào) → va chạm (0–0.1s: flash + hit-stop 0.05s + rung) → bùng (0.1–0.5s: sóng, hạt, mảnh) → dư chấn (0.5–2s: khói, ánh tắt dần, âm đuôi).
