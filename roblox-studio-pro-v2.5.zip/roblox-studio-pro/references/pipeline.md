# Pipeline công cụ và đường phát hành

> Khi nào dùng: khi dựng repo cho một experience, cấu hình VS Code/Cursor, thêm package, sửa lỗi sourcemap/require, viết test, hoặc tự động hoá build và publish lên Roblox.

## Chọn mô hình đồng bộ
| Nhu cầu | Dùng |
| --- | --- |
| Chỉ sửa script bằng editor ngoài, Studio vẫn là source of truth, có Team Create | **Studio Script Sync** (chuột phải folder → **Sync to…**) |
| Toàn bộ project nằm trên đĩa, file system là source of truth, CI build, có package | **Rojo** (`rojo serve` + plugin Studio) |

Script Sync chỉ đồng bộ `Script`, `LocalScript`, `ModuleScript`, `Folder` — tối đa **10.000 script** mỗi root, tối đa **128 root**. Không sync script có attribute/tag: chúng không được ghi ra đĩa nên mất khi kéo từ file lên. Cả hai cách nên đi kèm extension **Luau Language Server** và plugin Studio **Luau Language Server Companion** (plugin gửi cây DataModel cho LSP, nhờ đó `require` và đường dẫn instance mới type-check được).

## Rojo
```json
{
  "name": "my-game",
  "tree": {
    "$className": "DataModel",
    "ReplicatedStorage": { "Shared": { "$path": "src/shared" }, "Packages": { "$path": "Packages" } },
    "ServerScriptService": { "Server": { "$path": "src/server" }, "ServerPackages": { "$path": "ServerPackages" } },
    "StarterPlayer": { "StarterPlayerScripts": { "Client": { "$path": "src/client" } } },
    "Workspace": { "$properties": { "StreamingEnabled": true } }
  }
}
```

| File | Kết quả |
| --- | --- |
| `Foo.luau` / `Foo.server.luau` / `Foo.client.luau` | `ModuleScript` / `Script` / `LocalScript` |
| thư mục có `init.luau`, `init.server.luau`, `init.client.luau` | script đó, con nằm bên trong |
| `*.meta.json` | property/attribute |
| `*.model.json`, `.rbxm`, `.rbxmx` | instance dựng sẵn |
| `*.json`, `*.toml`, `*.txt` | `ModuleScript` trả data, hoặc `StringValue` |

Lệnh: `rojo serve`, `rojo build -o game.rbxl`, `rojo sourcemap default.project.json -o sourcemap.json`, `rojo upload`. Map và art để trong Studio (hoặc `.rbxm`), code để trong Rojo — cây quản lý một phần là hợp lệ.

## Rokit — ghim toolchain
```toml
# rokit.toml (commit file này; chạy `rokit install`)
[tools]
rojo = "rojo-rbx/rojo@7.7.0"
wally = "UpliftGames/wally@0.3.2"
lune = "lune-org/lune@0.10.5"
stylua = "JohnnyMorganz/StyLua@2.5.2"
selene = "Kampfkarren/selene@0.31.0"
luau-lsp = "JohnnyMorganz/luau-lsp@1.70.1"
darklua = "seaofvoices/darklua@0.19.0"
```

Cài: `curl -sSf https://raw.githubusercontent.com/rojo-rbx/rokit/main/scripts/install.sh | bash` (Windows: `install.ps1`). Thêm tool: `rokit add owner/repo`. Aftman và Foreman là tiền thân, không cần cho repo mới.

## Package: Wally và pesde
```toml
# wally.toml
[dependencies]
React = "jsdotlua/react@17.2.1"
ReactRoblox = "jsdotlua/react-roblox@17.2.1"
[server-dependencies]
ProfileStore = "lm-loleris/profilestore@1.0.3"
```

`wally install` đổ vào `Packages/`, riêng `realm = "server"` vào `ServerPackages/`. Wally bọc package trong thunk nên **mất type**: chạy `wally-package-types --sourcemap sourcemap.json Packages/` sau mỗi lần install. Tên/version lấy đúng từ trang package trên wally.run, không đoán. **pesde** (`pesde.toml`) là manager mới cho Roblox/Lune/Luau, phụ thuộc ngược được vào package Wally. Commit `wally.lock`/`pesde.lock`; không commit `Packages/`.

## Chất lượng code
- **luau-lsp**: `luau-lsp analyze --definitions=@roblox=globalTypes.d.luau --sourcemap=sourcemap.json --base-luaurc=.luaurc src/` (tải `globalTypes.d.luau` từ `JohnnyMorganz/luau-lsp`, đường dẫn `scripts/globalTypes.d.luau`). Bật `luau-lsp.fflags.enableNewSolver` để khớp solver của Studio, nếu không sẽ có type đúng trong Studio mà lỗi trong editor.
- **StyLua** — formatter; `stylua.toml`: `indent_type = "Tabs"`, `column_width = 120`; CI dùng `stylua --check src`.
- **selene** — linter; `selene.toml`: `std = "roblox"`, file std sinh/tải lại bằng `selene generate-roblox-std`.
- **darklua** — biến đổi code: đổi string require sang relative path, bundle nhiều module, strip code debug. Chạy trước publish, không chạy lúc dev vì làm lệch sourcemap.
- **`.luaurc`**: `{ "languageMode": "strict", "aliases": { "Shared": "src/shared", "Packages": "Packages" } }`. Roblox resolve string require theo DataModel (`./`, `../`, `@self`, `@game`); alias trong `.luaurc` chỉ luau-lsp và darklua hiểu, runtime không hiểu.

## Lune, roblox-ts, git
**Lune** là runtime Luau độc lập: bước build, thao tác place file (`@lune/roblox` đọc/ghi `.rbxl`/`.rbxm`), pipeline asset, chạy unit test thuần Luau, gọi Open Cloud qua `@lune/net`. Chạy `lune run scripts/build`. Không có engine nên module cần `game`, `Instance`, `task` đều không chạy được.
**roblox-ts**: repo có `tsconfig.json` và `package.json` chứa `roblox-ts` + `@rbxts/types` thì viết TypeScript — `npx rbxtsc -w` biên dịch `src/*.ts` sang `out/*.luau`, Rojo sync `out/`; dùng `@rbxts/services` thay `game:GetService`. Không sửa tay Luau sinh ra.
**`.gitignore`**: `*.rbxl.lock`, `*.rbxlx.lock`, `Packages/`, `ServerPackages/`, `sourcemap.json`, thư mục build. Commit `rokit.toml`, `wally.toml`, `wally.lock`, `selene.toml`, `stylua.toml`, `.luaurc`, `default.project.json`.

## GitHub Actions CI
```yaml
name: CI
on: { push: { branches: [main] }, pull_request: }
jobs:
  check:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Install tools and packages
        run: |
          curl -sSf https://raw.githubusercontent.com/rojo-rbx/rokit/main/scripts/install.sh | bash
          echo "$HOME/.rokit/bin" >> "$GITHUB_PATH"
          "$HOME/.rokit/bin/rokit" authenticate github --token "$GITHUB_PAT"
          "$HOME/.rokit/bin/rokit" install --no-trust-check
          wally install
          wally-package-types --sourcemap sourcemap.json Packages/
          rojo sourcemap default.project.json -o sourcemap.json
        env: { GITHUB_PAT: "${{ secrets.GITHUB_TOKEN }}" }
      - run: stylua --check src
      - run: selene src
      - name: Type check
        run: |
          curl -fsSL -o globalTypes.d.luau \
            https://raw.githubusercontent.com/JohnnyMorganz/luau-lsp/main/scripts/globalTypes.d.luau
          luau-lsp analyze --definitions=@roblox=globalTypes.d.luau --sourcemap=sourcemap.json \
            --base-luaurc=.luaurc --ignore="Packages/**" src
      - run: rojo build default.project.json -o build.rbxl
      - uses: actions/upload-artifact@v4
        with: { name: place, path: build.rbxl }
```

`rokit authenticate github` tránh bị GitHub API rate-limit khi `rokit install` tải nhiều binary. Cache `~/.rokit` và `Packages/` bằng `actions/cache` với key theo `rokit.toml`/`wally.lock`.

## Publish bằng Open Cloud
Tạo API key (Creator Dashboard → Open Cloud → API Keys) với quyền **universe-places** (write) trên universe đích, lưu thành secret `ROBLOX_API_KEY`. Job `publish` khai `needs: check`, `if: github.ref == 'refs/heads/main'`, tải artifact rồi chạy:

```bash
curl --fail -X POST \
  "https://apis.roblox.com/universes/v1/$UNIVERSE_ID/places/$PLACE_ID/versions?versionType=Published" \
  -H "x-api-key: $ROBLOX_API_KEY" -H "Content-Type: application/octet-stream" \
  --data-binary @build.rbxl
```

`versionType=Saved` chỉ upload, không publish — dùng cho place staging và test place. Luôn publish lên **staging universe** trước rồi chạy test ở đó.

## Viết code test được trước đã
Đưa luật chơi vào **ModuleScript thuần** (input → output, không service, không yield): công thức damage, cộng trừ inventory, giá shop, state machine, serialize, validate. Service nhận dependency qua tham số (**dependency injection**) để test truyền fake thay cho DataStore, remote, `Players`.

```luau
--!strict
-- ReplicatedStorage/Shared/Inventory.luau — thuần logic, không service.
export type Inventory = { [string]: number }
local Inventory = {}

function Inventory.add(inventory: Inventory, itemId: string, amount: number, maxStack: number): (boolean, string?)
	local current = inventory[itemId] or 0
	if amount <= 0 or amount ~= math.floor(amount) or current + amount > maxStack then
		return false, "invalid"
	end
	inventory[itemId] = current + amount
	return true, nil
end
return Inventory
```

Với service: khai type `Store = { GetAsync: (self: Store, key: string) -> any, SetAsync: (self: Store, key: string, value: any) -> () }`, nhận `store` làm tham số factory, trong test truyền một table bọc `fakeData[key]`. Không `require` `DataStoreService` trực tiếp trong module cần test.

## Jest Lua
Bản port của Jest (`describe`/`it`/`expect`, mock, snapshot). TestEZ là legacy; Jest Lua 3 có guide migrate.

```toml
[dev-dependencies]
Jest = "jsdotlua/jest@3.10.0"
JestGlobals = "jsdotlua/jest-globals@3.10.0"
```

```luau
--!strict  -- src/shared/Inventory.spec.luau
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local JestGlobals = require(ReplicatedStorage.DevPackages.JestGlobals)
local Inventory = require(ReplicatedStorage.Shared.Inventory)
local describe, it, expect = JestGlobals.describe, JestGlobals.it, JestGlobals.expect

describe("Inventory.add", function()
	it("stacks items up to the limit", function()
		local inventory = {}
		expect(Inventory.add(inventory, "Apple", 3, 5)).toBe(true)
		local ok = Inventory.add(inventory, "Apple", 3, 5)
		expect(ok).toBe(false)
	end)
end)
```

- Đặt `jest.config.luau` (`return { testMatch = { "**/*.spec" } }`) ở mỗi test root.
- Runner: `require(ReplicatedStorage.DevPackages.Jest).runCLI(root, { ci = true }, { root }):awaitStatus()`, đọc `result.results.numFailedTests`.
- Jest Lua 3 cần fast flag `FFlagEnableLoadModule = true` trong `ClientAppSettings.json` khi chạy local trong Studio.
- Chỉ map `DevPackages` cho build test (project riêng, ví dụ `test.project.json`), không đưa vào place production.

## Nơi chạy test
| Runner | Dùng khi |
| --- | --- |
| Studio (command bar hoặc Script trong test place) | Dev hằng ngày, vòng lặp nhanh nhất |
| Studio MCP (`execute_luau`, `start_stop_play`, `get_console_output`) | Agent chạy test và playtest trên place đang mở |
| `run-in-roblox` | CLI mở Studio, chạy script, pipe output; cần Studio trên runner local/Windows/mac |
| **Open Cloud Luau Execution** | CI headless, chạy trong server Roblox thật cho place version đã publish |
| Lune | Module thuần Luau, không phụ thuộc API Roblox |

## Open Cloud Luau Execution
Chạy trong server thật của một place version: hợp cho code cần engine (instance, service, physics). **Không** có player/character; DataStore hoạt động như server live của universe đó nên phải dùng universe test riêng. Chuẩn bị: test universe + test place; API key với `universe.place.luau-execution-session:write` (thêm `universe-places` write để upload version). Script trong task phải `error` khi fail — đó là cách duy nhất khiến task chuyển `FAILED`:

```luau
--!strict
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Jest = require(ReplicatedStorage.DevPackages.Jest) :: any
local root = ReplicatedStorage.Shared

local status, result = Jest.runCLI(root, { ci = true, verbose = true }, { root }):awaitStatus()
if status ~= "Resolved" then error(`Jest failed to run: {result}`) end
local failed = result.results.numFailedTests + result.results.numFailedTestSuites
if failed > 0 then error(`{failed} failing tests/suites`) end
return result.results.numPassedTests
```

Driver bash + curl + jq: upload `Saved` version → tạo task → poll → in log.

```bash
VERSION=$(curl -sf -X POST "$API/universes/v1/$UNIVERSE_ID/places/$PLACE_ID/versions?versionType=Saved" \
  -H "x-api-key: $ROBLOX_API_KEY" -H "Content-Type: application/octet-stream" \
  --data-binary @test.rbxl | jq -r .versionNumber)
TASK=$(jq -n --rawfile script scripts/run-tests.luau '{script: $script, timeout: "300s"}' |
  curl -sf -X POST "$API/cloud/v2/universes/$UNIVERSE_ID/places/$PLACE_ID/versions/$VERSION/luau-execution-session-tasks" \
    -H "x-api-key: $ROBLOX_API_KEY" -H "Content-Type: application/json" --data @- | jq -r .path)
while true; do
  R=$(curl -sf "$API/cloud/v2/$TASK" -H "x-api-key: $ROBLOX_API_KEY")
  S=$(echo "$R" | jq -r .state)
  [ "$S" = COMPLETE ] && { echo "$R" | jq .output; break; }
  [ "$S" = FAILED ] || [ "$S" = CANCELLED ] && { echo "$R" | jq .error; exit 1; }
  sleep 5
done
curl -sf "$API/cloud/v2/$TASK/logs" -H "x-api-key: $ROBLOX_API_KEY" | jq -r '.luauExecutionSessionTaskLogs[]?.messages[]?'
```

Task mặc định timeout **5 phút**; rate limit khoảng **5 task/phút** trên mỗi chủ API key; log chỉ đọc được sau khi task xong.

## Playtest nhiều client và QA
Tab **Test**: Play (bạn + server), Run (chỉ server, không character), **Clients and Servers** với 2+ player. Phần lớn bug multiplayer chỉ hiện khi có ≥ 2 client: replication trễ, trade, PvP, UI không cập nhật. Bật network simulation (latency, jitter, packet loss) để test lag compensation; Device Emulator và Controller Emulator cho input/UI; test streaming với `StreamingTargetRadius = 64`. DataStore trong Studio cần bật API access và nên dùng universe hoặc tên store riêng.

Checklist trước khi ship: late joiner và sau respawn vẫn đúng; 2+ client với server authoritative và UI mọi client cập nhật; player rời giữa trade/mua/round không để state hỏng hay bảng rò rỉ; remote từ chối khi spam hoặc sai kiểu tham số; data save/reload sau rejoin kể cả teleport; mobile, gamepad, keyboard đều dùng được và UI đọc được trên điện thoại; Output sạch error/warning ở cả server và client.

## Open Cloud: xác thực
Base URL `https://apis.roblox.com`. Ưu tiên endpoint **Open Cloud** (API key hoặc OAuth 2.0, ổn định). Web API legacy xác thực bằng cookie trên `*.roblox.com` có thể đổi hoặc chết không báo trước — đừng xây tool trên đó.

| Cách | Dùng cho |
| --- | --- |
| **API key** (header `x-api-key`) | Resource của chính bạn hoặc của group; automation, CI, dashboard |
| **OAuth 2.0** (authorization code + PKCE) | App hành động thay mặt người dùng khác (tool bên thứ ba) |

Cấp scope tối thiểu theo từng universe, đặt **IP allowlist** (CIDR) và **expiration**, lưu trong secret vault. Resource thuộc group phải tạo key dưới group đó — key cá nhân không với tới. Kiểm tra key bằng `POST /api-keys/v1/introspect`. Không bao giờ nhúng key vào script trong game, attribute, hay code client.

## Endpoint thường dùng (v2 trừ khi ghi khác)
| Việc | Endpoint |
| --- | --- |
| Data store entry | `/cloud/v2/universes/{u}/data-stores/{ds}/entries`, `.../entries/{id}`, `:increment`, `:listRevisions`; scope qua `/scopes/{scope}/entries` |
| Ordered data store | `/cloud/v2/universes/{u}/ordered-data-stores/{ods}/scopes/{scope}/entries[...]` |
| Memory store | `/cloud/v2/universes/{u}/memory-store/sorted-maps/{map}/items`, `/queues/{q}/items[:read\|:discard]`, `memory-store:flush` |
| Message vào server đang chạy | `POST /cloud/v2/universes/{u}:publishMessage` body `{ "topic": "...", "message": "..." }` |
| Publish place file | `POST /universes/v1/{u}/places/{p}/versions?versionType=Published\|Saved` body `.rbxl` |
| Restart server sau update | `POST /cloud/v2/universes/{u}:restartServers` |
| Chạy Luau trong cloud | `POST /cloud/v2/universes/{u}/places/{p}[/versions/{v}]/luau-execution-session-tasks` |
| Ban | `PATCH /cloud/v2/universes/{u}/user-restrictions/{userId}?updateMask=gameJoinRestriction` (scope `universe.user-restriction:write`), `user-restrictions:listLogs` |
| Notification | `POST /cloud/v2/users/{userId}/notifications` |
| Secrets | `/cloud/v2/universes/{u}/secrets` |
| Configs / experiments | `/creator-configs-public-api/v1/configs/universes/{u}/repositories/{repo}[/draft\|/publish]`, `/experimentation/...` |
| Setting universe/place | `GET/PATCH /cloud/v2/universes/{u}`, `/cloud/v2/universes/{u}/places/{p}` |

Danh sách chuẩn kèm scope và rate limit từng endpoint ở Open Cloud reference (`create.roblox.com/docs/cloud/reference`) và OpenAPI description của nó. Mẫu gọi: pagination bằng `maxPageSize` + `nextPageToken` → `pageToken` tới khi rỗng; operation dài poll `GET /cloud/v2/{path}` tới khi `done`; list endpoint hỗ trợ tham số `filter`; đọc header `x-ratelimit-*` và backoff exponential kèm jitter khi `429`; lỗi trả `{ code, message }`, chỉ retry `429` và `5xx`. Budget data store **dùng chung** giữa Open Cloud và server live — script bulk phải tự throttle.

```bash
curl -s -X POST "https://apis.roblox.com/cloud/v2/universes/$UNIVERSE_ID:publishMessage" \
  -H "x-api-key: $ROBLOX_API_KEY" -H "Content-Type: application/json" \
  -d '{"topic":"Announcements","message":"{\"text\":\"Update in 5 minutes\"}"}'
```

`publishMessage` chỉ tới server đang sống tại thời điểm gọi — server khởi động sau không nhận lại; cần đảm bảo consumer nhận được thì dùng memory store queue.

## HttpService trong game
Bật **Allow HTTP Requests** (Experience Settings → Security); chỉ gọi được từ server. Giới hạn: **500 request/phút mỗi server** cho URL ngoài; call Open Cloud có budget riêng **2.500/phút mỗi server**. Luôn `pcall` và kiểm `response.Success`. Chỉ **một tập con** endpoint Open Cloud gọi được từ trong game (asset, ban, config, data/memory store, messaging, notification…); gọi sang domain `roblox.com` khác bị chặn. Secret lưu trong **Secrets store** của experience (Creator Hub), đọc bằng `HttpService:GetSecret(name)` — trả về object `Secret` không đọc được, chỉ dùng trong header (kèm `AddPrefix`/`AddSuffix`).

```luau
local HttpService = game:GetService("HttpService")

local function banViaOpenCloud(universeId: number, userId: number, reason: string): boolean
	local ok, response = pcall(function()
		return HttpService:RequestAsync({
			Url = `https://apis.roblox.com/cloud/v2/universes/{universeId}/user-restrictions/{userId}?updateMask=gameJoinRestriction`,
			Method = "PATCH",
			Headers = { ["Content-Type"] = "application/json", ["x-api-key"] = HttpService:GetSecret("OpenCloudKey") },
			Body = HttpService:JSONEncode({ gameJoinRestriction = { active = true, displayReason = reason, privateReason = reason } }),
		})
	end)
	return ok and response.Success
end
return { banViaOpenCloud = banViaOpenCloud }
```

Trong game, ưu tiên API native (`Players:BanAsync`, `DataStoreService`) thay vì gọi Open Cloud cho cùng việc. Không log hay gửi chat/PII của player cho bên thứ ba khi chưa có mục đích chính đáng và review compliance.

## Webhook (Roblox → server của bạn)
Cấu hình ở Creator Dashboard → Webhooks. Trigger: subscription purchased/renewed/cancelled/refunded/resubscribed, right-to-erasure, commerce order paid/refunded, transaction refunded. Khi webhook có secret, Roblox gửi header `roblox-signature: t=<timestamp>,v1=<signature>` với `signature = Base64(HMAC-SHA256(key = secret, message = "<timestamp>.<raw JSON body>"))`. Verify trên **raw body bytes**, không phải object serialize lại, và từ chối request cũ hơn **300 giây**.

```javascript
app.post("/roblox-webhook", express.raw({ type: "application/json" }), (req, res) => {
  const parts = Object.fromEntries((req.get("roblox-signature") ?? "").split(",").map((kv) => kv.split("=", 2)));
  const { t: timestamp, v1: signature } = parts;
  if (!timestamp || !signature) return res.sendStatus(401);
  if (Math.abs(Date.now() / 1000 - Number(timestamp)) > 300) return res.sendStatus(401);
  const expected = crypto.createHmac("sha256", SECRET)
    .update(`${timestamp}.${req.body.toString("utf8")}`).digest("base64");
  const ok = expected.length === signature.length &&
    crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signature));
  if (!ok) return res.sendStatus(401);
  res.sendStatus(200); // xử lý async; delivery fail sẽ được retry
});
```

- **Right to erasure**: xoá dữ liệu user khỏi mọi data store/key và mọi storage ngoài.
- **Refund**: tuỳ chính sách, thu hồi item/currency đã hoàn; ghi lại pattern lạm dụng.
- **Commerce order paid** có thể giao **nhiều lần** — deduplicate theo order ID; webhook cũng có thể trùng nên lưu event ID đã xử lý.
- Trả `2xx` nhanh rồi xử lý nền; delivery fail được retry.

## Bẫy
- **Sửa trong Studio xong mở editor thấy code cũ** — đang sync hai chiều trên cùng cây, Rojo và Script Sync ghi đè lẫn nhau; chỉ giữ một nguồn, tắt plugin hoặc tắt sync của root kia.
- **Script có attribute bị mất sau khi sync từ đĩa** — Script Sync không ghi attribute/tag ra file; chuyển metadata sang `*.meta.json` của Rojo hoặc tạo attribute bằng code lúc runtime.
- **`require` báo "Unknown require" trong editor nhưng chạy được trong Studio** — LSP chưa có sourcemap; chạy `rojo sourcemap`, trỏ `luau-lsp.sourcemap`, bật Companion plugin.
- **Type của package Wally toàn `any`** — thunk che type; chạy `wally-package-types --sourcemap sourcemap.json Packages/` sau mỗi `wally install`, và trong CI trước bước analyze.
- **CI xanh nhưng game lỗi lúc chạy** — CI chỉ build, không chạy engine; thêm bước Luau Execution trên test universe cho phần cần engine.
- **Luau Execution báo `COMPLETE` dù test fail** — script không `error` khi fail; ngược lại chạm timeout 5 phút thì bị cắt, giảm phạm vi test hoặc tăng `timeout` trong body.
- **Test pass local, fail trong cloud** — DataStore trong cloud là dữ liệu thật của universe đó; luôn dùng test universe riêng.
- **`429` hàng loạt khi backfill data store** — budget chia sẻ với server live; throttle, đọc `x-ratelimit-*`, backoff có jitter, chạy ngoài giờ cao điểm.
- **Publish xong người chơi vẫn thấy bản cũ** — server cũ còn sống; gọi `:restartServers` sau khi publish và thông báo trước bằng `publishMessage`.
- **`versionType=Published` trong CI làm hỏng bản live** — dùng `Saved` cho staging/test, chỉ `Published` ở `main` sau khi test xanh.
- **Webhook luôn 401** — body bị parse thành object rồi stringify lại (thứ tự key và whitespace đổi); dùng raw body, và kiểm đồng hồ server lệch quá 300 giây.
- **`HttpService:GetSecret` trả về thứ không dùng được như string** — `Secret` là opaque; chỉ nhét vào header hoặc `AddPrefix`/`AddSuffix`, không `tostring` rồi cắt chuỗi.
- **`HttpService` gọi API Roblox bị chặn** — chỉ tập con endpoint được whitelist và chỉ từ server; kiểm danh sách in-game HTTP trước khi thiết kế kiến trúc.
