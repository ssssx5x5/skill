# Hiểu ảnh tham chiếu đến mức dựng lại được (cho AI viết code)

Nhìn thoáng một bảng thiết kế rồi dựng = sai tỉ lệ, thiếu chi tiết, đếm nhầm. Quy trình dưới biến ảnh thành **số + ảnh phóng to có lưới**.
Công cụ chính: `scripts/imgread.py`. Bổ sung: `scripts/ref_analyze.py` (3 việc imgread không làm: `swatches`, `compare` tự nhận lật gương, `bbox --units-wide`).

## 1. Tách bảng thành đối tượng
`python scripts/imgread.py sheet bang.png out/` → liệt kê hộp + nhãn OCR gần nhất (TOP/FRONT/BACK/BOTTOM/LEFT/RIGHT...), lưu `obj_XX.png` và `overview.png` (**mở overview.png**: số nào là góc nào; nhãn OCR chỉ là gợi ý). Gán vai trò: góc nhìn / chi tiết phóng to / bảng màu / kích thước / animation / ảnh FPS. (`ref_analyze.py panels` là phương án dự phòng, chỉnh `--merge`.)

## 2. Đọc chữ & số trong ảnh
Ghi nguyên văn nhãn kích thước ("48 × 16 × 16 ô"), tên góc, tên chi tiết. "Ô pixel" ≠ stud: chọn `stud/ô` (ví dụ 0.25) rồi nhân.
⚠ Bảng do AI sinh thường **tự mâu thuẫn**: LEFT và RIGHT có nòng cùng một phía; "16 cao" không tính vòm/tay cầm (đo trên ảnh: cao tổng ≈ 21 khi dài 48). Coi góc rõ nhất làm gốc, các góc khác là gợi ý; đo trên chính hình.

## 3. Phóng to để ĐẾM và ĐO
- `imgread.py overlay obj.png out.png --n 10 --zoom 3` → lưới có nhãn toạ độ; đọc vị trí từng bộ phận.
- `imgread.py scan obj.png x0,y0 x1,y1` → quét dọc một đường: các đoạn màu liên tiếp (ĐẾM vòng/sọc/nòng chính xác).
- `ref_analyze.py crop bang.png x0 y0 x1 y1 out.png --scale 4 --grid 50` → cắt vùng bất kỳ, phóng to, vẽ lưới toạ độ gốc.
Mô hình thị giác hay đếm sai khi >4 vật: luôn đếm trên crop/scan và ghi con số. Vị trí ghi theo **% chiều dài vật**.
Kiểm chéo các góc: chi tiết thấy ở iso phải khớp front/top (nòng xếp **vòng tròn** nhìn từ front, không phải một hàng).

## 4. Số đo tự động
- `imgread.py measure obj.png` → hộp bao chủ thể, tỉ lệ, đối xứng, vị trí từng màu (0..1).
- `imgread.py palette obj.png --k 10` → hex + % diện tích + dòng Lua `Color3.fromRGB`. Với hàng ô màu rời trong bảng: `ref_analyze.py swatches panel.png` đọc chính xác từng ô (trái→phải, `PALETTE_JSON`).
- `imgread.py grid obj.png out.png` / `ascii obj.png --cell N` → tìm ô pixel-art và in bản đồ chữ cái (đọc layout voxel, làm `Rows` cho `PixelShapes.PixelArt`). Ảnh AI sinh hiếm khi có lưới chuẩn: nếu báo độ khớp thấp, dùng `ref_analyze.py bbox panel.png --units-wide N` khi biết số ô.

## 5. Viết Reference Spec (bắt buộc, đưa vào câu trả lời)
```
Vật: Pixel Minigun | 1 ô = 0.25 stud | trục dài = Z (nòng −Z)
Kích thước đo: dài 48 ô, rộng 16 ô, cao tổng ≈ 21 ô (gồm vòm + tay cầm)
Số lượng (đếm trên crop/scan): 6 nòng (đỏ cam vàng lục lam tím, xếp tròn), vòng kẹp tím ×N, thanh nối hồng ×4 ...
Vị trí (% dài từ đầu nòng): nòng 0–45% | thân xanh 45–85% | đuôi mây 85–100% | vòm cầu vồng giữa thân, rộng ≈ 22% dài
Bảng màu: [swatches/palette]
Chi tiết bề mặt: mặt mây cười ở đầu nòng; biểu tượng mây ở hông; dấu cộng hồng ở đuôi
Mâu thuẫn trong ảnh mẫu & cách chọn: ...
```
Từ spec sinh `expect.json` cho `sandbox.py run --expect` (`ratio`, `counts`, `palette`).

## 6. So sánh từng góc sau khi dựng
`imgread.py compare mẫu.png render.png diff.png` (IoU, tỉ lệ, màu, vùng lệch) hoặc `ref_analyze.py compare mẫu.png render.png --out diff.png` (thêm: tự thử lật gương, báo màu của mẫu **thiếu** trong render; ĐỎ = mẫu có mà render thiếu, XANH = render thừa). Làm cho front, side, top, iso: lỗi lộ ở góc này mà không lộ ở góc khác.

## Giới hạn trung thực
Công cụ đo hình bao, tỉ lệ, màu, số lượng; **không** hiểu "đẹp/giống phong cách". Chi tiết nhỏ hơn ~2% ảnh có thể lọt. Luôn kết thúc bằng một lần nhìn mắt ảnh render cạnh ảnh mẫu.
