# Sandbox: dựng → NHÌN → đo → sửa (bắt buộc cho model từ ảnh/mô tả phức tạp)

Lỗi như "vòm cầu vồng thành tấm phẳng", "6 nòng thành một lớp dẹt", "thân quá hẹp" có chung nguyên nhân: dựng xong mà **không nhìn và không đo**. Sandbox cho phép làm cả hai ngay trong phiên, không cần Studio.

## Cài một lần
```
pip install numpy pillow scipy
python scripts/sandbox.py install-luau        # tải luau CLI (cần mạng GitHub) hoặc đặt biến LUAU=/đường/dẫn/luau
python scripts/test_sandbox.py                 # tự kiểm (phải ALL PASS)
```

## Lệnh
```
python scripts/sandbox.py run build.lua --autolib --render out.png --front=-z \
        [--views front,left,top,iso] [--expect expect.json] [--time 2 --snaps 0,0.5,1] [--json scene.json] [--outline] [--ids]
python scripts/sandbox.py inspect scene.json          # cây, kích thước, cụm rời, weld, cảnh báo
python scripts/scene_check.py scene.json --expect expect.json
```
- `build.lua` chạy như một Script (`workspace`, `Instance.new`, `Model:PivotTo`, Weld...). `--autolib` cho `require(game.ReplicatedStorage.PatternKit)` (và GeoKit, AnimKit, PixelShapes...).
- `--front=-z` (mặc định) là hướng **mặt trước của vật** (nòng/lưỡi/mặt). Tên góc theo CHÍNH vật: `front` đứng trước nhìn vào; `left`/`right` đứng bên trái/phải vật (mặt trước nằm bên trái/phải ảnh); `top` mặt trước hướng lên ảnh; `iso`, `iso2`, `az=A:el=E`.
- Ảnh có chú thích kích thước (studs). `--ids` đánh số part để chỉ ra part lỗi.

## `--expect expect.json` (kỳ vọng bằng số, rút từ ảnh mẫu)
```json
{"ratio": {"L": 48, "H": 21.4, "W": 16, "tol": 0.15},
 "counts": [{"match": "^Barrel", "min": 6, "max": 6}],
 "palette": ["#EB5A5A", "#508CE6"], "palette_tol": 20,
 "joined": true, "min_parts": 100, "max_parts": 700, "bbox_studs": {"L": [20, 30]}}
```
`L` = dài theo `--front`, `H` = cao (Y), `W` = rộng. Tỉ lệ khớp theo trung bình nhân (sai số chia đều, không lấy một cạnh làm chuẩn). `joined` = 1 cụm nhìn thấy (SAT) **và** 1 assembly vật lý (weld + Anchored gom vào mặt đất). Mã thoát 1 nếu có FAIL → dùng làm cổng chặn. Ví dụ: `examples/minigun_expect.json` với `examples/MinigunRainbow.lua`.

## Vòng lặp (≥ 2 vòng; dừng khi hết FAIL và mọi góc IoU ≥ 0.75 hoặc đã nêu lý do)
1. **Chạy** → đọc cảnh báo/FAIL → **mở ảnh render bằng công cụ xem ảnh** (con số không thay được mắt).
2. Có ảnh mẫu: `python scripts/imgread.py compare mẫu_góc.png render.png diff.png` (xem `image-understanding.md`) → xem vùng lệch.
3. Sửa **lỗi lớn nhất trước**: tỉ lệ → số lượng → hình cong/tròn → màu → chi tiết. Mỗi vòng sửa một nhóm lỗi.
4. Giao kèm: IoU từng góc, FAIL còn lại, phần chưa kiểm trong Studio (xem `templates/sandbox/README.md`).

## Công cụ dựng hình cong/tròn
`templates/PatternKit.lua`: `VoxelArch` (vòm/cầu vồng nhiều lớp màu), `RadialSlots` (N vật quanh trục), `VoxelBlob` (khối cầu/mây), `Plus`, `Rod`, `WeldAll`. `templates/PixelShapes.lua`: `Annulus`/`Disc` (vòng, đĩa), `PixelArt` (mặt cười từ chuỗi ký tự, đúng chiều đọc khi nhìn từ phía trước), `Raster`. Mẫu hoàn chỉnh: `examples/MinigunRainbow.lua`.
