# Assets — từ yêu cầu đến asset trong engine

> Khi nào dùng: khi người dùng đưa một câu yêu cầu ("làm cho tôi Michael Jackson", "làm một cái máy bay", "vụ nổ tia gamma") và chờ một asset cụ thể trong Roblox Studio — outfit, animation, model hay VFX — chứ không chờ một đoạn mô tả.

## 0. Cổng vào — Studio phải sống

`list_roblox_studios` phải trả về ≥1 instance; lấy `id` truyền làm `studio_id` cho **mọi** call. Trả `{"studios": []}` = Studio mở nhưng bridge không listen → bảo người dùng mở place, bật MCP bridge, thử lại. **Không generate blind.**

| Asset | Có tool sinh? | Đường đi |
|---|---|---|
| Mesh có texture | có | `generate_mesh` |
| Model tham số | có | `generate_procedural_model` |
| Texture / material trên asset có sẵn | có | `generate_texture` (`instance_path`) / `generate_material` |
| Quần áo, decal, icon | có (ảnh) | ImageGen → `upload_image` |
| Animation, audio | **không** | id đã publish / `search_asset` → `insert_asset` |
| VFX | **không** | `execute_luau` dựng `ParticleEmitter` / `Beam` / `Trail` |

**Cost gate:** `ImageGen` ~**5-10 credit/ảnh**, bill riêng ngoài Studio MCP — nói giá và xin phép **trước** call đầu. Mesh, material, procedural qua MCP không tốn credit.

## 1. Routing — câu nói thành loại việc

Tách ra hai thứ và **nói ra**: *build cái gì* và *nó là loại gì*. Không suy diễn im lặng.

| Câu người dùng (VI / EN) | Intent | Dấu hiệu |
|---|---|---|
| "make me X", "hoá thân thành X", "cho tôi mặc đồ X", "make me look like X" | **OUTFIT** | động từ mặc |
| "animation X", "điệu nhảy X", "động tác X", "bắt chước X đi", "walk like X" | **MOTION** | chuyển động, nhịp |
| "làm một cái X", "tạo model X", "làm chiếc X", "build cho tôi X", "make an X" | **MODEL** | danh từ vật thể |
| "hiệu ứng X", "vụ nổ X", "tia X", "VFX X", "impact frame", "làm đẹp cái effect" | **VFX** | nổ, sáng, hạt |
| "làm hết", "full set", nhiều ý trong một câu | **COMBO** | nhiều intent |

Ba ca dễ nhầm: một **điệu nhảy của một người** là MOTION kèm rider OUTFIT ("Michael Jackson doing the moonwalk" = cả hai). "X model" là xe / con vật / đạo cụ thì là MODEL. Một đòn đánh hay vụ nổ có tên là VFX. **Thứ tự COMBO: OUTFIT → MODEL → MOTION → VFX** — thân phải tồn tại trước khi pose, hiệu ứng bọc lấy thứ đã xong; đảo thứ tự là làm lại từ đầu.

Keyword là **tên chuẩn, search được của chủ thể**, không phải chuỗi người dùng gõ. (1) **Bỏ dấu nhưng giữ cả hai dạng** — "Mai-cồ" → search `Michael Jackson` và `Mai-cồ`; tên nghệ sĩ/brand/địa danh thường có dạng Latin chính thức. (2) **Không dịch danh từ riêng** — "Người Nhện" search `Spider-Man`. (3) **Không tự sửa typo bằng cách đoán — search đúng typo trước**, rồi lấy tên đã sửa từ kết quả và dùng **một** cách viết đó ở mọi nơi. (4) **Thêm disambiguator** — `Michael Jackson Thriller 1983 outfit`, không phải trần `Michael Jackson`. (5) **Gọi tên biến thể** — OUTFIT cần thời kỳ (`Thriller`), MOTION cần style + rig (`moonwalk R6`), MODEL cần phiên bản (`Boeing 747`), VFX cần ngôn ngữ thị giác (`anime impact frame`); không có thì chọn bản biểu tượng nhất và **nói rõ đã chọn gì**.
Mơ hồ thật thì hỏi **một** câu với 2-3 lựa chọn; không hỏi thứ research trả lời được; không quá một câu hỏi mỗi lượt.
**Brief là file, không phải ký ức.** Viết `brief.md` (10-40 dòng, tiếng Việt) **trước** dòng code build đầu tiên; Sources ở câu trả lời cuối đọc ra từ đây.

```text
# <subject> - <intent>                    -- build gì, thời kỳ/biến thể/rig nào
Nguồn: <url> | <url> | <url>              -- >= 3, độc lập
Sự thật: - <thành phần> : <chi tiết, màu, chất liệu, số đo>   -- mỗi dòng truy được về một nguồn
Checklist: - [ ] <thành phần>             -- mỗi dòng thành một BoolValue trong RecreateSpec
Giả định: <chỗ research không chốt> | Chưa tra được: <chỗ search bị chặn>
```

Research theo intent — OUTFIT: đủ garment + **mọi** accessory; MOTION: cơ chế bằng lời (stance, chân chịu lực, chi nào đi đâu, tempo, điểm tiếp đất); MODEL: component kèm tỉ lệ và cách nối; VFX: mô tả vật lý trước, ngôn ngữ thị giác sau. **Đọc ảnh, không chỉ đọc chữ**: tải 3-6 ảnh (`refs/front.jpg`, `side`, `back`) rồi mở từng file. Ba nguồn độc lập là mức tối thiểu — một wiki cộng hai mirror vẫn là một nguồn. Chỗ không chốt thì ghi `assumed`, không trình bày phỏng đoán như sự thật.
Trước khi build, tạo `Folder` tên `RecreateSpec` trong `ReplicatedStorage` chứa một `BoolValue` mỗi thành phần (`Hat`, `Hair`, `Jacket`, `Glove`, `Shoes`, `FaceUnchanged`, `RootMotion`), mặc định `false` — cơ chế duy nhất biến "không thiếu phụ kiện" từ tuyên bố thành thứ kiểm được. Bật cờ **lúc thành phần được xác nhận có mặt**, không bật vào cuối; cờ còn `false` = thiếu phụ kiện. Chia nhỏ: `Hat` và `Hair` là hai mục, không phải "headwear".

## 2. Art direction — khoá trước khi generate

Chọn **một** preset, viết tên preset và bảng hex vào câu trả lời; không có preset thì mọi vòng sau không so sánh được với gì.

| Preset | Dùng cho | Palette | Tránh |
|---|---|---|---|
| **Stylized low-poly** | mặc định cho hầu hết game Roblox | 3-4 hue phẳng + 1 accent | noise, micro-detail, hình mỏng |
| **Hand-painted mobile** | cozy / casual / tycoon / obby | 4 hue ấm, value tương phản cao | PBR map, bóng tối |
| **Semi-realistic PBR** | showcase, horror, sim, PC cao cấp | 3 hue desaturate, grey trung tính | màu quá bão hoà, outline |
| **Blocky classic** | retro / parody | 3 tông mỗi vật liệu | bevel, cong, part mỏng |
| **Dark fantasy gothic** | dungeon, soulslike, horror | 2 hue lạnh + 1 accent ấm | primary sáng, mặt sạch |
| **Sci-fi hard-surface** | space, mech, cyber | grey đậm + 1 hue + emissive | gỉ, cong hữu cơ, gỗ |
| **Cartoon cel** | anime, chibi, mascot | 4 hue phẳng đậm | gradient, PBR |

**Palette:** chia **60/30/10** — 60% chủ đạo, 30% thứ cấp, 10% accent; accent là màu bão hoà duy nhất và nằm trên **đúng một** chi tiết. Tối đa 3 hue cho prop, 5 cho scene kit; thân asset giữ saturation 30-60%, 80-100% chỉ cho accent và emissive. Roblox render linear rồi tone-map nên màu ra **sáng hơn, kém bão hoà hơn** hex đã chọn — chọn tối và đậm hơn reference. Palette phẳng thì ưu tiên `Color3.fromRGB` trên part thay vì texture: nét hơn, không tốn texture streaming. **Value contrast là lỗi phổ biến nhất**: chuôi tối trên lưỡi tối đọc thành một cục ở khoảng cách xa.
**Prompt `generate_mesh`:** `[noun] + [silhouette cue] + [preset] + [material] + [palette] + [detail]`, một câu 25-45 từ, mở bằng **silhouette cue** vì hình là thứ sống sót ở khoảng cách xa. **Gán màu theo từng phần, gọi tên phần** — generator gán màu cho bề mặt **lớn nhất**, không phải phần bạn muốn: "muted steel grey and near-black" từng cho ra **lưỡi gần đen** vì màu 30% rơi vào bề mặt 60%; viết `blade in mid-tone steel grey, crossguard and pommel in near-black iron, grip in desaturated oxblood leather`. Thêm "restrained muted palette" khi cần ghìm saturation — không có nó, oxblood `#7A2A24` ra crimson sáng. Không viết "realistic photo", "8k", "octane", "render", "no background": đây là mesh generator, nó sinh geometry chứ không sinh scene. `segmentation="explicit"` + `partNames` (tối đa **8**) chỉ khi có phần chuyển động có tên (cửa, bánh, nắp); còn lại để `auto` tự đặt tên (`handle`, `hand guard`, `blade`, `pommel`).
`generate_texture` chỉ tả **bề mặt**, không tả hình, và truyền `instance_path` đầy đủ (`"Workspace.Arena.Floor"`) thay vì dựa vào selection. `generate_material` set đủ **bốn** field: `baseMaterial` (gần nhất trong 40 material engine), `materialPattern` (`Regular` đồ nhân tạo / `Organic` thứ mọc, rải), `materialId` (PascalCase, ví dụ `MossySlate`), `materialDescription` — `baseMaterial` quyết định **vật lý** (tiếng bước chân, hạt va chạm, blend terrain) nên sàn đá set `Fabric` nghe sai ngay. ImageGen: `[subject] + [preset] + [palette] + [composition] + [technical]`; clothing = flat lay chính diện đối xứng, không có cơ thể trong khung; icon = chủ thể giữa khung, `background="transparent"`, `1024x1024`, `quality="high"`; `image1` (image-to-image) để tinh chỉnh thay vì roll lại từ đầu.
`generate_mesh` nhận `maxTriangles` trong **12-20000** — **luôn set**, vì ngân sách tính cho asset nằm cùng nhiều asset khác trên màn hình.

| Class | Triangles | Ví dụ |
|---|---|---|
| Micro prop | 200 - 800 | gem, key, coin, potion |
| Small prop | 800 - 2,500 | mug, lantern, book |
| Medium prop | 2,500 - 5,000 | vũ khí, ghế, crate |
| Environment kit | 300 - 2,000 | wall module, đá, hàng rào |
| Character / creature | 4,000 - 12,000 | NPC, enemy, pet |
| Vehicle | 6,000 - 15,000 | xe, thuyền, máy bay nhỏ |
| Hero / centerpiece | 12,000 - 20,000 | boss, tượng landmark |

Nhiều mesh **giống nhau** thì rẻ (instanced), **khác nhau** thì không — dùng lại kit. Nhìn từ 50+ studs thì giảm nửa. VFX card (flipbook) là quad phẳng: dưới 200 tam giác.

## 3. Model

| Đường | Dùng khi | Giá |
|---|---|---|
| `generate_mesh` + `segmentation="explicit"` | hình hữu cơ, muốn cả chủ thể có texture một lần | chậm, phải normalize |
| Primitive + `UnionAsync` | hard-surface, chính xác, cần sửa được | thủ công, chính xác |
| Creator Store kitbash | một chi tiết con khó dựng (quạt, strut, rig) | thời gian vetting |
| `generate_procedural_model` | người dùng muốn **tinh chỉnh được**, không phải độ trung thực | primitive |

`generate_procedural_model` muốn **nguyên văn lời người dùng** trong `prompt` — không paraphrase, không diễn giải thành art direction; nó phơi ra đúng attribute *họ* gọi tên, art direction để cho bước material. Ảnh tham chiếu: `store_image` (PNG/JPG local ≤ 5 MB) trả URI `IMAGEID_<id>` → `attachedImageUri`, khi đó `prompt` để rỗng. Mặc định `async=true` → `wait_job_finished` → `inspect_instance`. Code chỉ đi tới primitive và `SpecialMesh`; `MeshPart` cần `MeshId` đã upload.
Mọi model bắt đầu bằng một bảng số theo stud: `STUDS_PER_METRE = 3` (người 1.7 m ≈ 5 studs). Ví dụ máy bay — fuselage 38 m dài / 3.8 m ⌀ → **100 × 12** studs (cylinder + mũi thuôn, là xương sống mọi thứ treo vào); wing 36 m span, sweep 25°, dihedral 5° → **100 span, dày 1.2** (block mỏng + wedge mép trước); fin 7 m → **22** (wedge); nacelle 2.5 m ⌀ → **6 ⌀ × 12**, gắn ~30% span dưới cánh; gear 3 chân (cylinder strut + wheel); cửa sổ là dải tối mỏng. **Tỉ lệ trước chi tiết**: đúng span/dài và đúng sweep là đọc ra đúng chiếc đó từ 50 studs, kể cả không có cửa sổ; cửa sổ hoàn hảo mà sweep sai thì đọc thành đồ chơi.

Từ vựng primitive: `Cylinder` cho thân/nacelle/bánh/strut/ống — **trục tròn là X**, xoay để nằm theo Z/Y; `WedgePart` cho mép trước, chine, fillet, chân cánh, đuôi, lật bằng `CFrame.Angles(0, math.pi, 0)`; `Ball` cho radome, dome, canopy (scale không đều → ellipsoid); `Part` block **không** bao giờ làm thân chính; `UnionAsync` chỉ cho 2-3 chỗ blend thật (một material mỗi union, tránh mặt coplanar, hình mỏng là fail im lặng); `MeshPart` với `CollisionFidelity = Hull`; `SpecialMesh` cho rivet/lưới (không collision); `Beam` cho dây, cáp, thanh mảnh.
Ráp: dựng mọi part ở origin với size cuối rồi mới đặt vị trí (không scale cụm đã đặt) → `PrimaryPart` + `WeldConstraint` từng part vào part kề → di chuyển bằng `PivotTo` (một phép, không trôi) → `CanCollide = false` mọi part trang trí, thêm 2-3 box vô hình nếu cần rắn (máy bay 40 part bật collision từng part là bom vật lý) → `Metal` chỉ cho trim và vỏ động cơ, `SmoothPlastic` thân sơn, `Glass` canopy, `Neon` đèn.

**Normalize — bắt buộc sau mỗi `generate_mesh`.** Ba kiểu sai luôn xảy ra: `size` chỉ là gợi ý (đo được nhỏ hơn **~10 lần**, có ca staff về **0.5 studs** khi xin 8 — hệ số **16**); tên model là prompt **cắt đúng 100 ký tự**; trục dài có thể không như ý (kiếm về lưỡi chúc `-Y`, staff về dài theo `Z`).

```luau
--!strict — execute_luau, datamodel_type = "Edit"
local ws = game:GetService("Workspace")
local target
for _, inst in ipairs(ws:GetChildren()) do
	if inst:IsA("Model") and inst:FindFirstChild("blade") then target = inst end   -- tên prompt KHÔNG dùng để tìm
end
if not target then return "not found" end
target.Name = "IronBroadsword"                        -- tên gốc = prompt cắt 100 ký tự
local _, s0 = target:GetBoundingBox()
target:ScaleTo(6 / math.max(s0.X, s0.Y, s0.Z))        -- 6 studs = trục dài nhất mong muốn
for _, d in ipairs(target:GetDescendants()) do
	if d:IsA("MeshPart") then d.Anchored, d.CanCollide, d.CastShadow = true, false, true end
end
local _, s1 = target:GetBoundingBox()
target:PivotTo(CFrame.new(0, s1.Y / 2 + 0.5, -14) * CFrame.Angles(math.rad(180), 0, 0))
```

`string.find` theo cụm giữa prompt **luôn trượt** vì tên bị cắt — nhận diện bằng child ổn định (`blade`) cộng loại trừ model đã rename, hoặc rename ngay sau từng lần generate. `segmentation="none"` **không** cho MeshPart trần: output vẫn là `Model -> Model "body" -> MeshPart "body_geom"` — làm phẳng (reparent lên model trên, đổi tên `Handle`) trước khi weld. Pivot: generator đặt ở tâm, phải sửa tay về điểm tiếp xúc (chuôi với vũ khí, đáy với prop). Part có texture phải đọc được thì `SmoothPlastic`, `Metal` chỉ cho accent — nó giết diffuse shading.
Model hero: **20-80 part** — dưới 10 là khối hộp, trên 200 là chưa ai xem lại bản insert; model thủ tục vài trăm part ổn cho NPC, `Anchored = true` phần tĩnh, `CanCollide`/`CanQuery`/`CanTouch = false` cho chi tiết. Kiểm: `GetExtentsSize()` so với bảng spec (máy bay 100 studs cạnh nhân vật 5 studs là đúng, 40 studs là đồ chơi); capture trước / bên / 3/4 trên, camera cách ~2× chiều dài; **đi vòng ra sau** — mặt đuôi là phần bị bỏ quên nhiều nhất.

Đặt part lên mặt cong (mắt, gai, vảy): bán trục `a,b,c = Size/2`, giao điểm `P = d / sqrt((dx/a)² + (dy/b)² + (dz/c)²)`, pháp tuyến `n = normalize(x/a², y/b², z/c²)`, tâm part tại `P + n * (size/2) * (1 - 2*embed)` — `embed` 0 = tiếp tuyến, 0.5 = chìm nửa (mắt lồi), 1 = chìm hẳn. Rải đều bằng xoắn ốc Fibonacci (`golden = math.pi * (3 - math.sqrt(5))`, `y = 1 - 2*(i+0.5)/count`) hoặc vòng quanh một hướng cho cụm mắt. Thân không phải ellipsoid thì raycast từ ngoài vào tâm lấy `Position` + `Normal` thật rồi dùng cùng công thức. Kiểm bằng số: `|(x/a)² + (y/b)² + (z/c)² − 1|` và gap theo pháp tuyến; lệch > **0.05 stud** là sai.

## 4. Outfit

`ApplyDescription` thay **mọi** field được truyền, field không set là `0` = "xoá". Dựng `HumanoidDescription` từ đầu là mất face decal, màu da, body scale. Vậy: **copy, sửa, apply lại**.

```lua
local function dress(humanoid, mutate)
	local desc = humanoid:GetAppliedDescription()   -- bản COPY của thứ đang mặc
	mutate(desc)
	local ok, err = pcall(function() humanoid:ApplyDescription(desc) end)
	if not ok then warn("ApplyDescription failed:", err) end
	return desc
end
```

Không bao giờ gán `desc.Face`, `desc.Head`, `desc.Torso`, `desc.LeftArm` … `desc.BodyTypeScale`, `desc.HeadScale`, `desc.WidthScale` — **Face là `desc.Face`**, thấy `Face = 0` trong hàm mutate là sắp xoá mặt người chơi. `desc.AccessoryBlob` là JSON array id và là thứ `ApplyDescription` thật sự đọc; các field lẻ (`HatAccessory`, `HairAccessory`, …) ghi vào cùng blob đó, nên **set field lẻ, không sửa blob** — sửa tay blob là cách phụ kiện rơi im lặng.

| | Shirt / Pants cổ điển | HumanoidDescription |
|---|---|---|
| Bản chất | asset **ảnh** upload, không phải mesh | gói mô tả toàn bộ avatar |
| Ảnh | **585x559** (shirt), **585x559** (pants) | — |
| Gán | `Shirt.ShirtTemplate = "rbxassetid://<id>"` | `desc.Shirt = <id số>` → `humanoid:ApplyDescriptionAsync(desc)` (server, replicates) |
| Rủi ro | vẽ lệch tâm là wrap lệch; tràn vùng là cổ áo nằm trên bụng | tạo mới từ đầu là mất face / skin / scale |
| Dùng khi | thay một món, cần đúng từng vùng UV | thay cả bộ, giữ nguyên cơ thể |

Id trong `desc.Shirt` là **số**, không prefix; trong `ShirtTemplate` có `rbxassetid://`. Hai đường lấy ảnh: Creator Store (`search_asset(assetType="Image")`, free, tức thì) hoặc ImageGen → `upload_image` (qua cost gate). Ảnh phẳng hình chữ nhật **không** map lên thân Roblox: classic clothing cần đúng template UV (thân trước/sau, tay áo, hông ở vùng cố định) — generate **lên layout template**, không lên canvas trơn. **Màu thắng hoạ tiết**: không có đúng pattern thì một màu đúng hue và value vẫn đọc ra bộ đồ. `upload_image` cần path phục vụ qua HTTP bởi bridge; lỗi thì fallback **Asset Manager → Bulk Import**, nói rõ đã dùng đường nào. Layered clothing (R15 3D) là `MeshAccessory`, pipeline khác — nói rõ giới hạn thay vì ép về classic.

| Thành phần trong reference | Slot / kênh | Ghi chú |
|---|---|---|
| Fedora, mũ, nón | `desc.HatAccessory` | gắn tại `HatAttachment` |
| Tóc, wig, afro | `desc.HairAccessory` | `HairAttachment`; **thêm tóc trước mũ** |
| Kính, mặt nạ | `desc.FaceAccessory` | `FaceFrontAttachment` |
| Áo khoác, suit / quần, jeans | `desc.Shirt` / `desc.Pants` | ảnh classic |
| Graphic tee | `desc.TShirt` | phủ lên `Shirt`, chỉ cho logo |
| Thắt lưng, đuôi, cape, balo / dây chuyền, cà vạt | `desc.WaistAccessory` / `BackAccessory` / `desc.NeckAccessory` | chủ yếu R15 |
| Găng một bên (ca MJ), giày | **không slot** — weld part | primitive hoặc `MeshPart` vào tay/chân |
| Micro, gậy, prop | `Tool` trong `Backpack` hoặc weld | weld cho pose tĩnh |

Món không có slot là món bị quên, và cũng là món bán được bộ đồ — mỗi món một cờ spec.
**R6 vs R15.** Phụ kiện chỉ gắn được nếu limb có `Attachment` **trùng tên**; R6 có ít điểm gắn hơn nên phụ kiện apply "thành công" rồi lơ lửng hoặc biến mất. Tạo nếu thiếu — `ensureAttachment(head, "FaceFrontAttachment", CFrame.new(0, -0.1, -0.55))`, `ensureAttachment(head, "HairAttachment", CFrame.new(0, 0.6, 0))`. Không chắc thì **weld thay vì attach**: `WeldConstraint` từ `Handle` vào đầu/limb với offset đặt tay không bao giờ trượt. R6 còn từ chối layered clothing: bắt lỗi chứa `"Layered"`, set `desc.LayeredClothingAccessory = ""` rồi `ApplyDescription` lại bằng classic.

Màu da, màu tóc, tỉ lệ **không** được sửa — thuộc về người chơi. Hex đọc từ ảnh reference rồi chọn tối và đậm hơn một chút vì tone-map làm sáng lên; giữ value gap giữa áo và quần, một bộ suit đen toàn bộ đọc thành một khối ở 20 studs. Tỉ lệ: R6 head rộng ~**1.2 studs**, người cao ~**5 studs** — mọi phụ kiện dựng tay đo theo hai số này. Mũ dựng tay: vành `Cylinder` dày 0.16 bán kính 3.4 (xoay `math.rad(90)`), chóp 1.5 × 2.1 × 2.1, weld, `Material = Fabric`, `Anchored = false`; **nghiêng cả cụm 6-10°** — góc đó là khác biệt giữa "cái mũ" và "fedora".
Lần đọc description **đầu tiên** là bộ đồ thật của người chơi. Lưu **một lần**, trước mọi mutation, và mở hàm restore — không có nó thì bộ đồ là một chiều.

```lua
local Original = {}
local function snapshot(player, humanoid)     -- gọi TRƯỚC lần ApplyDescription đầu tiên
	if Original[player] then return Original[player] end
	local d = humanoid:GetAppliedDescription()
	d.Name, d.Parent = "OriginalOutfit_" .. player.UserId, player   -- giữ instance sống qua respawn
	Original[player] = d
end
```

Gọi lần hai sau khi mặc sẽ chụp lại chính bộ costume. Giữ instance parent vào `Player` để soi được trong Explorer; xoá `Original[player]` khi `PlayerRemoving`, nếu không mỗi người từng đổi đồ rò một description. Nối vào thứ bấm được — `TextButton` trong `ScreenGui` hoặc `/undress` qua `TextChatService`; hàm restore không ai gọi được thì không phải restore.

## 5. Procedural nature — cây, hoa, đá

**Random có seed** (`Random.new(seed)` — cùng seed ra cùng cái cây; không dùng `math.random` trần cho hình cần dựng lại). **Cấu trúc trước, chi tiết sau**: thân → cành → nhánh → lá, dựng skeleton bằng điểm rồi mới biến điểm thành part. **Không hai cái giống nhau**: lệch size/góc/màu 5-10%; lá quanh thân theo golden angle `2.39996` rad. **Thuôn**: nhỏ dần về ngọn, lá rộng nhất ở ~40% chiều dài.

| Loại | Budget | Ghi chú |
|---|---|---|
| Prop plant | < 60 part | `CastShadow = false` trên part nhỏ |
| Tree | < 120 part | chỉ đốt thân đầu `CanCollide = true` |
| Rock / crystal | 3-5 khối / 5-9 mảnh | khối lớn nhất giữ collision |

Palette 3 màu mỗi cây (thân tối, lá mid, highlight) + 1 accent (hoa, quả). **Pivot ở gốc**: `model.WorldPivot = CFrame.new(basePosition)` để `PivotTo`, `ScaleTo`, đặt xuống đất đều tính từ điểm chạm đất.

```lua
local function branch(from, dir, length, thick, depth)
	local to = from + dir * length
	limb(from, to, math.max(thick, 0.15), bark).Material = Enum.Material.Wood
	if depth >= maxDepth then
		makePart({ Shape = Enum.PartType.Ball, Size = Vector3.one * length * rng:NextNumber(1.8, 2.6),
			Position = to, Material = Enum.Material.Grass, CanCollide = false })
		return
	end
	for _ = 1, (depth == 0 and 1 or rng:NextInteger(2, 3)) do
		local axis = dir:Cross(Vector3.new(rng:NextNumber(-1, 1), rng:NextNumber(-1, 1), rng:NextNumber(-1, 1)))
		if axis.Magnitude < 0.01 then axis = Vector3.xAxis end
		local nd = (CFrame.fromAxisAngle(axis.Unit, math.rad(rng:NextNumber(20, 45))) * dir + Vector3.yAxis * 0.25).Unit
		branch(to, nd, length * 0.72, thick * 0.62, depth + 1)   -- 0.72/0.62 = thuôn
	end
end
```

`+ Vector3.yAxis * 0.25` là phototropism — không có nó cây xoè ngang như san hô. Đá: 3-5 khối `Slate`, scale 0.5-1×, xoay ngẫu nhiên, chỉ khối đầu `CanCollide = true`. Crystal: 5-9 thanh `Glass`, `Transparency = 0.25`, `Reflectance = 0.1`, nghiêng 0.1-0.6 rad, một `PointLight` mềm (`Brightness 1.5`, `Range 16`).
Cây có hoa nên **data-driven**: một hàm `update(grow, unfurl, bloom, sway)` tính lại toàn bộ transform từ số — growth, héo, scrub, đung đưa dùng chung một đường code, không lệch `ScaleTo`, không tween từng part. Rải vật: raycast từ trên xuống, `hit.Normal.Y > 0.7` mới đặt (bỏ vách dốc), `r = sqrt(rng:NextNumber()) * radius` để đều trên đĩa, rồi `CFrame.lookAt(hit.Position, hit.Position + hit.Normal) * CFrame.Angles(math.rad(-90), 0, 0)` để trục Y trùng pháp tuyến; trộn 70% nhỏ / 25% vừa / 5% lớn. Đung đưa nhiều cây thì làm **client**, chỉ cây trong ~80 studs quanh camera, 30 Hz — một cây là ~35 phép ghi property mỗi frame.

## 6. Sprite pixel-art → voxel

Mỗi pixel của sprite là **một `Part`**: tái tạo reference chính xác từ mặt trước, đọc ra pixel-art 3D kiểu Minecraft. Không dùng `EditableMesh` / `CreateMeshPartAsync` — trong Play budget bộ nhớ rất nhỏ (`CreateEditableMesh` trả `nil`), và destroy EditableMesh giết luôn `MeshPart` tham chiếu nó.

Trích lưới bằng companion script `scripts/extract_sprite.py`: `python scripts/extract_sprite.py --image <path> --grid 16 --out sprite` — in lưới ASCII + palette, ghi `sprite.lua` (`PALETTE` + `CELLS`) và `sprite_compare.png`. **Đọc `sprite_compare.png` trước khi build** — hai nửa không khớp thì sửa `--grid` rồi chạy lại; không build từ lưới chưa kiểm.
**Cell size gần như không bao giờ nguyên**: render 360×360 của sprite 16×16 là **22.5 px** mỗi ô, không phải 22 — dùng 22 thì lưới trôi và màu bị blend/sai; luôn dùng `width / grid` dạng float. **Pixel trắng bên trong hình sẽ biến mất** nếu coi "trắng" là nền: flood fill từ **viền ảnh**, chỉ trắng *bị bao kín* mới là nội dung (sprite preview thường có viền xám mảnh quanh vùng trắng — chính nó làm vùng trắng hiện ra). Halo do anti-aliasing/JPEG để lại ô rìa chưa bị đánh dấu: yêu cầu **đa số** ô (mặc định **0.55**) là non-background, không nhận một pixel lẻ.

Build trong **Edit** datamodel, dán `PALETTE` và `CELLS` nguyên văn (tạo `Tool` tên `TNT`, `RequiresHandle = true`, parent vào `StarterPack`):

```lua
local GRID, U = 16, 0.13                  -- studs mỗi pixel; 16 px -> 2.08 studs
local half = GRID / 2 - 0.5
local handle, parts = nil, {}
for _, c in ipairs(CELLS) do              -- c = {col, row, paletteKey}
	local p = Instance.new("Part")
	p.Size = Vector3.new(U, U, U)
	p.CFrame = CFrame.new((c[1] - half) * U, (half - c[2]) * U, 0)   -- row tăng xuống
	p.Color, p.Material = PALETTE[c[3]], Enum.Material.SmoothPlastic
	p.Anchored = true
	p.CanCollide, p.CanQuery, p.CanTouch = false, false, false
	p.TopSurface, p.BottomSurface = Enum.SurfaceType.Smooth, Enum.SurfaceType.Smooth
	p.Parent = tool
	parts[#parts + 1] = p
	if c[1] == 2 and c[2] == 14 then handle = p end   -- một ô ở đầu chuôi
end
handle.Name = "Handle"
for _, p in ipairs(parts) do
	if p ~= handle then
		local w = Instance.new("WeldConstraint")
		w.Part0, w.Part1, w.Parent = handle, p, handle
		p.Anchored, p.Massless = false, true
	end
end
handle.Anchored = false
```

Parent part thẳng vào `Tool`, **không** vào `Model` tạm rồi `model:Destroy()` — destroy model là destroy mọi part vừa weld. Kiểm: clone các part sang `Model`, `Anchored = true`, `PivotTo` lên chỗ trống (ví dụ `0, 400, 0` để không có geometry trong khung), capture camera cách ~1.75 studs — `camera_position` / `look_at_position` **có** tác dụng trong Edit mode nên không cần move player. Rồi vào Play, `Humanoid:EquipTool(tool)`, capture trong tay; tấm bị nhìn nghiêng thì chỉnh `tool.GripForward` / `GripUp` / `GripRight` và chụp lại. Tỉ lệ: `U = 0.13` cho cây gậy ~2 studs vừa R6; giữ `GRID * U` trong **1.5-3 studs** cho đồ cầm tay.

## 7. Motion

Không có tool prompt-to-animation. Hai đường trung thực: dùng **id đã publish** (đọc từ `Animate` script mặc định — các `Animation` con của `StringValue` như `toolslash`, `idle`, `walk`, asset của Roblox, luôn resolve), hoặc tự dựng `KeyframeSequence`. `search_asset` **không** search được animation: enum `assetType` chỉ có `Model, Audio, Mesh, MeshPart, Image, Decal, Video, Package`, truyền `"Animation"` bị validation từ chối; `insert_asset` thì nhận nên chèn được nếu đã có id số.
`KeyframeSequence` đăng ký runtime **không** làm rig chuyển động: `KeyframeSequenceProvider:RegisterKeyframeSequence()` trả hash mà docs nói dùng cho "localized testing", nhưng đo suốt một vòng playback thì transform của joint đứng yên — **1/30 giá trị phân biệt**, so với **11-26/30** của animation đã publish; `track.IsPlaying` vẫn `true` nên lỗi hoàn toàn im lặng, và `RegisterActiveKeyframeSequence` không phải đường vòng (`can only be used in Solo mode`). Đường dùng thật: dựng sequence bằng code, giữ trong place, mở bằng **Animation Editor** để publish ra `rbxassetid://` — bước publish là UI-only.

Rig R15 hiện đại dựng bằng `AnimationConstraint` + `BallSocketConstraint`, **không phải `Motor6D`**: `C0`/`C1`/`Part0`/`Part1` là alias chỉ đọc, `Transform` mới ghi được và chỉ trong `RunService.PreSimulation`. Tên joint lấy bằng `if d:IsA("AnimationConstraint") then print(d.Name) end` — R15 trả 15 cái: `Root, Waist, Neck, LeftShoulder, LeftElbow, LeftWrist, RightShoulder, RightElbow, RightWrist, LeftHip, LeftKnee, LeftAnkle, RightHip, RightKnee, RightAnkle`.
Chia reference thành channel trước khi chạm code — mỗi dòng một câu đã đọc, không phải cảm giác: stance, weight transfer, limb path (đầu → cuối, có chạm sàn không), **contact** (bộ phận nào trên sàn và khi nào), tempo, torso (counter-rotation, lean, bob), arms (biên độ, pha so với chân), head. Hai dòng quyết định phần lớn độ nhận diện là **contact** và **bob**.

R6 có sáu `Motor6D`: `RootJoint` (yaw/lean toàn thân), `Neck`, `Right Shoulder` / `Left Shoulder`, `Right Hip` / `Left Hip` — không có đầu gối, không có cùi chỏ. `Motor6D.Transform` ghi được như `AnimationConstraint.Transform` (pose tuyệt đối, ai ghi sau thắng, ghi trong `PreSimulation`); vì ghi sau nên nó đè `Animate` mặc định, không cần tắt `Animate`, còn nếu vẫn đánh nhau thì `walkTrack:AdjustWeight(0)`. Mọi thứ reference gọi là gập gối (crouch, bounce, lunge) phải giả bằng pitch cả chân và dịch `RootJoint` theo Y — bản dịch R6 đúng, nhưng phải được **chọn** trước. **Translation làm rời chi**: giữ ≤ **0.8 studs** và đưa sải chân vào **rotation**; X luôn 0 để chân không cắt nhau.
Moonwalk: người nhảy đi **về phía sau**, trong world bàn chân chỉ trôi về sau hoặc đứng yên — chân tiếp đất đứng yên trong world nên trong hệ thân nó trôi về sau đúng `V`; chân tự do quay về dưới hông trong lúc nhấc lên, cũng trôi `V` nên cũng đứng yên trong world. Hai chân chạy cùng sóng tam giác lệch nửa chu kỳ. Hệ quả: **thân phải thật sự tịnh tiến về sau** (pose không, thân đứng yên, đọc ra giậm tại chỗ — lý do số một khiến moonwalk sai) và **không bob dọc** (chân tự do thấp ~**0.15-0.25 studs**). Ràng buộc `S = V * T / 2` với `T = 0.9`; `V` lấy từ `WalkSpeed` (5-6 đọc đẹp nhất, 16 là chạy nước rút), và `S = math.min(V * CYCLE / 2, 0.8)` vì translation bị chặn — phần sải còn lại nằm ở rotation. Hằng số đã chạy: `CYCLE = 0.9`, `HIP_PITCH = math.rad(22)`, `SLIDE = 0.7`, `LIFT = 0.2`, `TOE = math.rad(16)`, `ARM_SWING = math.rad(14)`. Năm chi tiết làm nó đọc ra: chân tiếp đất phẳng và chân tự do thấp (nhấc quá ~**0.3 studs** là thành đi đều); toe pitch 10-18° trên chân tiếp đất (chân R6 là hộp, độ nghiêng là thứ nói "dồn lên mũi chân"); counter-rotation nhỏ, torso yaw ≤ 5°, tay ngược pha; đầu đứng yên (`Neck` counter-rotate); và **tuyến tính, không easing** trên cả drift lẫn đường về — `sin`/`smoothstep` ở đó làm nó lơ lửng. Dừng phải sạch: `for _, m in pairs(motors) do m.Transform = CFrame.new() end`, nếu không thì để lại một cái chân khập khiễng vĩnh viễn.

Kiểm chứng: ảnh tĩnh không chứng minh được vòng 0.9 s. Sample `motors["Right Hip"].Transform` 90 lần cách 0.02 s, đếm `string.format("%.2f|%.2f", t.Position.Z, t.RightVector.Y)` — **~1 là đứng yên, ~10-40 là có chuyển động**; và kiểm `HumanoidRootPart.Position` qua một vòng, không dịch thì đọc ra giậm tại chỗ. Kiểm rẻ nhất chạy được cả khi bridge chết: hàm pose là toán thuần — chạy Lua 5.4 standalone, in `(slide, lift, pitch)` mỗi 5% vòng. Đạt khi `lift` = 0 suốt nửa tiếp đất, `slide` đảo chiều giữa hai pha, dòng `100%` bằng dòng `0%`, biên độ `slide` ≥ 0.3 studs, và `2 * peakSlide / CYCLE` ≈ `WalkSpeed` sẽ dùng. Sai thì sửa hằng số — sửa ở đây mất một giây, sửa trong Studio mất một lần playtest.

## 8. VFX

Sáu lớp xếp đúng thời điểm thì trông đắt tiền; một lớp bật/tắt thì trông nghiệp dư.

| Lớp | Việc | Part điển hình |
|---|---|---|
| 1. Core flash | bán khoảnh khắc va chạm | `Ball`, `Neon`, `LightEmission = 1`, 2-3 studs |
| 2. Glow | ánh loang quanh core | ball thứ hai, lớn hơn, gần như trong suốt |
| 3. Shape / debris | danh tính — mảnh, vòng, tia | `Part` shard, `MeshPart` ring, `Beam` jet |
| 4. Shockwave | sóng áp, đọc ra quy mô | đĩa hoặc vỏ cầu nở ra |
| 5. Light | nối hiệu ứng vào thế giới | `PointLight` / `SpotLight` |
| 6. Sound | bán cú va chạm hơn mọi thứ hình ảnh | transient + body + tail |

Stagger: core `t=0`, glow `0.02`, debris `0.04`, shockwave `0.08`, light `0`, sound `0` — tất cả cùng frame đọc thành một cú pop phẳng. Bốn property quyết định: `Transparency` là `NumberSequence` ramp `1 → 0.1 → 1` (bật/tắt cứng là dấu hiệu số một của VFX nghiệp dư); `Size` lớn dần hoặc nhỏ dần (size hằng đọc phẳng); `Color` là `ColorSequence` nóng → lạnh (một màu phẳng đọc như placeholder); `LightEmission > 0` chỉ cho phần thật sự phát sáng, dùng dè — nó là chi phí render thật.
**Quy mô impact — đo, đừng đoán.** Shockwave `Neon` nở tới **12 studs** cộng `PointLight` **Brightness 9 / Range 16** từng làm trắng cả viewport; dummy biến mất trong chính hiệu ứng của nó.

| Thành phần | Quá đà | Dùng thay |
|---|---|---|
| Shockwave max size | 12 studs | **6.5 studs** |
| Shockwave `Transparency` | 0.25 | **0.55** |
| `PointLight.Brightness` | 9 | **3** |
| `PointLight.Range` | 16 | **9** |
| Burst particle size | 1.6 | **~1.15** |
| Burst `:Emit(n)` | 34 | **~24-34** sau khi đã ghìm size |

Burst bắn ở **mọi** cú đánh, nên burst quá sáng không phải một lần loé mà là nhấp nháy suốt trận — luôn capture **trong lúc** hiệu ứng chạy, không phải ảnh tĩnh lúc idle. Ngân sách: `Rate` dưới ~50 mỗi emitter, tổng hạt sống mỗi màn hình dưới ~500; hiệu ứng liên tục thì ≤ 3 emitter, `Rate ≤ 40`, burst dùng `Rate = 0` + `:Emit(n)`. Mọi instance có `Debris:AddItem(obj, lifetime)` — emitter rò là bug bộ nhớ phổ biến nhất của Roblox; `CanQuery = false` trên mọi part trang trí, nếu không nó ăn raycast, kể cả raycast của chính bạn. Hiệu ứng cosmetic nằm trong LocalScript để không replicate, chỉ hiệu ứng ảnh hưởng gameplay mới chạm server; gắn vào `Attachment`, không gắn vào `CFrame` trần, để nó đi theo part đang động. Không dùng `Explosion` cho vụ nổ thuần thị giác — nó áp vật lý; buộc phải dùng thì `DestroyJointRadiusPercent = 0`, `BlastPressure = 0`.
Hai công thức đáng nhớ. **Gamma ray burst**: hai jet đối nhau dọc Y (`Beam` `Width0 = 1.2` → `Width1 = 16`, `FaceCamera = true`, trắng → `120, 60, 255`), core `Neon` nở 2 → 14 studs trong 0.12 s rồi mờ 0.7 s, ring `Cylinder` dày 0.3 nở 6 → 90 studs, `PointLight` `Brightness 60 / Range 80` tắt dần 0.6 s, 20-30 mảnh `hình thoi` văng 30-60 studs/s. **Impact frame**: 2-4 frame render (~0.04-0.07 s ở 60 fps) — `ColorCorrectionEffect` `Saturation -1, Contrast 2, Brightness 0.6`, một `Frame` trắng toàn màn `DisplayOrder = 100`, hitstop bằng `track:AdjustSpeed(0)` cho mọi track đang chạy rồi trả `1`; rung camera ±0.3-0.6 studs tắt dần tuyến tính 0.4 s, rung **camera** chứ không rung nhân vật.

Sound là ba lớp, không bao giờ một: transient (noise/crack 2-6 kHz, `t = 0`, 0.05-0.1 s), body (sine hoặc noise sweep 60-200 Hz, `t = 0.01`, 0.2-0.4 s), tail (reverb/rumble, `t = 0.05`, 1-3 s), gộp bằng `CompressorSoundEffect` (`Threshold -12, Ratio 4, Attack 0.002, Release 0.15`) trong một `SoundGroup`; random `PlaybackSpeed` ±5% mỗi lần phát, nếu không vụ nổ thứ ba nghe như bản copy; `RollOffMode = InverseTapered`, `RollOffMaxDistance = 120` cho hiệu ứng thế giới. Sound id là thứ duy nhất **không thể suy ra** — không bịa id, và đừng để hiệu ứng vỡ khi thiếu: `local id = SOUNDS[key]; if not id or id == "" then return end`, rồi nói với người dùng key nào còn rỗng.

## 9. Tự chấm trước khi giao

Chấm 1-5 từng trục. **Ngưỡng ship: trung bình ≥ 4.0 và không trục nào dưới 3**; chưa đạt thì thêm vòng, tối đa **3 vòng**.

| Trục | 1 - loại | 3 - tạm | 5 - xong |
|---|---|---|---|
| **Silhouette & readability** | không nhận ra khi tô đen | gọi được tên ở cỡ thumbnail | gesture rõ, đọc ở 50 studs, phá được đường viền của chính nó |
| **Palette & colour** | cầu vồng, >6 hue, bùn | 3-5 hue, có accent | giữ 60/30/10, accent trên đúng một chi tiết, value gap rõ |
| **Surface & material** | `Plastic` xám trần | `Material` có chủ đích trên mọi mặt | `baseMaterial` đúng vật lý, có variant, texel density đều |
| **Geometry & topology** | nhão, chảy, part chồng nhau | hình sạch, trong budget | topology hiệu quả, pivot hợp lý, không mặt ẩn thừa |
| **Scale & integration** | sai cỡ so với reference | stud hợp lý | pivot/hướng đúng, nằm tự nhiên, khớp kit có sẵn |
| **Technical cost** | hạt/mesh không budget, rò | trong budget | dùng lại kit, cosmetic ở client, hiệu ứng pool và dọn sạch |

**Auto-reject:** mesh không texture hoặc `Plastic` xám trần; silhouette không đọc được ở cỡ thumbnail; vượt budget tam giác của class; instance/hiệu ứng không bao giờ bị destroy; **tuyên bố thành công mà không có `screen_capture`**; audio không thuộc hoặc không được chia sẻ cho chủ place (runtime sẽ không phát).

**Checklist kiểm, đúng thứ tự — định nghĩa của "xong":** `get_studio_state` xác nhận instance và datamodel `Edit` → `inspect_instance` đọc số tam giác, số part, size stud, pivot → `screen_capture` từ **ba** góc: trước, 3/4, và ảnh rộng ở khoảng cách gameplay → kiểm dưới `Lighting` **thật của game** (place có custom lighting thì view mặc định của Studio không chứng minh gì) → chấm đủ sáu trục và **nêu con số** trong câu trả lời → animation hoặc VFX thì `start_stop_play` và capture **giữa** hiệu ứng → trục nào < 3 hoặc trung bình < 4.0 thì chạy vòng nữa.

Báo cáo: tên asset, preset, palette hex, số tam giác, điểm từng trục, trung bình, ảnh đã xem — **số, không phải tính từ**. Mỗi vòng chỉ đổi **một** biến (câu prompt, budget tam giác, hoặc material); vòng 2 tệ hơn vòng 1 thì quay lại tham số vòng 1 và đổi biến khác. Quá ba vòng chưa hội tụ thì brief hoặc preset sai — đổi cái đó và nói ra, đừng nghiền prompt.

## Bẫy

- **Model vừa generate không tìm thấy trong Workspace** — tên là prompt bị cắt đúng **100 ký tự** nên `string.find` theo cụm giữa prompt luôn trượt; tìm theo child ổn định (`blade`) cộng loại trừ model đã rename, hoặc rename ngay sau từng lần generate.
- **Mesh nhỏ tí so với `size` đã xin** — `size` là gợi ý chứ không phải hợp đồng (đo được nhỏ hơn ~10 lần; ca 0.5 studs khi xin 8 = hệ số 16); luôn `ScaleTo(target / longestAxis)`, đừng "chỉnh một chút".
- **Vũ khí chúc mũi xuống đất** — trục dài sinh ra thường là `-Y` (staff thì có khi là `Z`); đọc `part.Size` thật rồi xoay 180° quanh X, đừng giả định trục.
- **Một màu chiếm hết asset** — generator gán màu theo **diện tích bề mặt**, không theo phần bạn muốn, nên split 60/30/10 bị đảo; gọi tên phần đi kèm màu trong prompt.
- **Lưỡi kim loại render gần đen** — `Material = Metal` trên albedo tối giết diffuse shading; `SmoothPlastic` cho part có texture phải đọc được, `Metal` chỉ cho trim.
- **`MaterialVariant` set xong không đổi, hoặc throw** — set thiếu một trong hai; phải set **cả** `Material = <BaseMaterial>` **và** `MaterialVariant = "<name>"`.
- **Part trùng nhau sau khi generate** — `segmentation` tự suy ra phần chồng lấn; chạy lại `segmentation="none"`, rồi làm phẳng `Model -> Model "body" -> MeshPart "body_geom"` trước khi weld.
- **Asset ổn trong Studio nhưng tệ trong game** — chấm dưới `Lighting` mặc định; kiểm lại dưới `Lighting` thật của place, giảm texel density / tam giác nếu có streaming.
- **Chi tiết biến mất ở khoảng cách** — hình mỏng hơn ~**0.15 studs**; làm dày, hoặc bỏ hẳn và vẽ vào texture.
- **Mặt người chơi biến mất sau khi mặc đồ** — description dựng từ đầu, field không set = `0` = xoá; luôn `GetAppliedDescription()` rồi chỉ sửa field quần áo, và `desc.Face = 0` là dấu hiệu sắp mất mặt.
- **Chỉ một vài phụ kiện hiện ra** — sửa tay `AccessoryBlob`; set các field lẻ (`HatAccessory`, `HairAccessory`, …) và để chúng ghi vào blob.
- **Mũ lơ lửng trên đầu** — không có `Attachment` trùng tên trên limb (R6 thiếu điểm gắn); tạo attachment còn thiếu, hoặc weld `Handle` vào đầu.
- **`ApplyDescription` lỗi trên R6** — layered clothing; bắt lỗi chứa `"Layered"`, set `desc.LayeredClothingAccessory = ""` rồi thử lại bằng classic.
- **Shirt hiện ra như tấm ảnh dán lên người** — đã insert `Decal` thay vì set `desc.Shirt` / `ShirtTemplate` bằng id ảnh.
- **Người chơi bị đẩy văng bởi chính cái mũ** — cosmetic để `CanCollide = true`; set `CanCollide = false`, `Anchored = false`.
- **Người chơi không lấy lại được avatar** — bản gốc chưa lưu, hoặc lưu **sau** lần `ApplyDescription` đầu (lúc đó `GetAppliedDescription` trả về chính bộ costume); snapshot trước, parent vào `Player`, mở hàm restore bấm được.
- **Bộ đồ đọc ra "suit chung chung"** — phụ kiện bị bỏ qua; mỗi thành phần trong reference một cờ `RecreateSpec`, cờ còn `false` là chưa xong.
- **Các part trôi khỏi nhau khi di chuyển** — thiếu weld, hoặc `PivotTo` trên model không có `PrimaryPart`; weld hết, set `PrimaryPart`.
- **Vật lý nổ tung** — bật collision trên từng part trang trí; `CanCollide = false` hàng loạt và thêm 2-3 box va chạm vô hình.
- **Mắt / gai lơ lửng hoặc lệch khỏi mặt cong** — dùng `Size` thay vì `Size/2` làm bán trục, quên nhân `bodyCF`, hoặc offset theo trục thế giới thay vì theo pháp tuyến; dùng `P = d / sqrt((dx/a)² + (dy/b)² + (dz/c)²)` rồi offset theo `n`, và in residual (lệch > 0.05 stud là sai).
- **Animation "chạy" mà rig đứng yên** — `KeyframeSequence` đăng ký runtime không tạo chuyển động, `IsPlaying` vẫn `true`; đo `AnimationConstraint.Transform` qua một vòng (1 giá trị = đứng yên, hàng chục = chạy) và publish qua Animation Editor.
- **Moonwalk thành giậm tại chỗ** — thân không tịnh tiến về sau; chạy movement ở `WalkSpeed` trong lúc pose, giữ `S = V * T / 2`.
- **Chân moonwalk trượt như bánh xe** — pose nhanh/chậm không khớp tốc độ thân; khớp `S = V * T / 2`, chặn translation ≤ 0.8 studs, phần còn lại đưa vào rotation.
- **Voxel lưới trôi và màu sai** — cell size bị làm tròn thành số nguyên (360/16 = **22.5**, không phải 22); luôn dùng `width / grid` dạng float.
- **Pixel trắng bên trong hình biến mất** — "trắng" bị coi là nền; flood fill từ **viền ảnh**, chỉ trắng bị bao kín mới là nội dung.
- **Destroy model tạm làm mất sạch part vừa weld** — part parent vào `Model` tạm rồi `model:Destroy()`; parent thẳng vào `Tool`.
- **Camera Studio kẹt sau `screen_capture`** — capture bằng `camera_position` tạo `Camera` với `CameraType = Scriptable` và không trả lại; kết thúc bằng `workspace.CurrentCamera.CameraType = Enum.CameraType.Custom`.
- **VFX trông phẳng và rẻ** — chỉ một lớp; thêm glow, shockwave, light và **stagger** thời điểm, đừng bắn tất cả ở frame 0.
- **Cú đánh làm trắng cả màn hình** — shockwave 12 studs + `PointLight` Brightness 9 / Range 16; hạ về 6.5 studs, Transparency 0.55, Brightness 3, Range 9, và capture **trong lúc** hiệu ứng chạy.
- **Âm thanh chỉ là một tiếng "tách"** — một lớp; transient + body + tail qua `CompressorSoundEffect`, random `PlaybackSpeed` ±5%.
- **Hiệu ứng không phát tiếng dù id đúng** — audio không thuộc / không được chia sẻ cho chủ place, và Studio preview không chứng minh được gì; kiểm quyền sở hữu trước khi wiring.
