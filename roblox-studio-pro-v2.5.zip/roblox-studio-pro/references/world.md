# Dựng thế giới bằng code: part, lighting, terrain, CSG và hiệu ứng

> Khi nào dùng: khi map, ánh sáng, địa hình, vật thể phá huỷ hoặc hiệu ứng môi trường phải sinh ra từ code thay vì kéo thả trong Studio.

## Part, Model và pivot

`Instance.new("Part")` trả về `Size = Vector3.new(4, 1, 2)`, `Anchored = false`, `Material = Plastic`. Set hết property rồi **gán `Parent` cuối cùng**: mỗi lần parent là một lần chèn vào physics + replication, gán cuối thì chỉ một lần, không flicker, không một loạt event `ChildAdded`.

| Việc | API | Ghi chú |
| --- | --- | --- |
| Dời/xoay cả cụm | `Model:PivotTo(cf)` / `Model:GetPivot()` | một phép biến đổi trên toàn model, không phải N lần set `CFrame` từng part |
| Đặt tâm cụm | `Model.WorldPivot` | gán sau khi build xong, trước `PivotTo` |
| Tâm theo part | `Model.PrimaryPart` | `WorldPivot` được ưu tiên khi cả hai cùng tồn tại |
| Dời một part lẻ | `BasePart.CFrame`, `BasePart:PivotTo(cf)` | `PivotTo` của part cũng tính cả `PivotOffset` |
| Chia đơn vị stream | `Model.ModelStreamingMode` | `Default`, `Atomic`, `Persistent`, `PersistentPerPlayer`, `Nonatomic` |

- `PivotTo` lên part **chưa** `Anchored` là teleport: assembly giữ vận tốc cũ và đẩy văng mọi thứ chồng lên nó. Anchor trước, hoặc zero `AssemblyLinearVelocity`/`AssemblyAngularVelocity` sau khi dời.
- Part trang trí: `CanCollide = false` **không** tắt raycast. Phải set thêm `CanQuery = false` (raycast, mouse, `GetPartBoundsInBox`), `CanTouch = false` (event `Touched`), `CastShadow = false` (chi tiết nhỏ).
- `Part.Shape = Enum.PartType.Cylinder` quay theo trục **X**: `Size.X` là chiều dài, `Size.Y`/`Size.Z` là đường kính. Đổi `Shape` không đổi `Size`, nên cylinder tạo từ size mặc định ra một cái đĩa dẹt.
- Gom part theo **đơn vị stream được** (một toà nhà, một prop, một cụm đá), không gom thành container khổng lồ: `ModelStreamingMode`, LOD và `StreamingIntegrityMode` đều tính theo model.
- Nhiều bản sao của **cùng một** mesh là rẻ (instanced, một draw call). Nhiều mesh khác nhau, hoặc nhiều `UnionOperation`, thì không — mỗi cái một draw call.

## Material: cái nào thực sự đắt

| Material | Chi phí render | Vì sao |
| --- | --- | --- |
| `Enum.Material.Glass` | cao nhất trong nhóm dùng thường | khúc xạ + bắt buộc sort trong suốt; hai lớp glass chồng nhau là mất frame ngay |
| `Enum.Material.Neon` | cao khi diện tích lớn | ghi vào bloom, overdraw toàn vùng; cộng thêm `BloomEffect` thì nhoè cả màn hình |
| `Enum.Material.ForceField` | cao | shader động, không batch được |
| `Enum.Material.SmoothPlastic`, `Plastic`, `Slate`, `Concrete`, `Wood`, `Brick`, `Rock`, `Grass` | thấp | texture tĩnh, batch tốt |
| `SurfaceAppearance` trên `MeshPart` | +1 texture sample cho mỗi map | `ColorMap`/`NormalMap`/`RoughnessMap`/`MetalnessMap` — 4 map là 4 sample mỗi pixel |
| bất kỳ material + `Transparency < 1` | cao hơn cả việc chọn material | sort trong suốt + overdraw; 50 part trong suốt đắt hơn 500 part đục |

- Bề mặt tuỳ biến: `MaterialVariant` trong `MaterialService`, gán `part.MaterialVariant = "Tên"`. Chỉ áp cho `BasePart` — `Terrain` **không** nhận `MaterialVariant` lẫn `SurfaceAppearance`.
- PBR chỉ có trên `MeshPart` qua `SurfaceAppearance`. `Decal.Texture` đã bị thay bằng `ColorMapContent`.
- Quy tắc thực dụng: giảm số part trong suốt trước, giảm số material đặc biệt sau, giảm poly cuối. Thứ tự này khớp với thứ tự tác động lên frame time.

## Lighting

| Property | Ý nghĩa |
| --- | --- |
| `Lighting.LightingStyle` | `Realistic` (tự nhiên) hoặc `Soft` (stylized, bóng mềm). Thay `Lighting.Technology` đã bị supersede. |
| `Lighting.PrioritizeLightingQuality` | ưu tiên chất lượng (shadow map đi kèm `Soft`) thay vì FPS trên máy yếu |
| `Lighting.ClockTime` | 0–24, vị trí mặt trời. `Lighting.TimeOfDay` là bản string `"14:00:00"` của cùng giá trị — set cái này sẽ ghi đè `ClockTime`. |
| `Lighting.GeographicLatitude` | độ nghiêng đường đi của mặt trời theo vĩ độ |
| `Lighting.Brightness`, `Lighting.ExposureCompensation` | độ sáng tổng và bù trừ phơi sáng (dùng khi `LightingStyle` đổi làm cả map tối/sáng lệch) |
| `Lighting.Ambient` / `Lighting.OutdoorAmbient` | fill light trong nhà / ngoài trời |
| `Lighting.EnvironmentDiffuseScale` / `Lighting.EnvironmentSpecularScale` | mức skybox đóng góp vào diffuse và reflection |
| `Lighting.ShadowSoftness` | độ mềm bóng khi `LightingStyle = Soft` |

Object con của `Lighting`: `Atmosphere` (sương mù thay fog cũ), `Sky`, `BloomEffect`, `ColorCorrectionEffect`, `ColorGradingEffect`, `DepthOfFieldEffect`, `SunRaysEffect`, `BlurEffect`. `Clouds` thì nằm trong `Terrain`, không phải `Lighting`.

```luau
--!strict
-- Client: suy ra ClockTime từ đồng hồ server, không replicate mỗi frame.
local Lighting = game:GetService("Lighting")
local RunService = game:GetService("RunService")

local DAY_LENGTH_SECONDS = 20 * 60
local EPOCH = workspace:GetServerTimeNow()

RunService.RenderStepped:Connect(function()
	local days = (workspace:GetServerTimeNow() - EPOCH) / DAY_LENGTH_SECONDS
	Lighting.ClockTime = (days * 24) % 24
end)
```

- Server set `ClockTime` **một lần** lúc khởi động rồi thôi; mọi client tự suy ra từ `workspace:GetServerTimeNow()` (đồng hồ đã sync sẵn giữa các máy) nên tất cả thấy cùng một giờ, không tốn băng thông, không giật.
- Đèn cục bộ: `PointLight`, `SpotLight`, `SurfaceLight`. Mỗi đèn có `Shadows = true` là thêm một shadow map — bật cho đèn chính, tắt cho đèn trang trí.
- `Atmosphere` thay thế fog: khi có `Atmosphere` con của `Lighting`, `FogStart`/`FogEnd`/`FogColor` bị **bỏ qua hoàn toàn**.

## Terrain

```luau
--!strict
local terrain = workspace.Terrain

terrain:FillBlock(CFrame.new(0, -10, 0), Vector3.new(512, 20, 512), Enum.Material.Grass)
terrain:FillBall(Vector3.new(0, 0, 0), 24, Enum.Material.Air)      -- đục một hố
terrain:FillBlock(CFrame.new(40, -2, 0), Vector3.new(30, 4, 30), Enum.Material.Water)
terrain:FillCylinder(CFrame.new(-40, 5, 0), 20, 8, Enum.Material.Rock)
```

Với map lớn, `FillBlock` gọi hàng nghìn lần là sai cách. Dùng `ReadVoxels`/`WriteVoxels` theo chunk: mỗi voxel là **4 stud**, region phải align theo lưới 4, và index mảng là `x + (y - 1) * sizeX + (z - 1) * sizeX * sizeY` với `x`, `y`, `z` bắt đầu từ 1 (X đổi nhanh nhất, rồi Y, rồi Z).

```luau
--!strict
local terrain = workspace.Terrain

local VOXEL = 4
local CHUNK_STUDS = 64      -- bội số của 4, nếu lệch thì :ExpandToGrid(4) nới region ra ngoài
local HEIGHT_STUDS = 48

local function writeChunk(originX: number, originZ: number)
	local region = Region3.new(
		Vector3.new(originX, -HEIGHT_STUDS, originZ),
		Vector3.new(originX + CHUNK_STUDS, 0, originZ + CHUNK_STUDS)
	):ExpandToGrid(VOXEL)

	local size = region.Size / VOXEL              -- số voxel mỗi trục
	local count = size.X * size.Y * size.Z
	local materials = table.create(count, Enum.Material.Air)
	local occupancy = table.create(count, 0)      -- 0 = rỗng, 1 = đặc

	local base = region.CFrame.Position
	for z = 1, size.Z do
		for x = 1, size.X do
			local wx = base.X + (x - 1) * VOXEL
			local wz = base.Z + (z - 1) * VOXEL
			local h = math.noise(wx * 0.01, wz * 0.01) * 20 + 8
			for y = 1, size.Y do
				if base.Y + (y - 1) * VOXEL <= h then
					local i = x + (y - 1) * size.X + (z - 1) * size.X * size.Y
					materials[i] = Enum.Material.Grass
					occupancy[i] = 1
				end
			end
		end
	end

	terrain:WriteVoxels(region, VOXEL, materials, occupancy)
end

for x = -256, 256 - CHUNK_STUDS, CHUNK_STUDS do
	for z = -256, 256 - CHUNK_STUDS, CHUNK_STUDS do
		writeChunk(x, z)
		task.wait() -- nhả frame giữa các chunk, nếu không server đứng hình
	end
end
```

- `WriteVoxels` **ghi đè** toàn bộ region (cả voxel Air), không merge với terrain có sẵn. Muốn sửa cục bộ thì `ReadVoxels` trước, sửa mảng, ghi lại.
- Một lần gọi bị giới hạn **4.194.304 voxel** (ví dụ region 256×256×64 voxel = 1024×1024×256 stud). Vượt là lỗi, không phải chậm.
- `terrain:Clear()` xoá sạch. Nước: `Terrain.WaterColor`, `WaterWaveSize`, `WaterWaveSpeed`, `WaterTransparency`, `WaterReflectance`.
- Heightmap procedural: `math.noise(x * scale, z * scale, seed)` cộng nhiều octave; `Random.new(seed)` cho kết quả tất định. Sinh trên server, hoặc đẩy phần tính toán sang Parallel Luau nếu map lớn.

### Terrain voxel hay chunk bằng part

| Tiêu chí | Terrain voxel | Chunk ghép từ part |
| --- | --- | --- |
| Độ phân giải | cố định 4 stud/voxel | tuỳ ý, xuống dưới 0.05 stud |
| Draw call | gộp nội bộ theo chunk, rất ít | 1+ mỗi part; 5.000 part là 5.000 draw call |
| Streaming | theo `Terrain`, không tách rời từng vùng | tách rời theo `Model`, `ModelStreamingMode` điều khiển được |
| Sửa lúc runtime | `WriteVoxels` rẻ theo vùng nhưng rebuild chunk quanh đó | đổi `CFrame`/`Size` rẻ, nhưng nhiều part = nhiều assembly physics |
| Va chạm | khít theo voxel, không có lỗ hổng giữa các mảnh | khít theo hình học, dễ hở ở mép |
| Material | chỉ material built-in của terrain | mọi `Enum.Material` + `MaterialVariant` + `SurfaceAppearance` |
| Chi tiết < 4 stud | không làm được (bậc thang lộ rõ ở sườn dốc) | làm được |
| Chi phí bộ nhớ | một khối lượng lớn, luôn hiện diện | chỉ tốn khi part được stream vào |

Cách chọn: địa hình tự nhiên, diện rộng, không cần sửa → terrain. Địa hình cách điệu, module, cần phá huỷ hoặc đổi material → part. Map lớn thường lai: terrain cho nền, part cho chi tiết và prop.

## CSG lúc runtime và phá huỷ (GeometryService)

```luau
--!strict
local GeometryService = game:GetService("GeometryService")

-- Chỉ chạy trên server. CSG là async và rất đắt: một hàng đợi, một phép mỗi part.
local function carve(wall: BasePart, cutter: BasePart): { Instance }?
	local ok, results = pcall(function()
		return GeometryService:SubtractAsync(wall, { cutter }, {
			CollisionFidelity = Enum.CollisionFidelity.Default,
			RenderFidelity = Enum.RenderFidelity.Automatic,
			SplitApart = true, -- mảnh rời nhau thành part riêng
		})
	end)
	if not ok or not results then
		return nil -- operation fail: giữ nguyên wall, đừng destroy
	end
	for _, piece in results do
		if piece:IsA("BasePart") then
			piece.Anchored = wall.Anchored
			piece.Parent = wall.Parent
		end
	end
	wall:Destroy()
	cutter:Destroy()
	return results
end
```

| API | Kết quả |
| --- | --- |
| `UnionAsync(part, others, options)` | một part hợp nhất |
| `IntersectAsync(part, others, options)` | phần giao |
| `SubtractAsync(part, others, options)` | phần bị trừ; `SplitApart = true` trả nhiều mảnh rời |
| `FragmentAsync(part, sites)` | vỡ kiểu Voronoi theo danh sách điểm |
| `GenerateFragmentSites(part, gridSize)` | sinh điểm cho `FragmentAsync` |
| `SweepPartAsync(part, cframes)` | ép hình part dọc theo chuỗi `CFrame` |
| `CalculateConstraintsToPreserve(part, results)` | danh sách weld/constraint cần giữ khi thay part |

- Mọi hàm trả về part **chưa có parent**; phải tự gán `Parent` và `Anchored`, nếu không chúng rơi và biến mất.
- `CollisionFidelity` (`Default`, `Hull`, `Box`, `PreciseConvexDecomposition`) đánh đổi độ khít va chạm với chi phí physics; `RenderFidelity` (`Automatic`, `Precise`, `Performance`) đánh đổi hình với LOD.
- Chạy trên server, rate-limit theo player, và **dọn mảnh**: `Debris:AddItem(piece, 10)` hoặc pool. Mảnh vụn không dọn là nguồn tụt FPS phổ biến nhất của game phá huỷ.
- Đừng gọi CSG trong vòng lặp mỗi frame hay từ `Touched` trực tiếp: mỗi phép là một job nặng, chồng vài chục phép là server đứng.

## ProceduralModel

`ProceduralModel` tự sinh lại nội dung từ một **generator ModuleScript** khai báo `Attributes` (tham số) và hàm `OnGenerate(params, targetContainer)`. Chạy được cả lúc edit (có undo/redo, hợp tác Team Create) lẫn runtime, nên cùng một generator dùng cho cả pipeline dựng map và sinh map theo seed trong game. Sinh từ Studio, từ Assistant, hoặc qua Studio MCP (`generate_procedural_model`). Model lấy từ Creator Store được sandbox tự động.

## EditableMesh và EditableImage

`AssetService:CreateEditableMesh()`, `CreateEditableMeshAsync(content)`, `CreateEditableImage()`, `CreateEditableImageAsync(content)` cho phép sửa hình học và pixel lúc runtime (biến dạng terrain chunk, vẽ lên bề mặt, avatar tuỳ biến).

- Hiển thị mesh đã sửa: `AssetService:CreateMeshPartAsync(Content.fromObject(editableMesh))` — không gán trực tiếp vào `MeshPart.MeshId`.
- Game đã publish yêu cầu chủ game xác minh **ID + 13+** và bật **Enable Mesh / Image APIs** trong Creator Dashboard; thiếu một trong hai thì API trả lỗi ở production dù chạy tốt trong Studio.
- Budget bộ nhớ tính theo client và khá chặt: mesh `FixedSize` (khai báo trước số vertex/face) rẻ hơn nhiều so với mesh co giãn.
- Chỉ load được asset thuộc sở hữu chủ game hoặc được chia sẻ cho game.

## Hiệu ứng môi trường

| Object | Dùng cho | Điểm cần nhớ |
| --- | --- | --- |
| `ParticleEmitter` | khói, lửa, bụi, mưa | `:Emit(n)` cho burst; `Rate` cho dòng liên tục; `LockedToPart` quyết định hạt đi theo part hay đứng yên trong world |
| `Beam` | laser, dây, tia sáng | cần `Attachment0` và `Attachment1`; `Width0`/`Width1`, `CurveSize0` |
| `Trail` | vệt kiếm, đạn | cần hai `Attachment` trên part **đang di chuyển** |
| `Highlight` | outline/fill cho model | số lượng hiển thị đồng thời bị giới hạn, không vẽ trên `Terrain` |
| `Explosion` | nổ | hiệu ứng thuần: `BlastPressure = 0`, `DestroyJointRadiusPercent = 0` |
| `PointLight`/`SpotLight`/`SurfaceLight` | đèn cục bộ | `Shadows = true` chỉ cho đèn chính |

- Sinh hiệu ứng mỹ phẩm ở **client** (mỗi máy tự thấy), không replicate từ server. Dọn bằng `Debris:AddItem(obj, seconds)` hoặc pool.
- `Beam`/`Trail`/`ParticleEmitter` nằm trong part `Anchored` đứng yên vẫn chạy, nhưng `Trail` thì không: nó vẽ theo quỹ đạo, không có chuyển động thì không có vệt.

## Bẫy

- **Map mới dựng bị văng hoặc xuyên qua nhau sau khi `PivotTo`** — part chưa `Anchored` nên teleport giữ nguyên vận tốc cũ — anchor trước khi dời, hoặc zero `AssemblyLinearVelocity` và `AssemblyAngularVelocity` sau đó.
- **Click/raycast trúng một part vô hình** — `CanCollide = false` không tắt `CanQuery` — set `CanQuery = false` (và `CanTouch = false`) cho mọi part trang trí.
- **Chỉnh `Lighting.FogEnd`/`FogColor` mà sương không đổi** — có `Atmosphere` con của `Lighting` đang ghi đè toàn bộ fog cũ — xoá `Atmosphere` hoặc chỉnh `Atmosphere.Density`/`Haze`/`Color` thay vì fog.
- **Chu kỳ ngày/đêm giật và tốn băng thông khi đông người** — set `Lighting.ClockTime` mỗi `Heartbeat` trên server, replicate 30–60 lần/giây — server set một lần, client tự suy ra từ `workspace:GetServerTimeNow()`.
- **Terrain ghi ra bị lệch nửa voxel, mất một dải ở mép** — region không align lưới 4 stud — luôn `:ExpandToGrid(4)` và chọn kích thước chunk là bội số của 4.
- **`WriteVoxels` báo lỗi thay vì chậm** — region vượt 4.194.304 voxel — chia nhỏ chunk, yield giữa các chunk.
- **Đào terrain xong part xung quanh vẫn lơ lửng** — terrain và part là hai hệ va chạm độc lập, không có gì tự nâng đỡ part — dựng part theo đúng heightmap đã dùng, hoặc anchor và chấp nhận.
- **`SubtractAsync` trả `nil` ở lần thứ hai** — part nguồn đã bị `Destroy()` sau lần đầu, hoặc một phép CSG khác đang chạy trên cùng part — giữ tham chiếu tới kết quả mới, và xếp hàng đợi để mỗi part chỉ có một phép tại một thời điểm.
- **Bắn vài chục phát là server tụt FPS** — mỗi viên đạn một phép CSG cộng mảnh vụn không ai dọn — rate-limit, `Debris:AddItem` cho từng mảnh, pool part thay vì tạo mới.
- **`Highlight` không hiện** — adornee là `Terrain`, hoặc đã vượt giới hạn số highlight đồng thời — dùng `SelectionBox`/`BillboardGui`, hoặc chỉ highlight model nhỏ và huỷ khi không cần.
- **`Trail` không vẽ vệt** — part `Anchored` và không di chuyển, hoặc thiếu `Attachment1` — gắn trail vào part thật sự chuyển động, đủ hai attachment.
- **Hạt bụi đứng yên giữa không trung khi part bay đi** — `LockedToPart = false` — bật `LockedToPart` nếu muốn hạt đi theo vật thể.
- **Nổ một phát là cả map bay** — `Explosion` mặc định tác động physics — đặt `BlastPressure = 0` và `DestroyJointRadiusPercent = 0` cho hiệu ứng thuần.
- **Terrain không nhận màu/material tuỳ biến** — `MaterialVariant` và `SurfaceAppearance` không áp cho voxel — dùng material built-in, hoặc chuyển vùng đó sang part.
- **`CreateEditableMesh` chạy tốt trong Studio nhưng lỗi khi publish** — chưa xác minh ID + 13+ hoặc chưa bật Enable Mesh / Image APIs — bật trong Creator Dashboard trước khi test trên production.
