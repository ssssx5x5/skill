# Hiệu ứng quy mô khổng lồ

Dùng khi thứ bạn dựng **lớn hơn một người chơi vài chục đến vài trăm lần**: bom hạt nhân, thiên thạch, vụ nổ trùm, sập map, siêu tân tinh, cột sáng thần thánh.

Ở quy mô này, mọi thứ học được ở quy mô nhỏ đều **sai theo một cách riêng**:

- `Part.Size` bị engine giới hạn → khối lớn phải ghép từ nhiều mảnh.
- Một `ParticleEmitter` không đủ tạo khối → hình do **bố cục nhiều emitter** quyết định.
- Camera không lùi đủ thì đứng *bên trong* hiệu ứng và chỉ thấy sương.
- Đĩa phẳng dán lên đất trông như decal dán sai → phải bám địa hình thật.

Đọc kèm: `vfx-sfx.md` (6 lớp, nhịp), `animation.md` mục 5 (canh khung, thoát an toàn), `environment.md` (terrain), `procedural-modeling.md` mục 7 (đặt part lên mặt cong).

## Mục lục

1. Hiệu chỉnh tỉ lệ: ba giới hạn cứng của engine
2. Miệng hố bám địa hình
3. Vết nứt phát sáng
4. Khối khói khổng lồ: hình do emitter, không do hạt
5. Sóng xung kích
6. Bảng pha tuyệt đối
7. Số tham chiếu (bom hạt nhân)
8. Checklist trước khi báo xong

---

## 1. Hiệu chỉnh tỉ lệ: ba giới hạn cứng của engine

### 1.1 `Part.Size` tối đa 2048 stud mỗi trục

Đặt `Size = Vector3.new(8192, 16, 8192)` **không báo lỗi** — engine kẹp về 2048 và im lặng. Triệu chứng: `pcall` trả `true`, `Size` đọc lại vẫn là 2048.

```lua
-- Đừng tin pcall. Đọc lại giá trị.
local ok = pcall(function()
	baseplate.Size = Vector3.new(8192, 16, 8192)
end)
if baseplate.Size.X < 8000 then
	warn("[Ground] Size bị kẹp ở 2048, cần ghép tile")
end
```

Cách xử lý: **ghép lưới tile 2048**. Không cần khít tuyệt đối, chỉ cần phủ hết bán kính ảnh hưởng.

```lua
local function tileGround(center: Vector3, radius: number, color: Color3, material: Enum.Material)
	local T = 2048
	local n = math.ceil(radius / T)
	local folder = Instance.new("Folder")
	folder.Name = "GroundTiles"
	for ix = -n, n do
		for iz = -n, n do
			if not (ix == 0 and iz == 0) then -- ô gốc đã có baseplate
				local p = Instance.new("Part")
				p.Name = string.format("Tile_%d_%d", ix, iz)
				p.Size = Vector3.new(T, 16, T)
				p.CFrame = CFrame.new(center + Vector3.new(ix * T, -8, iz * T))
				p.Color = color
				p.Material = material
				p.Anchored = true
				p.CanCollide = false -- chỉ để nhìn, không cản đường
				p.CanQuery = false
				p.CanTouch = false
				p.TopSurface = Enum.SurfaceType.Smooth
				p.BottomSurface = Enum.SurfaceType.Smooth
				p.Parent = folder
			end
		end
	end
	folder.Parent = workspace
	return folder
end
```

Nếu không muốn sửa map, hãy **giảm bán kính ảnh hưởng** thay vì mở rộng đất — người chơi không thấy mép đĩa cháy nếu nó nằm ngoài tầm nhìn.

### 1.2 Bán kính nổ phải nhỏ hơn vùng nhìn thấy

`Radius` là bán kính sát thương. `Crater` (miệng hố) nên bằng khoảng **20–45%** `Radius`; đất cháy bằng khoảng **2× Crater**. Nếu đất cháy lớn hơn map, nó sẽ bị cắt thành hình vuông ở mép — đó là lỗi nhìn thấy được, không phải lỗi logic.

### 1.3 Camera: xem mục 5.3 của `animation.md`

Công thức `frameDistance(height, width, fov)` cho ra đúng con số bạn cần. Kiểm chứng bằng số thật: cây nấm cao 1 843 stud, nắp rộng 4 992 stud, FOV 60, khung 16:9 → công thức trả **2 918 stud**, và khoảng cách dùng được khi test là 2 900–3 000. Dùng công thức, đừng thử mò.

---

## 2. Miệng hố bám địa hình

Đĩa phẳng (`Part` hình trụ dán lên đất) chỉ đúng trên mặt phẳng tuyệt đối. Trên đất gồ ghề nó **lơ lửng ở chỗ trũng và lún ở chỗ gò** — người chơi nhận ra ngay.

Làm hai lớp: **terrain thật** (đổi vật liệu) + **decal bám mặt** (cho part/địa hình không phải Terrain).

### 2.1 Đổi vật liệu Terrain

`ReplaceMaterial` chỉ có tác dụng trên `Terrain`. Phải `pcall` vì `Region3` ngoài biên terrain sẽ lỗi:

```lua
local TERRAIN_MATS = {
	Enum.Material.Grass, Enum.Material.Ground, Enum.Material.Rock,
	Enum.Material.Sand, Enum.Material.Snow, Enum.Material.Mud,
	Enum.Material.Slate, Enum.Material.LeafyGrass, Enum.Material.Sandstone,
	Enum.Material.Limestone, Enum.Material.Basalt, Enum.Material.CrackedLava,
	Enum.Material.Asphalt, Enum.Material.Concrete, Enum.Material.Pavement,
	Enum.Material.Clay,
}

local function burnTerrain(pos: Vector3, radius: number)
	local t = workspace.Terrain
	local half = Vector3.new(radius, radius * 0.85, radius)
	-- độ phân giải lưới co giãn theo bán kính: 4 stud ở hố nhỏ, tới 40 ở hố khổng lồ
	local res = math.clamp(math.floor(radius / 8), 4, 40)
	local ok, region = pcall(function()
		return Region3.new(pos - half, pos + half):ExpandToGrid(res)
	end)
	if not ok then
		return
	end
	for _, mat in ipairs(TERRAIN_MATS) do
		pcall(function()
			t:ReplaceMaterial(region, res, mat, Enum.Material.Basalt)
		end)
	end
end
```

`res` cố định 4 stud trên một hố bán kính 800 sẽ quét hàng trăm nghìn ô và treo vài giây. Co giãn theo bán kính.

### 2.2 Decal bám mặt cho part/địa hình bất kỳ

Quét lưới từ trên xuống, mỗi ô đặt một phiến mỏng **xoay theo pháp tuyến** của mặt bắt được. Đây là kỹ thuật cốt lõi — cùng một đoạn code dùng cho đất cháy, tuyết, rêu, vết máu, vũng nước.

```lua
local function burnSurface(pos: Vector3, radius: number, folder: Folder)
	local params = RaycastParams.new()
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.FilterDescendantsInstances = folder and { folder } or {}
	params.IgnoreWater = true

	local step = math.max(4, radius / 14) -- ~28x28 ô, đủ dày, không quá nặng
	local n = math.floor(radius / step)
	local reach = radius * 3 + 120
	local count = 0

	for ix = -n, n do
		for iz = -n, n do
			local dx, dz = ix * step, iz * step
			local d = math.sqrt(dx * dx + dz * dz)
			if d <= radius then
				local from = Vector3.new(pos.X + dx, pos.Y + reach * 0.55, pos.Z + dz)
				local hit = workspace:Raycast(from, Vector3.new(0, -reach, 0), params)
				if hit and not hit.Instance:IsA("Terrain") then
					local t = math.clamp(d / radius, 0, 1) ^ 0.75 -- mờ dần ra mép
					local at = hit.Position + hit.Normal * 0.12

					local p = Instance.new("Part")
					p.Name = "Scorch"
					-- 1.42 để các ô chồng mép, không hở lưới
					local w = step * (1.42 + math.random() * 0.16)
					p.Size = Vector3.new(w, w, 0.1)
					-- lookAt(at, at + normal) làm phiến nằm phẳng trên mặt nghiêng
					p.CFrame = CFrame.lookAt(at, at + hit.Normal)
						* CFrame.Angles(0, 0, math.random() * math.pi * 2)
					p.Color = Color3.fromRGB(58, 52, 46):Lerp(Color3.fromRGB(20, 18, 17), t)
					p.Material = Enum.Material.Slate
					p.Anchored = true
					p.CanCollide = false
					p.CanQuery = false
					p.CanTouch = false
					p.CastShadow = false
					p.Transparency = 0.02 + t * 0.14
					p.Parent = folder
					count = count + 1
				end
			end
		end
	end
	return count
end
```

Bốn điểm quyết định chất lượng:

1. **`Size = step * 1.42`** — nhỏ hơn thì hở lưới thành từng ô rời; lớn hơn thì các phiến cắt nhau lộ cạnh cứng.
2. **`hit.Normal * 0.12`** — nâng lên khỏi mặt để không z-fighting. Đừng nâng quá 0.3, sẽ thấy nó lơ lửng.
3. **`t = (d/radius)^0.75`** — số mũ < 1 làm mép mờ nhanh, hố có tâm đậm. Số mũ 1 cho ra đĩa phẳng lì.
4. **`CanQuery = false`** — nếu để `true`, lần nổ sau raycast sẽ bắt chính các phiến này và sinh hiệu ứng chồng lên nhau.

`workspace:Raycast` **bỏ qua Terrain**. Nên đất Terrain cần cả hai hàm: `burnTerrain` cho vật liệu, `burnSurface` cho part.

---

## 3. Vết nứt phát sáng

Vết nứt là thứ bán được "mặt đất đang vỡ", rẻ hơn nhiều so với mesh nứt thật. Mỗi vết là một chuỗi đốt ngắn đi theo hướng ngẫu nhiên, bám địa hình, thu hẹp dần ra mép.

```lua
local function groundCracks(pos: Vector3, radius: number, folder: Folder, rays: number?)
	rays = rays or 20
	local params = RaycastParams.new()
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.FilterDescendantsInstances = { folder }
	params.IgnoreWater = true

	local HOT = Color3.fromRGB(255, 148, 52)

	for i = 1, rays do
		local ang = (i / rays) * math.pi * 2 + (math.random() - 0.5) * 0.35
		local dir = Vector3.new(math.cos(ang), 0, math.sin(ang))
		local reach = radius * (0.55 + math.random() * 0.45)
		local segLen = math.max(6, radius / 26)
		local t = 0

		while t < reach do
			local at2 = pos + dir * t + Vector3.new(
				(math.random() - 0.5) * segLen * 0.7, 0,
				(math.random() - 0.5) * segLen * 0.7
			)
			local hit = workspace:Raycast(at2 + Vector3.new(0, 400, 0), Vector3.new(0, -900, 0), params)
			if hit then
				local up = hit.Normal
				local fwd = dir - up * dir:Dot(up)
				if fwd.Magnitude > 1e-3 then
					fwd = fwd.Unit
					-- right = up:Cross(fwd). Dùng fwd:Cross(up) là hệ trái -> mặt bị lật
					local right = up:Cross(fwd)
					local k = 1 - (t / reach)
					local w = math.max(0.6, segLen * 0.55 * k)

					local p = Instance.new("Part")
					p.Name = "Crack"
					p.Size = Vector3.new(w, segLen * 1.35, 0.25)
					p.CFrame = CFrame.fromMatrix(hit.Position + up * 0.18, right, up, fwd)
					p.Color = HOT
					p.Material = Enum.Material.Neon
					p.Anchored = true
					p.CanCollide = false
					p.CanQuery = false
					p.CanTouch = false
					p.CastShadow = false
					p.Transparency = 0.15 + (1 - k) * 0.55
					p.Parent = folder
				end
			end
			t = t + segLen * (0.7 + math.random() * 0.5)
		end
	end
end
```

Làm mờ dần bằng `Transparency` theo `Tween` sau 2–4 giây, không để nằm mãi: vết nứt Neon tồn tại vĩnh viễn trông như lỗi.

---

## 4. Khối khói khổng lồ: hình do emitter, không do hạt

Ở quy mô nhỏ, một `ParticleEmitter` phun cầu là đủ. Ở quy mô khổng lồ, hạt chồng lên nhau thành một cục tròn không có hình. **Hình khối phải do vị trí emitter quyết định.**

Bố cục cây nấm (dùng được cho bất kỳ khối tròn có cột nào):

| Tầng | Số host | Cách rải | Vai trò |
|---|---|---|---|
| Thân | 14 | Cột thẳng đứng từ chân lên đáy nắp, đường kính loe ở đáy | Cột |
| Vành cuộn | 14 | Vòng tròn quanh đáy nắp, hơi thấp hơn | Chỗ nắp "cuộn" ra |
| Nắp | 34 | **Cầu rải đều theo góc vàng** quanh tâm nắp | Khối nắp |
| Sóng đất | 16 | Vòng tròn ở chân, bán kính lớn | Bụi đất bốc lên |

Rải đều trên mặt cầu bằng góc vàng — không dùng `math.random()` cho việc này, nó tạo cụm:

```lua
local GOLDEN = math.rad(137.507764) -- 2.399963 rad
for i = 1, N do
	local y01 = (i - 0.5) / N          -- -1..1 theo trục Y
	local r = math.sqrt(1 - y01 * y01) -- bán kính vòng tròn tại độ cao đó
	local a = i * GOLDEN
	local at = center + Vector3.new(math.cos(a) * r, y01, math.sin(a) * r) * radius
	-- đặt emitter tại `at`
end
```

Tham số hạt đã kiểm chứng cho nắp đường kính ~2 500 stud: `Size` 20–40, `Speed` 4–14, `Rate` 7, `SpreadAngle` 25°. Tăng `Size` lên 90 là mất hình ngay (xem `vfx-sfx.md` mục 1.3).

Màu phải theo **độ cao**, không theo một màu duy nhất: đáy nắp hắt sáng từ cầu lửa, đỉnh nguội dần.

```lua
local HOT = Color3.fromRGB(212, 130, 78)  -- đáy nắp, hắt sáng
local MID = Color3.fromRGB(128, 104, 92)  -- giữa
local TOP = Color3.fromRGB(74, 66, 64)    -- đỉnh nguội
local DEAD = Color3.fromRGB(44, 39, 38)   -- hạt tàn

local function capColor(y01: number): Color3
	y01 = math.clamp(y01, 0, 1)
	if y01 < 0.45 then
		return HOT:Lerp(MID, y01 / 0.45)
	end
	return MID:Lerp(TOP, (y01 - 0.45) / 0.55)
end
```

---

## 5. Sóng xung kích

Sóng xung kích đọc ra "phẳng" nếu chỉ là một `Part` dẹt nở ra. Cần **ba lớp** cùng lúc:

1. **Vành trên mặt đất** — vòng mỏng nở ra với `Quad/Out`, trong suốt dần.
2. **Vỏ cầu** — `Part` Ball, `Transparency` 0.85–0.95, `Material = ForceField` hoặc `Neon`, nở nhanh hơn vành.
3. **Bụi cuốn** — emitter ở vành, phun ra ngoài, `Drag` cao.

Tất cả dùng cùng một mốc thời gian và cùng một `EasingStyle.Quad, EasingDirection.Out` — nở rất nhanh lúc đầu rồi chậm lại. `Linear` làm nó đọc ra là "animation", không phải "vật lý".

Đừng làm sáng cả map: `PointLight` với `Brightness 30` và `Range = Radius * 2.2` sẽ xoá trắng mọi thứ trong khung. Giữ `Brightness ≤ 12`, `Range ≤ Radius * 1.15`.

---

## 6. Bảng pha tuyệt đối

Mốc thời gian cho vụ nổ khổng lồ, tính từ `t = 0` là lúc chạm đất. Dùng làm điểm khởi đầu rồi chỉnh theo cảm giác:

| t (s) | Pha | Việc phải xảy ra |
|---|---|---|
| −4.0 → 0 | **Rơi** | Vật thể rơi từ trên cao, trail khói, whoosh, cảnh báo điểm rơi nhấp nháy |
| 0.00 | **Chạm** | Tiếng đập, bụi bật lên, camera khựng 1 frame |
| 0.00–0.10 | **Flash** | `ColorCorrection.Brightness` → 2, `PointLight` đỉnh, màn hình trắng |
| 0.05–0.15 | **Đỉnh sáng** | Lõi Neon, hạt lửa bắn ra, shake bắt đầu |
| 0.10–0.80 | **Sóng xung kích** | Vành + vỏ cầu + bụi cuốn, `Quad/Out` |
| 0.20–3.00 | **Cột + nắp** | Emitter bật dần: thân trước, vành sau, nắp cuối (`Exponential/Out` cho cột, `Sine` cho nắp) |
| 0.30–1.20 | **Camera** | Kéo ra xa dần, FOV thu lại, letterbox vào |
| 0.80–8.00 | **Hậu quả** | Đất cháy, vết nứt, mảnh vụn rơi, ember bay |
| 3.00–20.0 | **Tan** | Nắp nguội màu, khói loãng, `Transparency` → 1, dọn dẹp |

Bốn nguyên tắc nhịp:

- **Flash phải ngắn hơn 0.15s.** Dài hơn là chói, không phải chớp.
- **Va chạm dồn trong 100ms.** Lệch nhau vài chục ms là mất lực.
- **Dư âm dài gấp 10–20 lần va chạm.** Đây là chỗ phân biệt "nổ to" và "nổ khổng lồ".
- **Không có pha nào bắt đầu cùng lúc với pha khác** trừ cú va chạm. Rải mốc ra.

---

## 7. Số tham chiếu (bom hạt nhân)

Bộ số đã dùng và test thật, làm mốc khi cần một vụ nổ "to gấp N lần":

| Tham số | Fat Man | Little Boy | Ghi chú |
|---|---|---|---|
| `Radius` (sát thương) | 1950 | 1500 | |
| `Crater` (miệng hố) | 540 | 380 | ≈ 26% Radius; đất cháy = `Crater × 2.2` ≈ 60% Radius |
| `Dmg` | 260 | 170 | sát thương mỗi nhịp cháy |
| `BurnDps` / `BurnTime` | 18 / 40s | 12 / 30s | cháy tiếp cả sau khi respawn |
| `FallTime` | 9.0s | 8.0s | rơi chậm để kịp cảnh báo |
| `DropHeight` | 6400 | 6400 | |
| `Shake` | 1.45 | 1.00 | hệ số nhân intensity |
| `CamDist` | 3300 | 2850 | ≈ `frameDistance(1843, 4992, 60)` = 2918 |
| Thân bom (dài × đường kính × sải đuôi) | 116 × 54 × 48 | 107 × 25 × 34 | `Scale = 10` nhân lên model |
| Nắp khói | cao 1843, rộng 4992 | ~0.77× | |

Tỉ lệ đọc được: **nắp rộng gấp ~2.5 lần bán kính sát thương**, **cột cao xấp xỉ bán kính**. Lệch khỏi khoảng này thì hoặc nấm lùn (trông như đám mây), hoặc cột cao lêu nghêu (trông như ống khói).

Với cây nấm, **thân phải mảnh**: đường kính thân ≈ **16%** đường kính nắp. 30% là đọc ra "cây nấm bằng gỗ", không phải khói.

---

## 8. Checklist trước khi báo xong

- [ ] `Part.Size` sau khi gán đã **đọc lại** và nằm trong 2048? Nếu không, đã ghép tile chưa?
- [ ] Bán kính đất cháy nằm gọn trong map nhìn thấy được?
- [ ] Đất cháy bám **mọi** địa hình (thử trên gò, dốc, part nghiêng), không chỉ mặt phẳng?
- [ ] Vết nứt dùng `right = up:Cross(fwd)` (không phải `fwd:Cross(up)`)?
- [ ] `CanQuery = false` trên mọi phiến decal/vết nứt?
- [ ] Hình khói do **bố cục emitter** quyết định, không phải một emitter phun cầu?
- [ ] `Size`/`Speed`/`SpreadAngle` của hạt nằm trong ngưỡng ở `vfx-sfx.md` mục 1.3?
- [ ] Camera đứng **ngoài** khối, tính bằng `frameDistance`, không thử mò?
- [ ] Đủ ≥5 trong 6 lớp hiệu ứng?
- [ ] Mọi thứ sinh ra đều có đường huỷ (`Debris`, `task.delay`, `:Destroy()`)?
- [ ] Người chơi chết giữa cutscene vẫn không kẹt camera/điều khiển?
- [ ] Đã **nhìn** bằng ảnh chụp hoặc preview tĩnh, không chỉ đọc số liệu?
