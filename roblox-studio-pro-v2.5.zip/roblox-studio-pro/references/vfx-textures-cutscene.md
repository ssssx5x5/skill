# Texture VFX và Cutscene timeline

> Khi nào dùng: hiệu ứng "rẻ tiền" vì hạt chỉ là chấm mềm mặc định; hoặc cần cutscene có camera + sự kiện đúng nhịp.

## 1. Texture VFX (scripts/gen_vfx_textures.py)

Sinh PNG trắng + alpha bằng toán (không cần AI, không tốn credit): `glow, smoke_puff, spark, ring, shockwave, slash, streak, smoke_flipbook, fire_flipbook`.

```bash
python scripts/gen_vfx_textures.py --out vfx_tex --size 256
```

Quy trình:
1. Chạy script → 9 PNG. **Mở ảnh xem** trước khi upload (alpha có đúng hình không).
2. Upload thủ công: Studio → Asset Manager → Bulk Import (upload từ script không làm được). Lấy `rbxassetid://<id>` — **id thật, không bịa**; chưa có id thì để engine texture mặc định.
3. Gán: `VFX.SetTextures({ Fire = "rbxassetid://...", Smoke = "...", Sparks = "..." })` hoặc `VFX.Emitter(part, "Fire", 1, { Texture = "rbxassetid://..." })`.
4. Flipbook: `VFX.UseFlipbook(emitter, true)` (lưới 4×4, 16 khung). Lifetime của hạt = thời lượng chơi hết 16 khung.
5. Texture để **trắng/xám**; màu do `ParticleEmitter.Color` quyết (đổi màu theo thời gian miễn phí). `LightEmission = 1` cho lửa/phép (cộng sáng), `0` cho khói.

Dùng texture nào cho gì: `slash` → `Beam.Texture` hoặc Decal phẳng xoay theo hướng chém; `ring/shockwave` → Part dẹt có `SurfaceGui`/`Decal` hoặc emitter `Orientation = FacingCameraWorldUp`; `glow` → hạt lõi sáng + `Bloom`; `streak` → `Trail`/`Beam`.

Giới hạn thật: texture sinh bằng toán là *nền tảng sạch*, không thay hoạ sĩ VFX. Muốn đẹp hơn: dùng `ImageGen` + `image1` tinh chỉnh (tốn credit — hỏi trước), rồi giữ nguyên quy ước trắng + alpha.

## 2. CutsceneKit

`templates/CutsceneKit.lua` (client): một vòng `BindToRenderStep`, camera keyframe với ease, sự kiện chạy đúng một lần, letterbox, khoá điều khiển, bỏ qua bằng Space/Enter.

Bảo đảm: camera, FOV, điều khiển, letterbox được khôi phục ở **mọi** đường thoát — hết giờ, Skip, Cancel, nhân vật chết, lỗi giữa chừng — qua một hàm `cleanup` duy nhất. Sau khi khôi phục có kiểm lại `CameraType` (đọc lại, không tin phép gán).

Quy tắc dựng:
- Lập **bảng thời gian** trước (đặt shot, nhịp, sự kiện) rồi mới viết keyframe. Mỗi shot 1.5–4 s; đổi hướng nhìn đột ngột = cắt (ease `lin` với 2 keyframe cách 0.01 s).
- Tọa độ camera **tính từ chủ thể** (`target + offset`), không đoán toạ độ thế giới.
- Sự kiện VFX/SFX đặt ở `Events` theo `t`, không `task.wait` chuỗi.
- `Cut.Validate(keys)` bắt keyframe lùi thời gian; test toán: `cd templates && LUAU=<luau> bash tests/run_cutscene_test.sh`.
- Tween camera bằng `Completed:Wait()` bị cấm (có thể không bao giờ fire) — kit này không dùng.

Chưa kiểm trong Studio: phần camera/UI/PlayerModule. Chạy một cutscene 3 s có `Skippable` và kiểm Output có `[CutsceneKit] kết thúc: ...` cùng camera quay về bình thường.
