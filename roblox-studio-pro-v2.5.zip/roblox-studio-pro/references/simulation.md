# Mô phỏng: vật lý, nhân vật và NPC

> Khi nào dùng: khi một part bay sai, một nhân vật bị văng, một viên đạn trượt, một NPC kẹt góc, hoặc khi cần quyết định cái gì do server mô phỏng và cái gì để client predict.

## Truy vấn không gian

Dùng truy vấn hình học cho mọi quyết định gameplay; `Touched` chỉ để làm trigger.

| API | Hình dạng | Dùng cho |
| --- | --- | --- |
| `workspace:Raycast(origin, direction, params)` | tia | hitscan, line of sight, ground check |
| `workspace:Blockcast(cframe, size, direction, params)` | hộp quét | đạn dày, vùng chém, kiểm tra mặt đất có bề rộng |
| `workspace:Spherecast(origin, radius, direction, params)` | cầu quét | đạn tròn, va chạm mềm |
| `workspace:GetPartBoundsInBox(cframe, size, params)` | hộp (bounding box) | hitbox melee, vùng an toàn |
| `workspace:GetPartBoundsInRadius(center, radius, params)` | cầu (bounding box) | nổ, perception, vùng aggro |
| `workspace:GetPartsInPart(part, params)` | hình học chính xác | overlap đắt tiền, chỉ khi bounding box không đủ |

- Độ dài `direction` **chính là** tầm xa tối đa; không có tham số range riêng.
- `RaycastResult` trả `Instance`, `Position`, `Normal`, `Material`, `Distance`. `Normal` là pháp tuyến bề mặt trúng, dùng để đặt decal/hiệu ứng.
- Tái dùng object params: tạo một lần, chỉ đổi `FilterDescendantsInstances` hoặc `params:AddToFilter(instance)`. Tạo mới mỗi phát bắn là rác GC trong combat.
- `FilterType = Enum.RaycastFilterType.Exclude` để loại nhân vật người bắn; `Include` khi chỉ muốn một nhóm.
- `RespectCanCollide = true` bỏ qua part không va chạm; `CollisionGroup = "Name"` lọc theo nhóm; `MaxParts` (ví dụ 50) chặn kết quả khổng lồ từ `GetPartBoundsInRadius`.
- `IgnoreWater = true` trên `RaycastParams` nếu không muốn terrain nước chặn tia.
- Deprecated, đừng dùng: `FindPartOnRay*`, `Ray.new`, `FindPartsInRegion3*`.
- Client chỉ thấy part đã stream vào, nên mọi kiểm tra authoritative phải chạy trên server.

## `Touched`: biết giới hạn của nó

`Touched` do physics engine phát, chỉ khi có tiếp xúc vật lý thật, và do **bên mô phỏng part đó** phát — client sở hữu part thì client có thể giả hoặc bóp event. Một lần chạm có thể phát nhiều lần.

- Dùng cho: pad, pickup, checkpoint, vùng trigger. Không dùng cho: hit detection, damage, vùng kiểm tra liên tục.
- Luôn có debounce theo `Player` (bảng + `task.delay(1, ...)`) trước khi xử lý.
- `CanTouch = false` tắt hẳn `Touched` và tiết kiệm CPU cho part trang trí; `CanCollide = false` **không** tắt `Touched`.

## Collision group

API nhóm va chạm giờ nằm trên `WorldRoot` (`workspace`), bản `PhysicsService` đã bị thay.

```luau
workspace:RegisterCollisionGroup("Players")
workspace:RegisterCollisionGroup("Ghosts")
workspace:CollisionGroupSetCollidable("Players", "Ghosts", false)
ghost.CollisionGroup = "Ghosts" -- gán theo tên
```

- Đăng ký một lần lúc server start; tối đa **32** nhóm (`workspace:GetMaxCollisionGroups()`).
- `CollisionGroupId` và `SetPartCollisionGroup` deprecated.
- Bốn công tắc hay bị lẫn: `CanCollide = false` bỏ va chạm, `CanQuery = false` ẩn khỏi raycast/overlap, `CanTouch = false` tắt `Touched`, `NoCollisionConstraint` tắt va chạm giữa đúng hai part.

## Assembly, weld và di chuyển

- **Assembly** = các part nối cứng với nhau (weld, `WeldConstraint`, `Motor6D`, constraint rigid). Nó mô phỏng như một vật thể; `part.AssemblyRootPart` quyết định network ownership.
- Hình học tĩnh: anchor. Part unanchored weld vào part anchored tạo assembly anchored.
- Weld lúc dựng map bằng `WeldConstraint` (giữ offset hiện tại); trong code thì set `Part0`/`Part1` rồi parent.
- Dời cả model: `model:PivotTo(cframe)`. Dời nhiều part một lúc: `workspace:BulkMoveTo`.
- Vận tốc: đọc/ghi `AssemblyLinearVelocity`, `AssemblyAngularVelocity`; tác động bằng `part:ApplyImpulse()`, `ApplyAngularImpulse()`; khối lượng là `AssemblyMass`. `Velocity`/`RotVelocity` deprecated.
- Vật liệu: `CustomPhysicalProperties = PhysicalProperties.new(density, friction, elasticity, frictionWeight, elasticityWeight)`.
- Đơn vị: 1 stud ≈ 0,28 m; `workspace.Gravity` mặc định **196,2** studs/s².

## Mover constraint thay BodyMover

| Mục tiêu | Constraint | Thay cho |
| --- | --- | --- |
| Giữ/dẫn vận tốc | `LinearVelocity` (`VelocityConstraintMode` Vector/Plane/Line) | `BodyVelocity` |
| Tiến tới một vị trí | `AlignPosition` (`Mode = OneAttachment` + `Position`, `Responsiveness`, `MaxForce`) | `BodyPosition` |
| Xoay tới một hướng | `AlignOrientation` (`CFrame` hoặc `LookAtPosition`) | `BodyGyro` |
| Lực không đổi | `VectorForce` (`RelativeTo = World`) | `BodyForce`, `BodyThrust` |
| Quay đều | `AngularVelocity` | `BodyAngularVelocity` |
| Kéo về một điểm | `LineForce` | `RocketPropulsion` |
| Mô-men xoắn | `Torque` | — |

Mọi constraint đều cần một `Attachment` (`Attachment0`). Đặt `MaxForce`/`MaxTorque` theo khối lượng thật, không `math.huge` trừ khi cố ý — đó là nguyên nhân fling phổ biến nhất.

```luau
local function makeFollower(part: BasePart, target: BasePart)
	local attachment = Instance.new("Attachment")
	attachment.Parent = part

	local align = Instance.new("AlignPosition")
	align.Mode = Enum.PositionAlignmentMode.OneAttachment
	align.Attachment0 = attachment
	align.MaxForce = part.AssemblyMass * workspace.Gravity * 4
	align.Responsiveness = 20
	align.Parent = part

	local orient = Instance.new("AlignOrientation")
	orient.Mode = Enum.OrientationAlignmentMode.OneAttachment
	orient.Attachment0 = attachment
	orient.Responsiveness = 20
	orient.Parent = part

	return function()
		align.Position = target.Position + Vector3.new(0, 4, 0)
		orient.CFrame = target.CFrame
	end
end
```

Constraint cơ khí: `HingeConstraint` (actuator Motor/Servo cho bánh xe, cửa), `PrismaticConstraint` (trượt, thang máy), `SpringConstraint` (giảm xóc), `RopeConstraint`, `RodConstraint`, `BallSocketConstraint`, `CylindricalConstraint` (bánh xe + lái), `UniversalConstraint`, `RigidConstraint`.

## Network ownership

- Server tự gán quyền sở hữu assembly unanchored cho một client gần đó: mượt cho client đó, nhưng client đó sửa được.
- `part:SetNetworkOwner(nil)` = server mô phỏng (an toàn, người chơi thấy trễ hơn); `SetNetworkOwner(player)` cho tài xế xe; `SetNetworkOwnershipAuto()` trả lại mặc định.
- Gọi trên **root part**, ở server, **sau khi** assembly đã nằm trong `Workspace`. Part anchored không có owner.
- Đổi ownership gây khựng; đừng lật mỗi frame. Xem bằng viewport → Visualization options → Network owners.

## Server authority

`Workspace.AuthorityMode = Server` cho server mô phỏng tất cả, client **predict** trước vài frame rồi **rollback/resimulate** khi lệch. Set thuộc tính này tự bật: `NextGenerationReplication`, `PlayerScriptsUseInputActionSystem`, `SignalBehavior = Deferred`, `UseFixedSimulation`, `StreamingEnabled`.

| Luật | Chi tiết |
| --- | --- |
| Logic nằm trong simulation | hàm bind bằng `RunService:BindToSimulation(fn)` trong ModuleScript được cả server Script và client LocalScript require |
| Chỉ API "Simulation Access" | ví dụ `BasePart.CFrame`; API khác gọi trong callback sẽ lỗi hoặc sai |
| Input | client chỉ tác động qua Input Actions; `InputContext` phải là descendant của `Player`; đọc `action:GetState()` trong simulation ở cả hai phía |
| State tuỳ biến | đồng bộ bằng **attribute** trên instance được predict, chỉ ghi trong callback simulation |
| Giới hạn attribute | 64 attribute đầu tiên mỗi instance, tên ≤ 50 ký tự, giá trị string ≤ 50 ký tự |
| Remote | vẫn dùng được cho message rời rạc (mua hàng, popup điểm), nhưng không đảm bảo thứ tự với replicate property/attribute |
| Ép predict | `RunService:SetPredictionMode(instance, mode)` |

Kỹ thuật: **instance stitching** (tạo instance trong callback từ module chung để hai bên ra cùng GUID, parent ngay trong frame đó); **position smoothing** (mô phỏng vật vô hình, render bản copy không khối lượng theo sau bằng `TweenService:SmoothDamp`); animation thì **không** cache `AnimationTrack` (rollback làm nó vô hiệu) mà lấy lại mỗi bước bằng `Animator:GetTrackByAnimationId(id)`; hiệu ứng không thể huỷ (âm thanh, giải thưởng) chỉ phát từ state đã xác nhận bởi server.

## CFrame

- `a * b` áp `b` trong không gian của `a`. Muốn xoay quanh gốc thế giới thì đảo thứ tự: `CFrame.Angles(...) * origin`.
- `LookVector` là **-Z**, nên "phía trước 5 stud" là `cf * CFrame.new(0, 0, -5)`.
- `CFrame.lookAt(pos, target)` dựng CFrame hướng tới mục tiêu; `:ToObjectSpace()` / `:ToWorldSpace()` đổi hệ quy chiếu; `:Lerp(a, b, t)` nội suy; `:ToOrientation()` trả radian theo thứ tự Y-X-Z giống `Orientation`; `CFrame.fromMatrix(pos, right, up)` dựng từ vector cơ sở.
- Model dùng `PivotTo`/`GetPivot`, part lẻ dùng `CFrame`.

## Đạn và xe

| Kiểu đạn | Khi dùng | Chi phí |
| --- | --- | --- |
| Hitscan | súng trường, laser, mọi thứ tốc độ cao | một `Raycast`, rẻ nhất |
| Mô phỏng bằng bước tia | đạn nhìn thấy đường bay, có rơi | một raycast mỗi frame, không cần part |
| Part vật lý | lựu đạn, vật tương tác chậm | đắt, phải set ownership có chủ đích |

Bước mô phỏng: `step = velocity * dt + 0.5 * gravity * dt * dt`, raycast từ vị trí hiện tại theo `step`, cộng dồn `position`, rồi `velocity += gravity * dt`. Cắt ở **1.000** studs để đạn không bay mãi. Client chỉ vẽ tracer (pool part hoặc `Beam`); server chạy cùng phép bước hoặc validate hit client báo.

Xe: chassis là root + 4 bánh cylinder, mỗi bánh nối bằng `CylindricalConstraint` (hoặc `HingeConstraint` cho bánh không lái) với `ActuatorType = Motor`, đặt `AngularVelocity` và `MotorMaxTorque` theo ga. Lái: `HingeConstraint` `ActuatorType = Servo` + `TargetAngle` ở giá bánh trước. Giảm xóc: `SpringConstraint` (`Stiffness`, `Damping`, `FreeLength`). Đọc input từ `VehicleSeat.ThrottleFloat`/`SteerFloat` (`Throttle`/`Steer` dạng integer đã deprecated), giao ownership cho tài xế và validate tốc độ ở server.

## Humanoid

| Property / API | Ghi chú |
| --- | --- |
| `WalkSpeed`, `JumpPower`/`JumpHeight`, `UseJumpPower` | client set được → phải chặn ở server; giá trị mặc định nằm trong Avatar Settings và `StarterPlayer` (`CharacterWalkSpeed`, `CharacterJumpHeight`) |
| `MaxHealth`, `Health` | set cả hai khi spawn; `TakeDamage` tôn trọng `ForceField`, trừ trực tiếp `Health` thì xuyên |
| `MoveDirection`, `FloorMaterial`, `RootPart`, `SeatPart` | read-only, dùng để suy luận trạng thái |
| `BreakJointsOnDeath = false` | cần cho ragdoll (kèm constraint ragdoll) |
| `Humanoid:MoveTo(pos)` | timeout **8 s**, phải phát lại cho đường dài |
| `ChangeState`, `SetStateEnabled(state, false)`, `StateChanged` | tắt state không dùng (ví dụ `Climbing`) để tránh hành vi lạ |

- Nhân vật là `Model` có `Humanoid`, `HumanoidRootPart`, các part R15 và LocalScript `Animate`. Di chuyển cả nhân vật bằng `character:PivotTo(cframe)`.
- Nhân vật bị destroy và tạo lại khi chết/respawn: mọi logic gắn theo nhân vật phải nằm trong `CharacterAdded`.
- Spawn: `Players.CharacterAutoLoads = false` rồi `player:LoadCharacterAsync()` khi data đã load (`LoadCharacter` không Async deprecated). Nhân vật tuỳ biến: `Model` tên `StarterCharacter` trong `StarterPlayer`.
- Hồi máu mặc định: script `Health` trong nhân vật — xoá/thay qua `StarterCharacterScripts` nếu muốn tự quản.

## Ngoại hình

`Players:GetHumanoidDescriptionFromUserIdAsync(userId)` → sửa `Shirt`, `Pants`, `HeightScale`... → `humanoid:ApplyDescriptionAsync(description)` (server, tự replicate). Spawn thẳng với outfit: `Player:LoadCharacterWithHumanoidDescriptionAsync(description)`. Mọi biến thể không Async (`ApplyDescription`, `GetHumanoidDescriptionFromUserId`) deprecated. Luôn bọc `pcall`: asset bị moderated hoặc không tồn tại sẽ làm hỏng cả luồng spawn.

## Tool

`Tool` trong `StarterPack`/`Backpack` cần `Handle` (hoặc `RequiresHandle = false`). `Equipped`, `Unequipped`, `Activated` phát ở **cả** client và server; `Activated` khởi nguồn từ client nên phải validate rate và state ở server. Giữ logic vũ khí trong module và dùng tag thay vì nhét script vào từng bản clone.

## Character Controller Library (beta)

Thay state machine cố định của `Humanoid` bằng các **ability** ghép được, require qua `require("@rbx/AvatarAbilities")`.

| Khái niệm | Nội dung |
| --- | --- |
| Ability | bảng `AvatarAbilities.AbilityDefinition` trong ModuleScript dùng chung server/client |
| Labels | bit trong mask 64-bit; `Labels` phát khi active, `TimedLabels` (`OnStart`, `OnStop` với thời lượng giây, `Consumes`) phát/gỡ tạm thời |
| Sensors | fact của engine, ví dụ `Identifiers.Sensor.Ground` |
| Conditions | `StartsWhen`/`RunsWhile` ghép từ label, sensor và `Rule.All`/`Rule.Any`/`Rule.Not` (`Not` chỉ nhận một label) |
| Conflicts | `Blocks`, `Stops`, `Suspends`, `ExclusiveGroup` |
| Input | `{ InputName = "Dash", Mode = "Press", ActionSlot = 5 }`, được chèn vào `StartsWhen` |
| Callbacks | `OnSetup`, `OnStart`, `OnUpdate`, `OnStop`, `OnTeardown` với `(managerCtx, abilityCtx)`; `managerCtx.AbilityOwner` là nhân vật |

Bật ở **File → Beta Features** và **Avatar Settings → Movement → Abilities**. Đăng ký bằng `AvatarAbilities.addAbilityForCharacter(character, abilityModule)` (truyền module, đừng require) sau khi `AbilityManagerActor` đã vào cây. Callback chạy ở cả client predict và server: phải deterministic — không `math.random` thiếu seed, không state chỉ client có.

## Pathfinding

```luau
local path = PathfindingService:CreatePath({
	AgentRadius = 2,
	AgentHeight = 5,
	AgentCanJump = true,
	AgentCanClimb = false,
	WaypointSpacing = 4,
	Costs = {
		Water = 20, -- tên Enum.Material
		DangerZone = math.huge, -- PathfindingModifier.Label: không bao giờ đi qua
	},
})
```

| Tham số / API | Ý nghĩa |
| --- | --- |
| `AgentRadius`, `AgentHeight` | kích thước agent; sai số này là NPC kẹt góc hoặc đi xuyên khe hẹp |
| `AgentCanJump`, `AgentCanClimb` | cho phép waypoint `Jump`/`Climb` |
| `WaypointSpacing` | khoảng cách waypoint; nhỏ thì mượt nhưng nhiều điểm hơn |
| `Costs` | key là tên `Enum.Material` hoặc `PathfindingModifier.Label`; `math.huge` = cấm tuyệt đối |
| `path:ComputeAsync(start, goal)` | **yield**, trả về sau; bọc `pcall`, kiểm `path.Status == Enum.PathStatus.Success` |
| `path:GetWaypoints()` | mảng `PathWaypoint` với `Position`, `Action` (`Walk`/`Jump`/`Custom`), `Label` |
| `path.Blocked` | phát index waypoint bị chặn giữa đường; đặt cờ rồi tính lại |
| `humanoid.MoveToFinished:Wait()` | trả `false` sau timeout 8 s |

- Giới hạn: khoảng cách thẳng start→goal ≤ **3.000** studs, ngân sách **20.000** node. Xa hơn phải chia mục tiêu trung gian.
- `PathfindingModifier` (con của part/region, `Label` khớp key trong `Costs`, `PassThrough` cho cửa) và `PathfindingLink` (giữa hai `Attachment`, cho thang/teleport/thuyền; waypoint có `Label` và `Action = Custom`) là cách duy nhất dạy navmesh những thứ hình học không nói được.
- Tái dùng object `Path` theo từng loại agent; `ComputeAsync` yield nên **không** gọi mỗi frame cho mỗi NPC.
- Tính path trên server: client chỉ thấy geometry đã stream.
- `FindPathAsync` đã bị thay bởi `CreatePath` + `ComputeAsync`.

## Vòng lặp đuổi bắt

```luau
-- Một NPC: tính lại path khi mục tiêu di chuyển đủ xa hoặc đã quá 0,75 s.
local RECOMPUTE_INTERVAL = 0.75
local RECOMPUTE_DISTANCE = 6

local function updateChase(npc, targetRoot, path, now)
	local root = npc.humanoid.RootPart
	if not root then
		return
	end
	local moved = (targetRoot.Position - (npc.lastGoal or Vector3.zero)).Magnitude
	if path and now - (npc.lastCompute or 0) < RECOMPUTE_INTERVAL and moved < RECOMPUTE_DISTANCE then
		return
	end
	npc.lastCompute = now
	npc.lastGoal = targetRoot.Position
	local ok = pcall(path.ComputeAsync, path, root.Position, targetRoot.Position)
	if not ok or path.Status ~= Enum.PathStatus.Success then
		npc.humanoid:MoveTo(targetRoot.Position) -- fallback: đi thẳng
		return
	end
	npc.waypoints = path:GetWaypoints()
	npc.waypointIndex = 2
end
```

- Có line of sight thì **bỏ qua pathfinding**: `MoveTo(targetRoot.Position)` là đủ và rẻ hơn nhiều.
- Tính lại khi mục tiêu đã đi xa vài studs hoặc mỗi ~0,5–1 s; không tính lại mỗi frame.
- Waypoint `Action == Enum.PathWaypointAction.Jump` thì set `humanoid.Jump = true` trước khi `MoveTo`.
- `MoveTo` chỉ đi thẳng tới điểm, không tự né; nó cũng không tự dừng khi tới nơi — kiểm khoảng cách.

## State machine cho NPC

| State | Điều kiện vào | Điều kiện ra |
| --- | --- | --- |
| `Idle` | mặc định | có mục tiêu trong `AGGRO_RANGE = 40` → `Chase` |
| `Chase` | có mục tiêu | cách `ATTACK_RANGE = 5` → `Attack`; xa `LEASH_RANGE = 80` khỏi nhà hoặc mất mục tiêu → `Return` |
| `Attack` | trong tầm | xa hơn `ATTACK_RANGE * 1.5` → `Chase`; hết `ATTACK_COOLDOWN = 1.2` thì đánh |
| `Return` | bị kéo quá leash | về cách nhà < 4 studs → `Idle` |

"Think" ở **5–10 Hz** và stagger (`npcIndex % 5 == frame % 5`), không phải một script `while true` mỗi NPC. Một service duy nhất giữ bảng state, tag NPC bằng `CollectionService`.

## Perception

- Tìm mục tiêu bằng `workspace:GetPartBoundsInRadius` với filter/collision group chỉ chứa nhân vật, hoặc lặp `Players:GetPlayers()` khi số người nhỏ và so bình phương khoảng cách (khỏi `sqrt`).
- Line of sight: `workspace:Raycast(from, target.Position - from, params)` với filter loại chính NPC; trúng `nil` hoặc trúng part thuộc mục tiêu là thấy.
- Cho NPC cảm giác công bằng: delay phản ứng và kiểm tra field of view bằng `root.CFrame.LookVector:Dot(direction.Unit) > 0.5`.
- NPC phải là server-owned: `npc.PrimaryPart:SetNetworkOwner(nil)` sau khi spawn, nếu không ownership nhảy giữa người chơi và NPC giật, đồng thời bị đẩy được.

## Scale lên nhiều NPC

- `Humanoid` chỉ cho NPC cần đi/bơi/leo. Turret, vật bay, đám đông: `AnimationController` + `Animator`, di chuyển bằng constraint hoặc CFrame — rẻ hơn nhiều.
- Pool model: tạo sẵn, `Parent = nil` khi chết, tái dùng bằng cách set `CFrame` và `Health` thay vì `Clone`/`Destroy` liên tục.
- NPC ở xa: giảm tần suất think, tắt animation, có thể thay bằng bản proxy không `Humanoid`.
- Animation của NPC đông: phát ở client (cosmetic) thay vì server.
- Đo trước khi tối ưu: số NPC × tần suất think là chi phí chính, không phải số part.

## Bẫy

- **Cả map rung khi có vật mới spawn** — `MaxForce = math.huge` trên part nhẹ, hoặc part chồng lấn lúc spawn — đặt `MaxForce` theo `AssemblyMass`, tách part ra trước khi parent.
- **Nhân vật bị văng lên trời khi chạm một part** — constraint đang chống lại physics hoặc tỉ lệ khối lượng > 1:100 — cân lại khối lượng, kiểm tra `CustomPhysicalProperties`.
- **Part đứng yên dù đã set `CFrame` mỗi frame** — set `CFrame` lên part unanchored mỗi frame ghi đè physics — dùng constraint, hoặc anchor rồi mới dời.
- **Xe giật và trượt bánh** — ownership nằm ở server trong khi tài xế ở xa — `chassis:SetNetworkOwner(driver)` và validate tốc độ ở server.
- **NPC giật khi người chơi đi ngang qua** — ownership tự chuyển sang client gần nhất — `npc.PrimaryPart:SetNetworkOwner(nil)` ngay sau khi spawn.
- **`Touched` bắn 10 lần cho một lần chạm** — physics phát nhiều event cho một tiếp xúc — debounce theo `Player`/model, hoặc chuyển sang overlap query.
- **Trigger không bao giờ chạy trên client của người khác** — `Touched` do bên mô phỏng part phát, part đó thuộc client khác — xử lý trigger trên server.
- **Raycast trúng part vô hình** — `CanCollide = false` không tắt `CanQuery` — set `CanQuery = false` cho mọi part trang trí.
- **Overlap trả về hàng nghìn part và tụt FPS** — không đặt `MaxParts`, filter rỗng — set `MaxParts` và filter theo collision group.
- **`GetPartsInPart` chậm bất thường** — nó kiểm hình học chính xác, không phải bounding box — dùng `GetPartBoundsInBox`/`InRadius` khi dung sai hình học chấp nhận được.
- **Đạn xuyên mục tiêu ở tốc độ cao** — một raycast mỗi frame với bước dài hơn mục tiêu — bước raycast chính là quỹ đạo, đừng teleport part đạn.
- **Đạn bay mãi, server chậm dần** — vòng lặp không có giới hạn tầm — cắt ở 1.000 studs và disconnect.
- **`Humanoid:MoveTo` dừng giữa đường** — timeout 8 s — phát lại `MoveTo` hoặc đi theo waypoint.
- **NPC kẹt ở góc, path luôn `NoPath`** — `AgentRadius`/`AgentHeight` lớn hơn khe thật, hoặc goal nằm ngoài navmesh — chỉnh agent, hoặc `ComputeAsync` tới điểm gần nhất rồi `MoveTo` thẳng.
- **NPC đi xuyên cửa/khu vực bị cấm** — navmesh không biết luật chơi — dùng `PathfindingModifier` + `Costs` (`math.huge` để cấm) hoặc `PathfindingLink`.
- **Server đứng hình mỗi lần NPC tính path** — `ComputeAsync` yield và bị gọi cho mọi NPC cùng frame — hàng đợi, tính lại theo lịch, bỏ qua khi có line of sight.
- **Path tính trên client trả về đường cụt** — client chỉ thấy geometry đã stream — luôn tính path trên server.
- **Animation không phát trên server production nhưng chạy trong Studio** — asset không thuộc sở hữu hoặc chưa chia sẻ quyền cho chủ experience — set quyền asset hoặc upload lại.
- **Rollback làm animation kẹt** — cache `AnimationTrack` qua các bước simulation — lấy lại mỗi bước bằng `Animator:GetTrackByAnimationId`.
- **Attribute không replicate dưới server authority** — vượt 64 attribute đầu tiên, tên > 50 ký tự, hoặc ghi ngoài callback simulation — gộp state vào ít attribute, ghi trong `BindToSimulation`.
- **Ability CCL chạy trên client nhưng server không thấy** — module ability chỉ được require ở một phía, hoặc đăng ký trước khi `AbilityManagerActor` vào cây — require ở cả hai phía và chờ actor.
