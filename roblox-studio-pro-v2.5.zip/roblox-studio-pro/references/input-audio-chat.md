# Input, camera, âm thanh và chat

> Khi nào dùng: khi thêm điều khiển, keybind, ability, xe cộ, nút on-screen, camera tùy biến, nhạc và SFX, hoặc bất kỳ tính năng nào hiển thị chữ do người chơi viết cho người chơi khác.

## Chọn cách xử lý input
| Cách | Dùng khi |
| --- | --- |
| **Input Action System** (`InputContext` → `InputAction` → `InputBinding`) | Điều khiển gameplay mới. Binding đa thiết bị khai báo bằng instance, context bật/tắt được, có nút on-screen và prompt sẵn. Khuyến nghị. |
| `UserInputService` events | Input thô, hotkey không phụ thuộc text, vị trí/delta chuột, gesture touch, phát hiện thiết bị. |
| `ContextActionService:BindAction` | Code cũ hoặc bind kèm nút mobile đơn giản. |

Toàn bộ xử lý input chạy **client-side**; gửi *ý định* lên server qua remote và để server validate. Không bao giờ để client quyết định damage, tốc độ hay vị trí cuối cùng.

## Input Action System
```text
Inputs (Folder)
  PlayContext (InputContext, Priority 1000)      -- điều khiển gameplay
    Sprint (InputAction, Type = Bool)
      Keyboard (InputBinding, KeyCode = LeftShift)
      Gamepad  (InputBinding, KeyCode = ButtonL3)
      Touch    (InputBinding, UIButton = <on-screen TextButton>)
  MenuContext (InputContext, Priority 2000, Sink = true, Enabled = false)
```

`InputAction.Type`: `Bool` (nhấn/nhả), `Direction1D` (cò, zoom), `Direction2D` (di chuyển, camera), `Direction3D` (bay), `ViewportPosition` (vị trí con trỏ).

| Sự kiện | Ghi chú |
| --- | --- |
| `Pressed` / `Released` | Chỉ với `Type = Bool` |
| `StateChanged(value)` | Mọi type, trả giá trị hiện tại |
| `action:GetState()` | Đọc giá trị ngay lập tức, không cần cache |

Trường của `InputBinding`: `KeyCode`; hướng ghép `Up`/`Down`/`Left`/`Right`/`Forward`/`Backward`; `Scale` (ví dụ `0.01` cho `MouseDelta`/`TouchDelta`); `PressedThreshold`/`ReleasedThreshold` cho cò analog; `PrimaryModifier`/`SecondaryModifier` cho tổ hợp (Ctrl+S); `UIButton` để nút GUI điều khiển action; `DisplayName`/`DisplayImage` cho prompt.

`InputContext.Enabled` đổi cả bộ điều khiển (gameplay ↔ menu ↔ xe). `Priority` + `Sink` cho context trên "nuốt" phím để context dưới không cùng nhận. Đặt `Workspace.PlayerScriptsUseInputActionSystem = Enabled` để script player/camera mặc định của Roblox cũng dùng hệ thống này — bắt buộc nếu muốn server authority.

```luau
--!strict
-- Client: dựng action bằng code, mỗi binding một thiết bị.
local Players = game:GetService("Players")
local player = Players.LocalPlayer
local context = Instance.new("InputContext")
context.Name = "PlayContext"
context.Priority = 1000

local sprint = Instance.new("InputAction")
sprint.Name, sprint.Type = "Sprint", Enum.InputActionType.Bool
sprint.Parent = context

for _, keyCode in { Enum.KeyCode.LeftShift, Enum.KeyCode.ButtonL3 } do
	local binding = Instance.new("InputBinding")
	binding.KeyCode = keyCode
	binding.Parent = sprint
end

context.Parent = player:WaitForChild("PlayerScripts")

local function setSprinting(on: boolean)
	local humanoid = player.Character and player.Character:FindFirstChildOfClass("Humanoid")
	if humanoid then
		humanoid.WalkSpeed = if on then 24 else 16 -- server vẫn validate giới hạn thật
	end
end

sprint.Pressed:Connect(function() setSprinting(true) end)
sprint.Released:Connect(function() setSprinting(false) end)
```

Hiển thị đúng phím/nút: `InputActionLabel` (beta) tự render theo thiết bị hiện tại, hoặc đọc `action.PreferredBinding` (kèm `DisplayName`/`KeyCode`) và `UserInputService:GetStringForKeyCode` / `GetImageForKeyCode`, cập nhật trong `GetPropertyChangedSignal("PreferredBinding")`.

## UserInputService
```luau
--!strict
local UserInputService = game:GetService("UserInputService")

UserInputService.InputBegan:Connect(function(input: InputObject, gameProcessedEvent: boolean)
	if gameProcessedEvent then return end -- đang gõ TextBox, bấm UI, hoặc core script đã xử lý
	if input.KeyCode == Enum.KeyCode.E then
		print("interact")
	elseif input.UserInputType == Enum.UserInputType.MouseButton1 then
		print("click at", input.Position)
	end
end)

UserInputService:GetPropertyChangedSignal("PreferredInput"):Connect(function()
	print("show prompts for", UserInputService.PreferredInput) -- KeyboardAndMouse | Touch | Gamepad
end)
```

- Luôn tôn trọng `gameProcessedEvent`, nếu không người chơi sẽ kích hoạt ability khi đang gõ chat.
- `PreferredInput` phản ánh thiết bị **đang dùng** (điện thoại + tay cầm Bluetooth → `Gamepad`). Đừng chỉ rẽ nhánh theo `TouchEnabled`/`KeyboardEnabled`.
- Chuột: `MouseBehavior = Enum.MouseBehavior.LockCenter` cho FPS (đặt lại mỗi frame nếu script khác có thể reset), `GetMouseLocation()` (đã tính inset thanh topbar), `MouseDeltaSensitivity`, `MouseIconEnabled`.
- Gamepad: `GetConnectedGamepads`, `GamepadConnected`/`GamepadDisconnected`, thumbstick qua `input.Position` trong `InputChanged` — áp dead zone ≈ 0.15. Rung: `HapticService` / `HapticEffect`.
- Touch: `TouchTap`, `TouchLongPress`, `TouchPinch`, `TouchSwipe`. Chỉ ẩn control mặc định khi đã thay thế (`GuiService.TouchControlsEnabled`).

## ContextActionService
`ContextActionService:BindAction(name, handler, createTouchButton, ...inputs)` với handler `(actionName, inputState, inputObject) -> Enum.ContextActionResult?`; trả `Pass` để binding khác còn thấy input. Dùng `BindActionAtPriority` để xếp thứ tự và `UnbindAction` khi context kết thúc (tool bị tháo). Việc mới thì dùng Input Action System.

## Phím bị giữ
Không override được: Esc/Start (menu), F9 (console), F11, F12, PrintScreen; chat `/`; Tab (player list); các phím backpack và phím số chọn tool — trừ khi tắt những core feature đó. Đừng thiết kế cơ chế gameplay quan trọng trên các phím này.

## Camera tùy biến
```luau
--!strict
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local camera = workspace.CurrentCamera
local OFFSET = Vector3.new(0, 30, 20)
camera.CameraType = Enum.CameraType.Scriptable

RunService:BindToRenderStep("TopDownCamera", Enum.RenderPriority.Camera.Value + 1, function(deltaTime: number)
	local character = Players.LocalPlayer.Character
	local root = character and character:FindFirstChild("HumanoidRootPart") :: BasePart?
	if root then
		local goal = CFrame.lookAt(root.Position + OFFSET, root.Position)
		camera.CFrame = camera.CFrame:Lerp(goal, 1 - math.exp(-8 * deltaTime))
	end
end)

-- Khôi phục: RunService:UnbindFromRenderStep("TopDownCamera"); camera.CameraType = Enum.CameraType.Custom
```

- Cập nhật camera trong `BindToRenderStep` (chạy trước render, có thứ tự), không dùng `Heartbeat` hay vòng `task.wait`.
- Làm mượt bằng `1 - math.exp(-speed * deltaTime)` để không phụ thuộc frame rate.
- First person: `player.CameraMode = Enum.CameraMode.LockFirstPerson`; giới hạn zoom bằng `player.CameraMinZoomDistance`/`CameraMaxZoomDistance`. Rung camera thì offset CFrame, đừng dịch part.
- Screen → world: `camera:ViewportPointToRay(x, y)` hoặc `ScreenPointToRay` + `workspace:Raycast`.

## Cross-platform
Mỗi action phải có binding keyboard, gamepad **và** touch (`UIButton` hoặc nút on-screen). Prompt đổi theo `PreferredInput`. UI console điều hướng được bằng D-pad và đóng bằng B. Không làm tương tác chỉ có hover (touch không có hover); hành động phá huỷ thì dùng hold-to-confirm. Test bằng Device Emulator và Controller Emulator.

## Audio: hai hệ thống
| Hệ thống | Khi nào |
| --- | --- |
| **Audio API** (`AudioPlayer` → `Wire` → `AudioEmitter`/`AudioListener` → `Wire` → `AudioDeviceOutput`) | Mặc định cho việc mới: mixer graph, effect, analyzer, xử lý voice chat, text-to-speech. |
| **`Sound`** cổ điển | Game đơn giản và code cũ: một object, parent vào part để 3D hoặc vào `SoundService`/UI để 2D, đi qua `SoundGroup` với `SoundEffect` con. |

Không trộn cả hai cho cùng một tính năng; theo hệ thống mà project đang dùng.

## Audio 2D và routing bằng Wire
```luau
--!strict
-- Client: dựng một lần, mọi âm thanh đi qua fader chung.
local SoundService = game:GetService("SoundService")

local function wire(source: Instance, target: Instance)
	local w = Instance.new("Wire")
	w.SourceInstance, w.TargetInstance, w.Parent = source, target, target
end
local player = Instance.new("AudioPlayer")
player.Name, player.Asset = "Music", "rbxassetid://1843463175" -- AssetId đã deprecated; dùng Asset
player.Looping, player.Volume = true, 0.5
player.Parent = SoundService
local fader = Instance.new("AudioFader") -- một chỗ duy nhất cho slider nhạc trong settings
fader.Name, fader.Parent = "MusicVolume", SoundService

local output = Instance.new("AudioDeviceOutput")
output.Parent = SoundService
wire(player, fader)
wire(fader, output)
player:Play()
```

Chèn effect bằng cách wire thêm một object vào chuỗi (`player → AudioEqualizer → fader → output`); `Wire` phải nằm trong cây và `TargetInstance` phải tồn tại trước khi wire.

## Audio 3D
Đặt `AudioEmitter` trên part/attachment của nguồn rồi wire `AudioPlayer → AudioEmitter`. Phía nghe: `SoundService.ListenerLocation` quyết định `AudioListener` mặc định (camera hay character); wire `AudioListener → AudioDeviceOutput` (setup mặc định đã làm sẵn). Suy giảm theo khoảng cách đặt trên emitter/listener (`AudioEmitter:SetDistanceAttenuation`); property chuỗi `AudioInteractionGroup` trên emitter và listener giới hạn ai nghe được gì.

## Sound cổ điển
```luau
--!strict
local SoundService = game:GetService("SoundService")
local sfxGroup = Instance.new("SoundGroup")
sfxGroup.Name, sfxGroup.Volume, sfxGroup.Parent = "SFX", 0.8, SoundService

local function playAt(part: BasePart, soundId: string)
	local sound = Instance.new("Sound")
	sound.SoundId, sound.SoundGroup = soundId, sfxGroup
	sound.RollOffMaxDistance = 80
	sound.Parent = part -- 3D: phát từ part; 2D: parent vào SoundService/UI
	sound:Play()
	sound.Ended:Once(function() sound:Destroy() end)
end
return playAt
```

`SoundService:PlayLocalSound(sound)` cho tiếng UI chỉ client nghe. Preload âm thanh quan trọng bằng `ContentProvider:PreloadAsync({ sound })` — chỉ những cái thật sự cần, preload hết sẽ làm join chậm. Tiếng phát liên tục (đạn, bước chân) thì pool object thay vì tạo mới mỗi lần.

## Client, server và streaming
- Âm thanh **start trên client** chỉ client đó nghe (UI, feedback, nhạc người chơi chọn). **Start trên server** replicate cho tất cả — dùng tiết kiệm; tốt hơn là remote bảo client tự phát, như vậy mỗi client áp được volume riêng.
- Với `SoundService.RespectFilteringEnabled = true` (mặc định), âm thanh do client phát không replicate.
- Streaming: sound/emitter nằm trong part bị stream out sẽ tắt. Giữ ambient trong model persistent hoặc trong `SoundService`.

## Asset và quyền
Dùng audio bạn sở hữu, upload cùng owner (user/group) với experience, hoặc audio Creator Store được đánh dấu free-to-use. Audio private của creator khác sẽ **không phát** trừ khi được chia sẻ cho experience (asset permissions) — triệu chứng là Output báo "failed to load" hoặc lỗi quyền. Upload được tự phân loại thành sound effect hoặc song; song hợp lệ có thể hiện trên trang game.

## Effect, voice, TTS
Effect: `AudioEqualizer`, `AudioCompressor`, `AudioReverb`, `AudioEcho`, `AudioChorus`, `AudioDistortion`, `AudioFlanger`, `AudioPitchShifter`, `AudioTremolo`, `AudioFilter`, `AudioLimiter`, `AudioAnalyzer` (đọc loudness/spectrum cho visualizer). `AudioTextToSpeech` (giọng nhân tạo) và `AudioSpeechToText` (transcript). Voice chat: `AudioDeviceInput` của từng người chơi wire qua effect được (bộ đàm, walkie-talkie, proximity) — xem docs voice chat và tôn trọng cài đặt voice của người chơi. Luôn có slider Music/SFX riêng và nút mute.

## Chat: quy tắc không thương lượng
1. Hội thoại giữa người chơi phải đi qua `TextChannel` của **TextChatService** (nó lo filter, privacy/parental settings và báo cáo). `Chat`/`ChatService` legacy đã bị bỏ — `TextChatService` là hệ thống chat duy nhất.
2. **Mọi chữ do người chơi này viết và người chơi khác nhìn thấy** (tên pet, biển hiệu, tên guild, ghi chú trade, UI tự làm) phải filter bằng `TextService:FilterStringAsync` trên **server** trước khi hiển thị — và filter lại khi đọc từ DataStore sau này.
3. Chữ sửa được mà người khác thấy (biển hiệu, bảng tin) cần rate limit **tối thiểu 1 phút**.
4. Tôn trọng privacy bằng `CanUserChatAsync`/`CanUsersChatAsync`/`CanUsersDirectChatAsync` và đánh dấu kênh nhắn riêng bằng `TextChannel:SetDirectChatRequester()`.

Không phải chat nên không cần filter: text UI của bạn, thông báo trạng thái game, announcement do bạn viết.

## Filter chữ do người chơi viết
```luau
--!strict
local TextService = game:GetService("TextService")

-- Broadcast: mọi người đều thấy (biển hiệu). Lỗi thì trả nil và hiển thị rỗng.
local function filterForEveryone(text: string, fromUserId: number): string?
	local ok, result = pcall(function()
		return TextService:FilterStringAsync(text, fromUserId, Enum.TextFilterContext.PublicChat):GetNonChatStringForBroadcastAsync()
	end)
	return if ok then result else nil
end

-- Theo từng người nhận: tôn trọng tuổi/cài đặt của người xem (ghi chú riêng).
local function filterForUser(text: string, fromUserId: number, toUserId: number): string?
	local ok, result = pcall(function()
		return TextService:FilterStringAsync(text, fromUserId, Enum.TextFilterContext.PrivateChat):GetNonChatStringForUserAsync(toUserId)
	end)
	return if ok then result else nil
end
return { forEveryone = filterForEveryone, forUser = filterForUser }
```

Filter trên server, sau khi người chơi submit (không filter theo từng phím), và rate-limit + giới hạn độ dài trước. Lỗi thì **fail closed** (hiện rỗng hoặc placeholder), tuyệt đối không hiện chữ thô. Lưu chữ thô nếu cần nhưng luôn filter ở thời điểm hiển thị — filter và cài đặt người xem thay đổi theo thời gian. Chuỗi toàn số hoặc rất ngắn vẫn có thể bị hashtag `###`; thiết kế UI chịu được việc đó.

## TextChatService
- Mặc định `CreateDefaultTextChannels` tạo `RBXGeneral` và `RBXSystem`; `CreateDefaultCommands` thêm lệnh built-in (`/whisper`, `/team`, `/mute`, …). Giao diện chỉnh qua `ChatWindowConfiguration`, `ChatInputBarConfiguration`, `BubbleChatConfiguration`, hoặc tắt hết và tự dựng UI.
- Luồng: client `TextChannel:SendAsync(text)` → server `TextChannel.ShouldDeliverCallback(message, textSource)` cho từng người nhận → filter → `OnIncomingMessage` ở client → hiển thị.
- Callback **không được yield**. `ShouldDeliverCallback` chỉ có ở server; `TextChatService.OnIncomingMessage` và `TextChannel.OnIncomingMessage` chỉ có ở client (định dạng).
- Tin hệ thống: `channel:DisplaySystemMessage(text)` ở client (chỉ máy đó thấy).
- Kênh riêng (team, party, proximity): tạo `TextChannel` dưới `TextChatService` ở server, `channel:AddUserAsync(userId)` để thêm thành viên, kiểm `TextSource.CanSend` trả về.

```luau
--!strict
-- Client: tag và màu qua OnIncomingMessage (chỉ định dạng, không yield).
local Players = game:GetService("Players")
local TextChatService = game:GetService("TextChatService")

TextChatService.OnIncomingMessage = function(message: TextChatMessage)
	local properties = Instance.new("TextChatMessageProperties")
	local source = message.TextSource
	local player = source and Players:GetPlayerByUserId(source.UserId)
	if player and player:GetAttribute("VIP") then
		properties.PrefixText = `<font color="#F5CD30">[VIP]</font> {message.PrefixText}`
	end
	return properties
end
```

## Lệnh chat có filter
`TextChatCommand` khai `PrimaryAlias`/`SecondaryAlias`; `Triggered` nhận `(source: TextSource, unfilteredText: string)`. Chữ trong lệnh **chưa** được filter, nên nếu đưa nó lên màn hình người khác thì phải tự filter và rate-limit:

```luau
--!strict
-- Server: /sign <text> — admin-only, filter trước khi broadcast, cooldown 60 giây.
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TextChatService = game:GetService("TextChatService")
local TextService = game:GetService("TextService")

local ADMINS: { [number]: boolean } = { [123456] = true }
local COOLDOWN, MAX_LENGTH = 60, 140
local lastPost: { [number]: number } = {}
local signChanged = Instance.new("RemoteEvent")
signChanged.Name, signChanged.Parent = "SignChanged", ReplicatedStorage
local command = Instance.new("TextChatCommand")
command.Name, command.PrimaryAlias, command.Parent = "SignCommand", "/sign", TextChatService

command.Triggered:Connect(function(source: TextSource, unfilteredText: string)
	if not ADMINS[source.UserId] then return end
	local text = string.match(unfilteredText, "^/sign%s+(.+)$")
	if not text or #text > MAX_LENGTH or utf8.len(text) == nil then return end
	local now = os.clock()
	if lastPost[source.UserId] and now - lastPost[source.UserId] < COOLDOWN then return end
	lastPost[source.UserId] = now

	local ok, filtered = pcall(function()
		return TextService:FilterStringAsync(text, source.UserId, Enum.TextFilterContext.PublicChat)
			:GetNonChatStringForBroadcastAsync()
	end)
	if ok and filtered then
		signChanged:FireAllClients(filtered) -- client hiện trên SurfaceGui
	end
end)
```

## Chat UI tự làm và bubble
Tắt `ChatWindowConfiguration.Enabled` và `ChatInputBarConfiguration.Enabled`, rồi: gửi bằng `(TextChatService.TextChannels.RBXGeneral :: TextChannel):SendAsync(textBox.Text)`; nhận bằng `TextChatService.MessageReceived` và render `message.PrefixText` + `message.Text` (đã filter). Dùng `message.MessageId` để thay tin đang chờ ở local khi bản đã xử lý ở server tới. Giữ bubble qua `BubbleChatConfiguration` hoặc `TextChatService.OnBubbleAdded`.

## Privacy, rate limit, PolicyService
`PolicyService:GetPolicyInfoForPlayerAsync(player)` (server, bọc `pcall`) trả các cờ: `ArePaidRandomItemsRestricted`, `IsPaidItemTradingAllowed`, `AreAdsAllowed`, `AllowedExternalLinkReferences`, `IsSubjectToChinaPolicies`, `IsContentSharingAllowed`. Dùng để chặn loot box, trading, quảng cáo và link mạng xã hội theo từng người chơi (chỉ hiện nền tảng có trong `AllowedExternalLinkReferences`).

## Migrate từ Chat legacy
| Legacy | TextChatService |
| --- | --- |
| `Chat:Chat(part, text)` bubble | `TextChatService:DisplayBubble(part, text)` (client) |
| ChatService speakers/channels | `TextChannel` + `AddUserAsync`; quyền qua `TextSource.CanSend` |
| Extra data (tag, màu) trên speaker | `OnIncomingMessage` trả `TextChatMessageProperties` (`PrefixText`, `Text`) với rich text |
| `Chat:FilterStringAsync` | `TextService:FilterStringAsync` |
| Command qua message hook | instance `TextChatCommand` (`PrimaryAlias`, `SecondaryAlias`, `Triggered`) |

## Bẫy
- **Người chơi kích hoạt ability khi đang gõ chat** — bỏ qua `gameProcessedEvent`; luôn `return` sớm khi nó `true`.
- **Prompt hiện phím sai trên điện thoại hoặc tay cầm** — rẽ nhánh theo `TouchEnabled`/`KeyboardEnabled` thay vì `PreferredInput`; dùng `PreferredInput` + `PreferredBinding` và cập nhật khi property đổi.
- **Context menu vẫn bắn phím xuống gameplay** — context trên không đặt `Sink = true`, hoặc hai context cùng `Priority`; đặt `Sink` và chênh priority rõ ràng.
- **Camera giật, lệch khi FPS thay đổi** — cập nhật trong `Heartbeat` hoặc lerp hệ số cố định; chuyển sang `BindToRenderStep` và `1 - math.exp(-speed * dt)`.
- **Camera không trả về bình thường sau cutscene** — quên `UnbindFromRenderStep` và `CameraType = Custom`; luôn khôi phục trong một hàm `cleanup` gọi cả khi lỗi.
- **`Wire` nối rồi mà không có tiếng** — thiếu `AudioDeviceOutput` ở cuối chuỗi, hoặc `Wire` không được parent vào cây, hoặc nối khi `TargetInstance` chưa tồn tại; dựng target trước, wire sau, kiểm cả `AudioListener` → output.
- **Âm thanh 3D nghe đều một mức** — `AudioEmitter` không nằm trên part/attachment, hoặc chưa `SetDistanceAttenuation`; kiểm `AudioInteractionGroup` có khớp listener không.
- **Âm thanh tắt khi đi xa** — emitter nằm trong part bị streaming loại bỏ; chuyển ambient sang model persistent hoặc `SoundService`.
- **SFX im lặng dù id đúng** — audio thuộc owner khác và chưa được cấp quyền cho experience; kiểm Output và upload lại dưới owner của experience.
- **Chữ người chơi hiện nguyên văn cho người khác** — filter ở client hoặc bỏ qua bước filter khi đọc lại từ DataStore; filter ở server mỗi lần hiển thị, fail closed.
- **`ShouldDeliverCallback` treo cả chat** — callback có `task.wait`/`:Wait()`; callback phải trả về ngay, mọi việc nặng đẩy sang task khác.
- **Tin nhắn không tới người nhận dù đã `AddUserAsync`** — `TextSource.CanSend` là `false` (privacy/parental control) hoặc kênh chưa `SetDirectChatRequester`; kiểm `CanSend` và đặt requester cho kênh DM.
- **Lệnh chat chạy với text chưa filter** — `Triggered` trả chữ thô; nếu hiển thị cho người khác phải `FilterStringAsync` và rate-limit trước khi broadcast.
