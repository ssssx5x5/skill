# Hiểu hướng, góc xoay và hành động mô tả bằng lời (BẮT BUỘC trước khi dựng model/animation)

Lỗi hay gặp nhất không phải code sai mà là **hiểu sai một chữ**: "mũi dao chỉ xuống", "xoay 90 độ", "cầm ngược". Quy trình này biến lời thành vector có số trước khi viết dòng code nào.

## Bước 1 — Viết "Spatial Brief" (4–8 dòng, đưa vào câu trả lời)
1. **Khung vật**: trục nào là chiều dài / độ dày / hướng "mặt trước" của vật. Mặc định của skill: `Y` = đuôi→đầu (dao, kiếm, súng đặt dọc), `−Z` = hướng lưỡi/nòng/mặt trước, `X` = bề dày.
2. **Quy ước thế giới**: trước = −Z, phải = +X, lên = +Y; "trái/phải" nói theo CHÍNH VẬT hoặc nhân vật, không theo người nhìn màn hình. Nếu câu mô tả mơ hồ về điểm này → nói rõ giả định đã chọn.
3. **Mỗi cụm hướng → một vector số** (dùng `python scripts/orient.py dir "…"`).
4. **Mỗi góc xoay → trục + dấu + độ** (`orient.py rot "…"`). Dương = ngược chiều kim đồng hồ nhìn từ đỉnh trục (tay phải); "theo chiều kim đồng hồ" = âm.
5. **Mỗi hành động → chuỗi tư thế khóa** (đầu – giữa – cuối) với góc từng khớp.
6. **Cái gì mơ hồ thật sự** (hai hướng không nói mức, thiếu trục): chọn mặc định hợp lý, GHI RÕ, không hỏi ngược nếu việc rẻ để sửa.

## Bảng từ vựng hướng
| Lời | Vector Roblox | Ghi chú |
|---|---|---|
| trước / forward | (0,0,−1) | |
| sau | (0,0,1) | |
| phải / trái | (1,0,0) / (−1,0,0) | theo vật |
| lên / xuống | (0,1,0) / (0,−1,0) | |
| "hơi / chếch / nghiêng" + hướng phụ | pha 30° vào hướng chính | |
| "chéo" không nêu độ | 45° | báo giả định |
| mũi/đầu chỉ X | trục "đầu" của vật trùng X | dùng `look_rotation(dir, up, tipAxis)` |

## Bảng xoay
| Lời | Trục & dấu | Kiểm tra |
|---|---|---|
| quay/xoay sang phải (yaw) | quanh Y, **−** | trước(−Z) → +X |
| quay sang trái | quanh Y, **+** | trước → −X |
| ngửa lên (pitch up) | quanh X, **+** | trước → +Y |
| cúi xuống (pitch down) | quanh X, **−** | trước → −Y |
| nghiêng sang phải (roll) | quanh Z, **−** | lên(+Y) → +X |
| theo chiều kim đồng hồ (nhìn từ trên) | quanh Y, **−** | |
| lộn nhào ra trước (front flip) | quanh X, **−**, 360° | đầu đi xuống phía trước |
| lộn ra sau (back flip) | quanh X, **+**, 360° | |
Mọi dòng trên đã có test số học trong `orient.py selftest`.

## Bẫy xoay Euler (làm AI hiểu sai nhiều nhất)
- `CFrame.Angles(rx,ry,rz) = Rx·Ry·Rz` — **thứ tự quan trọng**; xoay hai trục cùng lúc ≠ hai lần xoay riêng. Với vật lạ: xoay MỘT trục mỗi lần bằng `CFrame.fromAxisAngle(axis, rad)` rồi nhân.
- Xoay trong **khung vật** (nhân phải: `cf * ang`) khác xoay quanh **trục thế giới** (nhân trái: `ang * cf`). "Xoay dao quanh cán" = khung vật; "xoay nhân vật quay mặt về phía đông" = thế giới.
- Gimbal: pitch ≈ ±90° làm yaw/roll chập nhau → dùng `lookAt`/`fromMatrix`, không nội suy Euler.
- Cylinder: trục tròn là **X** (không phải Y). Muốn cột đứng: xoay Z 90°.
- Motor6D/Weld: Euler áp ở C0/C1 theo khung part cha/con. Dùng `AnimKit` (độ trong khung part cha) thay vì tự tính.

## Công thức tay cầm (cầm dao/kiếm/súng đúng hướng)
`Grip = HandRel⁻¹ · RGA`, trong đó `HandRel` = CFrame mong muốn của vật trong khung bàn tay. Helper: `templates/Orient.lua` (`Orient.GripFromCharacterPose`). Cầm **xuôi** (forward grip): lưỡi chỉ ra khỏi nắm đấm về phía trước. Cầm **ngược** (reverse/ice-pick): lưỡi chỉ về phía khuỷu, cạnh sắc quay ra ngoài. Karambit cầm ngược: ngón trỏ xuyên vòng, lưỡi cong lòng ra trước.

## Từ vựng hành động → tư thế khóa
| Hành động | Chuỗi tư thế |
|---|---|
| chém ngang (slash) | thu về vai đối diện → vung qua thân, cổ tay quay theo → dừng quá điểm giữa → hồi |
| đâm (stab) | rút khuỷu → cổ tay thẳng hàng với lưỡi → duỗi khuỷu + thân lao tới → rút |
| xoay dao (spin/flip) | xoay quanh trục qua trọng tâm vật, **không phải** quanh tay; trọng tâm đi theo parabol |
| tung rồi bắt (toss & catch) | vật rời tay theo vận tốc, tự quay ω; bắt = ghép lại Grip ở khung cuối |
| ngắm (aim) | tay chỉ → `AimLimb` IK, đầu quay theo mục tiêu |
Luôn viết **tư thế đầu / giữa / cuối bằng số** trước khi code. Nếu mô tả của người dùng bỏ trống khoảng nào, nêu giả định đã điền.

## Tự kiểm tra bắt buộc (chạy được ngoài Studio)
- `AssertAxis(vật, trục, hướngMong)` sau khi dựng: mũi dao có thật sự chỉ hướng mong muốn không.
- Với model dựng bằng spec: kiểm tra vector số (ví dụ `tipDir`), không "nhìn rồi tin".
- Chưa mở Studio thì ghi rõ: "hướng đúng theo số, chưa nhìn trong Studio".
