# Bảo mật và hiệu năng

> Khi nào dùng: Khi viết handler cho input từ client, thiết kế kinh tế/trade/combat, hoặc khi game lag, tụt FPS, phình bộ nhớ và cần biết đo cái gì trước khi sửa.

## Mô hình đe dọa

Exploiter kiểm soát hoàn toàn client: chạy Luau tuỳ ý, đọc mọi script đã replicate (kể cả đã decompile), bắn mọi remote với tham số bất kỳ ở tần suất bất kỳ, sửa mọi property local (`WalkSpeed`, `ProximityPrompt.Enabled`, `MaxActivationDistance`), và di chuyển bất cứ thứ gì chúng có network ownership. Anti-cheat phía client chỉ là vật cản tạm; bảo mật đến từ thiết kế server.

## Nguyên tắc lõi

1. **Server quyết định.** Client gửi *ý định* ("tôi bấm tấn công, ngắm hướng này"), không bao giờ gửi *kết quả* ("tôi gây 50 damage", "cho tôi 100 coin").
2. **Validate mọi tham số** của mọi `OnServerEvent`/`OnServerInvoke`: kiểu, cấu trúc, miền giá trị, tính hữu hạn.
3. **Validate ngữ cảnh**: người chơi còn sống, trong tầm, không cooldown, sở hữu vật phẩm, đúng phase?
4. **Rate limit** mọi thứ client chạm được: remote, prompt, touch, click.
5. **Giữ bí mật ở server**: code trong `ServerScriptService`/`ServerStorage`; API key qua `HttpService:GetSecret()`; không đẩy nội dung chưa release lên place production.
6. **Ưu tiên giảm thiểu im lặng** (drop, clamp, sửa state) hơn kick ngay; chỉ escalate khi có nhiều tín hiệu.

## Kiểm tra tham số

Mọi tham số sau `player` phải coi là `unknown` và thu hẹp bằng helper (`Validate.number`, `Validate.integer`, `Validate.string`, `Validate.vector3`, `Validate.instanceIn`, `Validate.enum`) đặt trong một module server dùng chung.

| Lỗi | Vì sao lọt qua kiểm tra thường | Cách chặn |
| --- | --- | --- |
| `NaN`, `±inf` | `NaN` so sánh luôn `false`, nên `amount > 0 and amount <= balance` vẫn "đúng" | `math.isfinite(value)` **trước** kiểm tra miền |
| Instance giả | Bảng có `ClassName = "Part"` trông như instance | `typeof(v) ~= "Instance"` → `v:IsA(className)` → `v:IsDescendantOf(trustedContainer)` |
| Instance thật nhưng sai chỗ | Part của người khác, tool trong `Workspace` | `IsDescendantOf` container tin cậy + kiểm tra quyền sở hữu |
| Số thực thay integer | `typeof` vẫn là number | `n == math.floor(n)` |
| String khổng lồ hoặc UTF-8 hỏng | Chỉ kiểm `typeof` | `#s <= maxLength` và `utf8.len(s) ~= nil` (DataStore cũng từ chối UTF-8 hỏng) |
| Bảng lồng nhau vô hạn | Duyệt đệ quy không giới hạn | Cap số key/độ sâu, chỉ đọc field mong đợi |
| Enum/ID lạ | So sánh chuỗi lỏng lẻo | Whitelist `{ [value]: boolean }` |
| Toạ độ xa | Chỉ kiểm từng trục | `v.Magnitude <= maxMagnitude` |

- Tra vật phẩm theo ID trong bảng **server** (`ITEMS[itemId]`); không đọc giá/stat từ dữ liệu client, không đọc từ `NumberValue` đã replicate.
- Không bao giờ để remote load asset hoặc `require` module theo ID/đường dẫn client gửi.

## Rate limiting

Token bucket: `capacity` token, refill `capacity / windowSeconds` mỗi giây; hết token thì từ chối, không kick.

- Ví dụ: `newLimiter(5, 1)` — burst 5, nạp lại 5/giây cho đòn đánh.
- Dọn `buckets[player] = nil` trong `Players.PlayerRemoving`, nếu không bảng phình theo session.
- Rate limit riêng, chặt hơn cho: DataStore/Badge/HTTP call (đã có budget riêng), clone model lớn, teleport, cấp currency, mọi thứ `FireAllClients`.
- Rate limit ở server luôn cần thiết kể cả khi client đã throttle: client sửa được code của nó.

## ProximityPrompt, ClickDetector, Touched

| Object | Exploiter làm được gì | Server phải |
| --- | --- | --- |
| `ProximityPrompt` | Bắn `Triggered` khi đang disabled; sửa `MaxActivationDistance`, line-of-sight, `HoldDuration` ở local. Chỉ `Triggered` được engine kiểm tra khoảng cách. | Kiểm lại enabled, khoảng cách tới character, còn sống, cooldown |
| `ClickDetector` | Bắn từ mọi khoảng cách, kể cả khi disabled. Không có kiểm tra server nào. | Như trên, coi như input thô |
| `DragDetector` | Sự kiện click kế thừa không được kiểm; drag chỉ tôn trọng `Enabled` và `PermissionPolicy` | Validate kết quả drag ở server |
| `Touched` trên part client sở hữu | Tạo hoặc chặn touch giả | Xác minh bằng distance/overlap query ở server |

Nếu các object này nằm trong part **không neo** mà client có thể sở hữu, exploiter kéo cả part về phía mình: anchor lại, hoặc `part:SetNetworkOwner(nil)`.

## Network ownership và di chuyển

Client sở hữu physics của character nên có thể teleport, bay, xuyên tường, speed hack, fling người khác (vận tốc NaN/rất lớn), và chặn `Touched`. Lựa chọn, mạnh nhất trước:

1. **Server authority** (`Workspace.AuthorityMode = Server`; đang triển khai trong 2026 — kiểm tra trạng thái hiện tại): server mô phỏng di chuyển với client prediction và rollback, xoá bỏ exploit di chuyển.
2. Kiểm tra phía server: so displacement ngang (XZ) mỗi interval với max speed cộng dung sai latency; miễn trừ teleport hợp lệ (bật cờ server-side khi **bạn** dịch chuyển họ); rubber-band về vị trí hợp lệ cuối thay vì kick.
3. Part quan trọng cho gameplay mà không neo thì giữ server sở hữu: `part:SetNetworkOwner(nil)`.

## Validate hit

Client gửi origin, hướng/part bị trúng, timestamp. Server kiểm:

- Origin gần vị trí **server** của character (dung sai scale theo `player:GetNetworkPing()`).
- Mục tiêu còn sống, là kẻ địch, trong tầm vũ khí; điểm trúng gần vị trí server của mục tiêu.
- Raycast server với **geometry tĩnh** không thấy tường giữa origin và mục tiêu.
- Fire rate, ammo, trạng thái reload/sprint do server giữ.
- Phần thưởng cho race/obby: checkpoint phải theo thứ tự và thời gian hợp lý.

## Kinh tế, trade, purchase

- Currency, inventory, giá chỉ tồn tại ở server. Client hỏi; server kiểm số dư và áp thay đổi atomically, trong **một** module có invariant (không âm, có cap).
- Trade: validate đủ hai phía → commit cả hai → save cả hai; lỗi bất kỳ thì revert hết. Cảnh giác "trade rồi thoát trước khi save": khoá item trong lúc trade và save ngay sau đó.
- Robux: chỉ cấp trong `MarketplaceService.ProcessReceipt` (developer product), idempotent theo `PurchaseId`, chỉ trả `PurchaseGranted` sau khi đã persist; pass thì kiểm quyền sở hữu ở server. Không tin `PromptProductPurchaseFinished` từ client.
- `PolicyService` cho nội dung ngẫu nhiên trả phí; công bố tỉ lệ.

## Teleport và access control

- Client tự teleport được tới **bất kỳ place nào** trong universe: đặt **Access Control for Places → Secure within universe only**, và kiểm tra điều kiện vào ở server khi join (mặc định từ chối).
- `TeleportData` do client đọc và sửa được: không dùng cho tiền, item, quyền. Server tra DataStore/MemoryStore theo `UserId` hoặc `PrivateServerId`.
- Teleport chỉ phát từ server; retry có backoff (`Flooded` → 15 giây, `Failure` → 1 giây, tối đa 5 lần).

## Bí mật code

- Mọi `LocalScript`, client `Script`, `ModuleScript` replicate đều decompile được — kể cả khi disabled hoặc không bao giờ `require`. Không trộn nhánh server-only vào module dùng chung.
- Mọi thứ replicate (model, UI, attribute) đều data-mine được: nội dung chưa release để ở universe private riêng, không giấu trong production.
- Không để API key trong script hay attribute; dùng Secrets của experience và `HttpService:GetSecret`.
- Lệnh admin kiểm `player.UserId` với danh sách server-side (hoặc role nhóm qua `GroupService:GetRolesInGroupAsync`), không bao giờ theo `player.Name` hay cờ client gửi.

## Heuristic và Ban API

Xếp lớp heuristic server trên nền validation: thời gian hoàn thành nhanh nhất có thể, tốc độ tăng tài nguyên, nhịp hành động đều bất thường, remote honeypot mà client hợp lệ không bao giờ gọi. Cộng điểm nghi ngờ, chỉ hành động khi nhiều tín hiệu. Thang bậc: log im lặng → giảm thiểu im lặng → hạn chế tính năng → kick/ban. Trì hoãn hậu quả hiển thị để exploiter không dò được check.

- `Players.BanningEnabled` phải bật để dùng Ban API.
- `Players:BanAsync({ UserIds, Duration, DisplayReason, PrivateReason, ExcludeAltAccounts, ApplyToUniverse })`: `Duration` tính bằng **giây**, `-1` = vĩnh viễn; `DisplayReason` tối đa **400 ký tự** và bị filter; `PrivateReason` chỉ bạn thấy; `ExcludeAltAccounts = false` để ban cả alt detect được; `ApplyToUniverse = true` áp cho toàn experience.
- `pcall` quanh `BanAsync`; fail thì fallback `player:Kick`.
- Ưu tiên ban có thời hạn và có thể đảo (`Players:UnbanAsync`); dùng `Players:GetBanHistoryAsync` để escalate. Version hoá rule phát hiện và theo dõi tỉ lệ false positive.

## Công cụ đo

| Tool | Mở | Dùng cho |
| --- | --- | --- |
| Developer Console | F9 trong game | Lỗi, memory theo category (server/client), network, script activity; chạy được trên server live |
| MicroProfiler | Ctrl+Alt+F6 (⌘⌥F6); server qua Dev Console | Timing từng frame, spike; dump một frame để phân tích |
| Script Profiler | Studio / Dev Console | Hàm nào ăn thời gian Luau (sampling) |
| Luau heap snapshot | Dev Console → Memory → Luau Heap | Bảng/closure/instance nào bị giữ và bị giữ bởi ai (leak) |
| Scene Analysis | Studio | Script memory, unparented instance (leak), thành phần instance, memory audio/animation, triangle count |
| Performance Stats / Debug Stats | Ctrl+Alt+F7 / Shift+Ctrl+F1–F5 | Overlay CPU/GPU/memory/network trực tiếp |
| Network Simulation | Studio (Alt+S) | Test với latency, jitter, packet loss |
| Performance dashboard | Creator Hub | FPS tổng hợp, server heartbeat, memory, crash rate theo thiết bị |

Gắn nhãn code của mình để đọc được trong MicroProfiler và memory view: `debug.setmemorycategory("EnemyAI")` cho thread hiện tại, `debug.profilebegin("EnemyAI.think")` / `debug.profileend()` quanh vùng cần đo.

## Mục tiêu

- Client: 60 FPS trên điện thoại tầm trung (≈16.6 ms/frame); phần lớn người chơi dùng Android yếu.
- Server: heartbeat gần 60 Hz (`workspace:GetRealPhysicsFPS()`, Dev Console Server Stats).
- Memory: client mobile chết vì OOM trước; giữ client memory dưới ~1–1.5 GB trên máy yếu, theo dõi `PlaceMemory`, `LuaHeap`, `GraphicsTexture`, `Sounds`, `Animation`.

## Chẩn đoán theo triệu chứng

| Triệu chứng | Nguyên nhân thường gặp | Sửa |
| --- | --- | --- |
| Memory tăng theo thời gian | Connection không disconnect, bảng key theo Player/Instance, instance đã destroy nhưng còn tham chiếu, instance `Parent = nil` | Dọn theo player/character, clear bảng ở `PlayerRemoving`, xem "unparented instances" + heap snapshot |
| Server lag khi đông người | Loop per-player mỗi frame, `while true do task.wait() end`, handler remote nặng, physics nhiều part không neo | Event-driven, một scheduler loop, throttle nhịp think, anchor part tĩnh |
| Client tụt FPS | Quá nhiều part/draw call, bóng từ nhiều đèn, overdraw trong suốt/particle, update UI mỗi frame | Gộp mesh/instance, `CastShadow = false` cho part nhỏ, bớt đèn đổ bóng, update UI khi đổi |
| Spike mỗi N giây | Autosave/GC burst, loop đồng bộ giữa các player, `Clone()` lớn | Lệch pha bằng random offset, pool object, chia việc qua nhiều frame |
| Ping cao, rubber banding | Remote spam, payload lớn, replicate nhiều thay đổi property | Batch, delta, throttle; tween ở client |
| Join lâu | Place lớn, nhiều asset riêng lẻ, không streaming | Streaming, SLIM LOD, ít mesh/texture độc nhất, `ContentProvider:PreloadAsync` chỉ cho asset quan trọng |

## Hot path Luau

- Cache service, instance, `RaycastParams` ra ngoài loop; không `FindFirstChild`/`GetDescendants` mỗi frame. Thay scan bằng tag (`CollectionService`) hoặc set được bảo trì.
- Dùng `deltaTime` từ `Heartbeat`/`PreSimulation` thay cho loop `task.wait()`.
- Không tạo closure/bảng mỗi frame trong loop nóng; tái dùng buffer bằng `table.clear`.
- `--!native` (cả script) hoặc `@native` (từng hàm) cho code nặng toán; tham số có kiểu giúp native compiler. Đừng bật tràn lan: tốn compile time và có giới hạn memory native toàn cục.
- `--!optimize 2` là mức Roblox dùng cho game live; đừng lấy timing trong Studio làm micro-benchmark.

## Rendering và asset

- Part: ít hơn và lớn hơn; `MeshPart` dùng chung `MeshId` được instanced (rẻ); union (`PartOperation`) có thể đắt — xem triangle count trong Scene Analysis.
- `RenderFidelity = Automatic`/`Performance` cho mesh chi tiết; `CollisionFidelity = Box`/`Hull` cho mesh trang trí; `CanCollide`/`CanQuery`/`CanTouch = false` cho đồ trang trí thuần.
- Đèn: giới hạn `PointLight`/`SpotLight`/`SurfaceLight` đổ bóng; giới hạn `ParticleEmitter.Rate` và kích thước particle (overdraw); giới hạn `Beam`/`Trail`.
- Texture: tái sử dụng, giữ độ phân giải hợp lý (tối đa 1024² cho hầu hết trường hợp); `SurfaceAppearance` dùng tiết kiệm.

## Physics

- Anchor mọi thứ không cần chuyển động; part trang trí weld vào assembly đang động vẫn tốn.
- Ít và đơn giản hơn về collision (`CollisionFidelity`, collision group để bỏ cặp); `CanTouch = false` khi không cần `Touched`.
- Không set `CFrame` của part không neo mỗi frame; dùng constraint hoặc anchor + CFrame.
- `workspace:BulkMoveTo(parts, cframes, Enum.BulkMoveMode.FireCFrameChanged)` để dịch nhiều part đã neo.
- `PhysicsSteppingMethod = Adaptive` giảm CPU physics.

## Streaming và native codegen

- Bật streaming cho place lớn, `Model.LevelOfDetail = SLIM` cho model tĩnh, để `StreamOutBehavior = Opportunistic` giải phóng memory.
- Client code phải streaming-safe: `WaitForChild`/nil check cho nội dung `Workspace`, không index cứng part chưa stream.
- Native codegen chỉ có lợi cho vòng lặp toán học thuần; code điều khiển instance hầu như không nhanh hơn.

## Parallel Luau

Script dưới các `Actor` khác nhau chạy song song; script trong **cùng** một `Actor` chạy tuần tự với nhau, nên phải chia việc ra nhiều `Actor`.

```luau
--!strict
-- Script gắn dưới một Actor (mỗi Actor một đơn vị logic: nhóm NPC, chunk bản đồ).
local RunService = game:GetService("RunService")

local results: { number } = {}

RunService.Heartbeat:ConnectParallel(function(_deltaTime)
	-- Pha song song: chỉ đọc hầu hết instance, tính toán thuần, API thread-safe (raycast).
	for i = 1, 100 do
		results[i] = math.noise(i / 10, os.clock())
	end
	task.synchronize()
	-- Pha tuần tự: ghi instance, phát event, gọi API không thread-safe.
end)
```

- `task.desynchronize()` / `task.synchronize()` chuyển pha; `ConnectParallel` bắt đầu ở pha song song.
- Không `require` hay sửa hầu hết instance khi đang desynchronize. Giao tiếp bằng `Actor:SendMessage` / `BindToMessageParallel` hoặc `SharedTable` (`SharedTableRegistry`).
- Hợp: validate raycast, sinh procedural, toán quanh pathfinding, mô phỏng lớn. Không hợp: việc quá nhỏ (overhead sync), việc nặng instance.

## Bộ nhớ và leak

1. Dev Console → Memory: category nào tăng (`LuaHeap`, `Instances`, `Signals`, `PhysicsParts`, `GraphicsTexture`, `Sounds`, `Animation`)?
2. Luau Heap: chụp snapshot, chơi một lúc, chụp lại, so sánh; xem "Unique references" để biết bảng/closure nào đang giữ object.
3. Scene Analysis → **Unparented instances**: instance `Parent = nil` vẫn được Luau tham chiếu (character cache, UI clone, part đã gỡ còn trong bảng).
4. Thủ phạm thường gặp: handler `PlayerAdded` tạo connection không bao giờ disconnect; bảng key theo `Player`/`Instance` không clear khi rời/huỷ; `Died:Connect` trong `CharacterAdded` giữ upvalue lớn (ổn nếu character bị `Destroy`, leak nếu chỉ reparent); gỡ instance bằng `Parent = nil` thay vì `:Destroy()`.
5. Pattern an toàn: "túi cleanup" theo player — `track(player, cleanup)` đẩy hàm vào `bags[player]`, chạy hết trong `PlayerRemoving` rồi `bags[player] = nil`.

## Chi phí replication

- Mỗi thay đổi property được replicate là băng thông; đổi 20 property mỗi frame cho 50 part là thảm hoạ. Gộp thành một attribute/bảng, hoặc để client tự suy ra.
- Server-side tween/`CFrame` set mỗi frame vừa tốn CPU server vừa tốn network: tween ở client.
- Theo dõi bằng label `ProcessPackets` và `Allocate Bandwidth and Run Senders` trong MicroProfiler, và tab **Network** của Dev Console.
- Streaming giảm join time nhưng làm client thiếu instance: code phải chịu được `nil`.

## Checklist review

Xếp theo mức độ; mỗi finding ghi **file:line, severity, cái gì hỏng, cách sửa**.

| Severity | Ví dụ |
| --- | --- |
| **Critical** | Thưởng/damage/currency do client quyết; tham số remote không validate (NaN, instance giả); cấp purchase ngoài `ProcessReceipt` hoặc không idempotent; nhiều server `SetAsync` cùng key không session locking; secret/API key trong code replicate; text người chơi chưa filter đã hiện cho người khác |
| **High** | Đường mất dữ liệu (không `BindToClose`, ghi default sau load fail, không retry); memory leak (connection, bảng key theo player); `InvokeClient`; remote mỗi frame; yield vô hạn (`WaitForChild` không timeout cho instance optional, handler `RemoteFunction` có thể treo); client index khi chưa stream |
| **Medium** | API deprecated/superseded; `wait`/`spawn`/`delay`; loop polling; tween ở server; thiếu `pcall` cho API network/yield; không xử lý late-joiner; race condition `CharacterAdded` |
| **Low** | Style, naming, thiếu type, magic number, dead code, tối ưu vụn |

- **Security**: mọi handler kiểm `typeof`, `math.isfinite`, độ dài/UTF-8 string, `IsA` + `IsDescendantOf`, rate limit, ngữ cảnh; không logic server-only trong `ReplicatedStorage`/`StarterPlayer`/`Workspace`; prompt/click/touch kiểm lại ở server; part quan trọng được server sở hữu.
- **Data**: session locking; `UpdateAsync` cho read-modify-write; retry có backoff; `BindToClose` flush song song; không lưu `Instance`/`Vector3`/bảng trộn; load fail không ghi đè default; key ổn định `User_{UserId}`; Studio dùng store/universe riêng.
- **Monetization**: một `ProcessReceipt`, idempotent theo `PurchaseId`, trả `PurchaseGranted` sau khi persist; pass kiểm lúc join **và** sau khi mua trong session; giá không hard-code; random trả phí công bố tỉ lệ và tôn trọng `PolicyService`.
- **Correctness**: xử lý người chơi đã ở trong game (`for _, p in Players:GetPlayers()`), character đã spawn; state theo character dựng lại khi respawn, state theo player dọn khi rời; không yield ở top-level module, không require vòng; deferred-event safe.
- **Performance**: không `FindFirstChild`/`GetDescendants`/`Instance.new` mỗi frame; event-driven thay polling; think loop throttle và lệch pha; tween/hiệu ứng ở client; remote batch/throttle; connection disconnect, instance destroy, cache có cap.
- **Text**: mọi text người chơi hiện cho người khác phải filter server-side (`FilterStringAsync`), fail closed; chat dùng `TextChatService`; text công khai cho sửa phải rate limit ≥ 1 phút.
- **Modern API**: `task.*`, biến thể `*Async`, `Raycast`, constraint mover, `PivotTo`, `Animator:LoadAnimation`, `TextChatService`, `UIDragDetector`, API collision group trên `workspace`, `CreatePath` + `ComputeAsync`.
- **Code quality**: `--!strict` với API public có type; service qua `GetService`; không `_G`/`shared`; tách config khỏi logic; test cho phần thuần.

## Bản đồ API thay thế

Camel-case alias (`:findFirstChild`, `:remove`, `.className`, ...) đều deprecated, dùng dạng PascalCase. "Superseded" vẫn chạy nhưng đã có replacement chính thức — coi như deprecated trong code mới.

| Cũ | Thay bằng | Vì sao |
| --- | --- | --- |
| `wait` / `spawn` / `delay` | `task.wait` / `task.spawn` / `task.delay` | Scheduler mới, không bị làm tròn 0.03 s, không mất thread |
| `getfenv` / `setfenv` | không có | Tắt optimization của Luau |
| `table.getn`, `table.foreach`, `table.foreachi` | `#t`, generic `for` | Thư viện chuẩn |
| `Ray.new` + `FindPartOnRay*` | `workspace:Raycast(origin, dir, RaycastParams)` | Lọc bằng params, nhanh hơn, không cần ignore list thủ công |
| `Region3` + `FindPartsInRegion3*`, `IsRegion3Empty*` | `workspace:GetPartBoundsInBox(cframe, size, OverlapParams)` | Cùng lý do |
| `Player:LoadCharacter()`, `LoadCharacterWithHumanoidDescription()` | `...Async()` | API đồng bộ bị loại bỏ dần |
| `Player:GetRankInGroup`, `GetRoleInGroup`, `IsInGroup`, `IsFriendsWith`, `GetFriendsOnline` | `GroupService:GetRolesInGroupAsync`, `IsInGroupAsync`, `IsFriendsWithAsync`, `GetFriendsOnlineAsync` | Bản sync chặn thread |
| `Player.MembershipType` | `Player.HasRobloxSubscription` | Premium đổi tên/ngữ nghĩa |
| `Player:Save*/Load*`, `DataReady`, `WaitForDataReady`, `DataComplexity` | `DataStoreService` | API cũ đã bỏ |
| `Players.NumPlayers` | `#Players:GetPlayers()` | Không còn cập nhật đáng tin |
| `Humanoid:LoadAnimation`, `AnimationController:LoadAnimation` | `Animator:LoadAnimation` | Track phải thuộc `Animator` để replicate đúng |
| `AnimationTrack.KeyframeReached` | `AnimationTrack:GetMarkerReachedSignal(name)` | Keyframe API cũ |
| `Humanoid:ApplyDescription`, `ApplyDescriptionReset`, `PlayEmote` | `...Async()` | Bản sync chặn |
| `BodyVelocity`, `BodyPosition`, `BodyGyro`, `BodyForce`, `BodyThrust`, `BodyAngularVelocity`, `RocketPropulsion` | `LinearVelocity`, `AlignPosition`, `AlignOrientation`, `VectorForce`, `AngularVelocity`, `LineForce` | Mover cũ không ổn định, không hỗ trợ constraint solver mới |
| `BasePart.Velocity` / `RotVelocity` | `AssemblyLinearVelocity` / `AssemblyAngularVelocity` (hoặc `ApplyImpulse`) | `Velocity` chỉ đọc/ghi trên một part, sai với assembly |
| `BasePart.Friction`/`Elasticity`/`SpecificGravity` | `CustomPhysicalProperties` | Thuộc tính rời rạc đã gộp |
| `MakeJoints`/`BreakJoints`, surface joints (`Glue`, `Snap`, `Motor`, `ManualWeld`), `JointsService` | `WeldConstraint`, `HingeConstraint`, `GetJoints()` + `Destroy()` | Joint ngầm gây lỗi khó tái hiện |
| `PhysicsService:CreateCollisionGroup`/`RemoveCollisionGroup`/`GetCollisionGroups`/`RegisterCollisionGroup`/`CollisionGroupSetCollidable`/`RenameCollisionGroup`/`GetMaxCollisionGroups` | Cùng tên trên `workspace` (WorldRoot) | Hợp nhất API về WorldRoot |
| `PhysicsService:SetPartCollisionGroup`, `GetCollisionGroupId/Name`, `CollisionGroupContainsPart`, `BasePart.CollisionGroupId` | `BasePart.CollisionGroup` (string) | ID số dễ lệch giữa các place |
| `Model:SetPrimaryPartCFrame()` / `GetPrimaryPartCFrame()` | `Model:PivotTo()` / `GetPivot()` | Không cần `PrimaryPart`, xử lý pivot đúng |
| `Model:GetModelCFrame()` / `GetModelSize()` | `GetBoundingBox()` / `GetExtentsSize()` | Tên phản ánh đúng phép đo |
| `BasePart:GetRenderCFrame()` | `BasePart.CFrame` | Render CFrame không còn khác biệt |
| `BasePart.StoppedTouching`, `LocalSimulationTouched` | `TouchEnded`, `Touched` | Trùng lặp |
| `Camera.CoordinateFrame`, `Camera:Interpolate`, `SetRoll/GetRoll`, `SetCameraPanMode` | `Camera.CFrame`, `TweenService`, toán CFrame | API camera cũ không hỗ trợ scripting hiện đại |
| `Hint`, `Message` | `TextLabel` trong `ScreenGui` | Không tuỳ biến, không scale |
| `Hat`, `Skin` | `Accessory`, `BodyColors` | Hệ thống avatar mới |
| `HopperBin`, `Hopper` | `Tool`, `StarterPack` | Đã bỏ khỏi engine |
| `Instance:Remove()` | `Destroy()` / `Parent = nil` | `Remove` không dọn connection, gây leak |
| `DataModel.OnClose` | `game:BindToClose()` | Chỉ `BindToClose` chạy đúng lúc shutdown |
| `DataModel.VIPServerId`/`VIPServerOwnerId` | `PrivateServerId` / `PrivateServerOwnerId` | Đổi tên |
| `DataModel.ItemChanged` | `Instance.Changed` / `GetPropertyChangedSignal` | Bắn cho mọi property, quá tốn |
| `CollectionService.ItemAdded/ItemRemoved`, `GetCollection` | `GetInstanceAddedSignal/GetInstanceRemovedSignal`, `GetTagged` | Tên mới, ngữ nghĩa rõ |
| `GuiObject:TweenPosition/TweenSize/TweenSizeAndPosition`, `GuiObject.Draggable` | `TweenService:Create`, `UIDragDetector` | Tween cũ không huỷ được, drag cũ không hỗ trợ touch |
| `FontSize`, `TextColor`, `TextWrap` | `TextSize`, `TextColor3`, `TextWrapped` | Đổi tên cho rõ kiểu |
| `StarterGui.ResetPlayerGuiOnSpawn` | `ScreenGui.ResetOnSpawn` | Cấu hình theo từng ScreenGui |
| `Mouse.KeyDown/KeyUp` | `UserInputService` / Input Action System | `Mouse` không có trên mobile/console |
| `ContextActionService:BindActionToInputTypes` | `BindAction` | Một entry point |
| `InputAction:Fire()` | `InputBinding:Fire()` | Tách action khỏi binding |
| `MarketplaceService:GetProductInfo`, `PlayerOwnsAsset`, `PlayerOwnsBundle` | `...Async()` | Bản sync chặn thread |
| `GamePassService:PlayerHasPass` | `MarketplaceService:UserOwnsGamePassAsync` | Service cũ đã bỏ |
| `BadgeService:AwardBadge`, `UserHasBadge`, `IsDisabled`, `IsLegal` | `AwardBadgeAsync`, `UserHasBadgeAsync`, `GetBadgeInfoAsync().IsEnabled` | Bản sync chặn |
| `TeleportService:Teleport`, `TeleportToPlaceInstance`, `TeleportToPrivateServer`, `TeleportPartyAsync`, `TeleportToSpawnByName` | `TeleportAsync()` + `TeleportOptions` | Không retry được, không trả kết quả |
| `TeleportService:ReserveServer()` | `ReserveServerAsync()` | Bản sync chặn |
| `GlobalDataStore:OnUpdate()` | `MessagingService` | Không đáng tin giữa các server |
| `PathfindingService:FindPathAsync`, `ComputeRawPathAsync`, `ComputeSmoothPathAsync`, `Path:GetPointCoordinates`, `CheckOcclusionAsync` | `CreatePath()` + `ComputeAsync()`, `GetWaypoints()`, `Path.Blocked` | API path cũ không hỗ trợ agent mới |
| `AnalyticsService:FireEvent/FireCustomEvent/FireInGameEconomyEvent/FirePlayerProgressionEvent` | `LogCustomEvent`, `LogEconomyEvent`, `LogProgressionEvent` (+ Start/Complete/Fail), `LogFunnelStepEvent` | Tên mới, có funnel |
| `Chat` service, `Chat:FilterStringForPlayerAsync`, module ChatService cũ | `TextChatService`, `TextService:FilterStringAsync` | Chat cũ bị gỡ |
| `TextFilterResult:GetChatForUserAsync()` | `TextChannel` cho chat; `GetNonChatStringForUserAsync`/`ForBroadcastAsync` cho text khác | Trả chuỗi rỗng, âm thầm mất chữ |
| `LocalizationService:GetTranslatorForPlayer()` | `...Async()` | Bản sync chặn |
| `Sound.Pitch`, `Sound.MinDistance`/`MaxDistance`/`EmitterSize` | `PlaybackSpeed`, `RollOffMinDistance`/`RollOffMaxDistance` | Đổi tên theo không gian 3D |
| `ContentProvider:Preload()` | `PreloadAsync()` | Có progress và lỗi rõ ràng |
| `Stats.HeartbeatTimeMs`/`PhysicsStepTimeMs` | `HeartbeatTime`/`PhysicsStepTime` | Đơn vị đổi |
| `InsertService:Insert`, `GetFreeModels`, `GetFreeDecals` | `LoadAsset`, `GetFreeModelsAsync`, `GetFreeDecalsAsync` | Bản sync chặn |
| `AudioPlayer.AssetId` | `AudioPlayer.Asset` | API audio mới |
| `Lighting.Technology` | `LightingStyle` + `PrioritizeLightingQuality` | Cấu hình ánh sáng mới |
| `Workspace.FilteringEnabled` | không có | Luôn bật |
| `Decal.Texture`, `Decal.Shiny/Specular` | `Decal.ColorMapContent`, `SurfaceAppearance`/material | Đổi sang content API |
| `Terrain:SetCell/GetCell/SetCells/GetWaterCell`, `ConvertToSmooth` | `FillBlock/FillBall/ReadVoxels/WriteVoxels` | API voxel mới, nhanh hơn nhiều |
| `FormFactorPart.FormFactor` | `Size` trực tiếp | FormFactor không còn ảnh hưởng |
| `Teams:RebalanceTeams()`, `Team.Score`, `PointsService` | Tự viết logic, badge/progression riêng | Không còn được bảo trì |
| `AdService:ShowVideoAd`, `AdGui.OnAdEvent` | `AdService:ShowRewardedVideoAdAsync` | API quảng cáo mới |
| `TestService:Run()`, `FunctionalTest` | `TestService:RunAsync()`, framework (Jest Lua) | Bản sync chặn |
| `OpenCloudService`, `OpenCloudApiV1` | `HttpService:RequestAsync` + API key secret | API cũ bị thay |
| `GenerationService:GenerateMeshAsync` | `GenerateModelAsync` | Sắp bị gỡ |

## Bẫy

- **Exploiter mua item giá 0** — giá đọc từ tham số client hoặc từ `NumberValue` đã replicate; sửa: tra `ITEMS[itemId].price` trong module server.
- **Số dư thành `nan` và mọi so sánh đều qua** — thiếu `math.isfinite` trước khi so sánh; sửa: validate finiteness rồi mới range check, và clamp mọi phép cộng.
- **`ProximityPrompt` kích hoạt từ xa** — prompt nằm trong part client sở hữu, `MaxActivationDistance` bị sửa ở local; sửa: kiểm distance + enabled + alive ở server, anchor hoặc `SetNetworkOwner(nil)`.
- **Người chơi fling người khác** — vận tốc NaN/rất lớn trên part client own; sửa: server sở hữu part quan trọng, kẹp vận tốc, dùng server authority.
- **Trade xong thoát game, item nhân đôi** — item chưa bị khoá và chưa save ngay, server thứ hai load bản cũ; sửa: khoá trong trade, commit rồi save, session locking.
- **Purchase cấp hai lần** — `ProcessReceipt` không idempotent theo `PurchaseId`; sửa: ghi nhận `PurchaseId` đã xử lý trước khi trả `PurchaseGranted`.
- **Script "bí mật" bị đọc** — `ModuleScript` trong `ReplicatedStorage` luôn decompile được dù không `require`; sửa: chuyển sang `ServerScriptService`/`ServerStorage`.
- **Người chơi vào thẳng place end-game** — Access Control mở; sửa: `Secure within universe only` + kiểm tra server khi join.
- **Exploiter dò được ngưỡng phát hiện** — kick ngay khi vượt check, nên họ bisect bằng cách thử tăng dần; sửa: cộng điểm nghi ngờ, trì hoãn hậu quả, log im lặng.
- **Ban API không có tác dụng** — `Players.BanningEnabled` chưa bật, hoặc `Duration` truyền ms thay vì giây; sửa: bật flag, `Duration` tính bằng giây, `-1` là vĩnh viễn.
- **FPS tụt chỉ trên mobile** — quá nhiều part/đèn đổ bóng/texture lớn chứ không phải script; sửa: đo memory + render trước, hạ `CastShadow`, gộp mesh, streaming.
- **Memory tăng đều mỗi lần respawn** — connection trong `CharacterAdded` không disconnect, bảng key theo character không clear; sửa: túi cleanup theo player, `Destroy()` thay `Parent = nil`.
- **Server lag dù script nhẹ** — hàng trăm part không neo hoặc `Touched` bật khắp nơi; sửa: anchor, `CanTouch = false`, collision group, adaptive stepping.
- **Spike đúng mỗi 3 phút** — autosave của mọi server/người chơi chạy cùng pha; sửa: `task.wait(math.random() * interval)` lúc khởi động và jitter từng lần lưu.
- **Join time vài chục giây** — place lớn không streaming, nhiều texture độc nhất; sửa: streaming + SLIM LOD + `PreloadAsync` chỉ asset quan trọng.
- **`ConnectParallel` không nhanh hơn** — việc quá nhỏ hoặc nằm trong cùng một `Actor` nên vẫn tuần tự; sửa: chia nhiều `Actor`, chỉ đưa phần tính toán thuần vào pha song song.
- **`--!native` làm chậm** — bật cả script có nhiều thao tác instance; sửa: chỉ `@native` cho hàm toán học nóng, đo lại trên thiết bị yếu.
