# Model không rời: lắp ráp có bảo đảm (sniper, xe, robot, máy bay...)

> Vì sao part bị rời: model khó có 15–60 part, mỗi part đặt bằng toạ độ tay → sai vài phần chục stud là "lơ lửng"; weld đặt sai thứ tự; Cylinder trục X; scale cụm đã đặt. Quy trình này biến "liền khối" từ cảm giác thành **số đo bắt buộc đạt**.

## 1. Quy trình bắt buộc (5 bước)

1. **Phân rã thành cụm con** (sub-assembly), không phải một danh sách part phẳng. Sniper = *thân* (receiver+rail+bolt) → *nòng* (barrel+brake+handguard) → *báng* (stock+cheek+butt) → *ống ngắm* (mount×2+tube+front+rear+lens) → *phụ kiện* (grip, magazine, bipod). Mỗi cụm có một **part gốc**.
2. **Khai báo Ổ NỐI (socket)** cho từng mối: điểm `sa` trên part cha, điểm `sb` trên part con. Con được đặt sao cho `sb` TRÙNG `sa` — liền theo cấu trúc, không dựa vào mắt. Dùng `AssemblyGuard.Build(parent, spec, origin)` (xem `examples/SniperAssembly.lua`).
3. **Kiểm bằng số trước khi nhìn**: `python scripts/sim_assembly.py spec.json` (ngoài Studio) hoặc `AssemblyGuard.Check` (trong Studio). Phải đạt: **1 cụm hình học**, **1 cụm weld**, **1 assembly vật lý**, `deepOverlaps = 0`.
4. **Chữa**: `AssemblyGuard.Heal(model, { Tol = 0.08, Snap = true, SnapMax = 1.5 })` weld mọi cặp đang chạm và kéo cụm lơ lửng ≤ 1.5 stud về thân chính. Hở lớn hơn = lỗi spec, sửa ổ nối, không "snap" che.
5. **Cổng giao**: `rep.ok == true` mới được báo xong. Báo kèm dòng `[AssemblyGuard] parts=… cụm-hình-học=1 cụm-weld=1 assembly=1`.

## 2. Quy tắc dựng (nguyên nhân gốc của part rời)

- **Mỗi part phải nối với một part CHA đã đặt** (cây, không phải bãi). Thứ tự `Joins` đi từ Root ra; part mồ côi bị assert.
- **Cylinder/Wedge xoay**: Cylinder có trục tròn là **X** → mối nối dùng `rot = CFrame.Angles(0, math.pi/2, 0)` để nằm theo Z. Đặt ổ nối trên **đầu mút** của trục (±nửa chiều dài), không phải tâm.
- **Đặt tại origin với size cuối** rồi mới `PivotTo`; **không scale cụm đã đặt** (scale làm lệch ổ nối). Muốn to/nhỏ: nhân mọi `Size` và mọi toạ độ ổ nối với cùng hệ số trong spec.
- **Mount/giá đỡ** là part thật nằm giữa hai cụm (ống ngắm ↔ rail cần 2 mount), không để ống ngắm "trùm" lên rail.
- **Weld**: `WeldConstraint` từng part vào **cha trực tiếp** (không weld tất cả vào một part — vẫn tốt nhưng mất cấu trúc để animate sau; xem `AnimKit.Rigify`). Unanchor **một lần ở cuối**, root part cuối cùng.
- **Collision**: `CanCollide=false` mọi part trang trí; 2–3 box vô hình làm collision (súng 40 part bật hết collision là bom vật lý).
- **Tool/vũ khí cầm tay**: parent part thẳng vào `Tool` (không qua Model tạm rồi Destroy — destroy Model là destroy mọi part đã weld); `Handle` là part gốc; chỉnh `GripPos/GripForward`.

## 3. Giới hạn của bộ kiểm

- SAT dùng **hộp bao** của mỗi part. Cylinder/Ball/Wedge/MeshPart bị coi như hộp → có thể báo "chạm" khi thực tế còn hở ở góc cong (≤ khoảng bán kính × 0.3). Part cong quan trọng: kiểm thêm bằng mắt hoặc để `Tol` nhỏ (0.03).
- Chỉ kiểm hình học + weld; **không** biết hai part có "hợp lý về cơ khí" (nòng có thật sự cắm vào thân?). Hãy đặt ổ nối có ý nghĩa cơ khí.
- Hở nhỏ ≤ `Tol` (mặc định 0.05–0.08) được coi là chạm: ở khoảng cách gần có thể thấy khe mảnh — dùng `gap = 0` và chồng nhẹ 0.02 stud để che khe.

## 4. Lỗi thường gặp

| Triệu chứng | Nguyên nhân | Sửa |
|---|---|---|
| Ống ngắm lơ lửng trên rail | đặt theo toạ độ thế giới, thiếu mount | thêm mount; ổ nối rail→mount→tube |
| Nòng xuyên vào báng | trục Cylinder sai hướng | `rot = ALONG_Z`, ổ nối ở đầu mút |
| Cả cụm rơi/trôi khi unanchor | nhiều cụm weld riêng | `Heal`, kiểm `weldGroups == 1` |
| Part nhỏ biến mất ở xa | dày < 0.15 stud | làm dày hoặc vẽ vào texture |
| Tool vỡ khi equip | destroy Model tạm | parent thẳng vào Tool |
