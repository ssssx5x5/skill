# Âm thanh chân thực (laser, nổ, súng, UI)

Hai đường, kết hợp được: **(A) tự tổng hợp** bằng `scripts/synth_sfx.py`, **(B) Toolbox/Creator Store** (thật hơn với tiếng phức tạp). Phát bằng `templates/SoundKit.lua`.

## (A) Tự tổng hợp
`python scripts/synth_sfx.py --out sfx --variants 3 --ogg --analyze`
Hiệu ứng: laser_shot, laser_beam_loop, plasma_charge, explosion, gunshot_rifle, sniper_shot, bolt_action, impact_hit, whoosh, teleport, ui_click, ui_ping. `--analyze` in phổ/đỉnh/độ dài để kiểm bằng số (không phải bằng tai). Roblox nhận mp3/ogg; **upload thủ công** lên Creator Hub (cần tài khoản) để có `rbxassetid://` thật; không bịa id.
Giới hạn thật: tiếng tổng hợp tốt cho laser/UI/charge; **nổ và súng thật cần mẫu thu âm** → ưu tiên (B).

## (B) Toolbox
Tìm "explosion", "sniper shot", "laser" trong Creator Store (hoặc `search_asset`), nghe thử, kiểm quyền sử dụng/độ dài, lấy id, điền vào `SoundKit.Ids`. Một số âm cũ bị gỡ/private: luôn có phương án dự phòng.

## SoundKit
```lua
local Snd = require(RS.SoundKit)
Snd.Ids.explosion = { "rbxassetid://<id thật>" }   -- nhiều id = biến thể
Snd.Play("explosion", position)      -- preset nhiều lớp: crack + sub-thump hạ cao độ + đuôi vọng
Snd.Play("sniper", muzzlePos)         -- shot + tiếng vọng xa + bolt
local loop = Snd.Loop("laser_beam_loop", part); loop:Stop()
Snd.Missing()                         -- in tên còn thiếu id
```
Cái làm tiếng "thật": (1) **nhiều lớp từ cùng mẫu** pitch/EQ khác nhau, (2) pitch ngẫu nhiên ±5%, (3) **trễ theo khoảng cách** (700 studs/s: nổ xa nghe trễ), (4) reverb ngoài trời, (5) EQ: tiếng xa mất cao. Chưa có id → `warn` một lần, không crash.

## Kiểm
Phân tích phổ bằng `--analyze`; nghe bằng tai trong Studio vẫn là bước không thay được — ghi rõ "chưa nghe trong Studio".
