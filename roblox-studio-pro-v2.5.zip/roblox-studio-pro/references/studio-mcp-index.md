# studio-mcp — mục lục theo số dòng

File `studio-mcp.md` dài ~2633 dòng. **Đừng đọc hết**: tra mục dưới, rồi đọc đúng khoảng dòng (Read với offset/limit).

| Dòng | Mục |
|---|---|
| 12-147 | Setup (Windows) |
| 148-157 | Every tool call needs `studio_id` |
| 158-308 | `multi_edit` with a non-empty `old_string` replaces; with `""` it APPENDS |
| 309-346 | `string.find` has no `|` — a Lua pattern is not a regex |
| 347-409 | A jumpable rise and a jumpable distance are two different limits |
| 410-457 | `humanoid.Jump = true` WIPES horizontal velocity |
| 458-531 | Measuring a character's real jump — and how a bad measurement poisons the model |
| 532-557 | A long raycast finds the floor BELOW the void |
| 558-586 | `humanoid:MoveTo` does nothing when the target is ~1 stud away |
| 587-629 | Small gaps are walkable — do not jump them |
| 630-775 | Choosing the ground the bot is standing on: overlap, not contact |
| 776-793 | Landing inset must be computed per axis |
| 794-819 | A Lua closure does not see a `local` declared after it |
| 820-850 | Testing a bot in Studio with one client: use a marker part |
| 851-860 | Edits made during a playtest are reverted when you stop it |
| 861-928 | Making a bot avoid hazards it was never told about |
| 929-948 | Streaming hides geometry from the client — check it before blaming the pathing |
| 949-987 | Benchmarking render performance |
| 988-999 | Roblox engine hard limits |
| 1000-1035 | Terrain vs Part-based chunks — choose by the void requirement |
| 1036-1045 | Streaming |
| 1046-1081 | Luau pitfalls encountered |
| 1082-1110 | `math.noise` has granularity 1.0 — integer arguments return 0 |
| 1111-1123 | Reading live state from `execute_luau` |
| 1124-1155 | GUI construction: set `.Parent` when creating |
| 1156-1479 | You cannot fake a `Player` — proven |
| 1480-1821 | NPC follower bot: the bugs that actually bite |
| 1822-1852 | Syntax-check a script in Edit mode without a playtest |
| 1853-1891 | Verifying a server→client port statically, before trusting it |
| 1892-1918 | A hard-coded rescue threshold must be checked against the map's floor level |
| 1919-2029 | Measuring whether a rig can traverse a structure: jump apex, then height gaps |
| 2030-2061 | Never compute a part's footprint as `Position ± Size/2` |
| 2062-2086 | Making a follower bot navigate a maze without writing a pathfinder |
| 2087-2125 | Input state in a playtest: listen to events, never poll |
| 2126-2142 | Editing a script when `multi_edit` will not cooperate |
| 2143-2160 | Other things that cost time here |
| 2161-2222 | Fly mode: do not anchor the root, and do not reuse the toggle key |
| 2223-2301 | Obby bot navigation: replace a greedy step-picker with PathfindingService |
| 2302-2337 | "My place is gone" — prove it first, and find who owns it |
| 2338-2431 | `Resolving timed out` in a Studio log — separate noise from a real resolver fault |
| 2432-2552 | Reading account state off the local machine (Windows) |
| 2553-2623 | Pushing a script when the MCP client is down (raw JSON-RPC) |
| 2624-2629 | Related Roblox MCP skills |
| 2630-2633 | Safety |
