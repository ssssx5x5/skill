# UI và lớp phủ màn hình (ScreenGui / Overlay)

## Mục lục
1. Nguyên tắc và khung ScreenGui
2. Letterbox (dải đen điện ảnh)
3. Vignette không cần asset (UIGradient)
4. Lớp VHS: scanline, tracking band, nhiễu, tint
5. REC indicator + timecode
6. Fade theo khoảng cách
7. Làm mượt giá trị theo thời gian
8. HUD: thanh máu, phụ đề, chớp sát thương
9. Lỗi thường gặp

## 1. Nguyên tắc và khung ScreenGui

- Overlay là **trình bày thuần**, chạy ở client (`StarterPlayerScripts` hoặc `StarterGui`). Server chỉ gửi sự kiện ("camera lock bắt đầu"), client tự dựng hiệu ứng.
- Dùng **Scale** (`UDim2.fromScale`) cho kích thước phủ màn hình, **Offset** chỉ cho chi tiết nhỏ cố định (viền, chấm REC). Như vậy chạy được trên điện thoại lẫn màn lớn.
- Mỗi lớp là một `Frame`/`ImageLabel` có `ZIndex` rõ ràng. Dùng `DisplayOrder` của ScreenGui để xếp chồng cả cụm.
- Tạo overlay **một lần** rồi bật/tắt hoặc tween độ trong suốt, đừng tạo/hủy mỗi lần dùng.

```lua
local Players = game:GetService("Players")
local player = Players.LocalPlayer

local function makeOverlayGui(name: string, displayOrder: number): ScreenGui
	local gui = Instance.new("ScreenGui")
	gui.Name = name
	gui.ResetOnSpawn = false             -- không mất khi nhân vật chết
	gui.IgnoreGuiInset = true            -- phủ cả vùng thanh trên cùng
	gui.DisplayOrder = displayOrder
	gui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
	gui.Parent = player:WaitForChild("PlayerGui")
	return gui
end

local function makeFrame(parent: Instance, name: string, props: { [string]: any }?): Frame
	local f = Instance.new("Frame")
	f.Name = name
	f.BorderSizePixel = 0
	f.BackgroundColor3 = Color3.new(0, 0, 0)
	f.Size = UDim2.fromScale(1, 1)
	for k, v in props or {} do
		(f :: any)[k] = v
	end
	f.Parent = parent
	return f
end
```

Overlay không được chặn thao tác của người chơi: với `Frame` phủ màn hình, mặc định nó **không** nuốt input điều khiển nhân vật, nhưng nếu dùng `TextButton`/`ImageButton` hay `Active = true` thì sẽ chặn. Chỉ dùng Frame/ImageLabel cho overlay.

## 2. Letterbox

Hai dải đen trên và dưới, trượt vào khi cutscene/camera lock, tạo cảm giác điện ảnh.

```lua
local TweenService = game:GetService("TweenService")

local function createLetterbox(gui: ScreenGui, barHeightScale: number)
	local top = makeFrame(gui, "LetterboxTop", {
		AnchorPoint = Vector2.new(0, 0), Position = UDim2.fromScale(0, 0),
		Size = UDim2.fromScale(1, 0), ZIndex = 50,
	})
	local bottom = makeFrame(gui, "LetterboxBottom", {
		AnchorPoint = Vector2.new(0, 1), Position = UDim2.fromScale(0, 1),
		Size = UDim2.fromScale(1, 0), ZIndex = 50,
	})
	local info = TweenInfo.new(0.6, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	local function setOpen(open: boolean)
		local goal = { Size = UDim2.fromScale(1, open and barHeightScale or 0) }
		TweenService:Create(top, info, goal):Play()
		TweenService:Create(bottom, info, goal):Play()
	end
	return setOpen
end

-- local setLetterbox = createLetterbox(gui, 0.11)  -- ~2.35:1 trên màn 16:9 cần khoảng 0.125
-- setLetterbox(true) ... setLetterbox(false)
```

Dải đen phải cao hơn một chút so với con số lý thuyết nếu `IgnoreGuiInset = false`, vì thanh hệ thống chiếm chỗ. Đặt `IgnoreGuiInset = true` để tránh phải tính bù.

## 3. Vignette không cần asset

Roblox không có gradient hướng tâm cho Frame. Cách không cần upload ảnh: **bốn Frame ở bốn cạnh**, mỗi Frame có `UIGradient` mờ dần vào trong. Góc màn hình chồng hai gradient nên tối hơn một cách tự nhiên, đúng kiểu vignette.

```lua
local function createVignette(gui: ScreenGui, color: Color3, edgeSize: number)
	local falloff = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 0),     -- sát mép: đặc
		NumberSequenceKeypoint.new(0.35, 0.45),
		NumberSequenceKeypoint.new(0.7, 0.85),
		NumberSequenceKeypoint.new(1, 1),     -- phía trong: trong suốt
	})
	local container = makeFrame(gui, "Vignette", { BackgroundTransparency = 1, ZIndex = 20 })

	local function edge(name: string, anchor: Vector2, pos: UDim2, size: UDim2, rotation: number): Frame
		local f = makeFrame(container, name, {
			BackgroundColor3 = color, AnchorPoint = anchor, Position = pos, Size = size,
			BackgroundTransparency = 1, -- cường độ điều khiển bằng thuộc tính này
		})
		local g = Instance.new("UIGradient")
		g.Transparency = falloff
		g.Rotation = rotation
		g.Parent = f
		return f
	end

	local edges = {
		edge("Top",    Vector2.new(0, 0), UDim2.fromScale(0, 0), UDim2.fromScale(1, edgeSize), 90),
		edge("Bottom", Vector2.new(0, 1), UDim2.fromScale(0, 1), UDim2.fromScale(1, edgeSize), -90),
		edge("Left",   Vector2.new(0, 0), UDim2.fromScale(0, 0), UDim2.fromScale(edgeSize, 1), 0),
		edge("Right",  Vector2.new(1, 0), UDim2.fromScale(1, 0), UDim2.fromScale(edgeSize, 1), 180),
	}

	-- strength: 0 (tắt) .. 1 (tối đa). Độ đặc cuối = (1 - BackgroundTransparency) * độ đặc gradient.
	local function setStrength(strength: number)
		local t = 1 - math.clamp(strength, 0, 1)
		for _, f in edges do f.BackgroundTransparency = t end
	end
	return setStrength
end
```

Ghi chú: hướng gradient (`Rotation`) có thể ngược tùy phiên bản; nếu mép tối nằm ở phía trong thay vì sát cạnh, đổi dấu `Rotation` của cạnh đó. Hãy xác nhận trong Studio khi dựng lần đầu. `NumberSequence` của UIGradient tối đa 20 keypoint.

Nếu người dùng có sẵn ảnh vignette: một `ImageLabel` phủ toàn màn hình, `ScaleType = Stretch`, chỉnh `ImageTransparency`. Nhưng phải là asset hợp lệ do họ cung cấp.

## 4. Lớp VHS

VHS giả lập gồm vài lớp nhẹ chồng lên nhau, không lớp nào cần shader:

| Lớp | Cách làm | Chi phí |
|---|---|---|
| Tint + giảm bão hòa | `ColorCorrectionEffect` (`TintColor` hơi xanh/lục, `Saturation` -0.2..-0.4, `Contrast` +0.1) | rất thấp |
| Mờ mềm | `BlurEffect.Size` 1-3 | thấp |
| Scanline | Dải Frame xen kẽ (dưới đây) hoặc ImageLabel tile nếu có texture | thấp, tĩnh |
| Tracking band | 1 Frame có gradient trượt từ trên xuống lặp lại | rất thấp |
| Nháy/nhiễu sáng | 1 Frame trắng/đen đổi độ trong suốt ngẫu nhiên | rất thấp |
| Tối góc | Vignette (mục 3) | thấp |

```lua
local function createVHS(gui: ScreenGui)
	local root = makeFrame(gui, "VHS", { BackgroundTransparency = 1, ZIndex = 30 })

	-- Scanline: N dải, dải chẵn tối nhẹ. Giữ N <= ~120, tạo một lần, không cập nhật mỗi frame.
	local lines = makeFrame(root, "Scanlines", { BackgroundTransparency = 1 })
	local N = 90
	local layout = Instance.new("UIListLayout")
	layout.SortOrder = Enum.SortOrder.LayoutOrder
	layout.Parent = lines
	for i = 1, N do
		makeFrame(lines, "L" .. i, {
			Size = UDim2.fromScale(1, 1 / N),
			BackgroundTransparency = (i % 2 == 0) and 0.88 or 1,
			LayoutOrder = i,
		})
	end

	-- Tracking band: dải sáng mờ chạy xuống rồi lặp
	local band = makeFrame(root, "TrackingBand", {
		BackgroundColor3 = Color3.new(1, 1, 1), BackgroundTransparency = 0.8,
		Size = UDim2.fromScale(1, 0.07), Position = UDim2.fromScale(0, -0.1),
	})
	local g = Instance.new("UIGradient")
	g.Transparency = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.5, 0), NumberSequenceKeypoint.new(1, 1),
	})
	g.Rotation = 90
	g.Parent = band
	TweenService:Create(band, TweenInfo.new(4.5, Enum.EasingStyle.Linear, Enum.EasingDirection.In, -1), {
		Position = UDim2.fromScale(0, 1.1),
	}):Play()

	-- Nháy sáng ngẫu nhiên
	local flicker = makeFrame(root, "Flicker", { BackgroundColor3 = Color3.new(1, 1, 1), BackgroundTransparency = 0.96 })
	local alive = true
	task.spawn(function()
		while alive do
			flicker.BackgroundTransparency = 0.93 + math.random() * 0.06
			task.wait(0.04 + math.random() * 0.08)
		end
	end)

	return function() -- hàm hủy
		alive = false
		root:Destroy()
	end
end
```

Việc nên tránh: tạo hàng trăm Frame cập nhật mỗi frame (nặng); `RenderStepped` chỉ để nháy (dùng vòng `task.wait` thưa hơn là đủ). Aberration màu (lệch kênh RGB) không làm đúng được nếu thiếu shader: đừng hứa, chỉ xấp xỉ bằng tint.

## 5. REC indicator + timecode

```lua
local function createRecIndicator(gui: ScreenGui)
	local holder = makeFrame(gui, "Rec", {
		BackgroundTransparency = 1, AnchorPoint = Vector2.new(0, 0),
		Position = UDim2.fromScale(0.04, 0.05), Size = UDim2.fromOffset(220, 32), ZIndex = 40,
	})

	local dot = makeFrame(holder, "Dot", {
		BackgroundColor3 = Color3.fromRGB(235, 30, 30),
		Size = UDim2.fromOffset(16, 16), Position = UDim2.fromOffset(0, 8),
	})
	local corner = Instance.new("UICorner")
	corner.CornerRadius = UDim.new(1, 0) -- tròn
	corner.Parent = dot
	-- Nhấp nháy bằng một tween lặp vô hạn, rẻ hơn tự đổi mỗi frame
	TweenService:Create(dot, TweenInfo.new(0.6, Enum.EasingStyle.Linear, Enum.EasingDirection.InOut, -1, true), {
		BackgroundTransparency = 1,
	}):Play()

	local label = Instance.new("TextLabel")
	label.BackgroundTransparency = 1
	label.Position = UDim2.fromOffset(26, 0)
	label.Size = UDim2.new(1, -26, 1, 0)
	label.Font = Enum.Font.Code            -- chữ đơn cách, hợp đồng hồ camera
	label.TextSize = 22
	label.TextColor3 = Color3.new(1, 1, 1)
	label.TextXAlignment = Enum.TextXAlignment.Left
	label.Parent = holder

	local start = os.clock()
	local conn = game:GetService("RunService").Heartbeat:Connect(function()
		local t = math.floor(os.clock() - start)
		label.Text = string.format("REC %02d:%02d:%02d", t // 3600, (t // 60) % 60, t % 60)
	end)

	return function()
		conn:Disconnect()
		holder:Destroy()
	end
end
```

Có thể thêm góc khung ngắm (4 chữ L làm từ Frame mảnh), nhãn ngày giờ kiểu camcorder, ký hiệu pin; tất cả đều là Frame/TextLabel tĩnh, đặt ở lề an toàn (4-5% mép màn hình).

## 6. Fade theo khoảng cách

Một hàm dùng cho mọi thứ: biến khoảng cách thành hệ số 0..1.

```lua
-- 0 khi dist <= nearD, 1 khi dist >= farD, nội suy trơn ở giữa
local function distanceAlpha(dist: number, nearD: number, farD: number): number
	local t = math.clamp((dist - nearD) / (farD - nearD), 0, 1)
	return t * t * (3 - 2 * t) -- smoothstep: không có "góc gãy" ở hai đầu
end
```

Ba cách dùng thường gặp:

1. **Cường độ overlay theo quái đến gần** (vignette đỏ, nhịp tim, nhiễu VHS tăng dần):
   `strength = 1 - distanceAlpha(dist, 8, 60)`, rồi làm mượt (mục 7) trước khi `setStrength`. Cập nhật 10-20 lần/giây là đủ.
2. **Nhãn/UI trong thế giới** (`BillboardGui`): đặt `MaxDistance` để Roblox tự ẩn khi xa; muốn mờ dần thì đổi `TextTransparency`/`ImageTransparency` theo `distanceAlpha`.
3. **Mờ cả model theo khoảng cách** (quái hiện dần trong sương): đặt `part.LocalTransparencyModifier` cho từng BasePart ở client (hệ số hiển thị cục bộ, không replicate). Cập nhật theo nhịp thưa:

```lua
local function fadeModel(model: Model, camera: Camera, nearD: number, farD: number)
	local dist = (camera.CFrame.Position - model:GetPivot().Position).Magnitude
	local a = distanceAlpha(dist, nearD, farD) -- xa thì a = 1 = ẩn hẳn
	for _, d in model:GetDescendants() do
		if d:IsA("BasePart") then d.LocalTransparencyModifier = a end
	end
end
```

Cache danh sách BasePart một lần thay vì gọi `GetDescendants()` mỗi lần.

## 7. Làm mượt giá trị theo thời gian

Cường độ thay đổi đột ngột trông rẻ. Dùng nội suy **độc lập frame rate**:

```lua
-- k càng lớn càng bám nhanh (thử 4-12). Cùng kết quả ở 30 hay 144 FPS.
local function smooth(current: number, target: number, k: number, dt: number): number
	return current + (target - current) * (1 - math.exp(-k * dt))
end
```

Không dùng `current + (target - current) * 0.1` mỗi frame: tốc độ phụ thuộc FPS.

Dùng cho: cường độ vignette, âm lượng nhạc nền, độ tối, cường độ blur. Cho cú giật mình thì **đảo ngược**: tăng tức thì lên đỉnh rồi giảm mượt (`k` nhỏ) để có cảm giác "đập rồi lắng".

## 8. HUD: thanh máu, phụ đề, chớp sát thương

- **Thanh máu**: 2 Frame lồng nhau (nền + lớp trên), cập nhật bằng `TweenService` trên `Size`; thêm lớp "máu trễ" (một Frame thứ ba giảm chậm hơn) để người chơi thấy mất bao nhiêu.
- **Phụ đề/thoại**: `TextLabel` với `TextWrapped = true`, `UITextSizeConstraint`, hiệu ứng gõ chữ bằng cách tăng `MaxVisibleGraphemes` theo thời gian (`label.MaxVisibleGraphemes = n`). Dùng `RichText` cho nhấn mạnh.
- **Chớp sát thương**: một Frame đỏ phủ màn, đặt `BackgroundTransparency = 0.5` tức thì rồi tween về 1 trong 0.4s. Kết hợp `ColorCorrectionEffect` và camera shake (xem `vfx-sfx.md`).
- Ẩn UI mặc định khi cần: `StarterGui:SetCoreGuiEnabled(Enum.CoreGuiType.Health, false)`; có thể cần gọi lại trong vòng `pcall` + `task.wait` vì core có thể chưa sẵn sàng lúc script khởi động.

## 9. Lỗi thường gặp

- Overlay không hiện: `ScreenGui` chưa vào `PlayerGui`, `Enabled = false`, `ZIndex` thấp hơn UI khác, hoặc `BackgroundTransparency = 1` cho cả cụm mà quên gán cường độ. **Lỗi "im lặng"**: in log khi tạo overlay, và xem `references/verification.md`.
- Overlay biến mất khi chết: quên `ResetOnSpawn = false`.
- UI lệch trên điện thoại: dùng Offset cho thứ cần phủ màn hình, hoặc quên `IgnoreGuiInset`.
- Vignette trông như bốn dải riêng biệt: `edgeSize` quá nhỏ hoặc gradient không đủ keypoint mờ dần; tăng `edgeSize` (0.3-0.4) và thêm keypoint trung gian.
- Nháy/scanline làm tụt FPS: số Frame quá nhiều hoặc cập nhật mỗi frame. Giảm N, không dùng `RenderStepped` cho việc chỉ cần 10-20 Hz.
