# Hình học sinh bằng code, rig và LOD

> Khi nào dùng: cần model **không** phải hộp ghép mà không có mesh upload; creature/vũ khí/tàu có đường cong; rig cho quái; pose procedural. Dùng `templates/GeoKit.lua`, `ModelKit.lua`, `PoseKit.lua`.

## 1. Chọn đường dựng (thứ tự thử)

| Hình cần | Đường | Ghi chú |
|---|---|---|
| Thân tròn xoay (bình, cột, chai, mũ, tên lửa) | `GeoKit.Lathe(profile, sides)` → `ToMeshPart` | profile là list `{bán kính, y}`; 12–24 cạnh |
| Thân thuôn (tàu, cá, thú, cánh) | `GeoKit.Loft` với `EllipseSection` đổi cỡ dọc thân | 8–16 điểm/mặt cắt, 6–14 mặt cắt |
| Cành, đuôi, xúc tu, rễ, dây | `GeoKit.Sweep(CatmullRom(points), radii)` | radii giảm dần về ngọn |
| Cùng hình nhưng không có EditableMesh | `GeoKit.Tube` (xi-lanh + bi) | chạy mọi nơi, ít mượt hơn |
| Hard-surface chính xác | primitive + Wedge + `UnionAsync` (assets.md) | 2–3 chỗ blend thật |
| Hữu cơ phức tạp | `generate_mesh` (Studio MCP) rồi `ModelKit.Normalize` | cần Studio sống |

`GeoKit.ToMeshPart` dùng `AssetService:CreateEditableMesh` + `CreateMeshPartAsync`. **Chỉ chạy được khi API khả dụng** (Edit mode / Command Bar / plugin). Trả `nil, lý do` nếu không — caller phải có đường rơi về `Tube`. **Không** `Destroy` EditableMesh khi MeshPart còn tham chiếu. Mesh dựng runtime **không lưu** vào asset: muốn dùng lâu dài phải upload qua pipeline bên ngoài; nếu không thì dựng lại lúc khởi động trong Edit mode và giữ MeshPart trong place.

## 2. Công thức đã có test

- Ellipsoid: `P = d / sqrt((dx/a)² + (dy/b)² + (dz/c)²)`, `n = normalize(x/a², y/b², z/c²)` — `GeoKit.EllipsoidSurface`, sai số `GeoKit.EllipsoidError` phải < 0.05.
- Rải đều: `GeoKit.Fibonacci(n)`.
- Test toán thuần: `cd templates && LUAU=<luau> bash tests/run_geokit_test.sh`.

## 3. Quy trình dựng creature (vd rồng, sói, nhện)

1. Breakdown (subject-breakdown.md): 5–8 khối lớn, tỉ lệ studs, trục đối xứng.
2. Thân = `Loft` (ngực → bụng → hông), cổ/đuôi = `Sweep`, chi = `Sweep` 2 đoạn + khớp bi.
3. Lắp: dựng ở origin → `ModelKit.MirrorX` cho nửa phải → `WeldToPrimary`.
4. Chi tiết nhỏ: mắt/gai/vảy rải bằng `EllipsoidSurface` + `Fibonacci`, lệch ngẫu nhiên 5–10%.
5. `ModelKit.Audit(model, { Size = ..., MinParts = 20, MaxParts = 200 })` rồi vòng chất lượng (quality-loop.md).

## 4. Rig và animation

- **Humanoid R15**: dùng `AnimationConstraint.Transform` trong `PreSimulation` → `PoseKit.Play(character, PoseKit.Walk, {Speed=1.2})`. Joint R15: `Root, Waist, Neck, L/R Shoulder, Elbow, Wrist, Hip, Knee, Ankle` (tên chính xác lấy bằng `GetDescendants` + `IsA("AnimationConstraint")`).
- **R6**: `Motor6D.Transform` (6 khớp; không có gối/khuỷu — giả bằng pitch cả chân + dịch `RootJoint`).
- **Creature không phải người**: dựng `Motor6D` giữa các part (Part0 = cha, Part1 = con, `C0/C1` đặt tại điểm khớp) rồi ghi `Transform` mỗi `PreSimulation`. Mỗi khớp một hàm sin/cos pha lệch: sói chạy = chân chéo lệch 0.5 pha; rắn/đuôi = sóng lan `sin(phase - i*0.4)` dọc đốt.
- **Bone/skinning**: chỉ khi có mesh đã skin từ Blender (Creator Store/upload). Code không tự skin được — ghi rõ giới hạn thay vì giả vờ.
- **Animation đăng ký runtime không chạy được** (`KeyframeSequence`); pose procedural là con đường duy nhất không cần publish.
- Kiểm chuyển động bằng số: sample `Transform` 90 lần cách 0.02 s; ~1 giá trị phân biệt = đứng yên, 10–40 = có chuyển động (assets.md).

## 5. LOD và chi phí

- Mesh giống nhau instanced rẻ; khác nhau thì đắt → dùng lại kit.
- Từ ≥ 50 studs giảm nửa chi tiết: bật/tắt nhóm `Folder` "Detail" theo khoảng cách, cập nhật ≤ 4 Hz.
- `CanCollide=false`/`CanQuery=false`/`CanTouch=false`/`CastShadow=false` cho chi tiết; 2–3 box vô hình làm collision.
- Hình mỏng hơn ~0.15 studs biến mất ở xa — làm dày hoặc vẽ vào texture.

## 6. Bẫy

- `Loft` các mặt cắt khác số điểm → assert lỗi: luôn tạo bằng cùng `n`.
- Sweep đổi hướng gấp (> ~120°/đoạn) bị xoắn tiết diện: thêm điểm `CatmullRom`.
- Thứ tự đỉnh quyết định mặt trước/sau (backface culling): nhìn thấy bên trong = đảo thứ tự tam giác.
- Cylinder của Roblox có trục tròn là **X** — `GeoKit.Tube` đã xoay sẵn; tự dựng thì nhớ.
