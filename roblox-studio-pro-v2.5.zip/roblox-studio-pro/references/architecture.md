# Kiến trúc dự án Roblox: client/server, bootstrap và streaming

> Khi nào dùng: Đọc khi khởi tạo dự án, khi phải quyết định một đoạn code hay asset thuộc container nào, khi dựng service/controller, hoặc khi một tính năng chạy đúng ở Studio nhưng hỏng trên client vì streaming.

## Mô hình trong một đoạn

Mỗi game là một **server** (authoritative, chạy `Script`, thấy toàn bộ world, giữ DataStore) cộng một **client** cho mỗi player (chạy `LocalScript`/`Script` client, render, đọc input). DataModel của server **replicate** xuống client tự động; thay đổi phía client **không** replicate ngược, trừ ba ngoại lệ: physics của part mà client có network ownership (mặc định là character của nó), state/animation của `Humanoid` chính nó, và lời gọi remote. Coi mọi client là đã bị compromise. Thiết kế mọi feature theo chuỗi: *client request → server validate và quyết định → state replicate → client render*.

## Nơi đặt code và asset

| Container | Chạy/thấy ở đâu | Đặt gì |
| --- | --- | --- |
| `ServerScriptService` | Chỉ server | `Script` server và ModuleScript chỉ server (game logic, data, anti-cheat). |
| `ServerStorage` | Chỉ server | Asset riêng server: map, template NPC, tool để clone, config cận secret. |
| `ReplicatedStorage` | Cả hai | Module dùng chung (type, config, pure util), `RemoteEvent`, asset client clone. |
| `ReplicatedFirst` | Client, sớm nhất | Chỉ loading screen; replicate trước mọi thứ khác. |
| `StarterPlayer.StarterPlayerScripts` | Client, copy một lần sang `PlayerScripts` | Entry point client và các controller. |
| `StarterPlayer.StarterCharacterScripts` | Client, copy mỗi lần spawn vào character | Script client theo character (hiếm khi cần). |
| `StarterGui` | Client, copy sang `PlayerGui` | `ScreenGui`; đặt `ResetOnSpawn = false` trừ khi muốn reset khi chết. |
| `Workspace` | Cả hai, có streaming | Chỉ world 3D. Không để code hay template ở đây. |
| `Lighting`, `SoundService`, `Teams`, `TextChatService` | Cả hai | Object cấu hình tương ứng. |

- Code trong `ReplicatedStorage` **exploiter tải được**. Không bao giờ đặt logic server, secret, danh sách admin, hay ngưỡng anti-cheat ở đó.
- `Script.RunContext` nhận `Legacy` (mặc định, hành vi phụ thuộc container), `Server`, `Client`, `Plugin`. RunContext khác `Legacy` làm `Script` chạy **bất kể container** — một `Script` `Client` nằm trong `ReplicatedStorage` sẽ chạy trên mọi client, nên template đem đi clone không được chứa loại script này ngoài ý muốn. `Script` `Legacy` **không** chạy trong `ReplicatedStorage`/`ServerStorage`.

## Layout dự án (kiểu Rojo)

```text
src/
  server/            -> ServerScriptService.Server   (init.server.luau = entry point)
    Services/        -> một ModuleScript mỗi hệ thống (DataService, CombatService, ...)
  client/            -> StarterPlayer.StarterPlayerScripts.Client (init.client.luau)
    Controllers/     -> một ModuleScript mỗi hệ thống client (InputController, UIController, ...)
  shared/            -> ReplicatedStorage.Shared (type, config, logic thuần, định nghĩa network)
Packages/            -> ReplicatedStorage.Packages (dependency từ Wally/pesde)
ServerPackages/      -> ServerScriptService.ServerPackages
```

Một entry script mỗi phía, phần còn lại là ModuleScript: thứ tự load xác định, module test được, một chỗ duy nhất để nối dependency. Khuyến nghị chính thức của Roblox tương đương: một `Script` (`RunContext = Server`) trong `ServerScriptService` và một `Script` (`RunContext = Client`) trong `ReplicatedStorage`, mỗi cái require module rồi gọi `start()`.

## Bootstrap service và controller

```luau
--!strict
-- ServerScriptService/Server/init.server.luau
type Service = {
	init: ((self: Service) -> ())?, -- setup đồng bộ, được tham chiếu service khác, không yield
	start: ((self: Service) -> ())?, -- chạy sau mọi init, được yield / connect event
}

local servicesFolder = script:WaitForChild("Services")
local services: { [string]: Service } = {}

for _, module in servicesFolder:GetChildren() do
	if module:IsA("ModuleScript") then
		services[module.Name] = (require :: any)(module)
	end
end

for name, service in services do
	if service.init then
		debug.setmemorycategory(name)
		service:init()
		debug.resetmemorycategory()
	end
end

for name, service in services do
	if service.start then
		task.spawn(function()
			debug.setmemorycategory(name)
			service:start()
		end)
	end
end
```

- Hai pha là bắt buộc: `init` đồng bộ và không yield (service được tham chiếu lẫn nhau an toàn), `start` được yield và connect event. Gộp một pha sẽ tạo bug thứ tự load chỉ xuất hiện khi đổi tên file.
- Service tham chiếu nhau bằng `require` thường (không vòng) hoặc nhận dependency trong `init`.
- Client phản chiếu y hệt với `Controllers`; giữ tên đối xứng (`ShopService` / `ShopController`) để grep một phát ra cả hai phía.
- Framework như Knit là không cần thiết với pattern này; nếu dự án đã dùng thì theo convention của nó, đừng trộn hai kiểu.

## Vòng đời player và character

```luau
--!strict
local Players = game:GetService("Players")

local function onCharacterAdded(player: Player, character: Model)
	local humanoid = character:WaitForChild("Humanoid") :: Humanoid
	humanoid.Died:Once(function()
		print(`{player.Name} died`)
	end)
end

local function onPlayerAdded(player: Player)
	-- Load data trước, rồi mới dựng character handling.
	if player.Character then
		task.spawn(onCharacterAdded, player, player.Character)
	end
	player.CharacterAdded:Connect(function(character)
		onCharacterAdded(player, character)
	end)
end

Players.PlayerAdded:Connect(onPlayerAdded)
Players.PlayerRemoving:Connect(onPlayerRemoving)
for _, player in Players:GetPlayers() do -- người đã vào trước khi script connect
	task.spawn(onPlayerAdded, player)
end

game:BindToClose(function()
	-- Server shutdown: flush save cho player còn lại (tổng tối đa ~30 giây).
end)
```

- Luôn xử lý player/character **đã tồn tại** lúc code bạn bắt đầu chạy — nếu không, người vào sớm nhất server mất toàn bộ tính năng.
- Character respawn: mọi thứ gắn vào character phải được tạo lại trong `CharacterAdded`. Đừng lưu state per-player trong character (nó bị destroy khi chết).
- Trên client, descendant của character có thể chưa tồn tại: `WaitForChild("Humanoid")` chứ không index trực tiếp — character được parent trước khi con replicate.
- `game:BindToClose` có ngân sách khoảng 30 giây cho toàn bộ server, không phải 30 giây mỗi player.

## Component bằng CollectionService

Tag instance (mục **Tags** trong Studio hoặc `CollectionService:AddTag`) rồi gắn hành vi bằng code. Cách này scale tốt hơn nhét script vào từng model và hợp với streaming, vì signal added/removed cũng fire khi instance stream in/out.

```luau
--!strict
local CollectionService = game:GetService("CollectionService")

local TAG = "KillBrick"
local cleanups: { [Instance]: () -> () } = {}

local function onAdded(instance: Instance)
	if not instance:IsA("BasePart") then
		return
	end
	local connection = instance.Touched:Connect(function(hit)
		local humanoid = hit.Parent and hit.Parent:FindFirstChildOfClass("Humanoid")
		if humanoid then
			humanoid.Health = 0
		end
	end)
	cleanups[instance] = function()
		connection:Disconnect()
	end
end

CollectionService:GetInstanceAddedSignal(TAG):Connect(onAdded)
CollectionService:GetInstanceRemovedSignal(TAG):Connect(onRemoved)
for _, instance in CollectionService:GetTagged(TAG) do
	task.spawn(onAdded, instance)
end
```

- Luôn `GetTagged` một lần sau khi connect signal: instance đã tag trước đó sẽ không phát lại signal added.
- Bảng `cleanups` keyed theo `Instance` phải được xoá trong `onRemoved`, nếu không nó giữ instance sống và rò rỉ.
- Cấu hình component bằng **attribute** (`instance:GetAttribute("Damage")`, `GetAttributeChangedSignal`) thay vì nhét `IntValue`/`StringValue` làm con: attribute replicate server → client, rẻ hơn, hiện trong Properties panel.

## Chia sẻ state

| Nhu cầu | Dùng |
| --- | --- |
| Giá trị nhỏ theo instance/player mà client cần thấy | Attribute trên instance/`Player`, server set. |
| Event và request | `RemoteEvent` / `UnreliableRemoteEvent`. |
| State lớn hoặc riêng tư (inventory, quest) | Bảng do server sở hữu + remote gửi snapshot/diff chỉ cho player đó. |
| Giao tiếp cùng phía | Gọi hàm module hoặc module Signal có type — không `BindableEvent`, `_G`, `shared`. |

## Streaming: setting của Workspace

Streaming bật mặc định cho place mới và là điều kiện của server authority.

| Property | Giá trị |
| --- | --- |
| `StreamingEnabled` | `true` |
| `ModelStreamingBehavior` | `Improved` |
| `StreamingIntegrityMode` | `PauseOutsideLoadedArea` |
| `StreamingMinRadius` | `64` (mặc định) |
| `StreamingTargetRadius` | `1024` (mặc định) |
| `StreamOutBehavior` | `Opportunistic` (giảm memory client, tránh crash OOM) |
| `EnableSLIMAvatars` | `Enabled` (stand-in nhẹ cho avatar R15 ở xa) |

`Model.ModelStreamingMode`:

| Mode | Hành vi |
| --- | --- |
| `Default`/`Nonatomic` | Từng part stream riêng lẻ. |
| `Atomic` | Toàn bộ descendant **ban đầu** đến cùng nhau; script index con trực tiếp được ngay khi model tồn tại. Instance thêm sau đó không atomic. |
| `Persistent` | Luôn có trên mọi client, không bao giờ stream out. Dùng tiết kiệm (tốn memory). |
| `PersistentPerPlayer` | Chỉ persistent với player đã `Model:AddPersistentPlayer(player)`. |

- `Model.LevelOfDetail = SLIM` cho model tĩnh: model ở xa render thành composite mesh tối ưu. Không dùng cho model có animation hoặc bị sửa lúc runtime.
- Giữ model gọn về không gian (extent khoảng 64 studs); tách các model "container" khổng lồ; làm phẳng nesting — một model `Persistent` nằm trong model `Atomic` ép cả parent thành `Persistent`.

## Pattern client hỏng dưới streaming

| Pattern | Vấn đề | Cách sửa |
| --- | --- | --- |
| `workspace.House1.Door` | Lỗi nếu chưa stream in. | `WaitForChild` (có timeout nếu optional), nil-check, hoặc đặt `House1` là `Atomic`. |
| `character.Humanoid` trong `CharacterAdded` | Character được parent trước khi con replicate. | `character:WaitForChild("Humanoid")`. |
| Remote mang theo `Instance` | Signal có thể tới trước (hoặc không bao giờ có) instance. | `WaitForChild` có timeout, pre-stream bằng `RequestStreamAroundAsync`, hoặc chấp nhận `nil`. |
| Đọc `part.Position` của part ở xa | Trả giá trị replicate cuối cùng (cũ). | Tính khoảng cách ở server, hoặc kiểm tra `part:IsDescendantOf(workspace)`. |
| `folder:GetChildren()` / `GetDescendants()` | Chỉ thấy tập con đã stream. | Đếm ở server, dùng `PersistentPerPlayer`, hoặc chấp nhận partial và ghi rõ. |
| Raycast / `GetPartBoundsInBox` ở client | Chỉ có geometry đã stream. | Query toàn world ở server; query bán kính cục bộ thì ổn. |
| `ChildAdded` / tag added | Fire lại mỗi lần stream in. | Đánh dấu hiệu ứng one-time bằng attribute; coi add/remove là stream in/out. |
| Clone map từ `ReplicatedStorage` ở client | Bản client không nhận update từ server và có thể stream out. | Dựng world ở server. |
| Loading screen chờ một part của map | Treo: chưa có replication focus trước khi spawn. | Chờ character + vùng xung quanh, hoặc `player:AddReplicationFocus(part)` trước spawn. |
| `Sound`/`AudioPlayer` trong part ở xa | Tắt khi part stream out. | Parent ambient audio vào model `Persistent` hoặc `SoundService`. |
| `Touched`, `ProximityPrompt`, `ClickDetector` | Không hoạt động với client thiếu part. | Đúng như thiết kế; giữ tương tác cục bộ theo player. |
| Pathfinding ở client | Chỉ thấy geometry đã stream. | Tính path ở server. |

## Truy cập an toàn dưới streaming

```luau
--!strict
local Players = game:GetService("Players")
local player = Players.LocalPlayer

local function onCharacterAdded(character: Model)
	local humanoid = character:WaitForChild("Humanoid", 10) :: Humanoid?
	if not humanoid then
		warn("Humanoid did not replicate in time")
		return
	end
	print("walk speed", humanoid.WalkSpeed)
end

if player.Character then
	task.spawn(onCharacterAdded, player.Character)
end
player.CharacterAdded:Connect(onCharacterAdded)
```

- `WaitForChild` **luôn có timeout** khi instance có thể không bao giờ tới; không có timeout là treo thread vĩnh viễn và bug chỉ hiện ở vùng xa.
- Pre-stream trước khi dịch chuyển, ở server:

```luau
local function teleportCharacter(player: Player, target: CFrame)
	local ok, err = pcall(function()
		player:RequestStreamAroundAsync(target.Position, 5) -- timeout tuỳ chọn, giây
	end)
	if not ok then
		warn(err)
	end
	local character = player.Character
	if character and character.Parent then
		character:PivotTo(target)
	end
end
```

- `Player:AddReplicationFocus(part)` / `RemoveReplicationFocus(part)` giữ thêm một vùng load cho player (ví dụ điểm quay cutscene). Giữ số focus phụ nhỏ — mỗi cái tốn memory client.
- Mọi query cần world đầy đủ (raycast tầm xa, kiểm tra vị trí hợp lệ, pathfinding, đếm object) phải chạy ở server.

## Lựa chọn thư viện

| Nhu cầu | Chọn |
| --- | --- |
| Quản lý package | Wally hoặc pesde; kết quả mount vào `ReplicatedStorage.Packages` / `ServerScriptService.ServerPackages`. |
| Signal có type | Module Signal tự viết hoặc package; không dùng `BindableEvent` cho giao tiếp cùng phía. |
| Dọn dẹp connection/instance | Trove / Janitor / Maid — một object giữ mọi thứ và `:Destroy()` một lần. |
| Framework | Không cần; bootstrap hai pha ở trên là đủ. Chỉ dùng Knit nếu dự án đã có. |
| Networking, UI, ECS, data | Chọn một thư viện cho mỗi mảng và giữ nguyên; trộn hai thư viện cùng mảng làm state phân mảnh. |

## Kiểm thử streaming

- Hạ `StreamingTargetRadius` xuống `64` để lộ bug nhanh, rồi trả về `1024`; đi hết map, teleport giữa các vùng xa và quay lại vùng đã rời để test cả stream out lẫn stream in.
- Test trên client thật, không chỉ Play Solo: Studio giữ nhiều thứ trong bộ nhớ hơn client thật, nên bug streaming thường không tái hiện ở đó.

## Bẫy

- **Tính năng chạy ở Studio nhưng chết trên client thật** — Studio giữ world đầy đủ; client bị streaming. Thêm `WaitForChild` có timeout và chuyển query toàn world về server.
- **Người chơi vào sớm nhất server không có dữ liệu** — script connect `PlayerAdded` sau khi player đã tồn tại; luôn lặp `Players:GetPlayers()` và gọi handler cho từng người.
- **Handler chạy hai lần cho cùng một sự kiện** — vừa connect signal vừa `GetTagged` mà không guard; dùng bảng `cleanups`/set để idempotent.
- **Memory client tăng đến crash trên mobile** — `StreamOutBehavior` khác `Opportunistic`, hoặc quá nhiều model `Persistent`. Chỉ `Persistent` cho thứ thực sự phải luôn hiện diện.
- **Model `Atomic` vẫn nil khi index con** — chỉ descendant **ban đầu** là atomic; instance thêm sau đó (vũ khí gắn runtime, part spawn) vẫn cần `WaitForChild`.
- **Map nhân đôi hoặc không nhận update** — client clone map từ `ReplicatedStorage`; dựng world ở server, client chỉ đọc.
- **`Sound` ambient tắt khi player đi xa** — part chứa sound bị stream out; parent vào `SoundService` hoặc model `Persistent`.
- **Service B nil khi service A `init`** — A require B trong khi B chưa load xong, hoặc `init` của B yield. Giữ `init` đồng bộ, chuyển yield sang `start`.
- **`GetService("PlayerGui")` trả về lỗi** — `PlayerGui` là con của `Player`, không phải service; dùng `player:WaitForChild("PlayerGui")`.
- **Player rời đi để lại rác** — bảng keyed theo `Player`/`Instance` không được dọn trong `PlayerRemoving`; `Destroy()` không xoá reference Lua.
