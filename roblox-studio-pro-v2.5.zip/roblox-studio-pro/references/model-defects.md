# Danh mục lỗi thường gặp và cách sửa

| Lỗi | Dấu hiệu | Nguyên nhân thường gặp | Cách sửa |
|---|---|---|---|
| Phần lơ lửng | Mảnh tách rời trong `qa_check` | Đặt vị trí bằng số ước lượng | Tính toạ độ từ bounds phần kề, dịch theo `move_to_close`, chồng 0.01–0.05 |
| Khe ở mối nối | Đường tối giữa hai phần trong ảnh | Hai mặt chỉ vừa chạm | Lún phần phụ 0.05–0.1 vào phần chính |
| Nằm nghiêng sau import | Model nằm ngang trong game | Dựng chiều cao theo trục Y | Dựng lại với +Z lên trên, apply rotation |
| Mặt biến mất | Nhìn xuyên được từ một phía | Mặt đơn, pháp tuyến ngược | Solidify, Recalculate Outside, bật DoubleSided |
| Sai tỉ lệ | Cửa thấp hơn nhân vật, cốc to bằng ghế | Không có thước tham chiếu | So với người mẫu 5 studs trong sandbox |
| Silhouette mờ nhạt | Nhìn xa không nhận ra là gì | Toàn khối hộp cùng kích thước | Phóng đại đặc điểm nhận dạng, đa dạng kích thước khối |
| Template tô lại màu | Mèo, chó, heo giống hệt nhau | Dùng chung một khung | Dựng tai, đuôi, mõm, chân theo đúng loài |
| Texture kéo giãn | Vân bị dãn, nhoè | UV chưa unwrap hoặc tỉ lệ UV lệch | Unwrap lại, giữ mật độ texel đều |
| Màu chết dưới đèn game | Đẹp trong Blender, xỉn trong Roblox | Chỉ xem dưới một kiểu ánh sáng | Kiểm tra day/sunset/night trong sandbox |
| Quá nặng | Lag, import chậm | Subdivision dư, nhiều object nhỏ | Giảm poly, join phần cùng vật liệu, giữ < ~20k tris/mesh |
| Pivot sai | Cửa xoay quanh tâm, chân xoay quanh bụng | Origin mặc định | Đặt origin tại bản lề / khớp hông |
| Rã khi unanchor | Rơi thành từng mảnh | Thiếu weld | Weld vào PrimaryPart |
| Mặt sau bỏ trống | Front đẹp, back trống trơn | Chỉ kiểm tra ảnh front | Bắt buộc ảnh iso_back, bổ sung chi tiết hợp lý |
