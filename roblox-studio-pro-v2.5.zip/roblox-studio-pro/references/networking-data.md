# Networking và lưu trữ dữ liệu

> Khi nào dùng: Khi thiết kế remote, đồng bộ state server → client, hoặc lưu bền và chia sẻ dữ liệu giữa các server bằng DataStore, MemoryStore, MessagingService và teleport.

## Chọn kênh truyền

| Kênh | Giao hàng | Dùng cho |
| --- | --- | --- |
| `RemoteEvent` | Tin cậy, giữ thứ tự | Yêu cầu client → server, sự kiện game, cập nhật UI. Mặc định. |
| `UnreliableRemoteEvent` | Có thể mất hoặc đảo thứ tự; payload ≤ **1000 bytes**, lớn hơn bị bỏ | Dữ liệu liên tục bị giá trị sau thay thế: hướng ngắm, VFX cosmetic, vị trí object không physics. |
| `RemoteFunction` | Request/response, chặn (yield) bên gọi | Truy vấn client → server cần câu trả lời ("mua được không?"). |
| Attributes / properties | Tự động replicate server → client | State bền client chỉ đọc: health, team, phase của round. |
| Physics replication | Tự động cho assembly thuộc sở hữu client | Part chuyển động. |

Không bao giờ dùng `RemoteFunction:InvokeClient`: client lỗi, thoát, hoặc không trả lời thì server ném lỗi hoặc **yield vĩnh viễn**. Cần hỏi ngược client thì dùng một `RemoteEvent` xuống và một `RemoteEvent` lên.

## Khai báo remote một lần

Tạo remote trên server, client chờ bằng `WaitForChild`; gom tên vào module `ReplicatedStorage/Shared/Net.luau` để gõ sai tên thành lỗi biên dịch.

- Hàm `get<T>(className, name)` idempotent: server `FindFirstChild` → `Instance.new` → gán `Name` → `Parent`; client `WaitForChild`; bảng trả về khai kiểu tường minh (`:: RemoteEvent`, `:: UnreliableRemoteEvent`, `:: RemoteFunction`) để `--!strict` bắt sai tham số.
- Mọi nơi khác `require` module này; không `Instance.new("RemoteEvent")` rải rác, không `WaitForChild` với chuỗi tự do.
- Remote chỉ nên chứa **ý định**, không chứa kết quả. `RequestPurchase(itemId)`, không phải `GiveCoins(100)`.

## Handler server: thứ tự bắt buộc

Rate limit → kiểm tra kiểu từng tham số → kiểm tra luật game → hành động. Tham số đầu tiên luôn là `Player` thật do engine điền, không giả mạo được.

```luau
--!strict
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Net = require(ReplicatedStorage.Shared.Net)

local ITEM_PRICES: { [string]: number } = { Sword = 100, Shield = 150 }
local MIN_INTERVAL = 0.25
local lastRequest: { [Player]: number } = {}

Net.RequestPurchase.OnServerEvent:Connect(function(player: Player, itemId: unknown)
	local now = os.clock()
	if now - (lastRequest[player] or 0) < MIN_INTERVAL then
		return -- bị rate limit
	end
	lastRequest[player] = now

	if typeof(itemId) ~= "string" or #itemId > 64 or utf8.len(itemId) == nil then
		return -- sai kiểu hoặc UTF-8 hỏng: DataStore sẽ từ chối về sau
	end
	local price = ITEM_PRICES[itemId]
	if not price then
		return -- item không tồn tại: tra ở bảng server, không đọc từ client
	end
	-- kiểm tra số dư server, trừ, cấp vật phẩm, rồi mới thông báo
	Net.InventoryChanged:FireClient(player, { added = itemId })
end)

Players.PlayerRemoving:Connect(function(player)
	lastRequest[player] = nil -- tránh giữ key Player gây leak
end)
```

- `RemoteFunction.OnServerInvoke` phải trả về nhanh và **không bao giờ yield vô hạn**: client bị chặn cho tới khi có return. Việc chậm (DataStore) phải có timeout, luôn trả bảng `{ ok = true/false, ... }`, và client bọc timeout khi `InvokeServer` để UI không treo.
- Handler không bao giờ cấp thưởng dựa trên số liệu client báo (damage, điểm, kill, coin).

## Serialization: cái gì qua được dây

- Bảng bị **copy**: mất identity và metatable; function thành `nil`. Không trộn key array và key dictionary trong một bảng; không để lỗ `nil` trong array.
- Key dictionary không phải string (Instance, number trong bảng thưa) bị đổi thành string → gửi mảng các cặp thay vì bảng.
- Instance về phía nhận là `nil` nếu receiver không thấy nó: đồ trong `ServerStorage`, hoặc part chưa stream vào client.
- Hợp lệ: `nil`, boolean, number, string, table, `buffer`, datatype của Roblox (`Vector3`, `CFrame`, `Color3`, `EnumItem`, ...), tham chiếu `Instance` đã replicate.
- Thứ tự remote so với replicate property **không được bảo đảm**: remote có thể tới trước hoặc sau thay đổi property liên quan.
- `buffer` đi qua dây nguyên vẹn và rẻ hơn bảng có key string.

## Snapshot + delta

State riêng của từng người chơi (inventory, quest): giữ sự thật trên server, gửi **một snapshot** khi join, sau đó chỉ gửi delta. Client áp delta lên bản copy và phát signal nội bộ cho UI.

| Message | Payload | Khi nào |
| --- | --- | --- |
| `"snapshot"` | Toàn bộ bảng | Ngay sau khi load xong dữ liệu, trước mọi delta |
| `"delta"` | `itemId, newCount` (giá trị tuyệt đối, không phải `+1`) | Mỗi lần state đổi |
| `"remove"` | `itemId` | Khi count về 0 |

Gửi giá trị tuyệt đối thay vì `+/-` để một delta bị mất không làm client lệch vĩnh viễn; client áp delta theo kiểu ghi đè (idempotent). State công khai (phase, điểm) đơn giản hơn khi để thành attribute trên instance đã replicate — client nghe `GetAttributeChangedSignal`.

## Đóng gói buffer

Với dữ liệu nóng, tần suất cao, đóng gói số cứng thay vì bảng có key string: một hit notification 11 bytes thay vì ~80 bytes.

```luau
--!strict
local function encodeHit(targetId: number, damage: number, position: Vector3): buffer
	local b = buffer.create(11)
	buffer.writeu32(b, 0, targetId)
	buffer.writeu16(b, 4, math.clamp(math.round(damage), 0, 65535))
	buffer.writei16(b, 6, math.clamp(math.round(position.X), -32768, 32767))
	buffer.writei16(b, 8, math.clamp(math.round(position.Z), -32768, 32767))
	buffer.writeu8(b, 10, math.clamp(math.round(position.Y / 4), 0, 255))
	return b
end

local function decodeHit(b: buffer): (number, number, Vector3)
	return buffer.readu32(b, 0),
		buffer.readu16(b, 4),
		Vector3.new(buffer.readi16(b, 6), buffer.readu8(b, 10) * 4, buffer.readi16(b, 8))
end
```

Quantize float trước khi ghi (`math.round(position.Y / 4)`), chọn độ rộng theo miền giá trị thật, và giữ nguyên thứ tự offset giữa encode/decode trong **một** module dùng chung.

## Batching và tần suất

- Gom nhiều message nhỏ vào một packet mỗi frame: đẩy vào hàng đợi, flush một lần trên `Heartbeat`, gửi cả mảng.
- Gửi **thay đổi**, không gửi toàn bộ state; gửi khi đổi, không gửi mỗi frame.
- Input-driven (hướng ngắm) throttle ở client còn ~20 Hz và vẫn rate limit ở server.
- Server-side `TweenService` replicate mỗi frame và trông giật: tween ở client.
- VFX: server quyết định kết quả rồi bắn event tối thiểu; mỗi client tự spawn hiệu ứng. Gửi ID/enum dưới dạng số nhỏ, bỏ các trường client tự suy ra được.

## Thời gian đồng bộ và ping

- `workspace:GetServerTimeNow()` là đồng hồ đã đồng bộ trên cả server và client: gửi **một** timestamp bắt đầu, client tự tính tiến độ (round timer, cooldown bar, projectile). Không gửi tick đếm ngược mỗi giây.
- `player:GetNetworkPing()` trả về round-trip tính bằng **giây**; client chỉ query được `LocalPlayer`. Dùng để nới cửa sổ lag-compensation.
- Timestamp của client chỉ dùng làm gợi ý, không dùng để tính thưởng.

## Schema-driven: Zap / Blink

Khi profiling cho thấy chi phí network đáng kể và có nhiều remote hot: các generator theo schema (**Zap**, **Blink**) sinh ra module `client.luau`/`server.luau` với hàm `Fire`/`On` có kiểu, validation và đóng gói buffer tự động. Schema khai báo `from` (Client/Server), `type` (`Reliable`/`Unreliable`), `call` (single/`SingleSync`, mỗi lần gọi đều trả về) và `data` là struct các kiểu `u32`, `u16`, `boolean`. Cú pháp khác nhau giữa tool và version — đọc docs của generator đang dùng.

## Chọn dịch vụ lưu trữ

| Nhu cầu | Dịch vụ | Ghi chú |
| --- | --- | --- |
| Tiến trình, inventory, setting của người chơi | **DataStore** qua ProfileStore (session-locked) | Một key mỗi người chơi (`User_{UserId}`), ≤ 4 MB |
| Leaderboard toàn cầu | `OrderedDataStore` | Chỉ giá trị integer; cập nhật định kỳ, đọc có cache |
| State nhanh, tạm, xuyên server | `MemoryStoreService` | Sorted map, queue, hash map; mọi thứ hết hạn (TTL ≤ 45 ngày) |
| Hàng đợi matchmaking, server list | MemoryStore queue / sorted map | Không bền — không bao giờ là bản sao duy nhất của dữ liệu có giá trị |
| Broadcast tới mọi server | `MessagingService` | ≤ 1 kB mỗi message, best effort, không bảo đảm giao |
| Giá trị đổi bởi live-ops không cần publish | Experience configs (`ConfigService`) | Không hard-code vào script |

## DataStoreService: luật cứng

- **Buffer trong bộ nhớ**: load một lần khi join, sửa bảng trong RAM, lưu định kỳ (2–5 phút, có jitter ngẫu nhiên), khi rời, tại checkpoint (mua hàng), và trong `game:BindToClose`.
- **`UpdateAsync` thay `SetAsync`** khi giá trị ghi phụ thuộc giá trị cũ hoặc nhiều server có thể ghi cùng key. Transform function phải thuần và nhanh (không yield); trả `nil` để huỷ ghi.
- Không lưu `Instance`, `Vector3`, `CFrame`, function, bảng trộn/thưa: chỉ bảng thuần, number, string, boolean, `buffer`. Serialize datatype thành `{ x, y, z }`. Validate UTF-8 trước khi ghi.
- Key và tên data store ≤ **50 ký tự**; value ≤ **4,194,304 ký tự** sau khi encode JSON.
- Key ổn định theo `User_{UserId}`, không bao giờ dùng display name. Ít data store, ít key mỗi người chơi.
- Studio cần **File → Experience Settings → Security → Enable Studio Access to API Services**; dùng universe test riêng hoặc tên store khác (`PlayerData_Studio`) để test không chạm dữ liệu production.
- Đừng nén dữ liệu trước: Roblox tự nén. Chỉ shard key thật sự nóng. Khôi phục bằng version (`ListVersionsAsync`, `GetVersionAtTimeAsync`), không bằng key backup tự tạo.

## UpdateAsync, retry và thứ tự ghi

- Transform của `UpdateAsync` có thể chạy **nhiều lần** khi có conflict: chỉ capture kết quả, không gây side effect (không cấp item, không phát message trong đó).
- Retry lỗi tạm thời bằng exponential backoff + jitter: 1 → 2 → 4 → 8 → 16 giây (cap 16), 5 lần thử, mỗi lần cộng thêm `math.random()`.
- Retry cho **cùng một key** phải xử lý theo thứ tự: một retry cũ không được ghi đè dữ liệu mới hơn.
- Coi lần ghi thất bại là "kết quả không xác định": không ghi dữ liệu mặc định hay dữ liệu một phần lên trên. `UpdateAsync` tiêu **cả** budget read và write.

## Ngân sách và giới hạn

| Giới hạn | Giá trị |
| --- | --- |
| Read / write toàn experience | `300 + 40 × CCU` / `300 + 20 × CCU` mỗi phút (chia sẻ với Open Cloud) |
| Read / write mặc định mỗi server | `60 + 40 × players` mỗi phút, mỗi loại (cấu hình được) |
| Write của OrderedDataStore mỗi server | `30 + 5 × players` mỗi phút |
| Throughput mỗi key | 25 MB/phút đọc, 4 MB/phút ghi |
| Dung lượng (version mới nhất, đã nén) | `500 MB + 1 MB × lifetime users` mỗi experience |
| Hàng đợi mỗi loại request | 30 request chờ, vượt thì lỗi 301–306 |

- Kiểm `DataStoreService:GetRequestBudgetForRequestType(Enum.DataStoreRequestType.StandardWrite)` trước khi làm việc hàng loạt.
- Tinh chỉnh giới hạn mỗi server một lần lúc khởi động bằng `SetRateLimitForRequestType`.
- Vượt budget thì request bị **xếp hàng rồi lỗi**, không tự retry: phải tự backoff.

## Session locking

Hai server không bao giờ được sở hữu dữ liệu của cùng một người chơi cùng lúc (teleport, rejoin nhanh), nếu không sẽ duplicate item và mất tiến trình. Lock nằm trong chính record, kèm `SERVER_ID` và thời điểm; lock cũ hơn **600 giây** bị coi là bỏ hoang (server crash).

```luau
--!strict
local STORE = game:GetService("DataStoreService"):GetDataStore("PlayerData")
local LOCK_EXPIRY = 600
local SERVER_ID = if game:GetService("RunService"):IsStudio()
	then "studio-" .. game:GetService("HttpService"):GenerateGUID(false)
	else game.JobId

type Record = { data: any, lock: { server: string, time: number }? }

local function load(player: Player): any?
	local loaded: any? = nil
	STORE:UpdateAsync(`User_{player.UserId}`, function(record: Record?): Record?
		local now = os.time()
		local current: Record = record or { data = defaultData(), lock = nil }
		local lock = current.lock
		if lock and lock.server ~= SERVER_ID and now - lock.time < LOCK_EXPIRY then
			loaded = nil
			return nil -- huỷ ghi: server khác đang sở hữu session này
		end
		current.lock = { server = SERVER_ID, time = now }
		loaded = current.data
		return current
	end)
	return loaded
end
```

- Khi save: nếu `record.lock.server ~= SERVER_ID` thì trả `nil, nil` — **không** ghi đè session của server khác; khi release thì set `lock = nil`.
- Trả user id làm giá trị thứ hai từ transform (`return newRecord, { player.UserId }`) để gắn key với RTBF.
- Sau teleport, server cũ có thể chưa nhả lock: thử load 3 lần, cách nhau 5 giây, kiểm `player.Parent == Players` giữa các lần; hết lượt thì kick với thông báo "thử lại sau".
- `BindToClose` có khoảng **30 giây** tổng: save song song tất cả người chơi bằng `task.spawn`, đếm pending, `task.wait()` tới khi xong — không save tuần tự.

## ProfileStore

**ProfileStore** (loleris) hiện thực session locking, auto-save và flush trong `BindToClose`; là lựa chọn mặc định. Cài từ Wally/Creator Store, đặt trong `ServerScriptService`.

- `ProfileStore.New("PlayerData", TEMPLATE)` với `TEMPLATE` là bảng mặc định có `version`.
- `StartSessionAsync(\`User_{UserId}\`, { Cancel = function() return player.Parent ~= Players end })`; trả `nil` thì kick thay vì tạo dữ liệu rỗng.
- `profile:AddUserId(player.UserId)` (GDPR/RTBF), `profile:Reconcile()` (điền field mới thêm vào TEMPLATE), `profile:EndSession()` khi rời (save + nhả lock).
- `profile.OnSessionEnd` → người chơi bị load ở server khác: xoá khỏi bảng và kick.
- Sửa trực tiếp `profile.Data` trên server; nó cache trong RAM và tự save. Không `SetAsync` mỗi lần đổi. Kiểm tra docs cho các API ít dùng (global updates, `MessageAsync`, mock store cho Studio).
- ProfileStore giải quyết conflict nhanh hơn raw lock vì nó message trực tiếp cho server đang giữ lock.

## Migration schema

Lưu field `version`. Khi load, chạy các hàm migration theo thứ tự tới version hiện tại, rồi reconcile default.

- `MIGRATIONS: { (Data) -> () }` đánh index từ 1; `CURRENT_VERSION = #MIGRATIONS + 1`; vòng `while version < CURRENT_VERSION do MIGRATIONS[version](data); version += 1 end`.
- Không xoá field trong cùng release ngừng ghi field đó; không tái sử dụng tên field với nghĩa khác.
- Migration phải idempotent và không yield; chạy trước khi bất kỳ hệ thống nào đọc `profile.Data`.
- Ghi lại version mới **sau** khi migration xong, không trước.

## Leaderboard (OrderedDataStore)

- Giá trị phải là integer. Ghi theo lịch hoặc khi thay đổi có nghĩa, không ghi mỗi lần tăng.
- Đọc top N bằng `GetSortedAsync(false, 100)` trên **một** vòng lặp server duy nhất (ví dụ mỗi 60 giây), cache kết quả rồi replicate xuống client. Không để mọi server/client tự đọc.
- Bảng "tuần này": đưa kỳ vào tên store (`Wins_2026W39`) hoặc dùng MemoryStore sorted map.

## MemoryStore

| Loại | API chính | Dùng cho |
| --- | --- | --- |
| `MemoryStoreSortedMap` | `SetAsync(key, value, expiration, sortKey)`, `GetRangeAsync`, `UpdateAsync` | Xếp hạng, server browser, leaderboard live |
| `MemoryStoreQueue` | `AddAsync`, `ReadAsync(count, allOrNothing, waitTimeout)`, `RemoveAsync(id)` | Hàng đợi matchmaking/việc cần xử lý |
| `MemoryStoreHashMap` | `SetAsync`, `GetAsync`, `UpdateAsync`, `ListItemsAsync` | Key-value khối lượng lớn, không cần sort (counter, cache) |

- Quota tính toàn experience: bộ nhớ `64 KB + 1.2 KB × users`; request `1000 + 120 × CCU` unit/phút.
- Queue: `GetQueue("Ranked1v1", 30)` — 30 giây invisibility timeout. Chỉ `RemoveAsync(readId)` **sau khi** xử lý thành công; nếu không item sẽ hiện lại sau timeout (đúng ý cho crash safety, sai nếu remove sớm).
- `ReadAsync(2, true, 5)`: đúng 2 item hoặc không gì cả, chờ tối đa 5 giây.
- Sorted map: entry là `{ key, value, sortKey }`; TTL nên ngắn hơn 2 lần chu kỳ heartbeat để server chết tự biến mất.
- Luôn set expiration; bọc `pcall` + retry vì bị throttle; giữ item nhỏ. MemoryStore **không bền**: bị evict khi chạm quota, không bao giờ là bản sao duy nhất.

## MessagingService

- Message ≤ **1 kB**. Mỗi server: `600 + 240 × players` lần gửi/phút; `20 + 8 × players` subscription.
- Giao **best effort**, không theo thứ tự: dùng cho thông báo ("refresh cache đi", announcement toàn cầu), không bao giờ làm nguồn sự thật. Cặp với DataStore/MemoryStore cho state.
- `SubscribeAsync(topic, callback)` nhận `message.Data` và `message.Sent` (timestamp publish); bọc `pcall` vì có thể fail hoặc yield.
- Message có thể mất (server đang khởi động, throttle). State cần hội tụ thì lưu ở DataStore/MemoryStore và dùng message như tín hiệu "đọc lại đi". Text hiển thị cho người chơi mà có nguồn gốc từ người chơi khác phải filter.

## TeleportAsync và TeleportOptions

| Option | Ý nghĩa |
| --- | --- |
| `ShouldReserveServer = true` | Tạo **reserved server** mới (private, chỉ vào được bằng access code) — hợp cho match, dungeon, party. `TeleportAsyncResult` trả `ReservedServerAccessCode` và `PrivateServerId`. |
| `ReservedServerAccessCode = code` | Vào reserved server đã có (từ `ReserveServerAsync(placeId)` hoặc kết quả trước). |
| `ServerInstanceId = jobId` | Vào đúng một server public ("join server của bạn bè"). |
| `SetTeleportData(table)` | Dữ liệu **không bảo mật**, đọc bằng `player:GetJoinData().TeleportData` (server) hoặc `TeleportService:GetLocalPlayerTeleportData()` (client). Client sửa được: không bao giờ dùng cho tiền, item, quyền. |

- `TeleportAsync` có thể trả về thành công rồi vẫn fail: luôn bắt `TeleportService.TeleportInitFailed`. `Enum.TeleportResult.Flooded` → chờ **15 giây**; `Failure` → chờ **1 giây** rồi thử lại; kết quả khác → log và bỏ.
- Vòng retry: tối đa **5** lần, delay **1** giây giữa các lần, mỗi lần bọc `pcall`.
- `SetTeleportGui(gui)` ở client trước khi teleport giữ loading screen xuyên suốt; dùng `ReplicatedFirst` cho màn hình khi tới nơi.
- Phân biệt server: public → `PrivateServerId == ""` và `PrivateServerOwnerId == 0`; reserved (`ReserveServerAsync`/`ShouldReserveServer`) → `PrivateServerId` khác rỗng, owner `0`; VIP → owner là user id của chủ.

## Lobby → match

1. Save dữ liệu người chơi **trước** khi teleport (ProfileStore: kết thúc session, chờ save); place đích load bằng session locking, ProfileStore tự retry trong lúc server cũ nhả lock.
2. Người chơi queue ở lobby; party leader mời, danh sách thành viên lưu **server-side**.
3. Queue bằng `MemoryStoreQueue` hoặc sorted map theo mode và rating, hoặc để matchmaking của Roblox lấp server public.
4. Khi đủ match: ghi config (mode, map, chia team) vào MemoryStore theo một id mới, `TeleportAsync` toàn bộ người chơi với `ShouldReserveServer = true`, lưu mapping `PrivateServerId` ↔ match id.
5. Server match đọc `game.PrivateServerId` lúc start, chờ đủ người (có timeout), chạy round, lưu kết quả, teleport mọi người về lobby (server public, hoặc lobby của party qua `ServerInstanceId`). Không nhét item/tiền vào `TeleportData`.

## Matchmaking signal tùy chỉnh

Matchmaking mặc định chấm điểm server public khả dụng theo tín hiệu (bạn bè, latency, ngôn ngữ, age group, độ đầy...) và chọn tổng có trọng số cao nhất. Tùy biến trong Creator Hub:

- Chỉnh trọng số tín hiệu của Roblox, hoặc thêm **custom signal** dựa trên **custom attribute**.
- Player attribute: giá trị lưu trong **DataStore** (ví dụ `PlayerElo`), khai báo trong cấu hình matchmaking.
- Server attribute: set lúc runtime bằng `MatchmakingService:SetServerAttribute(name, value)` (`GameMode`, `ServerLevel`); `InitializeServerAttributesForStudio` để test.
- Xem trước điểm với mock server trước khi apply, rồi apply cho từng place. Dùng cho server public theo kỹ năng; cần đội hình chính xác thì dùng reserved server.

## Access control, lifecycle, RTBF

- **Access Control for Places** (Creator Dashboard): `Fully open`, `Limited to same universe`, hoặc **`Secure within universe only`** (chỉ teleport do server khởi tạo vào place không phải start place). Client có thể tự teleport tới bất kỳ place nào trong universe nếu để mở.
- Place hạn chế phải kiểm tra điều kiện vào **trên server khi join**, mặc định từ chối.
- `game.JobId` định danh server; `BindToClose` để save khi shutdown; soft shutdown sau update teleport người chơi sang server mới.
- RTBF: dùng key pattern tĩnh để **automated RTBF** (cấu hình trong Creator Dashboard) xoá được template như `PlayerData/User_{userId}`. Nếu không, xử lý webhook right-to-erasure. Luôn gắn key với user id: `SetAsync(key, value, { userId })`, trả user id làm giá trị thứ hai từ `UpdateAsync`, hoặc `profile:AddUserId`. Dữ liệu người chơi rời game phải xoá khỏi bảng RAM ngay trong `PlayerRemoving`, không chờ GC.

## Bẫy

- **Remote nhận `nil` dù client gửi đủ** — tham số là `Instance` nằm trong `ServerStorage` hoặc chưa stream xuống client, nên về phía nhận thành `nil`; sửa: gửi ID rồi server tra instance, đừng gửi instance.
- **Bảng mất metatable/function sau khi qua remote** — bảng bị copy khi serialize; sửa: chỉ gửi dữ liệu thuần, dựng lại object ở phía nhận.
- **Unreliable event im lặng mất message** — payload vượt 1000 bytes bị bỏ, hoặc gửi delta thay vì giá trị đầy đủ; sửa: giữ payload nhỏ, mỗi message phải tự đứng một mình.
- **UI treo khi gọi `InvokeServer`** — server handler yield (DataStore, `WaitForChild`) và client không có timeout; sửa: handler trả về ngay, client bọc timeout và trả trạng thái lỗi.
- **Server treo vĩnh viễn ở `InvokeClient`** — client thoát giữa chừng; sửa: bỏ `InvokeClient`, dùng cặp `RemoteEvent`.
- **Item bị duplicate sau teleport** — hai server cùng giữ session, hoặc save ở server cũ ghi đè sau khi server mới đã load; sửa: session locking + kiểm `lock.server ~= SERVER_ID` trước khi ghi.
- **Mất trắng dữ liệu khi player rời lúc server shutdown** — không có `BindToClose`, hoặc save tuần tự vượt 30 giây; sửa: flush song song trong `BindToClose` và autosave có jitter.
- **Save fail rồi lần sau vào game thấy dữ liệu mặc định** — code ghi đè default data lên lần load thất bại; sửa: load fail thì kick hoặc giữ nguyên bản cũ, không ghi gì.
- **DataStore trả lỗi 301–306 hàng loạt** — vượt 30 request chờ mỗi loại, thường do loop gọi `SetAsync` từng item; sửa: một key mỗi người chơi, autosave theo interval, backoff.
- **Studio test ghi bẩn dữ liệu thật** — dùng chung tên store; sửa: `PlayerData_Studio` hoặc universe test riêng.
- **`UpdateAsync` cấp item hai lần** — transform chạy lại khi conflict và có side effect; sửa: transform thuần, chỉ trả record.
- **Migration làm hỏng dữ liệu cũ** — chạy migration không theo `version` hoặc ghi version trước khi migrate; sửa: vòng lặp theo version, ghi version sau cùng.
- **Queue matchmaking mất người chơi** — `RemoveAsync` gọi trước khi teleport thành công; sửa: remove sau khi xác nhận, để invisibility timeout cứu khi crash.
- **Server browser hiện server đã chết** — TTL dài hơn 2 lần chu kỳ heartbeat; sửa: rút TTL, heartbeat đều.
- **Teleport "thành công" nhưng người chơi kẹt** — không bắt `TeleportInitFailed`, gặp `Flooded` mà retry ngay; sửa: chờ 15 giây cho `Flooded`, 1 giây cho `Failure`.
- **Người chơi vào thẳng place end-game** — Access Control để `Fully open`; sửa: `Secure within universe only` + kiểm tra điều kiện ở server khi join.
- **TeleportData bị sửa để nhận quà** — tin dữ liệu client đọc được; sửa: tra DataStore/MemoryStore theo `PrivateServerId` hoặc `UserId`.
- **Message giữa các server không tới** — dựa vào `MessagingService` như nguồn sự thật, message bị throttle hoặc server đang start; sửa: lưu state ở DataStore/MemoryStore, message chỉ là hint.
- **Bảng key theo `Player` phình mãi** — không xoá khi `PlayerRemoving`; sửa: dọn mọi bảng per-player trong handler rời game.
