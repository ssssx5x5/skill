# Quy trình chất lượng model (9 cổng) — hợp nhất Model Quality Pipeline vào skill này

Áp dụng cho model Roblox (Parts/MeshPart) **và** Blender. Không có "đạt/hoàn hảo" nếu thiếu bằng chứng; thiếu công cụ → ghi **chưa kiểm chứng**.

| Cổng | Việc | Công cụ |
|---|---|---|
| 1 Brief | Mục đích, phong cách (`style`), kích thước, hướng trước, nền tảng đích, mức chi tiết, phần chuyển động, ngân sách. Có ảnh mẫu: 3–5 đặc điểm nhận dạng phải giữ + cách suy luận mặt không thấy | `imgread.py`, `ref_analyze.py` → Reference Spec |
| 2 Phân tích hình khối | Silhouette chính / khối phụ / chi tiết; tỉ lệ; điểm nối; pivot; vật liệu. **Dimension Table** | `dimdb.py plan` |
| 3 Blockout | Chỉ khối lớn, gắn bằng quan hệ; xem trước/sau/bên/trên/3-4 + người mẫu 5 stud | `mb.py` → `save` |
| 4 Chi tiết | Thêm lớp có nghĩa; chi tiết mỏng có độ dày; phần chuyển động tách riêng + pivot đúng (`rotate_about`) | `mb.py` |
| 5 Hình học | 0 ERROR của `mbcheck` (lơ lửng, ẩn, z-fight, thế đứng, đối xứng, kích thước thật). Blender: thêm `qa_check.py` | `mb.py check`, `qa_check.py` |
| 6 Vật liệu/UV | Vật liệu đúng bề mặt; texture tileable, texel đều | `texgen.py`, `references/model-builder.md` §5 |
| 7 QA hình ảnh & vòng sửa | Xem ảnh từng góc, đối chiếu mẫu, chấm điểm, sửa, render lại | `rbx_render.py`/`sandbox.py`, `imgread.py compare`, `sandbox_blender.py` |
| 8 Môi trường đích | Roblox: sandbox Studio (`roblox_sandbox.lua`) kiểm DoubleSided/weld/asset/collision; chụp ≥2 ánh sáng. Không có Studio → **chưa kiểm chứng** | `roblox_sandbox.lua` |
| 9 Bàn giao | File, kích thước, cấu trúc, giả định, kiểm tra đã chạy, lỗi còn lại, trạng thái từng cổng | `templates/model-report.md` |

## Vòng sửa NHANH (chống mất thời gian)
1. **Kiểm số trước, render sau.** `mbcheck` chạy trong vài giây và chỉ ra part/vector dịch cụ thể; chỉ render khi 0 ERROR.
2. **Sửa theo họ lỗi, không từng part.** Nhiều part lơ lửng cùng hướng → sai quan hệ gốc; sửa 1 chỗ gốc (đổi `on/mate`), toàn bộ con tự đi theo.
3. **Mỗi lần chỉ đổi một loại thứ** (kích thước / vị trí / xoay) để biết cái nào sửa được.
4. Tối đa **5 vòng** cho cùng một lỗi; một cách sửa thất bại 2 lần → **dựng lại phần đó theo cách khác** (đổi quan hệ gắn, đổi cách xoay) thay vì chỉnh số nhỏ. Hết 5 vòng: dừng, báo lỗi còn lại kèm ảnh.
5. Render rẻ: `--size 420`, 6 góc, một ảnh ghép; render nặng/đủ ánh sáng chỉ ở cổng 7 cuối.

## Chấm điểm (mỗi mục 0–2; đạt khi ≥ 12/14 và không mục nào 0)
Nhận diện · Tỉ lệ (đối chiếu Dimension Table + người mẫu) · Mối nối · Mọi góc · Vật liệu · Kỹ thuật (`mbcheck`/`qa_check` sạch) · Trong game. Chi tiết 0/1/2 từng mục xem `templates/model-report.md` và `references/model-acceptance.md`; lỗi thường gặp + cách sửa: `references/model-defects.md`.

## Ngân sách mặc định (Roblox)
≤ ~20k tri/mesh (prop 500–3k, nhân vật 3–10k); gộp phần cùng vật liệu không chuyển động; texture 512–1024; 1 stud = 1 đơn vị; nhân vật ~5 stud (`Model.stud_cm=35` → 1.75 m; Roblox công bố 1 stud ≈ 28 cm, đổi nếu brief yêu cầu).

## Blender
Dùng khi cần hữu cơ/điêu khắc/UV/bake. `mb.save()` sinh `blender.py` (dựng khung chuẩn tỉ lệ); `sandbox_blender.py` (sàn lưới, người mẫu, 8 góc × 3 ánh sáng) và `qa_check.py` (đảo liền, lơ lửng + vector đóng khe) chạy **trong Blender**. Các script Blender này **chưa được chạy thử trong môi trường dựng skill**.
