# Model Builder (`scripts/mb.py`) — dựng model nhanh, đúng chỗ, đúng xoay, đúng tỉ lệ

**Vấn đề gốc:** AI tự cộng/trừ toạ độ và góc Euler cho từng part → sai chỗ, sai xoay, sai tỉ lệ, rồi mất nhiều vòng render để vá. **Cách trị:** AI chỉ khai báo QUAN HỆ ("đặt B lên mặt trên của A, căn mép sau"), máy tính ra toạ độ/hướng; kiểm tra tự động (không cần render) bắt lỗi trước; một mô tả sinh ra cả Roblox lẫn Blender.

## 1. Quy trình bắt buộc (thứ tự này, không nhảy cóc)
1. **Dimension Table** — `python scripts/dimdb.py plan <họ vật thể> [--style ...]`. In khoảng cm/stud thật cho tổng thể + từng đặc trưng (vd chiều cao mặt ngồi, độ dài lưỡi...). Họ không có trong DB → tra web kích thước thật, ghi nguồn vào bảng. **Mọi số trong code phải lấy từ bảng này**, không "ước chừng".
2. **Khung (blockout)** — chỉ các khối lớn bằng `box/cyl/ball/wedge`; gắn bằng `on / inside / mate / beside`. Chưa thêm chi tiết.
3. `m.declare("<họ>")` + `m.feature("<tên đặc trưng>", giá_trị_stud)` (đo bằng `m.top_y(...)`, `m.span(...)`, **không gõ tay**) → `m.save("out/")` chạy kiểm tra tự động + render 6 góc kèm người mẫu 5 stud.
4. Sửa theo báo cáo (có vector dịch gợi ý), lặp tới khi 0 ERROR. **Chỉ khi blockout đạt** mới thêm chi tiết (mỗi lớp chi tiết lại `save`).
5. Texture/vật liệu (mục 5), rồi qua cổng nghiệm thu `references/model-pipeline.md`.

## 2. API gọn (đơn vị stud; `m.cm(x)` đổi cm→stud; trục Roblox: +X phải, +Y lên, trước = −Z)
| Muốn | Dùng | Ghi chú |
|---|---|---|
| Tạo khối | `m.box(tên, (x,y,z), at=, rot=, color=, material=)`, `m.cyl(tên, dài, đường_kính, axis="x/y/z")`, `m.ball`, `m.wedge` | `size` lưu theo **trục thế giới** kể cả trụ; backend tự quy đổi trục tròn Roblox (X) |
| Đặt lên/cạnh/gắn vào mặt | `m.on(con, cha, "top/bottom/left/right/front/back", align=(u,v), off=(du,dv), gap=, rot=)` | align −1/0/+1 = mép nhỏ/giữa/mép lớn theo 2 trục tiếp tuyến; **gap<0 = chìm vào** (nối chắc, không khe) |
| Đặt trong lòng | `m.inside(con, cha, align=(a,b,c), off=)` | hộc, khoang, lõi |
| Trùng điểm neo | `m.custom_anchor(p, "mũi", local, normal)`; `m.mate(con, "neo con", cha, "neo cha", off=)` | khớp, mũi, chốt |
| Cạnh theo trục thế giới | `m.beside(con, ref, "x", ±1, gap=)` | |
| Thanh nối 2 điểm (mọi hướng) | `m.rod(tên, p0, p1, thick, shape="box|cyl")` | dài đúng \|p1−p0\|; hướng tự tính, không gõ Euler |
| Đường gấp / cung / Bézier | `m.path`, `m.arc(tên, tâm, trục, bán_kính, a0, a1, segs)`, `m.bezier` | vật cong; thêm `segs` tới khi silhouette mượt |
| Xoay quanh bản lề | `m.rotate_about(part|nhóm, pivot_điểm, trục, độ)` | cửa, nắp, cánh, khớp; giữ nguyên quan hệ nội bộ |
| Đối xứng | `m.mirror(part|list, "x", plane=0)` | tự xử lý xoay (R′=M·R·M) nên không bị lật |
| Lặp | `m.array_linear(p, n, step)`, `m.array_radial(p, n, trục, tâm)` | |
| Nhóm | `with m.group("Tên") as g:` | thành Model con trong Luau |
| Hạ chạm sàn | `m.ground()` | |
| Ràng buộc | `m.expect("touch|above|inside|ratio|same_y", a, b, ...)` | kiểm sau khi dựng |

**Luật chống sai xoay:** (1) mặc định con **cùng hướng cha**; chỉ truyền `rot=` khi thực sự nghiêng, và là độ **trong khung của cha**; (2) thanh/cánh/ống nghiêng → dùng `rod`/`arc` (hướng từ 2 điểm), không Euler tay; (3) đối xứng → `mirror`, không tính góc âm; (4) xoay quanh khớp → `rotate_about` với pivot là toạ độ của khớp.

## 3. Báo cáo kiểm tra tự động (không phụ thuộc loại vật thể)
LƠ LỬNG (kèm vector dịch) · PART ẨN (nằm gọn trong part khác) · Z-FIGHT (mặt trùng phẳng, cùng hướng, có diện tích phủ) · MỎNG (<0.06 stud) · THẾ ĐỨNG (trọng tâm ngoài chân đế) · ĐỐI XỨNG (thiếu cặp, nếu `m.symmetry="x"`) · NGÂN SÁCH part · KÍCH THƯỚC THẬT so DB (tổng thể + đặc trưng + tỉ lệ giữa hai đặc trưng) · RÀNG BUỘC khai báo.
`m.style`: `realistic | stylized | chibi | exaggerated` nới khoảng cho phép ×1/1.5/2.2/3 — chọn **trước** theo brief và ghi trong báo cáo, **không** đổi style chỉ để qua kiểm.
Số liệu đạt ≠ đẹp: phải xem `views.png` (6 góc + người mẫu) và đối chiếu ảnh mẫu (`imgread.py compare`).

## 4. Đầu ra
`m.save(dir)` → `scene.json` (cho `rbx_render.py`, `scene_check.py`, `sandbox.py inspect`), `build.lua` (Roblox: Parts có `WeldConstraint` theo quan hệ đã khai báo, PrimaryPart, Anchored), `blender.py` (collection trong Blender; trục Blender=(−x, z, y), 1 stud = 1 đơn vị; dùng `from_pydata` nên chạy headless), `report.md/json`, `views.png`.
- **Roblox:** dán `build.lua` vào Command Bar/Script. Đã kiểm: chạy trong sandbox Luau và CFrame/Size/Shape khớp từng part với scene. **Chưa kiểm** trong Studio thật (vật lý, hiển thị Wedge cần xem).
- **Blender:** `blender -b --python blender.py`. Hình học đã kiểm bằng `bpy` **giả** (ma trận/bao hộp khớp Roblox qua phép ánh xạ, det=+1); **chưa chạy trên Blender thật** (không có Blender ở môi trường dựng skill). Lỗi API Blender nếu có: sửa tại chỗ và báo lại; muốn đối chiếu số liệu trong Blender dùng `scripts/qa_check.py`.
- Cần chi tiết mà part không đủ (đường cong mịn, điêu khắc) → làm mesh trong Blender (Blender mạnh hơn cho hữu cơ), vẫn dùng mb để chốt tỉ lệ/khung; xuất FBX/OBJ rồi MeshPart.

## 5. Texture & vật liệu — từng bước như người làm model
1. **Chọn vật liệu theo bề mặt thật** (gỗ, kim loại, vải, đá…): `python scripts/texgen.py list` cho biết kiểu → `Enum.Material` tương ứng. **Cách 1 (rẻ nhất, không cần upload):** `material=` + `color=` ngay trong `mb`; Roblox tự tile.
2. **Nhìn có đủ chưa:** render trong sandbox dưới ánh sáng khác nhau (renderer chỉ tô màu phẳng + metal/neon; không hiện vân). Nếu cần vân riêng → bước 3.
3. **Tạo bộ PBR tileable:** `python scripts/texgen.py make <kiểu> --out tex/ --size 512 --color "#hex" --scale 1 --seed N` → `_albedo/_normal/_roughness/_metalness/_ao/_preview.png`. Xem `_preview.png` (tile 2×2 để soi seam + cầu có đèn). Texture tự kiểm seam (`texgen.py selftest`).
4. **Đưa vào Roblox:** upload thủ công lên Creator Hub (sandbox không upload được), rồi: Part → `Texture` (StudsPerTileU/V theo kích thước thật của vân, không kéo giãn); MeshPart → `SurfaceAppearance` (ColorMap/NormalMap/RoughnessMap/MetalnessMap). Tối đa 1024 px, khuyên 512.
5. **Đưa vào Blender:** `m.save(out, tex_dir="tex/")` và đặt `part.tex="<kiểu>"` → script nối các map vào Principled BSDF (chưa chạy Blender thật).
6. **Kiểm:** texel đều (không bản này mịn bản kia thô), không kéo giãn trên mặt dài, màu còn đọc được dưới day/sunset/night.
Tham khảo thông số chính thức: [Roblox texture specifications](https://create.roblox.com/docs/art/modeling/texture-specifications), [SurfaceAppearance](https://create.roblox.com/docs/art/modeling/surface-appearance) (tra khi đưa vào dự án thật; chưa đối chiếu từng chi tiết).

## 6. Bẫy
- Gõ tay toạ độ/Euler cho từng part → quay lại gốc vấn đề; chỉ dùng `at=` cho **part gốc đầu tiên**, còn lại `on/inside/mate/rod`.
- `m.feature(...)` bằng số gõ tay (không đo từ part) → báo cáo "đạt" giả. Luôn đo bằng `top_y/span`.
- Dùng `gap=0` giữa hai mặt tưởng chạm → khe nhìn thấy; dùng `gap=-0.01…-0.05`.
- Hai mặt cùng phẳng cùng hướng (z-fight): đẩy lệch ≥0.01 hoặc làm part to hơn 0.02.
- Họ vật thể không có trong DB mà vẫn viết "đúng tỉ lệ": phải nêu nguồn kích thước thật hoặc ghi **chưa kiểm chứng tỉ lệ**.
