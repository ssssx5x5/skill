# Luau and Roblox optimization

## Contents
1. The rule: measure, change one thing, measure again
2. Symptom -> likely cause -> fix
3. Luau language tips (CPU)
4. Roblox engine tips (what actually costs frames)
5. Networking
6. VFX and animation budgets
7. Benchmark harness
8. Optimization report format
9. Checklist

## 1. The rule: measure, change one thing, measure again

Never claim "optimized" from reading code. Performance guesses are wrong about half the time.

1. **Define the symptom with a number**: "drops to 25 FPS when the explosion plays", "server heartbeat 18 ms".
2. **Find the hot spot**:
   - MicroProfiler (Ctrl+F6 in-game): the longest bars per frame. Add labels with
     `debug.profilebegin("MyLabel")` / `debug.profileend()` around suspect code.
   - Developer Console (F9): Memory, Network, Script Performance (server and client activity).
   - Studio: Script Performance window; `Stats` panels (Ctrl+Shift+F2 shows render stats).
   - Micro-benchmark with `os.clock()` (section 7) for pure-Luau questions only.
3. **Change one thing.** Re-measure the same scenario. Keep the change only if the number improves.
4. **Report** before/after numbers, or say you could not measure (no Studio access) and give the reasoning.

If you cannot run Studio, say so and give the user the 3-step measurement to run, instead of claiming a speedup.

## 2. Symptom -> likely cause -> fix

| Symptom | Likely cause | Fix |
|---|---|---|
| FPS drops during an effect | too many live particles / transparent overdraw / many parts updated per frame | cap `Rate x Lifetime`, smaller `Size`, fewer layers on low `QUALITY`, `LightInfluence`/`Lighting` effects only when needed |
| Lag grows over 10-20 minutes | leaked connections, instances, tables | `:Disconnect()` / `:Destroy()` / `Debris`, clear per-player tables on `PlayerRemoving`, check `Memory` tab |
| Server heartbeat high | many scripts each with `Heartbeat`, `GetChildren` / `GetDescendants` loops, big loops over players/NPCs | one shared dispatcher, event-driven updates, spatial queries, update NPC logic at 5-10 Hz |
| NPCs stutter | server physics ownership / pathfinding every frame | `SetNetworkOwner(nil)`, recompute path every 0.3-0.5 s, simple steering for short distance |
| Hitches (single long frames) | creating hundreds of Instances in one frame, big table builds, `Clone` of huge models | spread over frames (`task.wait()` every N), pool objects, preload, build at load time |
| High ping / network lag | remotes fired every frame, large payloads | batch, send deltas, `UnreliableRemoteEvent` for cosmetic data, throttle |
| Memory climbs | textures/meshes, unbounded caches | `StreamingEnabled`, destroy unused, weak-key caches |
| Slow load | too many parts, big scripts, synchronous asset waits | streaming, `ContentProvider:PreloadAsync` only for what is needed, split work |

## 3. Luau language tips (CPU)

Apply these in **hot code only** (per-frame loops, big loops). Elsewhere prefer readable code.

- **Cache**: services and frequently used functions at the top of the file (`local floor = math.floor`).
  Cache `workspace.CurrentCamera`, not `workspace.CurrentCamera.CFrame` chains every call.
- **Avoid allocation in hot loops**: creating tables, closures, strings, `Vector3`s each frame creates garbage.
  Reuse tables (`table.clear(t)`), pre-size arrays with `table.create(n)`, hoist closures out of loops.
- **Strings**: build with `table.concat(parts)` or `string.format`, not repeated `..` in a loop.
- **Iteration**: `for i, v in t do` (generalized iteration) is fine and fast; numeric `for i = 1, #t` is good for arrays.
  Do not call `#t` or `t:GetChildren()` inside the loop condition repeatedly.
- **Types**: `--!strict` and annotations catch bugs and let the compiler optimize; they do not slow runtime.
- **Native code generation**: `--!native` at the top of a script (or `@native` before a function)
  compiles it to machine code. It helps compute-heavy numeric code (noise, procedural mesh math, big
  loops over numbers/vectors). It does not help code that is mostly Roblox API calls. Measure it first.
- **`buffer`** library for packed binary data (voxel grids, network payloads, large numeric arrays) instead of big tables of numbers.
- **`table.freeze`** config tables (prevents accidental mutation and is free at runtime).
- **Math**: use `x * x` instead of `x ^ 2` in very hot code; compare squared distances
  (`(a - b):Dot(a - b) < r * r`) instead of `.Magnitude` when you only need "is it closer than r".
- **`pcall`** is cheap, but do not wrap hot loops in it per iteration; wrap the whole step.

## 4. Roblox engine tips (what actually costs frames)

**Parts and physics**
- Part count and physics dominate. `Anchored = true` for anything static. Turn off `CanCollide`,
  `CanQuery`, `CanTouch` on decoration; `CastShadow = false` on tiny parts; `Massless` for accessories.
- Many welded parts = one assembly; keep complex assemblies unanchored only when they must simulate.
- Use `CollisionGroups` to stop needless collision checks (players vs decoration, NPC vs NPC).
- Use `workspace:BulkMoveTo(parts, cframes, Enum.BulkMoveMode.FireCFrameChanged)` to move many parts in one call
  (e.g. 36 ring segments) instead of setting `CFrame` one by one when you control many parts per frame.
- `StreamingEnabled` for large maps: far parts are not sent or rendered. Handle missing instances with `WaitForChild` and `ModelStreamingMode`.

**Scripts**
- One loop beats many. Make a single `Heartbeat` dispatcher that calls registered update functions,
  and give each system its own rate (NPC brains 5-10 Hz, UI 60 Hz, ambience 1-2 Hz).
- Events over polling: `Changed`, `GetPropertyChangedSignal`, `Touched` (debounce it), `ChildAdded`, attributes.
- Spatial queries instead of looping all objects: `workspace:GetPartBoundsInRadius(pos, r, overlapParams)`,
  `workspace:Raycast`, `CollectionService:GetTagged` (cache the list, update on tag signals).
- Never call `GetChildren()` / `GetDescendants()` / `FindFirstChild` repeatedly per frame; cache the results.
- Object pooling for things created and destroyed constantly (bullets, hit sparks, damage numbers):
  keep a table of inactive objects, reuse, and park them far away or `Parent = nil`.
- **Parallel Luau** for heavy pure computation: scripts under `Actor`, `task.desynchronize()` to compute
  in parallel, `task.synchronize()` before touching the DataModel. Good for many raycasts or big math,
  useless for tiny work. Measure.

**Rendering**
- Transparent overlapping layers cost fill rate. A few large smoke puffs can cost more than many small sparks.
- Particles: cost ~ (live particles) x (screen area). Lower `Size`, `Lifetime`, `Rate`; split effects by `QUALITY`.
- `PointLight`/`SurfaceLight`/`SpotLight`: few, small `Range`, and `Shadows` off unless needed. Future-lighting cost scales with lights and range.
- Post effects (`Bloom`, `DepthOfField`, `ColorCorrection`) are per-screen cost; enable them only while needed, destroy after.
- `MeshPart.RenderFidelity` = Automatic/Performance for far or small items; `Material` choices matter less than count.
- Distance LOD: turn off `ParticleEmitter.Enabled`, `Light.Enabled`, and animation updates for things far from the camera.

## 5. Networking

- Server -> client visuals: one `RemoteEvent` with (name, position, options); the client does the work.
- Client -> server: validate every argument (type, range, cooldown, distance). Throttle (e.g. min 0.1 s apart).
- Batch many small updates into one message per frame/interval. Send changes (deltas), not full state.
- `UnreliableRemoteEvent` for high-frequency cosmetic data that can be dropped (cursor position, effects);
  never for important state.
- Do not replicate cosmetic state through properties on the server (e.g. server tweening 100 parts); let clients simulate it.
- DataStore: budgets and retries (`pcall`, backoff); save on leave and on interval, not on every change.

## 6. VFX and animation budgets

| Thing | Budget guideline |
|---|---|
| Live particles per client, large effect | 300-600; small effects 30-100 (see `subject-breakdown.md` section 5) |
| FX parts updated per frame | under ~60; above that use `BulkMoveTo` or reduce |
| Dynamic lights alive at once | under ~8, short lifetimes |
| Procedural animation (Motor6D per frame) | client only, only for rigs near the camera, 30 Hz for far ones |
| Tweens | fine in the hundreds; prefer `TweenService` over per-frame loops for single-property changes |
| `Kit.QUALITY` | 1 mobile / 2 mid / 3 high, multiply counts; choose from `UserInputService.TouchEnabled` as a first guess |

Always scale by quality, always clean up, always have an upper bound on how many instances of an effect can exist at once (queue or drop the oldest).

## 7. Benchmark harness

```lua
--!strict
local function bench(label: string, iterations: number, fn: () -> ())
	for _ = 1, 100 do fn() end -- warm-up
	local t0 = os.clock()
	for _ = 1, iterations do fn() end
	local dt = os.clock() - t0
	print(("[bench] %-24s %8.3f ms total  %8.3f us/iter"):format(label, dt * 1000, dt / iterations * 1e6))
end

-- compare two implementations on the same input
-- bench("A: magnitude", 100000, function() local _ = (a - b).Magnitude < 10 end)
-- bench("B: squared",   100000, function() local d = a - b; local _ = d:Dot(d) < 100 end)
```
This measures pure Luau only. For rendering/physics/replication, use the MicroProfiler and the Developer Console.
Run each benchmark a few times (results vary), and in a real place, not only a blank baseplate.

## 8. Optimization report format

1. Symptom and how it was measured (numbers).
2. Hot spot found (label, script, cause).
3. Change made (one sentence per change) and why it helps.
4. Result (before -> after) or "could not measure here; user should run steps X".
5. Trade-offs (visual quality, complexity) and what was intentionally left alone.

## 9. Checklist

- [ ] A measurement exists (or the steps for the user to take one); no unmeasured claims.
- [ ] No per-frame allocation, `GetChildren`/`GetDescendants`, or string building in hot loops.
- [ ] One dispatcher / event-driven updates; rates match importance.
- [ ] Parts: anchored, collisions off for decoration, streaming considered.
- [ ] Particles, lights, post effects budgeted, scaled by quality, cleaned up.
- [ ] Remotes validated, throttled, batched; cosmetic work stays on the client.
- [ ] All connections and instances cleaned up on every exit path.
