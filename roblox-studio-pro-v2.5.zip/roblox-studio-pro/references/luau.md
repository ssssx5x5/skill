# Luau trên Roblox: type solver mới, task, buffer và kiểm thử ngoài Studio

> Khi nào dùng: Đọc trước khi viết, refactor hay review bất kỳ script Roblox nào — đặc biệt khi phải sửa lỗi type dưới `--!strict`, khi cần chứng minh một script chạy đúng mà không mở Studio, hoặc khi hiện đại hoá code Lua cũ.

## Chế độ kiểm tra kiểu

| Hot comment | Hành vi |
| --- | --- |
| `--!nocheck` | Không báo lỗi type. |
| `--!nonstrict` | Suy luận type, chỉ báo lỗi chắc chắn; giá trị không annotate gần như `any`. |
| `--!strict` | Suy luận và kiểm tra đầy đủ. Mặc định cho mọi ModuleScript mới. |

- `Workspace.LuauTypeCheckMode` đặt mode mặc định cho script không có hot comment.
- `Workspace.UseNewLuauTypeSolver` (kiểu `RolloutState`) chọn solver; **new type solver** GA từ 11/2025.
- Rojo + luau-lsp: bật `"luau-lsp.fflags.enableNewSolver": true` để editor và Studio báo cùng một tập lỗi.
- Không có type definition của Roblox thì mọi thứ engine trả về là `unknown`; đó là lý do các cảnh báo lạ xuất hiện khi analyze offline.

## Cú pháp hiện đại phải dùng

| Cấu trúc | Ghi chú |
| --- | --- |
| `count += 1` | Compound assignment đầy đủ: `+= -= *= /= //= %= ^= ..=`. |
| `` `Player: {name}` `` | String interpolation; dùng `\{` cho dấu ngoặc nhọn literal. |
| `if c then a else b` (biểu thức) | Thay `c and a or b` — không sai khi `a` là `false`/`nil`. |
| `for i, v in t do` | Generalized iteration; bỏ `pairs`/`ipairs`, duyệt array theo đúng thứ tự. |
| `continue` | Là keyword, không phải hàm. |
| `7 // 2` → `3` | Floor division. |
| `table.freeze(t)` | Ghi vào bảng frozen sẽ throw; `table.isfrozen` để kiểm tra. |
| `table.create(100, 0)` | Cấp phát trước array 100 slot. |
| `table.clone(t)` | Shallow copy và trả bảng **không** frozen. |

- `#t` chỉ xác định trên array không có lỗ hổng. Gán `t[i] = nil` ở giữa tạo lỗ hổng và `#t` trả kết quả tuỳ ý.
- Number là double: integer chính xác đến `2^53`. Dùng `math.floor` hoặc `//` cho toán integer.
- `tick()` bị khuyến cáo bỏ: `os.clock()` để benchmark, `workspace:GetServerTimeNow()` cho thời gian đồng bộ client/server, `os.time()`/`DateTime.now()` cho wall-clock UTC.
- `math` bổ sung: `math.lerp`, `math.map`, `math.clamp`, `math.round`, `math.sign`, `math.noise` (Perlin, khoảng -1..1). Dùng `Random.new(seed)` thay `math.random` khi cần tái lập.

## Type: record, union, generic, type pack

```luau
--!strict
export type Item = { id: string, name: string, stack: number, tags: { string }? }
type Rarity = "Common" | "Rare" | "Legendary"
type Shape = { kind: "circle", radius: number } | { kind: "rect", w: number, h: number }
type Pair<K, V = string> = { key: K, value: V }
type Varargs = (...number) -> ()

local function first<T>(list: { T }): T?
	return list[1]
end

local function area(shape: Shape): number
	if shape.kind == "circle" then
		return math.pi * shape.radius ^ 2 -- đã refine về nhánh circle
	end
	return shape.w * shape.h
end
```

- Tagged union + so sánh `shape.kind` cho refinement đầy đủ; ưu việt hơn một record nhiều field optional.
- `T...` là **type pack** — dùng cho varargs và multiple return: `local function wrap<A..., R...>(fn: (A...) -> R...): (A...) -> R...`.
- Intersection `A & B` ghép shape; overloaded function type là intersection của các function type.
- Type function của engine: `keyof<T>` (union key literal), `index<T, K>`, `typeof(expr)`, cùng `rawkeyof`, `rawget`, `getmetatable`, `setmetatable`.
- `keyof<typeof(DEFAULTS)>` biến bảng hằng thành union tên field — đổi tên field là lỗi compile ngay, không phải lỗi runtime.

## Refinement và cast

```luau
--!strict
local function describe(value: unknown): string
	if typeof(value) == "Instance" then
		if value:IsA("BasePart") then
			return `part at {value.Position}` -- refine thành BasePart
		end
		return value:GetFullName()
	elseif type(value) == "number" then
		return string.format("%.2f", value)
	end
	return "unknown"
end
```

- `typeof(v)` biết type Roblox (`"Vector3"`, `"Instance"`, ...); `type(v)` chỉ biết type Lua.
- Dùng `unknown`, không dùng `any`, cho dữ liệu chưa validate — checker buộc phải refine.
- `assert(x, "msg")` refine `x` thành non-nil ngay sau lời gọi.
- `expr :: T` chỉ hợp lệ khi hai type có quan hệ (ví dụ `Instance` → `Part`). Ép qua `(x :: any) :: T` là mùi code xấu; ưu tiên refine.
- `FindFirstChild` trả `Instance?`. `FindFirstChildOfClass("Humanoid")` / `FindFirstChildWhichIsA` trả type cụ thể, đỡ phải refine.

## Read-only và type function tự định nghĩa

```luau
--!strict
type Settings = { read version: number, volume: number }
local settings: Settings = { version = 2, volume = 0.5 }
settings.volume = 1 -- ok
-- settings.version = 3 -- lỗi type: read-only
```

Kết hợp `table.freeze` để bất biến cả runtime. Type function chạy lúc phân tích, dựng type bằng thư viện `types` (`types.newtable()`, `:setproperty`, `types.optional`), hữu ích cho API thư viện nhưng làm code khó đọc — dùng tiết chế.

## Module, require-by-string và OOP

ModuleScript chạy **một lần cho mỗi environment** (server, hoặc từng client) và cache kết quả cho mọi `require` sau. Một module trong `ReplicatedStorage` được cả hai phía require sẽ chạy **hai lần** với state riêng biệt.

```luau
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Signal = require(ReplicatedStorage.Packages.Signal) -- instance path: luôn hoạt động
local Config = require("./Config") -- sibling của script (script.Parent)
local Utils = require("@self/Utils") -- con của script
local Shared = require("@game/ReplicatedStorage/Shared") -- tuyệt đối từ game
```

- `./` = `script.Parent`, `../` = `script.Parent.Parent`, `@self/` = `script`, `@game/` = `game`.
- String path **không chờ** instance tồn tại: nếu module chưa replicate, require fail ngay. Dùng instance path + `WaitForChild` khi có rủi ro đó.
- Không tạo require vòng (deadlock/error); phá vòng bằng dependency injection hoặc event.
- Không yield ở top level của module: mọi requirer bị chặn cho tới khi module return.

```luau
--!strict
local Counter = {}
Counter.__index = Counter

export type Counter = typeof(setmetatable({} :: { value: number, step: number }, Counter))

function Counter.new(step: number?): Counter
	return setmetatable({ value = 0, step = step or 1 }, Counter)
end

function Counter.increment(self: Counter): number
	self.value += self.step
	return self.value
end

return Counter
```

Pattern B cho API public: khai báo `export type Timer = { start: (self: Timer) -> (), elapsed: (self: Timer) -> number }` rồi trả factory — tách shape khỏi metatable. Kế thừa: ưu tiên composition (một field giữ object khác); nếu buộc phải kế thừa, trỏ `__index` của metatable con vào class cha và type con là intersection của hai shape.

## Task library và signal behavior

| Lời gọi | Hành vi |
| --- | --- |
| `task.spawn(fn, ...)` | Chạy ngay (đến lần yield đầu) trên thread mới. |
| `task.defer(fn, ...)` | Chạy cuối resumption cycle hiện tại. |
| `task.delay(t, fn, ...)` | Chạy sau `t` giây; trả thread để `task.cancel`. |
| `task.wait(t?)` | Yield ≥ `t` giây (một frame nếu bỏ trống); trả thời gian đã trôi. |
| `task.cancel(thread)` | Dừng thread đã spawn/delay. |
| `task.desynchronize()` / `task.synchronize()` | Parallel Luau, chỉ trong `Actor`. |

- Việc per-frame: `RunService.Heartbeat` (sau physics), `PreSimulation`/`PostSimulation`, `RunService:BindToRenderStep` (client, trước render, có thứ tự). Không `while true do task.wait() end`.
- Viết handler chạy đúng dưới **deferred** signal behavior (`Workspace.SignalBehavior`): handler chạy cuối frame, không inline. Template mới dùng `Deferred`, `Default` sẽ chuyển sang `Deferred`, và server authority yêu cầu nó. Đừng giả định side effect đã xảy ra ngay sau `:Fire()`.
- Không yield trong metamethod hoặc callback kiểu `Changed` cần đồng bộ.

## Lỗi và retry

```luau
local function retry<T...>(attempts: number, fn: () -> T...): (boolean, T...)
	local delaySeconds = 1
	for attempt = 1, attempts do
		local result = table.pack(pcall(fn))
		if result[1] then
			return table.unpack(result, 1, result.n)
		end
		if attempt < attempts then
			warn(`attempt {attempt} failed: {result[2]}`)
			task.wait(delaySeconds)
			delaySeconds *= 2 -- exponential backoff
		end
	end
	return false
end
```

- `error("message", 2)` quy lỗi cho caller; `error({ code = "X" })` throw bảng để lỗi có cấu trúc.
- `xpcall(fn, debug.traceback)` giữ stack trace; `pcall` trần làm mất nó.
- Chỉ bọc `pcall` quanh lời gọi có thể fail vì lý do ngoài code của bạn: DataStore, HTTP, Marketplace, Teleport, mọi `*Async`. Bọc tất cả là che bug.
- `table.pack` giữ `n` nên không mất giá trị `nil` ở giữa multiple return — dùng nó, đừng dùng `{ pcall(fn) }`.

## buffer và vector

```luau
local packet = buffer.create(10)
buffer.writeu16(packet, 0, 513) -- item id
buffer.writef32(packet, 2, 12.5) -- amount
buffer.writei32(packet, 6, -4)
print(buffer.readu16(packet, 0), buffer.readf32(packet, 2), buffer.len(packet))
```

- `buffer` là byte array cố định, **little-endian**, có `read/write` cho `i8 u8 i16 u16 i32 u32 f32 f64`, thêm `readstring/writestring(b, offset, str, count?)` và `readbits/writebits(b, bitOffset, bitCount, value)`.
- Buffer gửi được qua remote và lưu được trong DataStore (được serialize) — cách nhanh nhất để pack dữ liệu mạng.
- `vector.create(x, y, z)` là kiểu 3 float native, cùng type với `Vector3` lúc runtime nhưng gọi nhanh hơn và thân thiện codegen: `vector.magnitude`, `normalize`, `dot`, `cross`, `angle(a, b, axis?)`, `lerp`, `clamp`.
- Ghép chuỗi lớn bằng `table.concat` hoặc `buffer`, không `..` trong vòng lặp.

## Legacy → hiện tại

| Đừng viết | Viết thay |
| --- | --- |
| `wait()`, `spawn()`, `delay()` | `task.wait()`, `task.spawn()`, `task.delay()` |
| `game.Workspace`, `game.Players` | `workspace`, `game:GetService("Players")` |
| `Instance.new("Part", parent)` | tạo, set property, **gán `.Parent` cuối cùng** |
| `Humanoid:LoadAnimation()` | `Animator:LoadAnimation()` |
| `Model:SetPrimaryPartCFrame()` | `Model:PivotTo()` / `Model:GetPivot()` |
| `workspace:FindPartOnRay(Ray.new(...))` | `workspace:Raycast(origin, direction, params)` |
| `BodyVelocity`, `BodyPosition`, `BodyGyro` | `LinearVelocity`, `AlignPosition`, `AlignOrientation` |
| `player:LoadCharacter()` | `player:LoadCharacterAsync()` |
| `MarketplaceService:GetProductInfo()` | `:GetProductInfoAsync()` |
| `BadgeService:AwardBadge()` | `:AwardBadgeAsync()` |
| `player:GetRankInGroup()` | `GroupService:GetRolesInGroupAsync()` / `player:IsInGroupAsync()` |
| `TeleportService:Teleport*()` | `TeleportService:TeleportAsync()` |
| `Chat` / `ChatService` module | `TextChatService` |
| `GuiObject.Draggable` | `UIDragDetector` |
| `table.getn`, `table.foreach`, `getfenv` | `#t`, `for ... in`, không có gì thay thế |

- `--!native` ở đầu script (hoặc `@native` trên một hàm) compile code số học nặng sang native. Chỉ dùng cho module math-heavy — có giới hạn compile time và memory; type annotation giúp codegen.
- Cache service reference và kết quả `Instance` lookup ra ngoài vòng lặp; tái dùng `RaycastParams`/`OverlapParams`.

## Kiểm thử ngoài Studio

Script Roblox không chạy trực tiếp được, nhưng vẫn lấy được bằng chứng thật: compile bằng Luau CLI, rồi execute trên mock API tự viết.

**Bước 0 — luôn lấy Luau CLI thật.** `lupa` nhúng **Lua 5.5**, không parse được Luau: mọi script có `--!strict`, `local x: number`, `:: Type` hay `+=` sẽ báo syntax error **giả**. Tải bản release `luau-lang/luau` cho Windows, giải nén được `luau.exe`, `luau-compile.exe`, `luau-analyze.exe`, `luau-ast.exe`.

| Lệnh | Dùng để |
| --- | --- |
| `luau-compile.exe --null script.lua` | Compile đầy đủ; in `Compiled N KLOC`, exit 0. |
| `luau-compile.exe --only-parse script.lua` | Chỉ kiểm tra cú pháp. |
| `luau-analyze.exe script.lua` | Type check — bắt lỗi mà compile bỏ qua. |

- Mode là **flag**, không phải positional: `luau-compile null file` coi `null` là tên file (`Error opening ./null`); `--mode=null` báo `Unrecognized option`.
- Chạy `luau-analyze` **kể cả khi compile sạch**. Nó từng bắt một tham chiếu `CFG.MAX_WAYPOINTS` không tồn tại — compile hoàn toàn sạch, nhưng runtime sẽ `math.min(x, nil)`.
- Không có Roblox type definition nên mọi thứ engine là `unknown`; lọc nhiễu: `grep -v -E "Unknown (global|require|type)|Unknown symbol|does not have key|Cannot add property|depends on generic"`.
- `SameLineStatement` **không** phải lỗi: `local x = f() x.y = 1` là Lua hợp lệ, analyzer chỉ gợi ý thêm `;`. Đừng báo nó như bug.
- `Operator '+' could not be applied to operands of types number and unknown` trên callback `Heartbeat:Connect(function(dt)` là nhiễu — `dt` không có type khi thiếu Roblox defs.
- Dùng `lupa` **chỉ khi cần execute** trên mock, không dùng để compile Luau.

**Mock Instance có ba cái bẫy tạo ra bug giả.** (1) `__newindex` chỉ chạy với key chưa tồn tại: nếu `rawset(obj, "Parent", v)` một lần thì mọi `obj.Parent = x` sau đó là raw write và danh sách parent thành cũ — bạn sẽ "chứng minh" `FindFirstChild` hỏng trong khi mock hỏng. Giữ `Parent` và `Position` **virtual**, lưu parent thật trong `__parent`; `rawget(x, "Parent")` ở bất kỳ đâu trong mock là bug. (2) `require = function(m) return m end` trả chính Instance, khiến script `for k in pairs(require(mod))` nuốt `__class`, `ClassName`, `Changed` như dữ liệu. (3) `Humanoid:EquipTool` mặc định no-op — Roblox **move** tool vào character, nên mock rỗng làm `FindFirstChildOfClass("Tool")` luôn nil và mọi `attack()` early-return, trông y hệt bug thật.

Phần tối thiểu còn lại: một metatable với `__index`/`__newindex` **có fallback tra con theo tên** (Roblox resolve `mob.HumanoidRootPart` bằng child lookup); bảng `ANCESTORS` nhỏ cho `IsA` (Part→BasePart, LocalScript→Script→LuaSourceContainer, IntValue→ValueBase); signal có metatable riêng expose `Connect`/`Wait`/`Fire`; `game` với `GetService` **raise khi tên service không tồn tại** (bắt được bug kinh điển `GetService("PlayerGui")`) và mỗi service phải có `Parent = game`; `HttpService:JSONEncode` viết thật (stub trả `"{}"` che bug ở save path).

```lua
local __COROS = {}
function task.wait(t) coroutine.yield("wait") end
function task.spawn(fn, ...)
    local co = coroutine.create(fn); table.insert(__COROS, co)
    local ok, err = coroutine.resume(co, ...)
    if not ok then print("!! task.spawn ERROR: " .. tostring(err)) end
    return co
end
```

- Đừng stub `task.wait` thành no-op: `while true` sẽ treo run. Cho nó yield thật rồi step từng coroutine.
- `os.clock()` gần như không nhích giữa các step, nên rate limiter kiểu `if now - last < AttackDelay then return end` nuốt gần hết lời gọi — đặt delay = 0 trong harness.
- Bất cứ thứ gì có `task.wait` đều không gọi được từ main chunk (`attempt to yield from outside a coroutine`); bọc trong helper `run(fn)` resume tới khi xong (guard ~5000 lần).
- Nối `mock + script + harness` vào **một chunk** để `local` của script hiển thị cho harness; expose thứ mock cần qua `_G`.
- Shim cho `lupa`: `bit32` bị bỏ từ Lua 5.4 (dựng lại bằng `&`, `|`, `~`, `>>` rồi `% 4294967296`), `math.clamp` là Luau-only, `typeof` là global Roblox, string nhị phân không qua được Python (hex-encode rồi `bytes.fromhex()`), `table.unpack` thay `unpack`.
- Báo cáo: tách rõ finding **đã tái hiện** và phán đoán **đọc code**; nêu giới hạn của mock (nó chứng minh logic script, không chứng minh hành vi Roblox/executor).

## Bẫy

- **Type của module được require là `any`** — đường dẫn require không resolve được tĩnh; dùng instance path hoặc string require, và bật sourcemap Rojo để luau-lsp thấy cây instance.
- **`Key 'Foo' not found in external type 'Instance'`** — checker không biết con của Instance; refine bằng `IsA`, cast `:: Folder`, hoặc thêm sourcemap.
- **Handler chạy "trễ" và đọc state cũ sau `:Fire()`** — `Workspace.SignalBehavior` là `Deferred`; đừng giả định side effect đồng bộ, truyền dữ liệu qua tham số của event.
- **`#t` trả sai sau khi xoá phần tử giữa** — `t[i] = nil` tạo lỗ hổng; dùng `table.remove` hoặc swap-with-last rồi `table.remove`.
- **`table.sort` panic `invalid order function`** — comparator dùng `<=`; phải là strict weak ordering, chỉ dùng `<`.
- **Bảng frozen throw khi ghi** — `table.freeze` là shallow; `table.clone` trả bản không frozen, sửa bản clone rồi freeze lại.
- **Require treo vô hạn** — module top level yield (`WaitForChild` trên instance không bao giờ tới, hoặc gọi DataStore); mọi requirer chờ theo. Chuyển sang `init()` được gọi tường minh.
- **Memory tăng mãi dù đã `Destroy()`** — `Destroy()` chỉ ngắt connection của instance và khoá `Parent`, không xoá reference Lua; nil các bảng keyed theo Player/Instance trong `PlayerRemoving`.
- **Số integer sai ở giá trị lớn** — number là double, chính xác tới `2^53`; ID lớn hơn mất bit, giữ dạng string.
- **`attempt to index nil` chỉ xuất hiện trên client ở vùng xa** — streaming chưa giao instance; xem `architecture.md`, mục streaming.
- **Script compile sạch nhưng runtime chết** — chưa chạy `luau-analyze`; compile chỉ kiểm tra cú pháp.
- **"Bug" trong script thực ra là bug của mock** — parent list cũ, `EquipTool` no-op, không mô phỏng combat. Sửa mock trước, chạy lại sau mỗi lần sửa mock.
