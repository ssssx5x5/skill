# Subject Breakdown: how to build ANY thing (not only the examples)

## Contents
1. Why this file exists
2. The 7-question breakdown
3. Phenomenon -> Roblox technique lookup table
4. Worked breakdowns (nuclear blast, plant, waterfall, sword slash)
5. Scale, timing and budget defaults
6. Self-check against copy-paste from examples

## 1. Why this file exists

Examples in this skill (monster, jumpscare, roar) are **illustrations of a method, not the method**.
A common failure: the user asks for a plant or a nuclear explosion, and the agent produces a
monster-style impact (small burst + shake + roar) because that is the pattern it saw.

The fix is to always run the same breakdown on the *new* subject before writing code. The subject
changes; the breakdown does not.

## 2. The 7-question breakdown

Answer these in a short note (5-15 lines) BEFORE writing code. If you can use web search or you know
the real-world phenomenon, recall how it really looks and behaves. Realism comes from copying real
structure, not from adding more particles.

1. **Anatomy: what parts does it have?**
   Real objects/phenomena have named parts. Nuclear blast: flash, fireball, shockwave ring, dust
   skirt, stem, cap, condensation ring, fallout. Plant: seed, root, stem, leaves, bud, flower, pollen.
   Write the part list. Each part becomes an object or an emitter.

2. **Phases: what happens in time?**
   Almost everything is: *anticipation -> main event -> aftermath*, but with subject-specific
   phases (nuke: flash 0.1s, fireball rise 2s, shockwave expands 4s, mushroom forms 8s, dissipate 20s).
   Write each phase with a start time and duration. This becomes the timeline.

3. **Motion: how does each part move, and why?**
   Use the physics: hot gas rises and billows, shockwaves expand at constant-ish speed and thin out,
   plants grow from the tip and sway with a slow sine, water falls with acceleration, sparks arc under
   gravity, smoke slows by drag and spreads. Pick an easing/curve per part (see `animation-craft.md`).

4. **Look: color, material, light.**
   Choose a palette of 3-5 colors from the real thing and give each a role (core, body, edge, dark).
   Color changes over time (fire: white -> yellow -> orange -> red -> dark gray). Decide what emits
   light (LightEmission, Neon, PointLight) and what only reacts to light (smoke, leaves).

5. **Scale: how big, relative to the player (5 studs tall)?**
   Write real numbers in studs. A "nuclear boom" for a game is 200-600 studs wide, not 20. A plant is
   3-12 studs. Wrong scale is the #1 reason an effect feels weak or silly.

6. **Layers: what does the player see, hear, and feel?**
   Visual (shapes + particles), light (flash, dynamic light, Lighting change), sound (layers and delay
   by distance), screen/camera (shake, FOV, color correction, blur), world (debris, scorch, shaken
   parts). Aim for at least 4 of 5 layers on a "big" effect, 2-3 on a small one.

7. **Where does it run, and what does it cost?**
   Visuals on the CLIENT, truth/damage on the SERVER, one trigger event from server to clients.
   Set a budget: max parts, max live particles (rate x lifetime), max duration. Add cleanup.

If the user's prompt leaves any of these open, **choose a sensible default, state it in one line,
and make it a Config value** so they can change it. Do not stop to ask unless the choice changes the
whole direction.

## 3. Phenomenon -> Roblox technique lookup

Use this to pick the technique. "Primitive" = Part (Ball/Cylinder/Block/Wedge), needs no asset id.

| Subject | Best building blocks | Notes |
|---|---|---|
| Explosion, fireball | Neon Ball Part expanding + ParticleEmitter (fire/smoke) + PointLight + shockwave ring | Ball + Tween Size is asset-free and reliable. |
| Shockwave | Flat Cylinder Part (or `Torus`-like via thin Cylinder) expanding, Transparency to 1 | Axis of a Cylinder is X; rotate to lie flat (see recipes). |
| Mushroom cloud / pillar of smoke | Cylinder stem growing in Y + squashed Ball cap expanding + smoke emitters | Stem and cap speed differ: cap rises faster, stem catches up. |
| Smoke, steam, dust | ParticleEmitter, big Size, low Speed, Drag, Transparency fade, `LightInfluence` 1 | Dark/gray: `LightEmission` 0. |
| Fire, torch, ember | Emitter with Color gradient + `LightEmission` + PointLight flicker via noise | Upward `Acceleration`. |
| Sparks, debris | Emitter with gravity `Acceleration = (0,-60,0)`, short Lifetime, Stretch via `Orientation` | Or real small Parts with physics for debris that bounces. |
| Lightning | Beam chain with random jagged midpoints, re-randomize 20-30 Hz, flash light | See recipe. |
| Magic circle / rune | Flat Part with decal/SurfaceGui, or ring of Parts; rotate with `CFrame` | No texture? Build rings from thin Cylinders and Neon Blocks. |
| Aura / glow | Emitter on `Attachment` with `Shape` = Sphere, `ShapeInOut` = Inward | Plus Highlight instance for outline. |
| Water splash/waterfall | Emitter (white-blue, gravity), Beam for streams, foam ring Part | Terrain water if it is a real body of water. |
| Slash / swing trail | `Trail` between two Attachments on the blade | Plus a brief Neon wedge arc for the big hit. |
| Portal, black hole | Rotating ring Parts + inward emitter + dark sphere + distortion fake (BlurEffect pulse) | Inward emitters sell the "pull". |
| Plant growing | Procedural model + `ScaleTo` growth with overshoot + leaf unfurl + pollen emitter | See `procedural-nature.md`. |
| Wind, grass, trees sway | Sine noise on Motor6D / CFrame, phase offset by position | Use `Workspace.GlobalWind` for emitter drift. |
| Rain, snow | One big emitter in a part above the camera, follows the camera | Do not create one emitter per drop. |
| Dissolve, disintegrate | Tween Transparency + spawn emitter from each part's attachment + shrink | Stagger by distance for a wave. |
| Heal, buff, level up | Rising sparkles + soft ring + gentle light pulse + chime | Upward, slow, warm colors. |
| Impact on a creature | The monster example in `vfx-sfx.md`: warn -> hit -> aftermath | Only ONE of many; do not default to it. |

## 4. Worked breakdowns

### 4a. "nuclear boom" (large cinematic explosion)
1. Anatomy: white flash; fireball (Neon sphere); shockwave ring on ground; dust skirt (ring-shaped
   dust emitter); stem (cylinder); cap (squashed sphere); smoke emitters inside cap and stem; debris
   lifted upward; late fallout (dark falling particles); ground scorch decal optional.
2. Phases: 0.0 flash (0.15s) -> 0.0-1.5 fireball grows, rises -> 0.2-5 shockwave expands to full
   radius -> 1-8 stem rises, cap billows -> 8-25 cloud cools to gray and spreads -> 25-40 fade out.
3. Motion: fireball ease-out expansion then slow rise; shockwave linear-ish expansion with
   transparency 0.2 -> 1; cap accelerates then slows; stem top follows the cap.
4. Look: flash white; fireball white -> yellow -> orange -> dark red; smoke cap orange-brown at the
   bottom to dark gray at the top (lit from the fireball below).
5. Scale: radius 120-300 studs, cloud height 300-600 studs. State it in Config (`SCALE`).
6. Layers: whiteout `ColorCorrection` + Bloom spike, camera shake that depends on distance, sound
   delayed by `distance / speedOfSound` (studs/s), a low rumble tail, wind gust (`GlobalWind`),
   parts near the blast pushed outward (server).
7. Runs: server decides "blast at position P with power N" and damages; clients play visuals via one
   RemoteEvent. Budget: under 80 parts, under 600 live particles per client, auto-cleanup at 45s.
Recipe: `vfx-recipes.md` -> "Nuclear blast".

### 4b. "a plant"
1. Anatomy: pot or soil mound, main stem, 3-6 leaf pairs, bud, flower (petals around a center), pollen.
2. Phases: sprout (0-1s) -> grow (1-4s) -> leaves unfurl (3-5s) -> bud opens (5-6s) -> idle sway.
3. Motion: stem grows upward with slight overshoot; leaves start folded (rotated) and rotate open;
   idle: slow sine sway, phase shifted per leaf; pollen drifts up on wind.
4. Look: 3 greens (dark stem, mid leaf, light highlight), one flower accent color; Material `Grass`
   or `SmoothPlastic`; soft green `PointLight`.
5. Scale: 4-8 studs tall for a prop; 20+ for a giant "magic" plant.
6. Layers: soil puff on sprout, soft rustle SFX, small sparkles on bloom.
7. Runs: model built by code (server or Command Bar), growth animation on client or via tween on
   server if everyone must see the same state. Budget: under 150 parts.
Recipe: `procedural-nature.md`.

### 4c. "waterfall"
Anatomy: cliff lip, falling sheet, mist at the base, splash foam ring, pool surface, rainbow optional.
Motion: sheet = tall thin emitter with downward `Acceleration`, texture stretched (`Orientation`
`VelocityParallel`); mist rises and drifts; foam pulses. Layers: loud 3D looping water sound (min
distance 30, max 200), cool color grade near it. Runs: client emitters, static, cheap.

### 4d. "sword slash"
Anatomy: blade, trail, impact flash, sparks, afterimage arc. Phases: wind-up 0.15s -> swing 0.1s ->
impact 0.05s -> recovery 0.2s. The Trail is only active during the swing. Layers: whoosh, hit, hit stop
(freeze animation speed to 0.05 for 0.06s), small camera kick. Runs: client visuals, server damage.

## 5. Scale, timing and budget defaults

| Effect size | Duration | Radius (studs) | Layers | Part budget | Live particle budget |
|---|---|---|---|---|---|
| Tiny (pickup, hit spark) | 0.2-0.6s | 1-4 | 2 | 0-5 | 30 |
| Small (hit, spell) | 0.5-1.5s | 3-10 | 3 | 5-15 | 100 |
| Medium (grenade, boss attack) | 1-4s | 10-40 | 4 | 15-40 | 300 |
| Large (big explosion, nuke, storm) | 5-40s | 50-400 | 5 | 40-100 | 600 |

Total live particles ~ sum over emitters of (Rate x Lifetime). Emit(n) bursts count too.
Quality scaling: read a Config `QUALITY` (1-3) and multiply counts by 0.4 / 0.7 / 1 so mobile does not die.

## 6. Self-check against copy-paste from examples

Before delivering, ask:
- Did I run the 7 questions on THIS subject, or did I reuse the monster/jumpscare structure?
- Do the part names, comments, config keys and SFX names describe this subject (`Shockwave`, `Cap`,
  `Petal`), not words from an example (`Roar`, `Jumpscare`, `Monster`)?
- Is the scale right for this subject in studs?
- Does the timeline have this subject's phases, not a generic 3-step pattern?
- Is every visual layer I list actually implemented, not just mentioned?
