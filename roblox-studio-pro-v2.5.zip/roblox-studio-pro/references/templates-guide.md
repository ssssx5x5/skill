# Hướng dẫn dùng `templates/`

| File | Loại | Đặt ở | Dùng để |
|---|---|---|---|
| `VFXKit.lua` | ModuleScript | `ReplicatedStorage` (client gọi) | Explosion, Impact, Lightning, Slash, Ring, Shards, Emitter preset, Shake, ScreenFlash, HitStop, AutoQuality |
| `GeoKit.lua` | ModuleScript | ServerStorage / plugin / Command Bar | Lathe, Loft, Sweep, Tube, ellipsoid, Fibonacci |
| `ModelKit.lua` | ModuleScript | cùng chỗ GeoKit | Part/Wedge chuẩn, MirrorX, WeldToPrimary, Normalize, PlaceOnGround, **Audit** |
| `PoseKit.lua` | ModuleScript | ReplicatedStorage | Walk, Idle, SwordSlash, Crouch cho R15 |
| `project/` | dự án Rojo | — | Remotes + Validate + DataService + bootstrap + cấu hình lint/format |

## Quy tắc dùng

1. **Không viết lại helper** (`tween`, `ringWave`, `lightFlash`...): `require` VFXKit. Các recipe trong `vfx-animation.md` là mô tả pha/số đo; code chạy được nằm ở VFXKit.
2. Muốn hiệu ứng mới → thêm hàm vào VFXKit (cùng khung instant → body → detail → feel → cleanup, có `Scale`, đi qua `fxPart` để có ngân sách và dọn), đừng rải code rời.
3. Command Bar chỉ chạy được một chunk: nhúng module bằng cách tạo `ModuleScript` từ chuỗi source, hoặc dán file vào Studio rồi `require`.
4. Sau khi chép template vào dự án: `python scripts/lint_luau.py <path>` + `luau-compile`.
5. Test: `templates/tests/run_geokit_test.sh` và `templates/project/tests/run_validate_test.sh` (cần `luau` CLI; đặt `LUAU=/đường/dẫn/luau`).

## Những gì template CHƯA kiểm được

Mọi thứ phụ thuộc API Roblox (Part, Beam, ParticleEmitter, camera, EditableMesh) chỉ được **kiểm cú pháp** bằng `luau-compile`, chưa chạy trong Studio. Lần đầu dùng: chạy `VFX.SelfTest()` lúc Play và đọc Output; báo kết quả thật cho người dùng, đừng tuyên bố đã chạy ổn.
Texture hạt dùng `rbxasset://textures/particles/*.dds`: đường dẫn này có sẵn trong engine nhưng **chưa xác minh** trên mọi bản — nếu hạt trắng/vuông, đổi sang texture id của bạn qua `overrides`.
