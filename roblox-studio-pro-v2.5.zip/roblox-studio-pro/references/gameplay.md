# Hệ thống gameplay: kinh tế, vòng chơi, combat, monetization và live ops

> Khi nào dùng: khi dựng hoặc soát một hệ thống gameplay có tiền tệ, vòng chơi, combat, shop, phần thưởng hay vật phẩm trả phí — nơi state phải sống trên server và không được mất hay nhân đôi khi có lag, respawn hay retry.

## Hợp đồng chung

Mọi hệ thống dưới đây theo cùng bốn luật; vi phạm một luật là có exploit hoặc mất dữ liệu.

| Luật | Nghĩa | Cách kiểm |
| --- | --- | --- |
| State ở server | biến authoritative nằm trong một service module; phần bền vững đi qua data layer | client chỉ đọc attribute hoặc snapshot |
| Client gửi intent | remote validate kiểu, validate giá trị, rate-limit | không bao giờ tin vị trí, giá, số lượng do client gửi |
| Config là data | tunable trong module shared/server hoặc `ConfigService` | đổi số không phải sửa logic |
| Lifecycle-safe | join giữa ván, respawn, thoát giữa hành động, server shutdown | mọi bảng state phải clear ở `PlayerRemoving` |

Câu hỏi bắt buộc trước khi viết dòng đầu: state authoritative ở đâu và persist thế nào; client được request gì và mỗi request validate/rate-limit ra sao; chuyện gì xảy ra khi join giữa ván, respawn, teleport, shutdown; tune bằng gì và đo bằng gì; hành vi với 1 người, với server đầy, với 300 ms ping.

## Tiền tệ và leaderstats

Một module sở hữu một resource; không chỗ nào khác ghi vào nó.

| Quy tắc | Chi tiết |
| --- | --- |
| Trần | `MAX_BALANCE = 1e12`; clamp khi load, clamp khi cộng |
| Validate số | `math.isfinite(amount)` chặn `nan`/`inf` trước khi so sánh |
| Chiều | `add` chỉ nhận amount > 0; `spend` là check-and-spend nguyên tử, trả `false` nếu thiếu |
| Làm tròn | `math.floor(amount)` — không để số lẻ trôi vào hiển thị |
| Replicate | `player:SetAttribute("Coins", balance)`; client nghe `GetAttributeChangedSignal("Coins")` |
| Nguồn/đích | mỗi lần add/spend truyền `source`/`sink` để log economy event |

`leaderstats` chỉ là bản hiển thị: một `Folder` tên **chính xác** `leaderstats` (chữ thường) gắn dưới `Player`, chứa `IntValue`. Cho `IntValue` đồng bộ từ attribute qua `GetAttributeChangedSignal`, đừng cho nó là nguồn sự thật — nếu không, hai nguồn lệch nhau sau khi respawn hoặc sau khi data load chậm.

`IntValue` đó nên sync từ attribute trong một hàm `sync()` gọi ngay lúc tạo và nối vào `GetAttributeChangedSignal("Coins")`; giá trị attribute không phải number thì gán 0. Người chơi vào trước khi script chạy: lặp `Players:GetPlayers()` và `task.spawn` cho từng người, đừng chỉ dựa vào `PlayerAdded`.

## XP và level

Đường cong nhẹ, hàm thuần để test được: `xpForLevel(level) = math.floor(100 * level ^ 1.5)`.

| Level | XP cần cho level kế |
| --- | --- |
| 1 → 2 | 100 |
| 2 → 3 | 282 |
| 3 → 4 | 519 |
| 10 → 11 | 3.162 |
| 50 → 51 | 35.355 |
| 100 | 100.000 (chạm `maxLevel`, XP reset về 0) |

`addXp` nhận `(level, xp, amount, maxLevel)` và trả `(level, xp, levelsGained)`: cộng dồn rồi `while level < maxLevel and xp >= xpForLevel(level)` trừ dần và tăng level. Trả `levelsGained` để chỗ gọi biết có phát level-up VFX, mở khoá, hay grant reward — đừng để chỗ gọi tự so sánh level trước/sau.

## Vòng chơi

State machine trên server, client render từ attribute của một `Folder` shared trong `ReplicatedStorage`.

| Phase | Thời lượng | Việc xảy ra |
| --- | --- | --- |
| `Waiting` | không giới hạn | chờ đủ `MIN_PLAYERS = 2` |
| `Intermission` | 15 s | chuẩn bị, chọn map, chia team |
| `Playing` | 180 s | ván đấu; kết thúc sớm khi còn ≤ 1 người sống |
| `Results` | 8 s | trao thưởng, teleport về lobby, dọn map |

- Timer dùng **thời điểm kết thúc tuyệt đối**: `state:SetAttribute("PhaseEndsAt", workspace:GetServerTimeNow() + duration)`. Client tự đếm bằng `endsAt - workspace:GetServerTimeNow()` trên `Heartbeat`, chỉ update `TextLabel` khi giây đổi. Không bắn remote mỗi giây.
- `participants` là bảng riêng, không phải `Players:GetPlayers()`: người vào giữa ván không tham gia, người thoát giữa ván phải bị xoá khỏi bảng, nếu không điều kiện thắng ("còn 1 người sống") không bao giờ đúng.
- Vòng chờ kết thúc: poll `aliveParticipants()` mỗi 0,5 s, không phải mỗi frame.
- Map: `Clone()` từ `ServerStorage.Maps`, gán `Parent = workspace`, ghi tên vào attribute `Map`; `Destroy()` ở `endRound`. Quên destroy là rò rỉ part qua từng ván.
- Team: tạo `Team` trong `Teams` với `AutoAssignable = false` khi tự chia, set `player.Team`, dùng `SpawnLocation.TeamColor` cho spawn. Trả `player.Neutral = true` khi về lobby.
- Người vào giữa `Playing`: cho spectate (camera lên một người còn sống) tới ván sau, đừng nhét vào giữa ván.
- Thưởng: grant ở `Results` cho người **còn trong server**, qua currency service, không sửa `leaderstats` trực tiếp.

## Combat có server validate

Client predict (phát animation/âm thanh ngay) và gửi intent; server sở hữu cooldown, hit detection và damage.

| Weapon | kind | damage | cooldown | range | hitbox |
| --- | --- | --- | --- | --- | --- |
| Sword | `Melee` | 25 | 0,6 s | 7 | `Vector3.new(6, 5, 7)` |
| Blaster | `Ranged` | 18 | 0,25 s | 300 | — |

- Config là bảng `table.freeze` trong `ReplicatedStorage` để client biết cooldown/range mà vẽ UI; server **đọc lại** từ đó, không đọc từ message.
- Cooldown so với `os.clock()` và chấp nhận sai số: `now - last < cooldown * 0.9` thì bỏ. Không có dung sai thì jitter mạng làm phát bắn hợp lệ bị nuốt.
- Melee: hộp overlap đặt **phía trước theo vị trí server** — `root.CFrame * CFrame.new(0, 0, -range / 2)` với `hitboxSize`. `LookVector` là `-Z`, nên dịch `-range/2` theo trục Z.
- Dedupe theo `Model`: một nhân vật nhiều part nằm trong hộp sẽ trúng nhiều lần nếu không có bảng `hitModels`.
- Ranged: client chỉ gửi **hướng ngắm**; server cast từ `root.Position + Vector3.new(0, 1.5, 0)` với độ dài `range`. Validate `typeof(direction) == "Vector3"`, `Magnitude > 0.01`, và `direction.Magnitude == direction.Magnitude` (phép so sánh tự loại `nan`).
- Damage: `Humanoid:TakeDamage` tôn trọng `ForceField`; muốn xuyên thì trừ `Health`. Ghi `LastAttacker` bằng attribute để chỗ chết biết ai giết.
- Friendly fire: chặn khi `victim.Team == attacker.Team and not victim.Neutral`.
- Mọi bảng `lastAttack`/`equipped` phải clear ở `PlayerRemoving`; `equipped` do inventory set, **không** do client set.

```luau
local overlap = OverlapParams.new()
overlap.FilterType = Enum.RaycastFilterType.Exclude

local function meleeAttack(player: Player, root: BasePart, damage: number, range: number, hitboxSize: Vector3)
	local boxCFrame = root.CFrame * CFrame.new(0, 0, -range / 2)
	overlap.FilterDescendantsInstances = { player.Character :: Model }
	local hitModels: { [Model]: boolean } = {}
	for _, part in workspace:GetPartBoundsInBox(boxCFrame, hitboxSize, overlap) do
		local model = part:FindFirstAncestorOfClass("Model")
		if model and not hitModels[model] then
			hitModels[model] = true
			damageModel(model, player, damage)
		end
	end
end
```

**Lag compensation** (chỉ cần cho shooter nhanh): raycast trên vị trí server hiện tại sẽ trượt mục tiêu mà người bắn đã thấy. Cách làm: giữ lịch sử vị trí mỗi nhân vật ~1 s sample trên `Heartbeat`; client gửi `(targetCharacter, hitPosition, clientTime)`; server rewind theo `player:GetNetworkPing()`, kiểm tra vị trí mục tiêu lúc đó nằm trong dung sai, kiểm tra line of sight với geometry tĩnh, range và fire rate. Không làm được thì chọn chế độ server authority.

## Inventory, tool và shop

| Khái niệm | Quy tắc |
| --- | --- |
| Catalog | `table.freeze` trong `ReplicatedStorage`, có `price`, `maxStack`, `toolTemplate`; server đọc lại giá từ đây |
| Stack | `add` từ chối khi `current + amount > maxStack`; `remove` xoá key khi về 0 |
| Replicate | `FireClient(player, "snapshot", inventory)` lúc load, `"delta"` cho từng thay đổi |
| Equip | clone `Tool` template từ `ServerStorage.Tools` vào `Backpack`; kiểm tra đã có trước khi clone |
| Respawn | tool trong `Backpack` mất khi chết — clone vào `player.StarterGear` hoặc re-grant ở `CharacterAdded` |

Mua bằng soft currency phải nguyên tử. Thứ tự: rate-limit → validate kiểu → đọc giá từ catalog → kiểm tra stack → `spend` → `add` → nếu `add` fail thì `add` lại tiền (refund) và trả lỗi. Không có bước refund là mất tiền của người chơi khi inventory đầy.

```luau
buy.OnServerInvoke = function(player: Player, itemId: unknown): (boolean, string)
	if os.clock() - (lastBuy[player] or 0) < 0.3 then
		return false, "Too fast"
	end
	lastBuy[player] = os.clock()
	if typeof(itemId) ~= "string" then
		return false, "Invalid item"
	end
	local item = Items[itemId]
	if not item or not item.price then
		return false, "Not for sale"
	end
	if InventoryService.count(player, itemId) >= item.maxStack then
		return false, "Inventory full"
	end
	if not CurrencyService.spend(player, item.price, `Shop:{itemId}`) then
		return false, "Not enough coins"
	end
	if not InventoryService.add(player, itemId, 1) then
		CurrencyService.add(player, item.price, "Refund")
		return false, "Could not add item"
	end
	return true, "Purchased"
end
```

## Obby checkpoint

- Đánh dấu checkpoint bằng `CollectionService` tag, mỗi part mang attribute `Stage` kiểu number.
- Chỉ nhận khi `stage == current + 1` — chặn nhảy cóc và chặn đi lùi ghi đè tiến độ.
- Respawn: `character:PivotTo(checkpoint.CFrame + Vector3.new(0, 4, 0))` trong `task.defer` (chạy sau khi character ổn định), tìm checkpoint có `Stage` bằng stage đã lưu.
- `Touched` trên checkpoint cần debounce và vẫn nên kèm heuristic thời gian tối thiểu mỗi stage để bắt teleport.

## Daily reward

`utcDay() = os.time() // 86400` — mốc ngày UTC, không phụ thuộc timezone máy người chơi.

| Trạng thái | Kết quả |
| --- | --- |
| `lastClaimDay == today` | từ chối, "already claimed" |
| `lastClaimDay == today - 1` | `streak += 1` |
| còn lại (lần đầu hoặc đã lỡ ngày) | `streak = 1` |

Bảng thưởng 7 ngày: `{ 50, 75, 100, 150, 200, 300, 500 }`, lấy `REWARDS[math.min(streak, #REWARDS)]` nên ngày 8 quay lại mức ngày 7. Lưu `RewardState` vào profile và **save ngay** sau khi grant — nếu không, crash server giữa chừng là grant lặp vô hạn. Client hiển thị giờ claim kế tiếp bằng `(utcDay() + 1) * 86400` so với `workspace:GetServerTimeNow()`.

## Pet đi theo người chơi

- Server spawn model pet, set `pet.PrimaryPart:SetNetworkOwner(player)` để client của chủ sở hữu mô phỏng mượt, và replicate `PetOwner` bằng attribute.
- Cách rẻ cho hàng trăm pet: **không** dùng physics — mọi client tự animate pet cục bộ từ vị trí chủ sở hữu.
- Cách có vật lý: `AlignPosition` + `AlignOrientation` đẩy pet tới offset sau lưng nhân vật.
- Pet mở bằng Robux hoặc bằng currency mua bằng Robux là **paid random item**: phải công bố tỉ lệ và tôn trọng `PolicyService` (xem dưới).

## Monetization: chọn đúng loại sản phẩm

| Loại | Mua | Dùng cho | Grant qua |
| --- | --- | --- | --- |
| Developer product | lặp lại | currency, consumable, boost, revive | `MarketplaceService.ProcessReceipt` (server) |
| Pass | một lần, vĩnh viễn | VIP, perk vĩnh viễn, thêm slot | `UserOwnsGamePassAsync` lúc join + event purchase |
| Subscription | hàng tháng, thu hồi được | perk định kỳ (currency ngày, VIP) | `GetUserSubscriptionStatusAsync` + `UserSubscriptionStatusChanged` |
| Rewarded video | miễn phí (xem quảng cáo) | thưởng nhỏ, giá trị ≈3–10 Robux | developer product qua `ProcessReceipt` |
| Commerce product | tiền thật (hàng vật lý) | merch kèm quyền lợi số | `CommerceService`; quyền lợi số qua `ProcessReceipt` |
| Private server | hàng tháng | server riêng trả phí | cấu hình trong Creator Dashboard |

Grant **luôn** ở server. Không grant từ `PromptProductPurchaseFinished` hay bất kỳ event client nào — client giả được.

## ProcessReceipt: idempotent, persisted, một script

| Luật | Vì sao |
| --- | --- |
| Đúng **một** script server set `ProcessReceipt` | hai handler thì cái sau ghi đè cái trước, receipt rơi vào hư không |
| Chỉ trả `PurchaseGranted` sau khi đã persist | chưa persist mà trả granted là mất vật phẩm khi server chết |
| Ghi `PurchaseId` đã xử lý vào data đã lưu | retry gửi lại **cùng** `PurchaseId`; không có danh sách là grant đôi |
| Giữ tối đa `MAX_REMEMBERED_PURCHASES = 100` id | danh sách phình vô hạn làm hỏng save |
| Player có thể chưa load hoặc đã rời | chờ data (tối đa 20 s, poll 0,5 s) hoặc trả `NotProcessedYet` |

```luau
--!strict
local MarketplaceService = game:GetService("MarketplaceService")
local Players = game:GetService("Players")

local MAX_REMEMBERED_PURCHASES = 100
local PRODUCTS: { [number]: (Player, any) -> () } = {
	[1234567] = function(_player, data) data.coins += 100 end,
}

local function processReceipt(receipt): Enum.ProductPurchaseDecision
	local player = Players:GetPlayerByUserId(receipt.PlayerId)
	if not player then
		return Enum.ProductPurchaseDecision.NotProcessedYet -- grant ở lần vào sau
	end
	local data, deadline = getLoadedData(player), os.clock() + 20
	while not data and player.Parent == Players and os.clock() < deadline do
		task.wait(0.5)
		data = getLoadedData(player)
	end
	if not data then
		return Enum.ProductPurchaseDecision.NotProcessedYet
	end
	if table.find(data.purchaseIds, receipt.PurchaseId) then
		return Enum.ProductPurchaseDecision.PurchaseGranted -- retry của receipt đã grant
	end
	local handler = PRODUCTS[receipt.ProductId]
	if not handler or not pcall(handler, player, data) then
		return Enum.ProductPurchaseDecision.NotProcessedYet
	end
	table.insert(data.purchaseIds, receipt.PurchaseId)
	while #data.purchaseIds > MAX_REMEMBERED_PURCHASES do
		table.remove(data.purchaseIds, 1)
	end
	if not saveNow(player) then
		return Enum.ProductPurchaseDecision.NotProcessedYet -- danh sách id chặn grant đôi
	end
	return Enum.ProductPurchaseDecision.PurchaseGranted
end

MarketplaceService.ProcessReceipt = processReceipt :: any
```

Với ProfileStore, "đã persist" nghĩa là `PurchaseId` đã nằm trong `profile.LastSavedData`, hoặc `profile:Save()` xong. Prompt từ client bằng `MarketplaceService:PromptProductPurchase(Players.LocalPlayer, productId)`; grant vẫn ở server.

## Pass và subscription

- Pass: kiểm tra `UserOwnsGamePassAsync(userId, passId)` trong `pcall` lúc join, và kiểm tra lại trong `PromptGamePassPurchaseFinished` thay vì tin tham số `purchased`. Kết quả được cache theo server, nên handler purchase là thứ bắt kịp giao dịch trong phiên.
- Subscription: `GetUserSubscriptionStatusAsync(player, "EXP-...")` trả `{ IsSubscribed, IsRenewing }`; kiểm tra lúc join và trong `Players.UserSubscriptionStatusChanged(player, subscriptionId)`.
- Quyền lợi subscription phải **thu hồi được**: khi `IsSubscribed` false thì gỡ perk đã persist, không chỉ ngừng grant mới.
- Thay pass bằng subscription: giữ tôn trọng người đã mua pass, gỡ pass khỏi bán.

## Rewarded video

Điều kiện: creator 13+ và đã xác minh danh tính, game public ≥ 2.000 người dùng duy nhất mỗi tháng, đã bật serving trong Creator Hub → Monetization → Ads → Settings, và phần thưởng phải là developer product.

- Client chỉ hiện nút khi có quảng cáo: `AdService:GetAdAvailabilityNowAsync(Enum.AdFormat.RewardedVideo)` và so `AdAvailabilityResult == Enum.AdAvailabilityResult.IsAvailable`; gọi ngay trước khi show, không cache lâu.
- Server: `AdService:CreateAdRewardFromDevProductId(productId)` rồi `AdService:ShowRewardedVideoAdAsync(player, reward)`; thành công là `Enum.ShowAdResult.ShowCompleted`. Chặn gọi chồng bằng bảng `watching[player]`.
- Bảo vệ nhân vật trong lúc xem (lobby/safe zone hoặc tắt damage). Phần thưởng không được random.

## Giá, shop và policy

- **Không hardcode giá Robux.** Managed pricing (regional pricing + tối ưu giá) hiển thị giá khác nhau cho từng người. Lấy giá live bằng `GetProductInfoAsync(id, Enum.InfoType.Product)` hoặc `GetDeveloperProductsAsync()`; số tiền thật đã trả nằm trong `receipt.CurrencySpent`.
- Cá nhân hoá thứ tự shop bằng `MarketplaceService:RankProductsAsync(identifiers)` — gọi một lần lúc join, rate limit rất chặt. "Top picks" bằng `RecommendTopProductsAsync({ Enum.InfoType.Product, Enum.InfoType.GamePass })` — cần có giao dịch trong 28 ngày, gọi trong `task.spawn`.
- Chống arbitrage vùng giá: `GetUsersPriceLevelsAsync(userIds)` trả mức 1–1000 (% giá toàn cầu) cho 1–1000 user; fetch lúc join, **không** cache qua session, dùng để chặn gift/trade vật phẩm mua bằng tiền.
- Paid random item (loot box, gacha, spin mua bằng Robux hoặc currency mua bằng Robux): công bố tỉ lệ trước khi mua và đọc `PolicyService:GetPolicyInfoForPlayerAsync(player)`:
  - `ArePaidRandomItemsRestricted` → phải có đường miễn phí kiếm được, chuỗi kết quả cố định đã công bố, hoặc bán trực tiếp.
  - `IsPaidItemTradingAllowed` → `false` thì tắt trade vật phẩm trả phí.
- Tôn trọng giới hạn tuổi/vùng mà `PolicyService` trả về cho quảng cáo, link xã hội và trading.

## Analytics

Log từ **server** (các API này yêu cầu vậy, và chỉ server mới đáng tin). Họ `Fire*` đã deprecated, dùng `Log*`.

| API | Dùng cho | Tham số then chốt |
| --- | --- | --- |
| `LogEconomyEvent` | nguồn/đích currency | `Enum.AnalyticsEconomyFlowType.Source`/`Sink`, currency, amount, **endingBalance**, transaction type, SKU |
| `LogOnboardingFunnelStepEvent` | funnel tutorial phiên đầu | step 1-based, **tuần tự**, tên step |
| `LogFunnelStepEvent` | funnel lặp (mua hàng) | tên funnel, `sessionId` dùng chung mỗi lần thử, step, tên step |
| `LogProgressionStartEvent` / `LogProgressionCompleteEvent` | level, chương | tên path, level, tên milestone |
| `LogCustomEvent` | số đo bất kỳ | giá trị number + tối đa **3** custom field |

- `endingBalance` sai là dashboard economy sai; thiếu một source/sink là toàn bộ biểu đồ lệch.
- Cardinality thấp: custom field chứa id danh mục, không chứa free text hay `UserId`.
- Thiết kế funnel trước khi xây feature, không phải sau.
- `AnalyticsService:GetPlayerSegmentsAsync(player)` cho biết segment (đã từng trả tiền chưa, tuổi tài khoản trong game...) để tune onboarding/offer; bọc `pcall`.

## Config và thực nghiệm

- `ConfigService:GetConfigAsync()` trả snapshot; đọc bằng `snapshot:GetValue(key)`. Config có thể fail → **luôn** có default.
- Bản mới publish tới server đang chạy qua `snapshot.UpdateAvailable`; gọi `snapshot:Refresh()` ở thời điểm an toàn (giữa hai ván), không giữa combat.
- Thực nghiệm/targeted config phải dùng `ConfigService:GetConfigForPlayerAsync(player)` — `GetConfigAsync` bỏ qua targeting.
- Thực nghiệm chạy 14–60 ngày, tối đa hai biến thể cộng control; chọn một goal metric và tôn trọng minimum detectable effect.
- Test trong Studio: `ConfigService:SetTestingValue(key, value)` / `ClearTestingValue`.

## Badge, thông báo, sự kiện

- `BadgeService:AwardBadgeAsync(userId, badgeId)` trên server, bọc `pcall`; bỏ qua nếu `UserHasBadgeAsync`/`CheckUserBadgesAsync` đã nói có. `AwardBadge`/`UserHasBadge` deprecated.
- Thông báo kéo người chơi về: xin opt-in đúng lúc bằng `ExperienceNotificationService:CanPromptOptInAsync()` rồi `PromptOptIn()` (client); gửi từ backend qua Open Cloud `POST /cloud/v2/users/{userId}/notifications`. Có rate limit và duyệt nội dung.
- Timed event: mốc `eventStart`/`eventEnd` là timestamp UTC trong config, so bằng `os.time()` trên server, broadcast state bằng attribute, client đếm ngược từ `workspace:GetServerTimeNow()`.
- Season pass / shop xoay vòng: seed = `math.floor(os.time() / 86400)` cho shop ngày; lưu reward đã claim theo `seasonId` trong data người chơi.

## Bẫy

- **Người chơi mất tiền mà không nhận item** — `spend` xong `add` fail (inventory đầy) và không refund — luôn `add` lại đúng số vừa trừ trong nhánh lỗi.
- **Nhận 2 lần cùng một giao dịch** — handler grant rồi mới ghi `PurchaseId`, hoặc ghi vào bảng in-memory không persist — ghi id vào data đã lưu trước khi trả `PurchaseGranted`.
- **Receipt rơi mất, không ai xử lý** — hai script cùng set `ProcessReceipt`, cái sau ghi đè — chỉ một script, đặt trong `ServerScriptService`.
- **Người chơi mua lúc đang load data, vật phẩm biến mất** — handler trả `PurchaseGranted` khi chưa có data — trả `NotProcessedYet`, chờ tối đa 20 s rồi trả lại để Roblox retry.
- **`leaderstats` không hiện trong player list** — `Folder` đặt tên `Leaderstats` hoặc `LeaderStats` — phải đúng `leaderstats`.
- **Số coin hiển thị đúng lúc đầu rồi đứng im** — `IntValue` chỉ set một lần, không nối `GetAttributeChangedSignal` — nối signal và sync lại sau mỗi thay đổi.
- **Ván không bao giờ kết thúc dù còn 1 người** — bảng `participants` còn giữ người đã rời — clear ở `PlayerRemoving` và kiểm tra `player.Parent == Players` khi đếm người sống.
- **Đồng hồ đếm ngược lệch giữa các client** — server bắn remote mỗi giây, mỗi client cộng dồn — replicate `PhaseEndsAt` tuyệt đối, client tự tính từ `workspace:GetServerTimeNow()`.
- **Map cũ còn part sau nhiều ván, server chậm dần** — `endRound` không `Destroy()` map clone — giữ tham chiếu `currentMap` và destroy, set `nil` sau đó.
- **Đánh trúng một người 3 lần bằng một nhát chém** — mỗi part của nhân vật là một lần `TakeDamage` — dedupe theo `Model` trước khi damage.
- **Bắn xuyên tường hoặc trúng người sau lưng** — client gửi `target`/`position` và server tin — chỉ nhận hướng ngắm, server tự raycast từ vị trí của nó.
- **Phát bắn hợp lệ bị từ chối ngẫu nhiên** — cooldown so tuyệt đối, không dung sai — dùng `cooldown * 0.9` để bù jitter.
- **Tool biến mất sau khi chết** — tool chỉ nằm trong `Backpack`, `Backpack` bị tạo lại — clone vào `player.StarterGear` hoặc re-grant ở `CharacterAdded`.
- **Người chơi nhảy cóc checkpoint** — chỉ kiểm tra `stage > current` — chỉ nhận `stage == current + 1`.
- **Daily reward grant lặp sau khi server crash** — grant xong mới set `lastClaimDay` và không save ngay — cập nhật state và save trước khi trả về thành công.
- **Streak reset oan cho người chơi ở múi giờ khác** — dùng ngày theo giờ địa phương — luôn dùng `os.time() // 86400` (UTC).
- **Pet giật khi có người khác đi qua** — network ownership nhảy giữa các client — `pet.PrimaryPart:SetNetworkOwner(player)` ngay sau khi spawn.
- **Bán loot box bị từ chối kiểm duyệt** — không công bố tỉ lệ, không kiểm tra `ArePaidRandomItemsRestricted` — hiển thị odds trước khi mua và luôn có đường miễn phí khi bị hạn chế.
- **Doanh thu hiển thị thấp hơn thực tế** — UI hiện giá hardcode thay vì giá managed pricing — đọc giá qua `GetProductInfoAsync` và dùng `receipt.CurrencySpent` khi đối soát.
- **Nút "xem quảng cáo" bấm vào không có gì xảy ra** — kiểm tra availability một lần lúc mở shop rồi cache — gọi `GetAdAvailabilityNowAsync` ngay trước khi show.
- **Đổi config mà server đang chạy không nhận; thực nghiệm không chia nhóm** — chỉ đọc `GetConfigAsync` một lần lúc khởi động, hàm này bỏ qua targeting — nối `UpdateAvailable` + `Refresh()` giữa hai ván, và dùng `GetConfigForPlayerAsync(player)` cho thực nghiệm.
- **Dashboard economy vô nghĩa** — log `endingBalance` sai hoặc bỏ sót sink — log mọi source/sink ngay tại chỗ thay đổi số dư, kèm balance sau giao dịch.
