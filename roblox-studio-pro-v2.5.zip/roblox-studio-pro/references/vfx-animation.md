# VFX & Animation

> Khi nào dùng: dựng hoặc gỡ lỗi chuyển động rig, hiệu ứng hạt/ánh sáng và cutscene camera trong Roblox, nhất là khi animation "không chạy" hay VFX "không thấy" mà Output không báo lỗi.

Không có text-to-animation và không có text-to-VFX: animation đến từ asset đã publish hoặc tự pose bằng code, VFX là code. Bốn đường đi: id đã publish cho chuyển động có sẵn, `AnimationConstraint.Transform` trong `PreSimulation` cho chuyển động tuỳ biến, `Trail` + `ParticleEmitter` cho hiệu ứng gắn vũ khí, `Rate = 0` + `:Emit(n)` cho cú nổ một lần.

## Animation

### Rig R15 dùng `AnimationConstraint`, không phải `Motor6D`

Đo trên model tạo bằng `Players:CreateHumanoidModelFromDescription(desc, Enum.HumanoidRigType.R15)`: 15 `AnimationConstraint`, 14 `BallSocketConstraint`, 53 `Attachment`, 19 `NoCollisionConstraint`, và **0 `Motor6D`**.

Hệ quả: **không có `C0` để tween**. Trên `AnimationConstraint`, `C0` / `C1` / `Part0` / `Part1` chỉ là alias **read-only**; gán vào sẽ lỗi. Pose property dùng chung và ghi được trên cả hai class là `Transform`.

```luau
for _, d in ipairs(model:GetDescendants()) do
	if d:IsA("AnimationConstraint") then print(d.Name) end
end
```

15 khớp R15 (cũng là tên `Pose`): `Root, Waist, Neck, LeftShoulder, LeftElbow, LeftWrist, RightShoulder, RightElbow, RightWrist, LeftHip, LeftKnee, LeftAnkle, RightHip, RightKnee, RightAnkle`.

### Enum — giá trị thật

Đo bằng `Enum.X:GetEnumItems()`, đừng đoán:

| Enum | Thành viên hợp lệ |
|---|---|
| `PoseEasingStyle` | `Linear`, `Constant`, `Elastic`, `Cubic`, `Bounce`, `CubicV2` |
| `PoseEasingDirection` | `In`, `Out`, `InOut` |
| `AnimationPriority` | `Idle`, `Movement`, `Action`, `Action2`, `Action3`, `Action4`, `Core` |

**Không có `Quad`, `Quint`, `Sine`, `Exponential` trong `PoseEasingStyle`.** Cú đánh bật nhất là `CubicV2`.

### `KeyframeSequence` đăng ký runtime KHÔNG làm rig chuyển động

`KeyframeSequenceProvider:RegisterKeyframeSequence(ks)` trả hash mà tài liệu nói dùng được trong `Animation.AnimationId` "để test cục bộ" — **không đủ** để điều khiển rig. Đo qua một lượt playback, sample `RightShoulder.Transform`: published `cheer` cho 26/30 transform khác nhau, published `toolslash` 11/30, còn **`KeyframeSequence` đăng ký runtime chỉ 1/30 — đứng yên**.

`track.IsPlaying == true`, `track.Length` đúng, không lỗi nào — nhân vật chỉ đơn giản là không nhúc nhích. Service này **deprecated** theo hướng `AnimationClipProvider` và không hỗ trợ `AnimationClip` mới; `RegisterActiveKeyframeSequence` trả `Usage error: RegisterActiveKeyframeSequence can only be used in Solo mode` nên cũng không chạy trong Play thường.

Dùng id đã publish — script `Animate` mặc định có các `StringValue` chứa `Animation` do Roblox sở hữu:

```luau
for _, sv in ipairs(character.Animate:GetChildren()) do
	if sv:IsA("StringValue") then
		local a = sv:FindFirstChildOfClass("Animation")
		if a then print(sv.Name, a.AnimationId) end
	end
end
-- toollunge  http://www.roblox.com/asset/?id=522638767
-- toolslash  http://www.roblox.com/asset/?id=522635514   (0.5 s)
```

Tự author vẫn được, nhưng phải **publish qua Animation Editor** để có `rbxassetid://` thật; bước đó chỉ làm bằng UI, không automate được. Dựng `KeyframeSequence` bằng code và để trong place cho dễ mở bằng editor, nhưng đừng trông nó phát.

### Phát, priority, marker

```luau
local function getAnimator(model: Model): Animator?
	local host = model:FindFirstChildOfClass("Humanoid") or model:FindFirstChildOfClass("AnimationController")
	if not host then return nil end
	return host:FindFirstChildOfClass("Animator") or Instance.new("Animator", host)
end
local anim = Instance.new("Animation")
anim.AnimationId = id                  -- phải thuộc sở hữu của experience/group
local track = getAnimator(model):LoadAnimation(anim)
```

Quái không có `Humanoid` thì dùng `AnimationController` + `Animator`. `track:Play(fadeTime, weight, speed)`, `track:Stop(fadeTime)`, `track:AdjustSpeed(s)`, `track:AdjustWeight(w, fade)`; `Looped`, `Ended`, `Stopped` để nối clip. Animation không thuộc quyền sở hữu của experience thì `LoadAnimation` không báo lỗi rõ, track im lặng không chạy. Resolve lại `Animator` **mỗi lần đánh** — nhân vật bị destroy và dựng lại khi respawn, track cache thành vô hiệu.

Animation mặc định (`toolnone`, `idle`, `walk`) nằm ở `Idle`, nên đòn đánh phải cao hơn mới không bị blend mất: đòn thường `Action`, đánh khi cầm tool đè `toolnone` thì `Action4`, biểu cảm nền `Core`. Marker (Animation Event trong editor) bám theo frame thật kể cả khi `AdjustSpeed` đổi tốc độ hoặc clip bị ngắt, thứ `task.wait(0.4)` không làm được: `track:GetMarkerReachedSignal("Hit"):Connect(function() damage(); burst() end)`. Tên marker sai là lỗi **im lặng** — handler không bao giờ chạy — nên đối chiếu tên (phân biệt hoa/thường) với editor và cảnh báo nếu clip kết thúc mà marker chưa bắn.

### Procedural: ghi `Transform` trong `PreSimulation`

Đường duy nhất để có animation tuỳ biến hoàn toàn mà không publish, đã verify đầu-cuối.

```luau
RunService.PreSimulation:Connect(function()
	if animator and animator.EvaluationThrottled then return end  -- pose có thể đã cũ
	joint.Transform = authoredPose                                -- TUYỆT ĐỐI, không nhân
end)
```

1. **Chỉ `PreSimulation`** — phase duy nhất chạy sau khi Animator evaluate và trước physics. Ghi trong `RenderStepped`, `PreRender` hay `PreAnimation` bị ghi đè mỗi frame và pose "biến mất".
2. **Bỏ qua khi `EvaluationThrottled`** — lần evaluate đó bị skip, pose cũ được giữ, cộng dồn lên sẽ trôi.
3. **Ghi tuyệt đối cho clip toàn thân** — nhân vào pose hiện tại chỉ đúng cho một *layer* (aim offset, look-at). Vì write của bạn là cuối cùng, nó đè luôn idle/walk trong suốt clip: không cần tắt `Animate`.

Đo trên rig R15, sample mỗi 40 ms trong 2.4 s: `Waist.Transform` 60/60, `UpperTorso.CFrame` 60/60, `Head.CFrame` 60/60. Theo clip: `sweep` cho `Waist` 41, `RightShoulder` 38, `Root` 37, `Head` 42, nhấc `Root` 0.08 studs; `slam` cho 54 / 51 / 34 / 8 và nhấc `Root` **3.40 studs** — chênh lệch đó là cách chứng minh hai clip thật sự khác nhau.

`Transform` không phải kênh replication: ghi ở client chỉ client đó thấy. Cần mọi người thấy thì ghi ở **server** (part thật dời, `CFrame` replicate bình thường), chấp nhận người chơi cục bộ thấy trễ một round-trip. Phải lọc theo class khi resolve khớp: một `KeyframeSequence` cùng character chứa `Pose` tên `RightShoulder`, `Waist` y hệt tên khớp, nên `if d.Name == "RightShoulder"` sẽ vớ phải `Pose` rồi lỗi `IsKinematic`.

```luau
local function resolveJoints(character)
	local map = {}
	for _, d in ipairs(character:GetDescendants()) do
		if d:IsA("AnimationConstraint") then map[d.Name] = d end
	end
	return map
end
```

### Hệ keyframe tối giản

Author 15 khớp bằng hàm per-frame thì không bảo trì nổi. Keyframe + nội suy; `CFrame:Lerp` slerp rotation và lerp position, đúng thứ một pose cần. Key là `{t =, ease =, pose = {joint = CFrame}}`; tìm cặp key bao quanh `t`, tính `alpha = (t - a.t) / (b.t - a.t)`, cho qua hàm ease của key đích, rồi `out[name] = (a.pose[name] or CFrame.new()):Lerp(b.pose[name], alpha)`. `PoseEasingStyle` không áp dụng cho đường này; vào đòn đánh bằng `outQuint` (khởi đầu nhanh, dừng gắt), vào cú đập bằng `inCubic` (rơi tăng tốc), và easing của một keyframe điều khiển nội suy **vào** keyframe đó.

```luau
local function smooth(t) return t * t * (3 - 2 * t) end
local function outQuint(t) return 1 - (1 - t) ^ 5 end
local function inCubic(t) return t ^ 3 end
local function outBack(t) local c, p = 1.70158, t - 1
	return 1 + (c + 1) * p * p * p + c * p * p end   -- overshoot, hợp cho cú tiếp đất
```

### Đòn đánh toàn thân

| Thời điểm | Nhịp | Easing | Cái gì động |
|---|---|---|---|
| 0.00 | rest | `Linear` | mọi khớp ở identity |
| 0.10 | anticipation | `Cubic InOut` | trọng tâm dồn **về sau**, counter-rotation nhỏ |
| 0.26 | windup peak | `Cubic Out` | torso xoắn hết, vũ khí cao và ra sau |
| 0.40 | strike | `CubicV2 Out` | bung xoắn, vũ khí quét qua |
| 0.48 | impact hold | `Linear` | khựng ngắn ở độ duỗi tối đa |
| 0.68 | follow-through | `Cubic Out` | quán tính vượt qua, overshoot nhẹ |
| 0.86 | recovery | `Cubic InOut` | thu về |
| 1.05 | rest | `Cubic InOut` | giống 0.00 để loop/blend được |

1. **Hông dẫn, torso theo, tay quất sau cùng** — `Waist` biên độ lớn nhất (±55-65° cho cú quét), vai trễ vài frame. Chỉ xoay vai trông như con rối.
2. **Giữ chân trụ** — counter-rotate `LeftHip`/`RightHip` ngược `Waist`, rồi khử phần dư trên `LeftAnkle`/`RightAnkle`.
3. **Nạp gối** — `LeftKnee`/`RightKnee` gập 15-40° ở windup rồi duỗi xuyên cú đánh; đánh bằng chân thẳng thì không có lực.
4. **`Root` translation là kênh dọc của cơ thể** — `Root` nối `HumanoidRootPart` với `LowerTorso`, dịch nó nhấc cả thân hình mà không đổi vị trí thật, nên crouch (Y âm) và nhảy (Y dương) luôn tiếp đất đúng, không physics. Clip `slam` đi qua `-1.20 -> +0.45 -> +3.40 -> +2.10 -> -1.00 -> -1.60 -> 0` studs.
5. **Sáu nhịp, không phải hai** — anticipation bắt buộc; strike là đoạn nhanh nhất (~0.14 s từ windup peak tới strike); keyframe đầu và cuối giống nhau nếu clip có thể loop. Xoay `Neck` ngược `Waist` để nhân vật vẫn nhìn mục tiêu trong lúc torso lấy đà.

### Gắn vào Tool

`StarterPack/<Tool>` chứa `Handle` (MeshPart), `SwingAnimation` (`Animation`), `SwingClient` (`LocalScript`); nội dung được clone vào `Backpack` mỗi lần spawn. Engine weld tool sao cho điểm cục bộ `g` của handle nằm ở grip attachment của tay, nên muốn nắm ở vị trí `f` dọc trục dài: `offset = handle.Size.Y * (f - 0.5)` (âm khi nắm dưới tâm), rồi `tool.Grip = CFrame.new(0, offset, 0) * CFrame.Angles(...)` (rotation tuỳ chọn).

Phát cú chém ở **client** trong `Tool.Activated` — phản hồi tức thì, và animation của nhân vật local tự replicate cho người khác. Gửi `RemoteEvent` cho sát thương; không bao giờ gửi "tôi trúng X". Equip bằng automation: `humanoid:EquipTool(tool)` ở server thì được; giả lập phím số thì không — phím slot tool bind vào CoreGUI và virtual input bị từ chối (`key is permanently bound to a CoreGUI core action`).

```luau
tool.Activated:Connect(function()
	if os.clock() - lastAttack < COOLDOWN then return end
	lastAttack = os.clock()
	playSwing()                                  -- resolve Animator lại ở đây
	fireSwingVFX()
	task.delay(HIT_AT, function() remote:FireServer() end)
end)
```

### `IKControl`

Bù động lên animation đang chạy (tay bám vũ khí, chân bám dốc, đầu nhìn mục tiêu), parent vào `Humanoid`: `Type` (`Enum.IKControlType`: `Position`, `Rotation`, `Transform`, `LookAt`), `ChainRoot` (`BasePart` gốc chuỗi, ví dụ `UpperTorso`), `EndEffector` (`Attachment`/`BasePart` cuối chuỗi), `Target` (`Instance` để bám vào), `Weight` (0-1, pha trộn với clip), `SmoothTime` (giây, làm mượt việc đuổi target), `Pole` (định hướng khuỷu/đầu gối), `Offset` (`CFrame` lệch so với `Target`).

Nó chạy **sau** Animator nên bù lên clip chứ không thay clip; `Weight` cho chạy 0 -> 1 trong ~0.2 s; `ChainRoot` sai một bậc sẽ cong cả cột sống thay vì chỉ cong khuỷu. Cảm giác: **hit stop** bằng `track:AdjustSpeed(0.05)` rồi trả về 1 sau 0.05-0.09 s (đòn nhẹ) hoặc 0.12 s (đòn nặng); **spring** (`force = (target - pos) * k - vel * d`, `k` 80-200, `d` ~ `2*sqrt(k)`, kẹp `dt = math.min(dt, 1/30)`) cho thứ đuổi theo mục tiêu liên tục như camera, đầu quái nhìn người chơi, thanh UI.

## VFX

### `Trail`

Cần **hai `Attachment`** và chỉ vẽ ribbon giữa các vị trí chúng đã đi qua trong `Lifetime`. Khoảng cách giữa hai attachment **chính là bề rộng ribbon**: hai đầu cây gậy 7 studs cho một bức tường sáng 7 studs nuốt cả màn hình; cách nhau ~2 studs gần mũi cho cung sáng gọn bám đúng đường chém (`arcTip.Position = Vector3.new(0, half, 0)`, `arcBase.Position = Vector3.new(0, half - 2.2, 0)`). Trail chỉ vẽ khi attachment **di chuyển**, nên bản thân nó đã là swing-only; vẫn đặt `Enabled = false` lúc đầu để vũ khí đứng yên không để lại vệt rác, rồi bật trong cửa sổ chém. Texture của trail bị **nhân** với `Trail.Color`, nên decal slash xanh tô vàng sẽ ra bùn — palette vàng/đỏ thẫm thì ribbon rỗng + `ColorSequence` tốt hơn một texture lệch tông.

| Thuộc tính | Giá trị đọc ra như một nhát chém |
|---|---|
| `Texture` | `""` — ribbon đặc, không phụ thuộc asset |
| `Lifetime` / `MinLength` | 0.30 / 0.05 |
| `FaceCamera` / `LightEmission` / `LightInfluence` | `true` / 0.9 / 0 |
| `Color` | `ColorSequence` 4 key: `255,253,240` (lõi trắng nóng) -> `255,226,128` @0.30 -> `245,150,40` @0.62 -> `150,58,12` @1.00 (nguội dần) |
| `Transparency` | `NumberSequence` 0.0 -> 0.25 @0.45 -> 1.0, không bao giờ cắt phựt |
| `WidthScale` | `NumberSequence` 1.0 -> 0.55 @0.60 -> 0.05 |

### `ParticleEmitter` — phát từ đâu

Parent quyết định vùng phát: một `Part`/`MeshPart` dài với `Shape = Sphere` phát ra **toàn bộ bounding volume** (tia lửa rải khắp vũ khí), còn `Attachment` phát đúng **một điểm** — thứ cần cho tia lửa ở mũi. `Rate = 0` + `:Emit(n)` là pattern đúng cho cú chém: vài đợt burst trong cửa sổ thay vì stream liên tục; hiệu ứng liên tục thì ngược lại, `Rate > 0` + `Enabled = true`. Mọi effect phải **ramp**, không bật/tắt: `Transparency` là `NumberSequence` kiểu `1 -> 0.1 -> 1`, `Size` phình hoặc teo dọc lifetime, `Color` đi từ lõi nóng sang rìa nguội, `LightEmission > 0` chỉ cho thứ thật sự phát sáng.

```luau
sparks.Parent = arcTip          -- Attachment ở mũi, KHÔNG phải Handle
sparks.Shape = Enum.ParticleEmitterShape.Sphere
sparks.Rate = 0                 -- 0 = chỉ bắn tay bằng :Emit(n)
sparks:Emit(20)
task.delay(0.16, function() sparks:Emit(12) end)
task.delay(0.32, function() sparks:Emit(8) end)
```

### `Beam`, `Highlight`, và quy mô impact

**Beam** nối `Attachment0` và `Attachment1`: tia sét dùng `Segments` cao (10+), `CurveSize0`/`CurveSize1`, đổi `CurveSize` ngẫu nhiên mỗi vài frame để nó "nhảy"; chỉnh `Width0`/`Width1`, `LightEmission`, `FaceCamera = true`. **Highlight**: `Adornee`, `FillColor`/`FillTransparency`, `OutlineColor`/`OutlineTransparency`, `DepthMode` (`AlwaysOnTop` = thấy xuyên tường, `Occluded` = bị che thì mất); parent vào `PlayerGui` thì chỉ client đó thấy, đúng cho highlight chọn mục tiêu.

Impact quá sáng bắn **mỗi** cú trúng, nên nó không nháy một lần mà nhấp nháy suốt trận. Số đo từ một case làm trắng cả viewport:

| Thành phần | Quá tay | Dùng |
|---|---|---|
| `Shockwave` size tối đa | 12 studs | 6.5 studs |
| `Shockwave.Transparency` | 0.25 | 0.55 |
| `PointLight.Brightness` | 9 | 3 |
| `PointLight.Range` | 16 | 9 |
| Size hạt burst | 1.6 | ~1.15 |
| `:Emit(n)` burst | 34 | 24-34 sau khi đã tiết chế size |

Ball `Neon` + `PointLight` là **hai** nguồn sáng chồng nhau — chọn một làm chính, giữ cái kia yếu. Cú chém nhiều lớp thì xếp: **arc** (`Trail`, bật trong cửa sổ chém ~0.50 s rồi tắt), **tip sparks** (burst `:Emit()` tại 0.00 / 0.16 / 0.32 s từ `Attachment` ở mũi), **impact** (chỉ khi trúng: burst + shockwave `Neon` nhỏ tại điểm chạm, destroy khi tween xong). Giữ template trong `ReplicatedStorage/ImpactVFX` (emitter `Burst` + part `Shockwave`) và clone mỗi lần trúng: một template, nhiều hiệu ứng, không tốn chi phí dựng mỗi hit.

### Recipe

> **Code chạy được của các recipe dưới đây nằm ở `templates/VFXKit.lua`** (`VFX.Explosion/Impact/Lightning/Slash/Ring/Shards/Burst/Shake/ScreenFlash/HitStop`). Các đoạn code ở đây là mô tả pha và số đo; helper `lightFlash/ball/tween/ringWave/shake` = `VFX.LightFlash/Ball/Tween/Ring/Shake`. Đừng viết lại — `require` VFXKit.

Mọi recipe cùng khung: **instant** (flash/ánh sáng/screen) -> **body** (Part + tween hoặc một driver `RenderStepped` theo `t`) -> **detail** (emitter) -> **feel** (shake, sound trễ) -> **cleanup**. Thời gian điều khiển tất cả bằng `t = os.clock() - t0` trong một vòng lặp, không xâu chuỗi `task.wait(0.1)`. Một tham số `Scale`/`Radius` nhân toàn bộ để cùng recipe ra bản nhỏ và bản khổng lồ. Ease chuyển động: nở ra là ease-out, rơi là ease-in, đổi màu theo thời gian, thêm ngẫu nhiên (góc, size, delay, pitch) để lần lặp không giống hệt.

**Nổ (lựu đạn, thùng, mìn, đòn boss)** — flash 0-0.1 -> fireball 0-0.5 -> vòng sóng 0-0.7 -> tia lửa và khói 0-3:

```luau
local s = opts.Scale or 1
local up = Vector3.new(0, 2 * s, 0)
lightFlash(pos + up, Color3.fromRGB(255, 170, 80), 8, 60, 0.5)
local fb = ball(pos + up, 1, Color3.fromRGB(255, 240, 200))       -- Neon Ball
tween(fb, 0.35, { Size = Vector3.one * 14 * s }, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
task.delay(0.1, function() tween(fb, 0.5, { Color = Color3.fromRGB(255, 110, 30), Transparency = 1 }) end)
Debris:AddItem(fb, 1.2)
ringWave(pos, 24 * s, 0.7, { Width = 2 * s, Height = 1.2 * s })    -- 28-36 mảnh, nở ease-out
sparks:Emit(60)   -- Lifetime 0.5-1.3, Speed 40-90*s, Acceleration (0,-60,0), Drag 1
smoke:Emit(14)    -- Size 4*s -> 14*s, Lifetime 2-3.5, Transparency 0.3 -> 1
shake(1.2 * s * math.clamp(1 - camDistance(pos) / (60 * s), 0, 1), 0.5)
```

**Bom hạt nhân** — `Radius` mặc định 120 studs, toàn cảnh rộng ~2.5R, `DURATION = 30`, `RING_TIME = 5`, tốc độ âm thanh 700 studs/s. Khoảng 50 Part và **một** driver `RenderStepped` tính tất cả từ `t`, không phải một đống tween phải đồng bộ. `near = clamp(1 - dist / (R * 12), 0, 1)` để hiệu ứng màn hình mạnh khi đứng gần; damage/knockback (`ApplyImpulse`, phá part yếu) làm ở **server** theo khoảng cách, không bao giờ ở client.

| Lớp | Số đo |
|---|---|
| Fireball | bán kính `R * 2 * ease(t / 1.6)`, trôi lên `R * 0.5` trong 6 s, mờ từ 2.5 s tới 7 s |
| Dome shockwave | bán kính `R * 5 * ease(t / 3.5)`, `Transparency` 0.7 -> 1.0 |
| Ground ring | bán kính `R * 2.5` trong 5 s, `Segments = 36`, Width `8k`, Height `5k` |
| Stem | cylinder (trục là X), dài từ mặt đất tới cap, rộng `R * 0.55` |
| Cap | 16 puff quanh tâm, bán kính `R * 0.85-1.25`, nâng `R * 4.5` trong 10 s |
| Screen | `screenFlash` peak `0.3 + 0.7 * near`, `bloomPulse` `1 + 2 * near` |
| Sound / shake | sound trễ `dist / 700` giây; shake tới cùng lúc với sóng xung kích |
| Emitter | khói `Rate 35` tới 14 s thì `Rate = 0`; embers `Emit(150)`; dust bám vòng nở mỗi 0.12 s |

**Sét** — sinh `nSeg = 12` điểm dọc `a -> b`, mỗi điểm lệch `jag * sin(pi * i / nSeg)` theo hai trục vuông góc với `fwd` (taper giữ hai đầu bám đúng), mỗi đoạn là Part `Size = (thick, thick, d)` với `CFrame.lookAt` trung điểm. Lặp `flickers = 5` lần trong `Duration = 0.35`, **dựng lại đường mới mỗi lần** rồi destroy — đó là thứ làm nó "sống". Kèm `lightFlash` và tiếng sấm.

**Vòng phép** — vòng ngoài 32 đoạn bán kính `radius` dày 0.35, vòng trong 32 đoạn `radius * 0.85` dày 0.2, sao 5 cánh dày 0.25. Đặt `Model.WorldPivot` về tâm **trước**, rồi `ScaleTo` mở ra trong 0.5 s và `PivotTo` xoay `t * 0.8` rad/s — model có `WorldPivot` riêng vẫn xoay tại chỗ. 0.8 s cuối: `Rate = 0` và tăng `Transparency` từng part. **Dissolve** thì lấy `GetBoundingBox`, đặt `delay = ((part.Y - bottom) / size.Y) * duration * 0.6` để hiệu ứng quét từ dưới lên, mỗi part `Emit(3)` rồi tween `Transparency = 1` trong `duration * 0.4`.

Preset emitter cho chủ đề khác (`Rate` + `Enabled` cho liên tục, `:Emit(n)` cho burst). Mưa/tuyết: **một** emitter đi theo camera, không phải một emitter mỗi hạt; tắt (`Enabled = false`) emitter ở xa camera.

| Chủ đề | Texture | Thuộc tính then chốt |
|---|---|---|
| Lửa | Fire | Lifetime 0.6-1.1; Speed 3-6; Acceleration (0,8,0); Spread (10,10); Size 1.5 -> 0; vàng -> cam -> đỏ; Rate 40 |
| Khói / hơi | Smoke | Size nhỏ -> lớn; Transparency 0.3 -> 1; Speed 2-8; Drag 2; Acceleration (0,4,0) |
| Than hồng | Soft | Size 0.2-0.4; Lifetime 3-6; Speed 2-6; Acceleration (0,3,0); Rate 8 |
| Tia lửa | Soft | Lifetime 0.3-0.8; Speed 30-80; Acceleration (0,-80,0); Orientation `VelocityParallel` |
| Bụi | Smoke | nâu nhạt; Lifetime 1-2; Speed 5-15; Spread (60,60); Transparency 0.4 -> 1 |
| Aura phép | Soft | `Shape` Sphere + `ShapeInOut` `Inward` (hút vào); Rate 30; Lifetime 1 |
| Hồi máu / buff | Soft | bay lên: Acceleration (0,6,0); Speed 1-3; xanh/vàng ấm; Rate 20; cộng `ringWave` |
| Mưa | Soft | host là Part dẹt trên camera; `Shape` Box rộng; `EmissionDirection` `Bottom`; Speed 120; Lifetime 1.2; Size 0.1; Rate 500 |
| Tuyết | Soft | Rate 150; Lifetime 8; Speed 4-8; Acceleration (0,-2,0); Drag 1; RotSpeed -60..60 |
| Nước bắn | Soft | trắng-xanh; Speed 20-40; Acceleration (0,-90,0); Lifetime 0.6-1; Spread (40,40) |
| Portal / hố đen | Soft | `Shape` Sphere + `Inward`; thêm vòng part xoay và một ball tối |

### Chữ CJK như hiệu ứng

`TextLabel` **có** render chữ Hán — verify với `如意金箍棒` dạng cột dọc: `TextBounds` trả `44.0 x 192.0` cho năm glyph ở `TextSize = 64`, ảnh chụp ra glyph vàng sạch có viền tối. Dựng `BillboardGui` trên một Part vô hình weld sau lưng nhân vật (`anchor.CFrame = root.CFrame * CFrame.new(0, 1.6, 4.2)`; `+Z` cục bộ là phía sau), part đó `Size = 0.2`, `Transparency = 1`, `Massless = true`, `CanCollide/CanQuery/CanTouch/CastShadow = false`. Dùng `\n` để thành cột dọc (cột thư pháp đọc tốt hơn hẳn chuỗi ngang); dùng `Font` enum, **không** dùng `FontFace` — `Enum.Font.GothamBlack` resolve được glyph, một family `FontFace` cụ thể có thể không có CJK; đừng bật `TextScaled` với cột nhiều dòng vì nó đánh nhau với tỉ lệ khung; giữ `AlwaysOnTop = false` để chữ nằm trong không gian thế giới. Fade bằng cách đặt `TextTransparency` ~0 rồi tween lên 1 trong lúc trượt `Position` lên trên; bật/tắt phựt đọc như lỗi.

```luau
gui.Size = UDim2.fromScale(6, 11); gui.LightInfluence = 0; gui.MaxDistance = 120
label.Font = Enum.Font.GothamBlack
label.Text = "\u{5982}\n\u{610F}\n\u{91D1}\n\u{7B8D}\n\u{68D2}"   -- một glyph mỗi dòng = cột
label.TextColor3 = Color3.fromRGB(255, 224, 130)
label.TextStrokeColor3 = Color3.fromRGB(120, 44, 10)
label.TextScaled = false; label.TextSize = 42; label.TextTransparency = 1   -- bắt đầu ẩn
```

Mọi instance spawn ra đều phải có tuổi thọ: `Debris:AddItem(holder, 2)` hoặc `tween.Completed:Once(function() wave:Destroy() end)` — emitter và part rò rỉ là bug memory phổ biến nhất. Hiệu ứng thuần thẩm mỹ chạy ở **client**; chỉ hiệu ứng ảnh hưởng gameplay mới replicate.

## Cutscenes

Camera luôn là cục bộ, nên cutscene **chạy ở client**; server chỉ nói "phát cutscene X cho player P (hoặc tất cả)". Trả lời năm câu trước khi code: ai thấy; camera đặt ở đâu (không bao giờ gõ toạ độ thế giới bằng cách đoán); cái gì kích hoạt; người chơi và thế giới ra sao trong lúc đó (khoá điều khiển, server dừng damage/AI, ẩn HUD hoặc letterbox); kết thúc thế nào và hỏng thì sao — camera và điều khiển phải khôi phục trên **mọi** đường thoát: xong, skip, chết, script lỗi, người chơi rời đi. Cấu trúc: `Cutscene` (ModuleScript, ReplicatedStorage — runner: shots, lock, restore, skip), `CutsceneLibrary` (ModuleScript — `name -> function(ctx) -> shots`), `CutsceneRemote` (RemoteEvent — server -> client `(name, ctx)`), `CutsceneClient` (LocalScript, StarterPlayerScripts), trigger (Script, ServerScriptService hoặc trong trigger part), và tuỳ chọn `Cutscenes/<Name>/Shot01...` (Folder of Parts, Workspace — camera đặt tay). `LocalScript` đặt trong `Workspace` hay `ServerScriptService` sẽ không chạy, và `Script` ở server không điều khiển được camera. Shot tính theo chủ thể dùng bounding box + FOV nên cây 3 studs và đám mây 300 studs đều vừa khung: `dist = radius * margin / math.sin(fov / 2)`.

| Field | Ý nghĩa | Thường dùng |
|---|---|---|
| `Yaw` | độ quanh chủ thể; 0 = trước mặt nó, 90 = bên trái, 180 = phía sau | `0`, `{-40, 40}` orbit |
| `Pitch` | độ trên đường chân trời; âm = nhìn từ dưới lên | `10`, `-15` (góc anh hùng) |
| `Margin` | khoảng trống quanh chủ thể; 1 = chật khung | `{2.2, 1.2}` push-in |
| `FOV` | góc nhìn, độ | `70` bình thường, `40` căng/tele |
| `LookOffset` | lệch world của điểm nhìn so với tâm | `Vector3.new(0, 4, 0)` nhắm vào đầu |

Mỗi field nhận số hoặc `{from, to}` để animate trong suốt shot. Shot dựng sẵn theo ý đồ: wide `Margin = 4, Pitch = 20, Yaw = 30`; push-in `Margin = {2.5, 1.2}`; pull-back `Margin = {1, 3.5}`; orbit `Yaw = {-50, 50}`; góc anh hùng `Pitch = -15, Margin = 1.4`; nhìn xuống vật nhỏ `Pitch = 55, Margin = 1.5`; crane `Pitch = {5, 50}, Margin = {1.5, 3}`; dutch thêm `Roll = 8`. Vòng chạy một shot suy ra mọi thứ từ `alpha` đã ease, không tween từng property: `camera.CameraType = Enum.CameraType.Scriptable`, rồi mỗi frame tính `a = clamp(elapsed / shot.Duration, 0, 1)`, `eased = TweenService:GetValue(a, shot.Ease or Enum.EasingStyle.Sine, shot.Dir or Enum.EasingDirection.InOut)`, `camera.CFrame = shot.Cam(eased)`; `Handheld` 0.1-0.3 độ cộng bằng `math.noise`; `FOV` nội suy theo `eased`; cue bắn một lần khi `elapsed >= c.At` và bọc `pcall` để cue lỗi không nhốt người chơi.

- **Khoá điều khiển:** `require(player.PlayerScripts.PlayerModule):GetControls():Disable()`, nhớ `:Enable()` khi restore. Skip bằng `ContextActionService:BindAction` với `Enum.KeyCode.Return` và `Enum.KeyCode.ButtonX`.
- **Cue giữ nhịp VFX/âm thanh:** `{ At = 0.3, Fn = function() Kit.play("NukeBlast", pos) end }` để camera đã yên rồi hiệu ứng mới nổ. Nếu độ dài shot phụ thuộc animation, đọc `track.Length` rồi đặt `Duration`.
- **Skip không được làm hỏng gameplay:** thứ quan trọng (spawn boss) phải chạy ở server độc lập với camera; cutscene chỉ là trình diễn.
- **An toàn:** server đặt attribute `InCutscene` để tạm dừng AI/damage, nếu không người chơi chết trong lúc xem. Với `StreamingEnabled`, gọi `player:RequestStreamAroundAsync(pos)` trước, hoặc kiểm `subject:IsDescendantOf(workspace)`. Camera xuyên tường thì raycast từ tâm chủ thể tới vị trí camera bằng `workspace:Raycast` rồi kéo vào trước điểm chạm.

## Kiểm chứng

Cú chém dài ~1.05 s, còn một vòng round-trip tool (gửi click, chờ, chụp, trả về) mất **vài giây**. Lúc ảnh về thì animation đã xong, trail đã tắt, ảnh chỉ thấy pose idle — và kết luận "animation không chạy" được rút ra từ một phép đo không bao giờ có thể phát hiện nó. Đúng chuỗi này đã xảy ra: ba lần query đều báo không có track, trong khi animation vẫn chạy đúng. Nếu buộc phải chụp, bắn trigger và capture như **hai lệnh song song trong cùng một lượt**; đó vẫn là một cuộc đua, không phải bảo đảm. Cách đúng là ghi trạng thái vào attribute rồi đọc sau — attribute tồn tại nên không bị áp lực thời gian:

| Attribute | Chứng minh |
|---|---|
| `AnimReady` | `KeyframeSequence` đăng ký thành công |
| `AnimId` | id đang thực sự dùng — đổi giá trị là registration runtime đã chạy |
| `SwingCount` | click có tới handler hay không |
| `LastAnimOk` | `LoadAnimation` thành công |
| `TrackIsPlaying` | track đã start, không chỉ load |
| `TrackLength` | đúng clip (cú chém ~1.05, không phải 0) |
| `LastError` / `LastBlocked` | text lỗi thật; input có bị cooldown nuốt không |

**Cần nhưng chưa đủ:** những attribute này theo dõi *track*, không theo dõi *rig*. Đã có case mọi thứ xanh — `LastAnimOk = true`, `TrackIsPlaying = true`, `TrackLength = 1.05`, `LastError` rỗng — mà rig **đứng yên hoàn toàn**. Luôn đo thêm khớp, và nhớ hai cái bẫy trong chính phép đo: dùng `Transform` (CFrame) chứ **không** dùng `Position`, vì pose khớp chủ yếu là rotation nên position gần như không đổi và làm animation đang chạy trông như đứng yên; và lọc theo class khi tìm khớp, vì `KeyframeSequence` chứa `Pose` trùng tên.

```luau
local function fingerprint(joint)
	local t = joint.Transform
	return string.format("%.3f,%.3f,%.3f|%.3f,%.3f,%.3f",
		t.RightVector.X, t.RightVector.Y, t.RightVector.Z,
		t.UpVector.X, t.UpVector.Y, t.UpVector.Z)
end
local uniq = {}
for i = 1, 400 do
	uniq[fingerprint(shoulder)] = true
	task.wait(0.05)            -- cửa sổ 20 s, đủ chứa vài cú chém
end
local n = 0
for _ in pairs(uniq) do n += 1 end
tool:SetAttribute("SwingProbe", "distinct=" .. n .. "/400")
```

| Nguồn | `RightShoulder` distinct | `Waist` distinct |
|---|---|---|
| published `cheer` | 26/30 | 30/30 |
| published `toolslash` | 11/30 | 1/30 |
| `KeyframeSequence` runtime | **1/30** | **1/30** |
| **tool đang chạy đúng (id published)** | **73/400** | **181/400** |

`1` là đứng yên; hàng chục hoặc hàng trăm là chạy đúng. **Thứ tự chẩn đoán:** (1) khớp có nhích không — phép đo trên, chạy đầu tiên vì đây là thứ duy nhất kết luận được; (2) id đã publish chưa — hash runtime không bao giờ điều khiển rig; (3) trigger có bắn — `SwingCount`/`LastBlocked`, nếu 0 thì input không tới nơi; (4) `LoadAnimation` có thành công — `LastAnimOk`/`LastError`; (5) priority đủ cao chưa — mặc định ở `Idle`, đòn chém cần `Action4`; (6) effect có bật — đọc thẳng `Trail.Enabled` / parent của emitter; (7) chỉ sau đó mới tới ảnh chụp. Bước 1-6 mỗi bước một lệnh và đều kết luận được; bước 7 là một cuộc đua.

Kiểm phần sát thương **riêng**, ở server nơi quyết định thật sự được đưa ra: `th.MaxHealth - th.Health` cho tổng damage đã áp. Một dòng log trong hit handler (`[StaffCombat] <player> hit N target(s)`) cho dấu vết độc lập với hình ảnh — và để ý nó bắn **nhiều hơn** dự kiến: hitbox diện rộng sẽ vớ cả đồng đội hoặc người đứng cạnh mục tiêu.

## Bẫy

- **Track báo đang phát mà nhân vật đứng yên** — `KeyframeSequence` đăng ký runtime không bao giờ được áp; `IsPlaying` và `Length` vẫn đúng, không lỗi. Sửa: dùng id đã publish, hoặc ghi `Transform` trong `PreSimulation`.
- **Animation không phát, không lỗi** — id đăng ký ở Edit mode, hash không sống qua playtest. Sửa: publish thật rồi dùng `rbxassetid://`.
- **`LoadAnimation requires the asset id to not be empty`** — `AnimationId` rỗng. Sửa: gán id đã publish.
- **Animation phát nhưng bị đè** — priority thấp hơn `toolnone`/`idle` đang ở `Idle`. Sửa: `track.Priority = Enum.AnimationPriority.Action4`.
- **`X is not a valid member of Enum.PoseEasingStyle`** — đoán tên easing. Sửa: chỉ dùng sáu giá trị ở bảng enum.
- **Chém được một lần rồi thôi** — track cache từ nhân vật đã chết sau respawn. Sửa: resolve lại `Animator` mỗi lần chém.
- **Pose không tác dụng dù đã publish** — `Pose.Name` không khớp tên khớp. Sửa: query tên `AnimationConstraint` trên rig thật.
- **Chém mà trông không có lực** — thiếu nhịp anticipation. Sửa: thêm keyframe counter-rotation ở 0.10, giữ strike là đoạn nhanh nhất (~0.14 s).
- **Ghi `Transform` xong pose biến mất mỗi frame** — ghi trong `RenderStepped`/`PreRender`/`PreAnimation`, bị Animator ghi đè. Sửa: ghi trong `RunService.PreSimulation`.
- **Pose cộng dồn, trôi dần** — nhân vào pose đang giữ, hoặc ghi khi `EvaluationThrottled`. Sửa: ghi tuyệt đối và `if animator.EvaluationThrottled then return end`.
- **Gán `C0`/`C1` báo lỗi** — khớp là `AnimationConstraint`, alias read-only. Sửa: ghi `Transform`.
- **`IsKinematic is not a valid member of Pose`** — vòng lặp bắt phải `Pose` chứ không phải khớp. Sửa: `d:IsA("AnimationConstraint")`.
- **Chỉ người chơi cục bộ thấy pose** — `Transform` không replicate. Sửa: ghi ở server (trễ một round-trip) hoặc dùng animation đã publish.
- **Nhân vật giãn dài thay vì hạ thấp** — dời `HumanoidRootPart` thay vì dịch `Root.Transform`. Sửa: translate `Root`.
- **Clip chạy một lần rồi đứng** — connection không disconnect, khớp còn dính pose cuối. Sửa: reset mọi khớp về `CFrame.new()` khi kết thúc.
- **Toàn màn hình trắng** — shockwave Neon quá lớn + `PointLight` quá sáng, lặp mỗi cú trúng. Sửa: 6.5 studs, `Transparency` 0.55, `Brightness` 3, `Range` 9.
- **Effect vô hình** — hai attachment quá sát nhau, hoặc trail bị disable và không bao giờ bật lại. Sửa: kiểm span (~2 studs) và kiểm cờ toggle.
- **Tia lửa rải khắp vũ khí** — emitter parent vào Part dài với `Shape = Sphere`. Sửa: parent vào `Attachment` ở mũi.
- **Effect "bụp" hiện rồi biến** — transparency bật/tắt cứng. Sửa: `NumberSequence` ramp `1 -> 0.1 -> 1`.
- **Màu bùn** — texture bị nhân với `Color` lệch tông. Sửa: trail texture rỗng + `ColorSequence`.
- **Effect trôi khỏi vũ khí** — emitter/part parent vào workspace. Sửa: parent vào part hoặc `Attachment`.
- **Chữ CJK ra ô vuông** — `FontFace` family không có glyph CJK, hoặc `TextScaled` với cột nhiều dòng. Sửa: `Enum.Font.GothamBlack`, `TextScaled = false`, đặt `TextSize`.
- **Marker không bao giờ chạy** — tên marker sai (kể cả hoa/thường), hoàn toàn im lặng. Sửa: đối chiếu với Animation Editor và log cảnh báo khi clip kết thúc mà marker chưa bắn.
- **Người chơi kẹt không di chuyển sau cutscene** — một đường thoát (chết, skip, lỗi) không restore camera và controls. Sửa: restore trong một hàm duy nhất gọi từ mọi nhánh, kể cả `humanoid.Died`.
- **Camera cutscene trôi dần** — cộng dồn offset lên `camera.CFrame` hiện tại mỗi frame. Sửa: cộng lên CFrame gốc đã lưu.
- **Người chơi chết trong lúc xem cutscene** — server vẫn chạy AI/damage. Sửa: attribute `InCutscene` để tạm dừng trước khi fire remote.
- **Sound im lặng không báo gì** — key thiếu hoặc id còn `rbxassetid://0`; `Sound:Play()` không nói gì. Sửa: một bảng id duy nhất, một hàm phát duy nhất, warn một lần khi key thiếu/placeholder.
- **Tiếng đầu tiên bị trễ** — asset chưa load. Sửa: `ContentProvider:PreloadAsync({sound})` ở client trước khi gameplay bắt đầu.
