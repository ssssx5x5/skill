# Vòng chất lượng: chụp → chấm bằng số → sửa → chụp lại

> Khi nào dùng: mọi việc tạo model/VFX/cutscene. Mục tiêu: "đẹp" không còn là cảm giác mà là danh sách điều kiện kiểm được. Tối đa **3 vòng**; vòng nào cũng phải đổi đúng **một họ** lỗi.

## 1. Vòng lặp

1. **Chụp** (`screen_capture` nếu có Studio MCP): model = trước / bên / 3/4 trên / sau, camera ~2× chiều dài; VFX = chụp **trong lúc** chạy ở 3 mốc `t` (đầu, đỉnh, tàn), không chụp sau khi hết.
2. **Đo** bằng `ModelKit.Audit(model, spec)` (part, bbox, part mỏng, trùng, CanCollide) và bảng ngân sách dưới đây.
3. **Chấm** theo rubric mục 2 — mỗi dòng đạt/không, có bằng chứng (số hoặc ảnh).
4. **Sửa** đúng dòng trượt nặng nhất; ghi lại đã đổi gì.
5. **Chụp lại** cùng góc/mốc để so; dừng khi đạt hoặc hết 3 vòng — rồi báo rõ dòng nào còn trượt.

Không có Studio sống: bỏ bước chụp, chạy `ModelKit.Audit`/`GeoKit.Stats`/test toán thuần, và **ghi rõ "chưa nhìn bằng mắt"** trong báo cáo.

## 2. Rubric (mỗi dòng 0/1)

**Model**
| # | Tiêu chí | Cách kiểm |
|---|---|---|
| M1 | Tỉ lệ đúng spec (±25%) | `Audit` + bbox so spec theo studs |
| M2 | Silhouette đọc được ở thumbnail ~64 px | chụp xa 50+ studs, thu nhỏ |
| M3 | Không có khối hộp làm thân chính | đếm part `Block` > 30% thể tích |
| M4 | Bất đối xứng có chủ đích (lệch size/góc/màu 5–10%) | so cặp part lặp |
| M5 | ≥ 3 lớp chi tiết: khối lớn / vừa / nhỏ | liệt kê theo tên part |
| M6 | Value contrast giữa các phần | chụp grayscale |
| M7 | Trong ngân sách part/tam giác của class | bảng assets.md |
| M8 | Mặt sau/đáy không bỏ trống | chụp góc sau |

**VFX**
| # | Tiêu chí | Cách kiểm |
|---|---|---|
| V1 | ≥ 4 lớp: sáng, hình khối, hạt/mảnh, màn hình/camera, (âm thanh) | đếm theo recipe |
| V2 | Có 3 pha: chuẩn bị → va chạm → dư chấn, với `t` cụ thể | bảng thời gian |
| V3 | Màu đổi theo thời gian (trắng → cam → đỏ → xám) | đọc `Color` sequence |
| V4 | Tỉ lệ studs hợp lý (impact 4–8; nổ lớn hàng chục; cataclysm hàng trăm) | in kích thước |
| V5 | Không làm trắng/che hết viewport | chụp ở đỉnh hiệu ứng |
| V6 | Dọn sạch: instance về mức ban đầu sau T giây | `VFX.SelfTest()` |
| V7 | Có Quality scaling + trần part | `VFX.Quality`, `MAX_ACTIVE_PARTS` |
| V8 | Ngẫu nhiên hoá (góc, size, delay) để lặp lại không giống hệt | đọc code |

**Code**
| # | Tiêu chí | Cách kiểm |
|---|---|---|
| C1 | `python scripts/lint_luau.py <path>` không ERROR | chạy |
| C2 | `luau-compile`/`luau-analyze` sạch | chạy |
| C3 | Remote có Validate (kiểu/khoảng/cooldown/khoảng cách) | `Validate.*` |
| C4 | Name contract + `wiring_check.py` | chạy |
| C5 | Xử lý nil: respawn, rời game, destroy giữa chừng | đọc code |
| C6 | Test toán thuần có (Lune/luau) | `templates/tests` |

## 3. Ngân sách mặc định

| Thứ | Mặc định | Nguồn đo |
|---|---|---|
| Part VFX cùng lúc | ≤ 400 | `MAX_ACTIVE_PARTS` trong VFXKit |
| Hạt/burst | ≤ 80 × `Quality` | `VFX.Burst` |
| PointLight VFX | Brightness ≤ 3, Range ≤ 22, `Shadows=false` | assets.md (đo thật) |
| Mesh prop | 200–5 000 tam giác | assets.md |
| NPC/creature | 4 000–12 000 tam giác hoặc 20–80 part | assets.md |
| Dung lượng EditableMesh | mỗi cái nhỏ; Play budget rất nhỏ → chỉ build ở Edit mode | assets.md |

## 4. Báo cáo cuối (bắt buộc đủ 4 dòng)

`Đã chạy:` (lệnh + kết quả) · `Đạt:` (mã rubric) · `Trượt/chưa kiểm:` (mã + lý do) · `Bạn cần làm:` (id thật, bấm Play, nhìn đâu).
