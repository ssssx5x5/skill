# UIKit — UI/HUD dùng lại (client)

`templates/UIKit.lua`: chỉ Frame/UIStroke/UIGradient/UICorner/TextLabel, **không cần asset**. Scale thay Offset, `UI.IsTouch()` để chỉnh cho mobile, mọi lớp trang trí `Active=false`.

| Cần | Hàm |
|---|---|
| ScreenGui gốc (ResetOnSpawn=false, IgnoreGuiInset) | `UI.Root(name)` |
| Nhãn / panel / nút (hover, nhấn, cooldown) | `UI.Label`, `UI.Panel`, `UI.Button` |
| Thanh máu có vệt "trễ" | `UI.Bar(root, opts)` → `bar:Set(0..1)` |
| Hồi chiêu dạng vòng | `UI.CooldownRing` |
| Thông báo nổi | `UI.Toast` |
| Số sát thương bay lên | `UI.DamageNumber` |
| Tâm ngắm co giãn theo độ giật | `UI.Crosshair` |
| Ống ngắm sniper (viền tối, vạch chia) | `UI.Scope` |
| Vignette, đường tốc độ | `UI.Vignette`, `UI.SpeedLines` |
Theme chỉnh ở `UI.Theme` (màu, bo góc, font) — đổi một chỗ, toàn UI đổi.

## Quy tắc
- Kích thước theo `UDim2.fromScale` + `UIAspectRatioConstraint`; thử 3 tỷ lệ (16:9, 20:9 mobile, 4:3).
- Vùng an toàn mobile: không đặt nút sát mép; dùng Root có `IgnoreGuiInset=false` cho nút điều khiển.
- Animation UI bằng tween ngắn (0.12–0.25s), không `Completed:Wait()`.
- Văn bản người chơi nhập phải qua `TextService:FilterStringAsync` (server).
- Chưa kiểm trong Studio: bố cục thật trên thiết bị; báo rõ trong báo cáo.
