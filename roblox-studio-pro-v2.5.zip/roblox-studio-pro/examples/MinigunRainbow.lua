-- Minigun Rainbow Cloud — dựng từ bảng thiết kế bằng PatternKit (ví dụ cho quy trình Reference Match).
-- Đơn vị u = 0.25 studs. Trục súng = trục Z, nòng chĩa về −Z (trước). Số đo lấy từ ảnh mẫu bằng scripts/imgread.py (xem references/image-understanding.md).
local PatternKit = require(game.ReplicatedStorage.PatternKit)
local U = 0.25
local function u(n) return n * U end

local model = Instance.new("Model"); model.Name = "MinigunRainbow"; model.Parent = workspace
local P = {}                                   -- mọi part (để weld)
local function add(t) if t.parts then for _, p in ipairs(t.parts) do table.insert(P, p) end elseif t[1] then for _, p in ipairs(t) do table.insert(P, p) end else table.insert(P, t) end return t end

local C = {
	purple = Color3.fromRGB(150, 100, 200), purpleDark = Color3.fromRGB(95, 75, 137), pink = Color3.fromRGB(235, 140, 200), pinkLight = Color3.fromRGB(240, 200, 225),
	blue = Color3.fromRGB(80, 130, 215), white = Color3.fromRGB(240, 238, 240), black = Color3.fromRGB(30, 28, 40),
	rainbow = { Color3.fromRGB(235, 90, 90), Color3.fromRGB(245, 150, 70), Color3.fromRGB(245, 215, 80), Color3.fromRGB(120, 200, 100), Color3.fromRGB(80, 140, 230), Color3.fromRGB(150, 100, 200) },
}
local function at(z, y, x) return CFrame.new(x or 0, y or 0, z) end   -- z đo từ họng súng về phía đuôi (+Z)

-- thân chính (gốc weld)
local body = add(PatternKit.Part(model, "Body", Vector3.new(u(10.9), u(11.5), u(10.3)), at(u(28.5)), C.blue))
model.PrimaryPart = body
add(PatternKit.Part(model, "PlateFront", Vector3.new(u(12.6), u(13.4), u(2.4)), at(u(22.2)), C.pinkLight))
add(PatternKit.Part(model, "PlateBack", Vector3.new(u(12.6), u(13.4), u(2.4)), at(u(34.9)), C.pink))

-- cụm nòng: vòng tím trước + 6 nòng cầu vồng + vòng tím giữa + thanh nối hồng
local ringAxis = CFrame.Angles(0, math.rad(90), 0)       -- Cylinder: trục X → xoay để trục chạy theo Z
add(PatternKit.Part(model, "RingFront", Vector3.new(u(2.6), u(12.2), u(12.2)), at(u(1.3)) * ringAxis, C.purple, nil, Enum.PartType.Cylinder))
add(PatternKit.Part(model, "RingMid", Vector3.new(u(3), u(12.2), u(12.2)), at(u(14.1)) * ringAxis, C.purple, nil, Enum.PartType.Cylinder))
for _, s in ipairs(PatternKit.RadialSlots(6, u(3.9), at(0), 30)) do
	add(PatternKit.Part(model, "Barrel" .. s.i, Vector3.new(u(11), u(2.5), u(2.5)), CFrame.new(s.offset.X, s.offset.Y, u(7.8)) * ringAxis, C.rainbow[s.i], nil, Enum.PartType.Cylinder))
end
for _, s in ipairs(PatternKit.RadialSlots(4, u(4.7), at(0), 45)) do
	add(PatternKit.Part(model, "Rod" .. s.i, Vector3.new(u(1.2), u(1.2), u(6)), CFrame.new(s.offset.X, s.offset.Y, u(18.6)), C.pink))
end

-- vòm cầu vồng trên đỉnh thân + 2 đám mây nhỏ ở chân vòm
local arch = add(PatternKit.VoxelArch(model, {
	center = CFrame.new(0, u(6.7), u(29.3)) * CFrame.Angles(0, math.rad(90), 0), outer = u(7), inner = u(3.5), voxel = u(0.6), depth = u(2.4),
	bands = { C.rainbow[1], C.rainbow[2], C.rainbow[3], C.rainbow[4], C.rainbow[5] },
}))
for _, z in ipairs({ 24.4, 34.2 }) do add(PatternKit.VoxelBlob(model, { center = CFrame.new(0, u(7.6), u(z)), radius = u(2.4), voxel = u(0.75), color = C.white, scale = Vector3.new(0.8, 0.6, 1) })) end

-- mây đuôi + dấu cộng hồng
add(PatternKit.VoxelBlob(model, { center = CFrame.new(0, 0, u(40.2)), radius = u(6.2), voxel = u(0.9), color = C.white, scale = Vector3.new(1, 1, 0.75) }))
add(PatternKit.Plus(model, CFrame.new(0, 0, u(45.2)) * CFrame.Angles(0, math.rad(90), 0), u(3.6), u(1.3), u(2.2), C.pink))

-- mặt mây trên thân (bên trái, −X): hộp trắng + mắt + má
local fx = -u(4.9)
add(PatternKit.Part(model, "FaceCloud", Vector3.new(u(0.8), u(3.4), u(5.2)), CFrame.new(fx, -u(0.8), u(28.5)), C.white))
for _, dz in ipairs({ -1.0, 1.0 }) do
	add(PatternKit.Part(model, "Eye", Vector3.new(u(0.3), u(0.6), u(0.6)), CFrame.new(fx - u(0.5), -u(0.4), u(28.5 + dz)), C.black))
	add(PatternKit.Part(model, "Cheek", Vector3.new(u(0.3), u(0.7), u(0.9)), CFrame.new(fx - u(0.5), -u(1.4), u(28.5 + dz * 1.7)), C.pink))
end

-- mặt mây ở họng súng (hình chính + góc FRONT của ảnh mẫu): đĩa mây trắng phía trước vòng nòng
add(PatternKit.VoxelBlob(model, { center = CFrame.new(0, u(0.8), -u(1.2)), radius = u(5.2), voxel = u(0.9), color = C.white, scale = Vector3.new(1, 0.9, 0.3) }))

PatternKit.WeldAll(P, body)
print("[MinigunRainbow] part:", #P, "vòm voxel:", arch.count)
