--!nonstrict
-- VÍ DỤ dùng AssemblyGuard.Build: súng bắn tỉa dựng bằng ổ nối (KHÔNG phải chủ đề để copy — đổi spec cho vật khác).
-- Chạy trong Command Bar (Edit mode) sau khi có ModuleScript AssemblyGuard & ModelKit trong ServerStorage.
-- Quy ước: súng dài theo trục Z, nòng hướng -Z. Cylinder của Roblox có trục tròn là X → mỗi mối nối dùng rot = Angles(0, pi/2, 0) để nằm theo Z.
local AG = require(game.ServerStorage.AssemblyGuard)

local STEEL = Color3.fromRGB(52, 54, 60)
local DARK = Color3.fromRGB(28, 29, 33)
local WOOD = Color3.fromRGB(94, 64, 42)
local ALONG_Z = CFrame.Angles(0, math.pi / 2, 0)
local C = Enum.PartType.Cylinder

local spec = {
	Name = "SniperRifle",
	Root = "receiver",
	Parts = {
		receiver   = { Size = Vector3.new(0.9, 1.1, 5.0), Color = STEEL, Material = Enum.Material.Metal },
		rail       = { Size = Vector3.new(0.5, 0.18, 4.4), Color = DARK, Material = Enum.Material.Metal },
		barrel     = { Size = Vector3.new(6.5, 0.5, 0.5), Shape = C, Color = STEEL, Material = Enum.Material.Metal },
		brake      = { Size = Vector3.new(1.0, 0.75, 0.75), Shape = C, Color = DARK, Material = Enum.Material.Metal },
		handguard  = { Size = Vector3.new(0.85, 0.85, 3.2), Color = DARK, Material = Enum.Material.SmoothPlastic },
		stock      = { Size = Vector3.new(0.7, 1.5, 3.6), Color = WOOD, Material = Enum.Material.Wood },
		cheek      = { Size = Vector3.new(0.75, 0.4, 1.8), Color = WOOD, Material = Enum.Material.Wood },
		butt       = { Size = Vector3.new(0.8, 1.7, 0.35), Color = DARK, Material = Enum.Material.SmoothPlastic },
		grip       = { Size = Vector3.new(0.55, 1.4, 0.7), Color = DARK, Material = Enum.Material.SmoothPlastic },
		magazine   = { Size = Vector3.new(0.6, 1.3, 1.0), Color = DARK, Material = Enum.Material.Metal },
		scopeTube  = { Size = Vector3.new(3.6, 0.65, 0.65), Shape = C, Color = DARK, Material = Enum.Material.Metal },
		scopeFront = { Size = Vector3.new(0.8, 0.95, 0.95), Shape = C, Color = DARK, Material = Enum.Material.Metal },
		scopeRear  = { Size = Vector3.new(0.6, 0.85, 0.85), Shape = C, Color = DARK, Material = Enum.Material.Metal },
		lens       = { Size = Vector3.new(0.08, 0.8, 0.8), Shape = C, Color = Color3.fromRGB(80, 140, 255), Material = Enum.Material.Glass },
		mountF     = { Size = Vector3.new(0.5, 0.6, 0.5), Color = STEEL, Material = Enum.Material.Metal },
		mountR     = { Size = Vector3.new(0.5, 0.6, 0.5), Color = STEEL, Material = Enum.Material.Metal },
		bolt       = { Size = Vector3.new(0.2, 0.2, 1.0), Color = STEEL, Material = Enum.Material.Metal },
		boltKnob   = { Size = Vector3.new(0.4, 0.4, 0.4), Shape = Enum.PartType.Ball, Color = DARK, Material = Enum.Material.Metal },
	},
	-- Mỗi mối: điểm sa trên A (toạ độ cục bộ A) TRÙNG điểm sb trên B (toạ độ cục bộ B).
	Joins = {
		{ a = "receiver",  sa = Vector3.new(0, 0.55, 0),     b = "rail",       sb = Vector3.new(0, -0.09, 0) },
		{ a = "receiver",  sa = Vector3.new(0, 0.1, -2.5),   b = "handguard",  sb = Vector3.new(0, 0, 1.6) },
		{ a = "receiver",  sa = Vector3.new(0, 0.1, -2.5),   b = "barrel",     sb = Vector3.new(3.25, 0, 0), rot = ALONG_Z }, -- chốt giữa thân tại mặt trước, nòng chìa ra -Z
		{ a = "barrel",    sa = Vector3.new(-3.25, 0, 0),    b = "brake",      sb = Vector3.new(0.5, 0, 0) },
		{ a = "receiver",  sa = Vector3.new(0, -0.1, 2.5),   b = "stock",      sb = Vector3.new(0, 0, -1.8) },
		{ a = "stock",     sa = Vector3.new(0, 0.75, 0.4),   b = "cheek",      sb = Vector3.new(0, -0.2, 0) },
		{ a = "stock",     sa = Vector3.new(0, 0, 1.8),      b = "butt",       sb = Vector3.new(0, 0, -0.175) },
		{ a = "receiver",  sa = Vector3.new(0, -0.55, 1.0),  b = "grip",       sb = Vector3.new(0, 0.7, 0), rot = CFrame.Angles(math.rad(-12), 0, 0) },
		{ a = "receiver",  sa = Vector3.new(0, -0.55, -0.2), b = "magazine",   sb = Vector3.new(0, 0.65, 0) },
		{ a = "rail",      sa = Vector3.new(0, 0.09, -1.2),  b = "mountF",     sb = Vector3.new(0, -0.3, 0) },
		{ a = "rail",      sa = Vector3.new(0, 0.09, 1.0),   b = "mountR",     sb = Vector3.new(0, -0.3, 0) },
		{ a = "mountF",    sa = Vector3.new(0, 0.3, 0),      b = "scopeTube",  sb = Vector3.new(0.5, -0.325, 0.0), rot = ALONG_Z }, -- khớp tâm ống với đỉnh mount (xem Check)
		{ a = "scopeTube", sa = Vector3.new(-1.8, 0, 0),     b = "scopeFront", sb = Vector3.new(0.4, 0, 0) },
		{ a = "scopeTube", sa = Vector3.new(1.8, 0, 0),      b = "scopeRear",  sb = Vector3.new(-0.3, 0, 0) },
		{ a = "scopeFront", sa = Vector3.new(-0.4, 0, 0),    b = "lens",       sb = Vector3.new(0.04, 0, 0) },
		{ a = "receiver",  sa = Vector3.new(0.45, 0.2, 0.6), b = "bolt",       sb = Vector3.new(0, 0, 0.5), rot = CFrame.Angles(0, math.rad(90), 0) },
		{ a = "bolt",      sa = Vector3.new(0, 0, 0.5),      b = "boltKnob",   sb = Vector3.new(0, 0, 0) },
	},
}

local model = AG.Build(workspace, spec, CFrame.new(0, 8, 0))
local rep = AG.Heal(model, { Tol = 0.08, Snap = true, SnapMax = 1.5 })
AG.Print(rep)
-- Cổng bắt buộc: chỉ giao khi rep.ok == true. Nếu FAIL: đọc rep.floating (tên part + khoảng hở) và sửa ổ nối tương ứng.
